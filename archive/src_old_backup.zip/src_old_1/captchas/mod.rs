//! Captcha Solver
//!
//! Tools for analyzing and solving various types of captchas.
