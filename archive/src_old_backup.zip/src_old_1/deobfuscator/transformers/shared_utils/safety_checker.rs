use oxc::ast::ast::{
    BinaryOperator, CallExpression, ComputedMemberExpression, Expression, LogicalOperator,
    StaticMemberExpression, UnaryOperator,
};

/// Utility for checking if expressions are safe to inline during AST transformations.
///
/// This prevents AST corruption and panics by ensuring only simple, side-effect-free
/// expressions are inlined.
pub struct SafetyChecker;

impl SafetyChecker {
    /// Checks if an expression is safe to inline during AST transformations.
    ///
    /// This is a comprehensive check that recursively validates all parts of an expression
    /// to ensure it won't cause AST corruption or panics when inlined.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // Safe expressions
    /// SafetyChecker::is_safe_to_inline(&Expression::StringLiteral(_)) // ✅
    /// SafetyChecker::is_safe_to_inline(&Expression::NumericLiteral(_))   // ✅
    /// SafetyChecker::is_safe_to_inline(&Expression::Identifier(_))         // ✅
    ///
    /// // Unsafe expressions
    /// SafetyChecker::is_safe_to_inline(&Expression::CallExpression(_))    // ❌
    /// SafetyChecker::is_safe_to_inline(&Expression::NewExpression(_))     // ❌
    /// ```
    pub fn is_safe_to_inline(expr: &Expression) -> bool {
        match expr {
            // Basic literals - always safe
            Expression::StringLiteral(_)
            | Expression::NumericLiteral(_)
            | Expression::BooleanLiteral(_)
            | Expression::NullLiteral(_)
            | Expression::Identifier(_) => true,

            // Member access: allow reads like window.prop or window["..."]
            Expression::StaticMemberExpression(member) => is_safe_static_member(member),
            Expression::ComputedMemberExpression(member) => is_safe_computed_member(member),

            // Allow specific timestamp patterns and benign literal/member reads
            Expression::CallExpression(call) => {
                is_safe_timestamp_call(call)
                    || is_safe_literal_callee_call(call)
                    || is_safe_storage_get_call(call)
            }

            // Simple unary operations (e.g., !!expr) - only if operand is safe
            Expression::UnaryExpression(unary) => {
                matches!(unary.operator, UnaryOperator::LogicalNot)
                    && Self::is_safe_to_inline(&unary.argument)
            }

            // Comparisons like ===, ==, !==, !=
            Expression::BinaryExpression(binary) => {
                matches!(
                    binary.operator,
                    BinaryOperator::StrictEquality
                        | BinaryOperator::Equality
                        | BinaryOperator::StrictInequality
                        | BinaryOperator::Inequality
                ) && Self::is_safe_to_inline(&binary.left)
                    && Self::is_safe_to_inline(&binary.right)
            }

            // Logical OR/AND
            Expression::LogicalExpression(logical) => {
                matches!(logical.operator, LogicalOperator::Or | LogicalOperator::And)
                    && Self::is_safe_to_inline(&logical.left)
                    && Self::is_safe_to_inline(&logical.right)
            }

            // Simple conditional - only if all parts are safe
            Expression::ConditionalExpression(conditional) => {
                Self::is_safe_to_inline(&conditional.test)
                    && Self::is_safe_to_inline(&conditional.consequent)
                    && Self::is_safe_to_inline(&conditional.alternate)
            }

            // Parenthesized expressions - only if inner expression is safe
            Expression::ParenthesizedExpression(parenthesized) => {
                Self::is_safe_to_inline(&parenthesized.expression)
            }

            // Everything else is not safe
            _ => false,
        }
    }
}

fn is_safe_static_member(me: &StaticMemberExpression<'_>) -> bool {
    matches!(
        &me.object,
        Expression::Identifier(_) | Expression::ThisExpression(_)
    )
}

fn is_safe_computed_member(me: &ComputedMemberExpression<'_>) -> bool {
    let obj_safe = matches!(
        &me.object,
        Expression::Identifier(_) | Expression::ThisExpression(_)
    );
    let key_safe = matches!(
        &me.expression,
        Expression::StringLiteral(_) | Expression::NumericLiteral(_)
    );
    obj_safe && key_safe
}

fn is_safe_timestamp_call(call: &CallExpression<'_>) -> bool {
    // Date.now() OR (new Date()).getTime()
    if let Expression::StaticMemberExpression(member) = &call.callee {
        // Date.now()
        let is_date_now = matches!(&member.object, Expression::Identifier(id) if id.name.as_str() == "Date")
            && member.property.name.as_str() == "now"
            && call.arguments.is_empty();
        if is_date_now {
            return true;
        }

        // (new Date()).getTime()
        let is_new_date_get_time = matches!(&member.object, Expression::NewExpression(new_expr) if matches!(&new_expr.callee, Expression::Identifier(id) if id.name.as_str() == "Date") && new_expr.arguments.is_empty())
            && member.property.name.as_str() == "getTime"
            && call.arguments.is_empty();
        if is_new_date_get_time {
            return true;
        }
    }
    false
}

fn is_safe_literal_callee_call(call: &CallExpression<'_>) -> bool {
    // Allow calling a string literal directly: "..."()
    matches!(&call.callee, Expression::StringLiteral(_))
        && call.arguments.is_empty()
}

fn is_safe_storage_get_call(call: &CallExpression<'_>) -> bool {
    // Allow benign getters like X.getItem(key) with any identifier object; read-only
    if let Expression::StaticMemberExpression(member) = &call.callee {
        if member.property.name.as_str() == "getItem" {
            if matches!(&member.object, Expression::Identifier(_)){
                return true;
            }
        }
    }
    false
}
