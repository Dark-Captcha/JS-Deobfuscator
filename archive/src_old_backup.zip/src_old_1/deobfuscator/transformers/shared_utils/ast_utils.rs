//! AST processing and code generation utilities
//!
//! This module provides utility functions for working with JavaScript ASTs,
//! including semantic analysis and code generation operations.

use anyhow::Result;
use oxc::{
    ast::ast::{CallExpression, Expression, Function, Program},
    codegen::{Codegen, CodegenOptions},
    semantic::{Scoping, SemanticBuilder, SymbolId},
};

/// Utility functions for AST processing and code generation
pub struct AstUtils;

impl AstUtils {
    /// Builds semantic scoping information from an AST program
    ///
    /// This function performs semantic analysis on the AST to build a scoping
    /// information structure that tracks variable declarations, references, and
    /// their relationships. This is essential for transformers that need to
    /// understand the symbol table.
    ///
    /// # Parameters
    /// - `program`: The AST program to analyze
    ///
    /// # Returns
    /// - `Scoping`: Complete scoping information including symbol tables
    ///
    /// # When to Use
    /// This should be called after AST modifications that change the symbol table,
    /// such as:
    /// - Adding or removing variable declarations
    /// - Changing identifier names
    /// - Modifying function signatures
    /// - Any structural changes that affect variable scope
    pub fn build_scoping(program: &Program) -> Scoping {
        SemanticBuilder::new()
            .build(program)
            .semantic
            .into_scoping()
    }

    /// Generate JavaScript code from an AST program
    pub fn generate_code(program: &Program, options: CodegenOptions) -> Result<String> {
        let output = Codegen::new().with_options(options).build(program).code;

        Ok(output)
    }

    /// Extracts SymbolId from a function if it has an ID
    ///
    /// This is a common pattern used across many transformers to get the
    /// unique symbol identifier for a function.
    ///
    /// # Parameters
    /// - `func`: The function to extract SymbolId from
    ///
    /// # Returns
    /// - `Option<SymbolId>`: The symbol ID if the function has an ID
    ///
    /// # Example
    /// ```rust
    /// if let Some(symbol_id) = AstUtils::get_function_symbol_id(func) {
    ///     // Use the symbol_id
    /// }
    /// ```
    pub fn get_function_symbol_id(func: &Function) -> Option<SymbolId> {
        func.id.as_ref().and_then(|id| id.symbol_id.get())
    }

    /// Extracts string value from a string literal expression
    ///
    /// This is a common pattern used across many transformers to get
    /// the string value from a StringLiteral expression.
    ///
    /// # Parameters
    /// - `expr`: The expression to extract string from
    ///
    /// # Returns
    /// - `Option<&str>`: The string value if the expression is a StringLiteral
    ///
    /// # Example
    /// ```rust
    /// if let Some(str_value) = AstUtils::extract_string_literal(expr) {
    ///     // Use the string value
    /// }
    /// ```
    pub fn extract_string_literal<'a>(expr: &'a Expression<'a>) -> Option<&'a str> {
        match expr {
            Expression::StringLiteral(lit) => Some(lit.value.as_str()),
            _ => None,
        }
    }

    /// Extracts the first argument from a call expression as an expression
    ///
    /// This is a common pattern for getting the first argument from function calls.
    ///
    /// # Parameters
    /// - `call`: The call expression
    ///
    /// # Returns
    /// - `Option<&Expression>`: The first argument expression if it exists
    pub fn get_first_argument<'a>(call: &'a CallExpression<'a>) -> Option<&'a Expression<'a>> {
        call.arguments.first()?.as_expression()
    }

    /// Extracts SymbolId from a call expression's callee
    ///
    /// This is a common pattern used across many transformers to get the
    /// SymbolId from a call expression's callee identifier.
    ///
    /// # Parameters
    /// - `call`: The call expression
    /// - `scoping`: The scoping context
    ///
    /// # Returns
    /// - `Option<SymbolId>`: The symbol ID if the callee is an identifier
    ///
    /// # Example
    /// ```rust
    /// if let Some(symbol_id) = AstUtils::get_callee_symbol_id(call, scoping) {
    ///     // Use the symbol_id
    /// }
    /// ```
    pub fn get_callee_symbol_id<'a>(
        call: &'a CallExpression<'a>,
        scoping: &Scoping,
    ) -> Option<SymbolId> {
        match &call.callee {
            Expression::Identifier(ident) => {
                let reference_id = ident.reference_id();
                scoping.get_reference(reference_id).symbol_id()
            }
            _ => None,
        }
    }
}
