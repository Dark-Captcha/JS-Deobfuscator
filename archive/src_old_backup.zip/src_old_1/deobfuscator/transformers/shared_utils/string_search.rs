//! String search utilities for AST traversal
//!
//! This module provides utilities for searching strings within JavaScript AST nodes.
//! It's used by various decoders to detect patterns like base64 alphabets or XOR keys.

use oxc::ast::ast::{Expression, ForStatement, ForStatementInit, Statement};

/// Utility for searching strings in AST nodes
pub struct StringSearcher;

impl StringSearcher {
    /// Searches for a target string in a list of statements
    pub fn search_in_statements(stmts: &[Statement], target: &str) -> bool {
        stmts
            .iter()
            .any(|stmt| Self::search_in_statement(stmt, target))
    }

    /// Searches for a target string in a single statement
    pub fn search_in_statement(stmt: &Statement, target: &str) -> bool {
        match stmt {
            Statement::VariableDeclaration(var_decl) => var_decl.declarations.iter().any(|decl| {
                decl.init
                    .as_ref()
                    .map_or(false, |init| Self::search_in_expression(init, target))
            }),
            Statement::ExpressionStatement(expr_stmt) => {
                Self::search_in_expression(&expr_stmt.expression, target)
            }
            Statement::IfStatement(if_stmt) => {
                Self::search_in_expression(&if_stmt.test, target)
                    || Self::search_in_statement(&if_stmt.consequent, target)
                    || if_stmt
                        .alternate
                        .as_ref()
                        .map_or(false, |alt| Self::search_in_statement(alt, target))
            }
            Statement::ForStatement(for_stmt) => Self::search_for_statement_body(for_stmt, target),
            Statement::TryStatement(try_stmt) => {
                Self::search_in_statements(&try_stmt.block.body, target)
                    || try_stmt.handler.as_ref().map_or(false, |handler| {
                        Self::search_in_statements(&handler.body.body, target)
                    })
                    || try_stmt.finalizer.as_ref().map_or(false, |finalizer| {
                        Self::search_in_statements(&finalizer.body, target)
                    })
            }
            Statement::BlockStatement(block) => Self::search_in_statements(&block.body, target),
            Statement::ReturnStatement(ret) => ret
                .argument
                .as_ref()
                .map_or(false, |arg| Self::search_in_expression(arg, target)),
            _ => false,
        }
    }

    /// Searches for a target string in an expression
    pub fn search_in_expression(expr: &Expression, target: &str) -> bool {
        match expr {
            Expression::StringLiteral(lit) => lit.value.as_str() == target,
            Expression::BinaryExpression(bin) => {
                Self::search_in_expression(&bin.left, target)
                    || Self::search_in_expression(&bin.right, target)
            }
            Expression::CallExpression(call) => {
                Self::search_in_expression(&call.callee, target)
                    || call.arguments.iter().any(|arg| {
                        arg.as_expression()
                            .map_or(false, |expr| Self::search_in_expression(expr, target))
                    })
            }
            Expression::StaticMemberExpression(member) => {
                Self::search_in_expression(&member.object, target)
            }
            Expression::ComputedMemberExpression(member) => {
                Self::search_in_expression(&member.object, target)
                    || Self::search_in_expression(&member.expression, target)
            }
            Expression::ConditionalExpression(cond) => {
                Self::search_in_expression(&cond.test, target)
                    || Self::search_in_expression(&cond.consequent, target)
                    || Self::search_in_expression(&cond.alternate, target)
            }
            Expression::AssignmentExpression(assign) => {
                Self::search_in_expression(&assign.right, target)
            }
            Expression::UnaryExpression(un) => Self::search_in_expression(&un.argument, target),
            Expression::ParenthesizedExpression(paren) => {
                Self::search_in_expression(&paren.expression, target)
            }
            Expression::SequenceExpression(seq) => seq
                .expressions
                .iter()
                .any(|expr| Self::search_in_expression(expr, target)),
            Expression::LogicalExpression(logical) => {
                Self::search_in_expression(&logical.left, target)
                    || Self::search_in_expression(&logical.right, target)
            }
            Expression::FunctionExpression(func) => func.body.as_ref().map_or(false, |body| {
                Self::search_in_statements(&body.statements, target)
            }),
            _ => false,
        }
    }

    /// Simplified search for for-statement body
    fn search_for_statement_body(for_stmt: &ForStatement, target: &str) -> bool {
        // Check initialization
        if let Some(init) = &for_stmt.init {
            if let ForStatementInit::VariableDeclaration(var_decl) = init {
                if var_decl.declarations.iter().any(|decl| {
                    decl.init
                        .as_ref()
                        .map_or(false, |init| Self::search_in_expression(init, target))
                }) {
                    return true;
                }
            }
        }

        // Check test condition
        if let Some(test) = &for_stmt.test {
            if Self::search_in_expression(test, target) {
                return true;
            }
        }

        // Check update expression
        if let Some(update) = &for_stmt.update {
            if Self::search_in_expression(update, target) {
                return true;
            }
        }

        // Check body
        if let Statement::BlockStatement(block) = &for_stmt.body {
            Self::search_in_statements(&block.body, target)
        } else {
            Self::search_in_statement(&for_stmt.body, target)
        }
    }
}
