//! Symbol manipulation utilities
//!
//! This module provides utility functions for working with JavaScript symbols,
//! including symbol ID resolution and reference counting.

use oxc::{
    ast::ast::{Expression, VariableDeclarator},
    semantic::{Reference, Scoping, SymbolId},
};

/// Get the symbol ID of a variable declarator's left-hand side
pub fn get_lhs_symbol_id(variable_declarator: &VariableDeclarator) -> Option<SymbolId> {
    variable_declarator
        .id
        .get_binding_identifier()
        .and_then(|identifier| identifier.symbol_id.get())
}

/// Get the symbol ID of an expression's right-hand side
pub fn get_rhs_symbol_id(expression: &Expression, scoping: &Scoping) -> Option<SymbolId> {
    expression
        .get_identifier_reference()
        .and_then(|identifier_reference| identifier_reference.reference_id.get())
        .and_then(|reference_id| scoping.get_reference(reference_id).symbol_id())
}

/// Count symbol references that match a predicate
pub fn count_symbol_references(
    scoping: &Scoping,
    symbol_id: SymbolId,
    predicate: impl Fn(&Reference) -> bool,
) -> usize {
    scoping
        .get_resolved_references(symbol_id)
        .filter(|reference| predicate(reference))
        .count()
}
