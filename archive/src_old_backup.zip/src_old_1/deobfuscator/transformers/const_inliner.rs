use oxc::{
    allocator::Allocator,
    allocator::CloneIn,
    ast::ast::{Expression, Program, Statement},
    semantic::{Scoping, SymbolId},
};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::deobfuscator::transformers::Transformer;

/// Inline simple constant variables into their use sites to expose literals
/// e.g. var _ai = (expr, 3600);  → inline identifier uses with 3600
pub struct ConstInliner;

impl<'a> Transformer<'a> for ConstInliner {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> anyhow::Result<Scoping> {
        let mut collector = ConstCollector {
            values: FxHashMap::default(),
        };
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        let mut inliner = ConstInlinerPass {
            values: collector.values,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        Ok(scoping)
    }
}

struct ConstCollector<'a> {
    values: FxHashMap<SymbolId, Expression<'a>>,
}

impl<'a> Traverse<'a, ()> for ConstCollector<'a> {
    fn enter_variable_declarator(
        &mut self,
        node: &mut oxc::ast::ast::VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let Some(init) = &node.init else {
            return;
        };

        // Try to extract a literal expression (supports sequence expr picking last literal)
        if let Some(lit_expr) = extract_final_literal(init) {
            if let Some(id) = node.id.get_binding_identifier() {
                if let Some(symbol_id) = id.symbol_id.get() {
                    self.values
                        .insert(symbol_id, lit_expr.clone_in(ctx.ast.allocator));
                }
            }
        }
    }
}

struct ConstInlinerPass<'a> {
    values: FxHashMap<SymbolId, Expression<'a>>,
}

impl<'a> Traverse<'a, ()> for ConstInlinerPass<'a> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        if let Expression::Identifier(ident) = expr {
            let reference_id = ident.reference_id();
            if let Some(symbol_id) = ctx.scoping().get_reference(reference_id).symbol_id() {
                if let Some(value) = self.values.get(&symbol_id) {
                    *expr = value.clone_in(ctx.ast.allocator);
                }
            }
        }
    }

    fn exit_statement(&mut self, _stmt: &mut Statement<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        // Do not remove declarations here to avoid changing control flow; only inline uses
    }
}

fn extract_final_literal<'a>(expr: &'a Expression<'a>) -> Option<&'a Expression<'a>> {
    match expr {
        // Direct literals
        Expression::NumericLiteral(_)
        | Expression::StringLiteral(_)
        | Expression::BooleanLiteral(_) => Some(expr),
        // Sequence expression: use last expression if it is a literal
        Expression::SequenceExpression(seq) => seq
            .expressions
            .last()
            .and_then(|last| extract_final_literal(last)),
        // Parenthesized: unwrap
        Expression::ParenthesizedExpression(p) => extract_final_literal(&p.expression),
        _ => None,
    }
}
