use crate::deobfuscator::transformers::{
    Transformer,
    shared_utils::ast_utils::AstUtils,
    variable_processor::{
        dead_code_remover::Remover, object_flattener::Initializer, variable_collector::Collector,
        variable_inliner::Applier,
    },
};
use anyhow::Result;
use oxc::{allocator::Allocator, ast::ast::Program, semantic::Scoping};
use oxc_traverse::traverse_mut;

/// Orchestrates variable normalization in 4 passes:
///
/// 1. **Initializer**: Flatten object literals
///    `var a = {S: 516}` → `var a_S = 516`
///
/// 2. **Collector**: Gather variables that can be inlined
///    Includes handling sequence expressions: `(r = -221, v = -206, Kv(r, v))`
///
/// 3. **Applier**: Replace identifier references with their values
///    `console.log(a_S)` → `console.log(516)`
///
/// 4. **Remover**: Delete unused variable declarations
///    `var a_S = 516;` removed if 0 reads after inlining
///
/// **Scoping Strategy:**
/// - Rebuild after Initializer (creates new symbols)
/// - Share scoping between Collector & Applier (keeps SymbolIds consistent)
/// - Rebuild before Remover (need fresh read counts after inlining)
pub struct VariableTransformer {
    pub logical_expressions: bool,
}

impl<'a> Transformer<'a> for VariableTransformer {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping> {
        // Pass 1: Flatten constant objects
        let mut initializer = Initializer::default();
        traverse_mut(&mut initializer, allocator, program, scoping, ());
        let scoping = AstUtils::build_scoping(&program);

        // Pass 2: Collect inlineable variables
        let mut collector = Collector::default();
        collector.logical_expressions = self.logical_expressions;
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        // Pass 3: Apply/inline collected variables (share scoping with collector so SymbolIds match)
        let mut applier = Applier {
            collected: collector.collected,
            collected_by_name: Some(collector.collected_by_name),
        };
        let _scoping_after_apply = traverse_mut(&mut applier, allocator, program, scoping, ());

        // Pass 4: Remove unused declarations
        let scoping = AstUtils::build_scoping(&program);
        let mut remover = Remover::default();
        let scoping = traverse_mut(&mut remover, allocator, program, scoping, ());

        Ok(scoping)
    }
}
