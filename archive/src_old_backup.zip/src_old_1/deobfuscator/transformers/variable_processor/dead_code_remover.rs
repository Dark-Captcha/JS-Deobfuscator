use oxc::{
    allocator::{TakeIn, Vec as ArenaVec},
    ast::ast::{Expression, ForStatement, ForStatementInit, Statement, VariableDeclarator},
    semantic::Scoping,
};
use oxc_traverse::{Traverse, TraverseCtx};

use crate::deobfuscator::transformers::shared_utils::symbol_utils::{
    count_symbol_references, get_lhs_symbol_id,
};

/// Removes variable declarations that have been fully inlined (0 reads).
///
/// Handles:
/// - Regular variable declarations: `var a = 5;` → removed if `a` has 0 reads
/// - For-loop declarations: `for (var i = 0, j = 1; ...)` → removes unused vars
/// - Uninitialized variables: `var r, v;` → removed if never read
#[derive(Default)]
pub struct Remover;

// ============================================================================
// Traverse Implementation
// ============================================================================

impl<'a> Traverse<'a, ()> for Remover {
    fn enter_for_statement(&mut self, node: &mut ForStatement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let scoping = ctx.scoping();

        // Handle variable declarations in for-loop initializer
        if let Some(init) = &mut node.init {
            if let ForStatementInit::VariableDeclaration(var_decl) = init {
                var_decl
                    .declarations
                    .retain(|declarator| should_keep_declarator(declarator, scoping));

                // If all declarations were removed, clear the init
                if var_decl.declarations.is_empty() {
                    node.init = None;
                }
            }
        }
    }

    fn enter_statements(
        &mut self,
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let scoping = ctx.scoping();
        let allocator = ctx.ast.allocator;
        let mut new_statements = ctx.ast.vec();

        for mut statement in statements.take_in(allocator) {
            if let Statement::VariableDeclaration(var_decl) = &mut statement {
                var_decl
                    .declarations
                    .retain(|declarator| should_keep_declarator(declarator, scoping));

                // Only keep statement if it has remaining declarators
                if !var_decl.declarations.is_empty() {
                    new_statements.push(statement);
                }
            } else {
                new_statements.push(statement);
            }
        }

        *statements = new_statements;
    }
}

// ============================================================================
// Helper Functions
// ============================================================================

/// Determines if a variable declarator should be kept or removed.
///
/// Keeps:
/// - Variables with complex initializers (function calls, etc.)
/// - Variables that are still being read (not fully inlined)
///
/// Removes:
/// - Variables with simple literal init and 0 reads (fully inlined)
/// - Uninitialized variables with 0 reads (unused)
fn should_keep_declarator(declarator: &VariableDeclarator, scoping: &Scoping) -> bool {
    let Some(symbol_id) = get_lhs_symbol_id(declarator) else {
        return true; // Keep if we can't get symbol ID
    };

    // Check if variable has simple init or no init
    let has_simple_init = if let Some(init) = &declarator.init {
        is_simple_expression(init)
    } else {
        true // No initializer (e.g., var r, v;)
    };

    if has_simple_init {
        let read_count = count_symbol_references(scoping, symbol_id, |r| r.is_read());
        return read_count != 0; // Remove if 0 reads
    }

    true // Keep complex initializers
}

/// Checks if an expression is "simple" enough to be inlined.
/// Simple = literals, identifiers, member expressions
fn is_simple_expression(expr: &Expression) -> bool {
    match expr {
        // Primitive leaves
        Expression::NumericLiteral(_)
        | Expression::StringLiteral(_)
        | Expression::BooleanLiteral(_) => true,

        // Identifiers
        Expression::Identifier(_) => true,

        // Unary over simple (e.g., +x, -1)
        Expression::UnaryExpression(u) => is_simple_expression(&u.argument),

        // Member access chains
        Expression::StaticMemberExpression(m) => is_simple_expression(&m.object),
        Expression::ComputedMemberExpression(m) => {
            is_simple_expression(&m.object) && is_simple_expression(&m.expression)
        }

        // Simple compositions (pure)
        Expression::BinaryExpression(b) => {
            is_simple_expression(&b.left) && is_simple_expression(&b.right)
        }
        Expression::LogicalExpression(l) => {
            is_simple_expression(&l.left) && is_simple_expression(&l.right)
        }
        Expression::ParenthesizedExpression(p) => is_simple_expression(&p.expression),

        _ => false,
    }
}
