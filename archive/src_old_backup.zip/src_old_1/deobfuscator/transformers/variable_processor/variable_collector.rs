use oxc::{
    allocator::{Allocator, Box as ArenaBox, CloneIn, TakeIn, Vec as ArenaVec},
    ast::ast::{
        Argument, AssignmentExpression, AssignmentTarget, BinaryExpression, CallExpression,
        ComputedMemberExpression, Expression, IdentifierReference, LogicalExpression,
        ParenthesizedExpression, StaticMemberExpression, VariableDeclarator,
    },
    semantic::{Scoping, SymbolId},
};
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::{FxHashMap, FxHashSet};

use crate::deobfuscator::transformers::shared_utils::safety_checker::SafetyChecker;
use crate::deobfuscator::transformers::shared_utils::symbol_utils::{
    count_symbol_references, get_lhs_symbol_id, get_rhs_symbol_id,
};

/// Collects variables that can be inlined.
///
/// ```mermaid
/// graph TD
///     A[enter_variable_declarator] --> B{Has init?}
///     B -->|No| C[Track as uninitialized]
///     B -->|Yes| D{0 writes?}
///     D -->|No| E[Skip]
///     D -->|Yes| F[resolve_expression]
///     F --> G{Is collectable?}
///     G -->|Yes| H[Add to collected map]
///     G -->|No| E
///     
///     I[enter_expression] --> J{Is SequenceExpression?}
///     J -->|No| K[Skip]
///     J -->|Yes| L[Process each sub-expression]
///     L --> M{Is assignment to uninitialized var?}
///     M -->|Yes| N[Collect & remove from sequence]
///     M -->|No| O[Keep in sequence]
///     N --> P{Only 1 expression left?}
///     O --> P
///     P -->|Yes| Q[Unwrap sequence]
///     P -->|No| R[Keep as sequence]
/// ```
#[derive(Default)]
pub struct Collector<'a> {
    /// Maps symbol ID to its resolved expression value
    pub collected: FxHashMap<SymbolId, Expression<'a>>,
    /// Fallback mapping for identifiers with no symbol (implicit globals)
    pub collected_by_name: FxHashMap<String, Expression<'a>>,
    /// Tracks uninitialized variables (var r, v;) for sequence expression handling
    uninitialized_variables: FxHashSet<SymbolId>,
    /// Whether to collect logical expressions
    pub logical_expressions: bool,
    /// Alias edges recorded independent of order: lhs_symbol -> rhs_symbol
    alias_edges: Vec<(SymbolId, SymbolId)>,
    /// Alias edges for identifiers without symbols: lhs_name -> rhs_name
    alias_edges_by_name: Vec<(String, String)>,
}

// ============================================================================
// Traverse Implementation
// ============================================================================

impl<'a> Traverse<'a, ()> for Collector<'a> {
    fn enter_expression(&mut self, node: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let scoping = ctx.scoping();
        let allocator = ctx.ast.allocator;

        // Handle plain assignment expressions: a = Date.now(); b = a;
        if let Expression::AssignmentExpression(assign) = node {
            if let AssignmentTarget::AssignmentTargetIdentifier(ident) = &assign.left {
                // Try to get a symbol for the LHS; may be None for implicit globals
                let symbol_id_opt = ident
                    .reference_id
                    .get()
                    .and_then(|ref_id| scoping.get_reference(ref_id).symbol_id());

                let rhs_is_simple = matches!(
                    &assign.right,
                    Expression::Identifier(_)
                        | Expression::ObjectExpression(_)
                        | Expression::StringLiteral(_)
                        | Expression::NumericLiteral(_)
                        | Expression::BooleanLiteral(_)
                        | Expression::UnaryExpression(_)
                );
                // Allow safe calls like Date.now() or new Date().getTime()
                let rhs_is_safe_call = matches!(&assign.right, Expression::CallExpression(_))
                    && SafetyChecker::is_safe_to_inline(&assign.right);

                if rhs_is_simple || rhs_is_safe_call {
                    let resolved = self.resolve_expression(&assign.right, scoping, allocator);
                    if Self::is_collectable(&resolved, self.logical_expressions) {
                        if let Some(symbol_id) = symbol_id_opt {
                            // debug: plain assignment collection
                            // eprintln!("collect assign sym={:?} rhs={:?}", symbol_id, resolved);
                            self.collected.insert(symbol_id, resolved);
                        } else {
                            // collect by name for implicit globals
                            let name = ident.name.as_str().to_string();
                            // eprintln!("collect assign name={} rhs={:?}", name, resolved);
                            self.collected_by_name.insert(name, resolved);
                        }
                    }
                }

                // Record alias edge if RHS is an identifier
                if let Expression::Identifier(rhs_id) = &assign.right {
                    if let Some(lhs_sym) = symbol_id_opt {
                        if let Some(rhs_sym) = get_rhs_symbol_id(&assign.right, scoping) {
                            self.alias_edges.push((lhs_sym, rhs_sym));
                        }
                    } else {
                        // name-based alias for implicit globals
                        let lhs_name = ident.name.as_str().to_string();
                        let rhs_name = rhs_id.name.as_str().to_string();
                        self.alias_edges_by_name.push((lhs_name, rhs_name));
                    }
                }
            }
            return;
        }

        // Process sequence expressions: (r = -221, v = -206, Kv(r, v))
        if let Expression::SequenceExpression(sequence_expr) = node {
            sequence_expr.expressions.retain(|sub_expr| {
                !self.try_collect_sequence_assignment(sub_expr, scoping, allocator)
            });

            // Unwrap sequence if only one expression remains
            if sequence_expr.expressions.len() == 1 {
                let mut single_expr = sequence_expr.expressions.take_in(allocator);
                if let Some(remaining) = single_expr.pop() {
                    *node = remaining;
                }
            }
        }
    }

    // removed enter_assignment_expression; handled inside enter_expression

    fn enter_parenthesized_expression(
        &mut self,
        node: &mut ParenthesizedExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Handle assignments like (m = u) or (w = {})
        let Expression::AssignmentExpression(assignment) = &node.expression else {
            return;
        };

        let AssignmentTarget::AssignmentTargetIdentifier(ident) = &assignment.left else {
            return;
        };

        let scoping = ctx.scoping();
        let allocator = ctx.ast.allocator;

        // Get symbol ID for the assignment target
        let Some(symbol_id) = ident
            .reference_id
            .get()
            .and_then(|ref_id| scoping.get_reference(ref_id).symbol_id())
        else {
            return;
        };

        // Only process assignments to uninitialized variables
        if !self.uninitialized_variables.contains(&symbol_id) {
            return;
        }

        // Collect assignments with simple values or allowed calls (timestamps)
        let right_is_collectable =
            matches!(
                &assignment.right,
                Expression::Identifier(_) | Expression::ObjectExpression(_)
            ) || (matches!(&assignment.right, Expression::CallExpression(_))
                && SafetyChecker::is_safe_to_inline(&assignment.right));

        if right_is_collectable {
            // Store the resolved expression so identifier chains like x = y = Date.now() collapse
            let resolved_value = self.resolve_expression(&assignment.right, scoping, allocator);
            // eprintln!("collect paren-assign sym={:?} rhs={:?}", symbol_id, resolved_value);
            self.collected.insert(symbol_id, resolved_value);

            // Replace (m = u) with just m (will be inlined later by Applier)
            node.expression = Expression::Identifier(
                ctx.ast
                    .alloc_identifier_reference(ident.span, ident.name.as_str()),
            );
        }
    }

    fn enter_variable_declarator(
        &mut self,
        node: &mut VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let Some(lhs_symbol_id) = get_lhs_symbol_id(node) else {
            return;
        };

        // Track uninitialized variables (var r, v;)
        if node.init.is_none() {
            self.uninitialized_variables.insert(lhs_symbol_id);
            return;
        }

        let Some(init_expr) = &node.init else {
            return;
        };

        let scoping = ctx.scoping();
        let allocator = ctx.ast.allocator;

        // Only collect variables with 0 writes (constants)
        let write_count = count_symbol_references(scoping, lhs_symbol_id, |r| r.is_write());
        if write_count != 0 {
            return;
        }

        // Resolve and collect if useful
        let resolved_expr = self.resolve_expression(init_expr, scoping, allocator);
        if Self::is_collectable(&resolved_expr, self.logical_expressions) {
            // eprintln!("collect decl sym={:?} init={:?}", lhs_symbol_id, resolved_expr);
            self.collected.insert(lhs_symbol_id, resolved_expr);
        }

        // Record alias edge for identifier initializer: var a = b;
        if let Expression::Identifier(_) = init_expr {
            if let Some(rhs_sym) = get_rhs_symbol_id(init_expr, scoping) {
                self.alias_edges.push((lhs_symbol_id, rhs_sym));
            }
        }
    }
}

// ============================================================================
// Private Implementation - Sequence Expression Handling
// ============================================================================

impl<'a> Collector<'a> {
    /// Try to collect an assignment from a sequence expression.
    /// Returns true if the assignment should be removed from the sequence.
    fn try_collect_sequence_assignment(
        &mut self,
        expr: &Expression<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> bool {
        let Some(assignment) = Self::extract_assignment(expr) else {
            return false;
        };

        // Try to resolve a symbol id for the LHS; may be None for implicit globals
        let symbol_opt = Self::get_assignment_target_symbol(assignment, scoping);

        // Allow either:
        // - Known uninitialized variables (tracked from var decls)
        // - Implicit globals without symbols
        let allow_collect = match symbol_opt {
            Some(sym) => self.uninitialized_variables.contains(&sym),
            None => true,
        };
        if !allow_collect {
            return false;
        }

        // Literal values or safe timestamp calls are OK
        let rhs_is_ok = Self::is_literal_value(&assignment.right)
            || matches!(&assignment.right, Expression::CallExpression(_))
                && SafetyChecker::is_safe_to_inline(&assignment.right);
        if !rhs_is_ok {
            return false;
        }

        let resolved_value = self.resolve_expression(&assignment.right, scoping, allocator);
        if let Some(sym) = symbol_opt {
            // eprintln!("collect seq-assign sym={:?} rhs={:?}", sym, resolved_value);
            self.collected.insert(sym, resolved_value);
        } else {
            // Fallback collect by name
            if let AssignmentTarget::AssignmentTargetIdentifier(ident) = &assignment.left {
                let name = ident.name.as_str().to_string();
                self.collected_by_name.insert(name, resolved_value);
            }
        }
        true // Remove from sequence
    }
}

// ============================================================================
// Private Implementation - Expression Resolution
// ============================================================================

impl<'a> Collector<'a> {
    /// Recursively resolves an expression by looking up identifiers in the collected map
    fn resolve_expression(
        &self,
        expr: &Expression<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> Expression<'a> {
        match expr {
            // Literals: return as-is
            Expression::StringLiteral(_)
            | Expression::NumericLiteral(_)
            | Expression::BooleanLiteral(_) => expr.clone_in(allocator),

            // Identifier: lookup and recursively resolve
            Expression::Identifier(_) => self.resolve_identifier(expr, scoping, allocator),

            // Member expressions: resolve components
            Expression::StaticMemberExpression(member) => {
                self.resolve_static_member(member, scoping, allocator)
            }
            Expression::ComputedMemberExpression(member) => {
                self.resolve_computed_member(member, scoping, allocator)
            }

            // Binary expressions: resolve both sides
            Expression::BinaryExpression(bin_expr) => {
                self.resolve_binary_expression(bin_expr, scoping, allocator)
            }

            // Logical expressions: resolve both sides
            Expression::LogicalExpression(logical_expr) => {
                self.resolve_logical_expression(logical_expr, scoping, allocator)
            }

            // Call expressions: resolve callee and arguments
            Expression::CallExpression(call_expr) => {
                self.resolve_call_expression(call_expr, scoping, allocator)
            }

            // Other expressions: return as-is
            _ => expr.clone_in(allocator),
        }
    }

    fn resolve_identifier(
        &self,
        expr: &Expression<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> Expression<'a> {
        if let Some(symbol_id) = get_rhs_symbol_id(expr, scoping) {
            if let Some(collected_expr) = self.collected.get(&symbol_id) {
                return self.resolve_expression(collected_expr, scoping, allocator);
            }
        }
        // Fallback: resolve by identifier name via collected_by_name and alias_edges_by_name
        if let Expression::Identifier(id) = expr {
            let mut current = id.name.as_str().to_string();
            let mut seen = FxHashSet::default();
            loop {
                if let Some(found) = self.collected_by_name.get(&current) {
                    return self.resolve_expression(found, scoping, allocator);
                }
                if seen.contains(&current) {
                    break;
                }
                seen.insert(current.clone());
                if let Some((_, rhs)) = self
                    .alias_edges_by_name
                    .iter()
                    .find(|(lhs, _)| lhs == &current)
                    .cloned()
                {
                    current = rhs;
                    continue;
                }
                break;
            }
        }
        expr.clone_in(allocator)
    }

    fn resolve_static_member(
        &self,
        member: &StaticMemberExpression<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> Expression<'a> {
        let resolved_object = self.resolve_expression(&member.object, scoping, allocator);
        let mut new_member = member.clone_in(allocator);
        new_member.object = resolved_object;
        Expression::StaticMemberExpression(ArenaBox::new_in(new_member, allocator))
    }

    fn resolve_computed_member(
        &self,
        member: &ComputedMemberExpression<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> Expression<'a> {
        let resolved_object = self.resolve_expression(&member.object, scoping, allocator);
        let resolved_property = self.resolve_expression(&member.expression, scoping, allocator);
        let mut new_member = member.clone_in(allocator);
        new_member.object = resolved_object;
        new_member.expression = resolved_property;
        Expression::ComputedMemberExpression(ArenaBox::new_in(new_member, allocator))
    }

    fn resolve_binary_expression(
        &self,
        bin_expr: &BinaryExpression<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> Expression<'a> {
        let resolved_left = self.resolve_expression(&bin_expr.left, scoping, allocator);
        let resolved_right = self.resolve_expression(&bin_expr.right, scoping, allocator);
        let mut new_bin_expr = bin_expr.clone_in(allocator);
        new_bin_expr.left = resolved_left;
        new_bin_expr.right = resolved_right;
        Expression::BinaryExpression(ArenaBox::new_in(new_bin_expr, allocator))
    }

    fn resolve_logical_expression(
        &self,
        logical_expr: &LogicalExpression<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> Expression<'a> {
        let resolved_left = self.resolve_expression(&logical_expr.left, scoping, allocator);
        let resolved_right = self.resolve_expression(&logical_expr.right, scoping, allocator);
        let mut new_logical_expr = logical_expr.clone_in(allocator);
        new_logical_expr.left = resolved_left;
        new_logical_expr.right = resolved_right;
        Expression::LogicalExpression(ArenaBox::new_in(new_logical_expr, allocator))
    }

    fn resolve_call_expression(
        &self,
        call_expr: &CallExpression<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> Expression<'a> {
        let resolved_callee = self.resolve_expression(&call_expr.callee, scoping, allocator);
        let resolved_args = self.resolve_call_arguments(&call_expr.arguments, scoping, allocator);

        let mut new_call_expr = call_expr.clone_in(allocator);
        new_call_expr.callee = resolved_callee;
        new_call_expr.arguments = resolved_args;
        Expression::CallExpression(ArenaBox::new_in(new_call_expr, allocator))
    }

    fn resolve_call_arguments(
        &self,
        arguments: &ArenaVec<'a, Argument<'a>>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> ArenaVec<'a, Argument<'a>> {
        let mut resolved_args = ArenaVec::new_in(allocator);

        for arg in arguments {
            let resolved_arg = match arg {
                Argument::SpreadElement(_) => arg.clone_in(allocator),
                // Resolve common expression-bearing argument variants
                Argument::AssignmentExpression(a) => {
                    let expr = Expression::AssignmentExpression(a.clone_in(allocator));
                    let resolved = self.resolve_expression(&expr, scoping, allocator);
                    Self::expression_to_argument(resolved, arg, allocator)
                }
                Argument::ParenthesizedExpression(p) => {
                    let expr = Expression::ParenthesizedExpression(p.clone_in(allocator));
                    let resolved = self.resolve_expression(&expr, scoping, allocator);
                    Self::expression_to_argument(resolved, arg, allocator)
                }
                Argument::StaticMemberExpression(m) => {
                    let expr = Expression::StaticMemberExpression(m.clone_in(allocator));
                    let resolved = self.resolve_expression(&expr, scoping, allocator);
                    Self::expression_to_argument(resolved, arg, allocator)
                }
                Argument::ComputedMemberExpression(m) => {
                    let expr = Expression::ComputedMemberExpression(m.clone_in(allocator));
                    let resolved = self.resolve_expression(&expr, scoping, allocator);
                    Self::expression_to_argument(resolved, arg, allocator)
                }
                Argument::CallExpression(c) => {
                    let expr = Expression::CallExpression(c.clone_in(allocator));
                    let resolved = self.resolve_expression(&expr, scoping, allocator);
                    Self::expression_to_argument(resolved, arg, allocator)
                }
                Argument::BinaryExpression(b) => {
                    let expr = Expression::BinaryExpression(b.clone_in(allocator));
                    let resolved = self.resolve_expression(&expr, scoping, allocator);
                    Self::expression_to_argument(resolved, arg, allocator)
                }
                Argument::LogicalExpression(l) => {
                    let expr = Expression::LogicalExpression(l.clone_in(allocator));
                    let resolved = self.resolve_expression(&expr, scoping, allocator);
                    Self::expression_to_argument(resolved, arg, allocator)
                }
                Argument::ObjectExpression(o) => {
                    let expr = Expression::ObjectExpression(o.clone_in(allocator));
                    let resolved = self.resolve_expression(&expr, scoping, allocator);
                    Self::expression_to_argument(resolved, arg, allocator)
                }
                Argument::Identifier(ident) => {
                    self.resolve_argument_identifier(ident, arg, scoping, allocator)
                }
                _ => arg.clone_in(allocator),
            };
            resolved_args.push(resolved_arg);
        }

        resolved_args
    }

    /// Convert a resolved expression into an Argument variant when possible,
    /// otherwise fall back to cloning the original Argument.
    fn expression_to_argument(
        resolved: Expression<'a>,
        fallback: &Argument<'a>,
        allocator: &'a Allocator,
    ) -> Argument<'a> {
        match resolved {
            Expression::NumericLiteral(lit) => Argument::NumericLiteral(lit),
            Expression::StringLiteral(lit) => Argument::StringLiteral(lit),
            Expression::BooleanLiteral(lit) => Argument::BooleanLiteral(lit),
            Expression::Identifier(id) => Argument::Identifier(id),
            Expression::ObjectExpression(obj) => Argument::ObjectExpression(obj),
            Expression::StaticMemberExpression(m) => Argument::StaticMemberExpression(m),
            Expression::ComputedMemberExpression(m) => Argument::ComputedMemberExpression(m),
            Expression::CallExpression(c) => Argument::CallExpression(c),
            Expression::BinaryExpression(b) => Argument::BinaryExpression(b),
            Expression::LogicalExpression(l) => Argument::LogicalExpression(l),
            Expression::ParenthesizedExpression(p) => Argument::ParenthesizedExpression(p),
            Expression::AssignmentExpression(a) => Argument::AssignmentExpression(a),
            Expression::SequenceExpression(s) => Argument::SequenceExpression(s),
            _ => fallback.clone_in(allocator),
        }
    }

    fn resolve_argument_identifier(
        &self,
        ident: &IdentifierReference<'a>,
        fallback: &Argument<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> Argument<'a> {
        // Get symbol ID directly from the original identifier (preserves reference_id)
        let Some(symbol_id) = ident
            .reference_id
            .get()
            .and_then(|ref_id| scoping.get_reference(ref_id).symbol_id())
        else {
            // Fallback by name if symbol is missing
            return self.resolve_argument_identifier_by_name(ident, fallback, scoping, allocator);
        };

        let Some(collected_expr) = self.collected.get(&symbol_id) else {
            // Fallback by name if not found by symbol
            return self.resolve_argument_identifier_by_name(ident, fallback, scoping, allocator);
        };

        let resolved = self.resolve_expression(collected_expr, scoping, allocator);
        match resolved {
            Expression::NumericLiteral(lit) => Argument::NumericLiteral(lit),
            Expression::StringLiteral(lit) => Argument::StringLiteral(lit),
            Expression::Identifier(id) => Argument::Identifier(id),
            _ => fallback.clone_in(allocator),
        }
    }

    fn resolve_argument_identifier_by_name(
        &self,
        ident: &IdentifierReference<'a>,
        fallback: &Argument<'a>,
        scoping: &Scoping,
        allocator: &'a Allocator,
    ) -> Argument<'a> {
        let mut current = ident.name.as_str().to_string();
        let mut seen = FxHashSet::default();
        loop {
            if let Some(found) = self.collected_by_name.get(&current) {
                let resolved = self.resolve_expression(found, scoping, allocator);
                return match resolved {
                    Expression::NumericLiteral(lit) => Argument::NumericLiteral(lit),
                    Expression::StringLiteral(lit) => Argument::StringLiteral(lit),
                    Expression::Identifier(id) => Argument::Identifier(id),
                    _ => fallback.clone_in(allocator),
                };
            }
            if seen.contains(&current) {
                break;
            }
            seen.insert(current.clone());
            if let Some((_, rhs)) = self
                .alias_edges_by_name
                .iter()
                .find(|(lhs, _)| lhs == &current)
                .cloned()
            {
                current = rhs;
                continue;
            }
            break;
        }
        fallback.clone_in(allocator)
    }
}

// ============================================================================
// Static Helper Functions
// ============================================================================

impl<'a> Collector<'a> {
    /// Checks if an expression is worth collecting (simple literals and references)
    /// Note: null is NOT collected
    fn is_collectable(expr: &Expression, logical_expressions: bool) -> bool {
        if matches!(
            expr,
            Expression::StringLiteral(_)
                | Expression::NumericLiteral(_)
                | Expression::UnaryExpression(_) // Negative numbers like -221
                | Expression::BooleanLiteral(_)
                | Expression::Identifier(_)
                | Expression::StaticMemberExpression(_)
                | Expression::ComputedMemberExpression(_)
        ) {
            return true;
        }
        // Allow safe call expressions like Date.now() or new Date().getTime()
        if matches!(expr, Expression::CallExpression(_)) && SafetyChecker::is_safe_to_inline(expr) {
            return true;
        }
        // Zero-arg IIFEs are handled by the dedicated zero_arg_proxy_inliner, not collected here
        if logical_expressions {
            return matches!(expr, Expression::LogicalExpression(_));
        }
        false
    }

    /// Checks if an expression is a literal value (for sequence expression handling)
    fn is_literal_value(expr: &Expression) -> bool {
        matches!(
            expr,
            Expression::NumericLiteral(_)
                | Expression::StringLiteral(_)
                | Expression::UnaryExpression(_) // Negative numbers like -221
        )
    }

    /// Extracts an assignment expression from a potentially parenthesized expression
    fn extract_assignment<'b>(expr: &'b Expression<'a>) -> Option<&'b AssignmentExpression<'a>> {
        match expr {
            Expression::AssignmentExpression(a) => Some(a),
            Expression::ParenthesizedExpression(p) => {
                if let Expression::AssignmentExpression(a) = &p.expression {
                    Some(a)
                } else {
                    None
                }
            }
            _ => None,
        }
    }

    /// Gets the symbol ID from an assignment target
    fn get_assignment_target_symbol<'b>(
        assignment: &'b AssignmentExpression<'a>,
        scoping: &Scoping,
    ) -> Option<SymbolId> {
        let AssignmentTarget::AssignmentTargetIdentifier(ident) = &assignment.left else {
            return None;
        };

        ident
            .reference_id
            .get()
            .and_then(|ref_id| scoping.get_reference(ref_id).symbol_id())
    }
}
