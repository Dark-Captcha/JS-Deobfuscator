use oxc::{
    allocator::{CloneIn, TakeIn},
    ast::ast::{AssignmentExpression, Expression, ParenthesizedExpression, VariableDeclarator},
    semantic::SymbolId,
};
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::FxHashMap;

use crate::deobfuscator::transformers::shared_utils::safety_checker::SafetyChecker;
use crate::deobfuscator::transformers::shared_utils::symbol_utils::{
    get_lhs_symbol_id, get_rhs_symbol_id,
};

/// Replaces identifier references with their collected values.
///
/// Example:
/// ```js
/// var a = window;      // Collected: {a → window}
/// console.log(a);      // After apply: console.log(window);
/// ```
pub struct Applier<'a> {
    pub collected: FxHashMap<SymbolId, Expression<'a>>,
    /// Fallback mapping for identifiers without symbols (implicit globals)
    pub collected_by_name: Option<FxHashMap<String, Expression<'a>>>,
}

// ============================================================================
// Traverse Implementation
// ============================================================================

impl<'a> Traverse<'a, ()> for Applier<'a> {
    fn enter_parenthesized_expression(
        &mut self,
        node: &mut ParenthesizedExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Enable inlining inside parentheses: e.g. (x) => (42)
        let scoping = ctx.scoping();
        let allocator = ctx.ast.allocator;

        // Also handle cases like (_obj.prop = ident)
        if let Expression::AssignmentExpression(assign) = &mut node.expression {
            if let Expression::Identifier(_) = &assign.right {
                // Resolve via symbol chain
                let mut current = assign.right.clone_in(allocator);
                loop {
                    let Some(sym) = get_rhs_symbol_id(&current, scoping) else { break };
                    let Some(mapped) = self.collected.get(&sym) else { break };
                    if matches!(mapped, Expression::ObjectExpression(_)) { break }
                    current = mapped.clone_in(allocator);
                    if !matches!(current, Expression::Identifier(_)) {
                        if SafetyChecker::is_safe_to_inline(&current) {
                            assign.right = current;
                        }
                        break;
                    }
                }
            }
        }
    }
    fn enter_assignment_expression(
        &mut self,
        node: &mut AssignmentExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Inline simple RHS identifiers directly in assignments when safe
        let scoping = ctx.scoping();
        let allocator = ctx.ast.allocator;

        // Unwrap a single level of parentheses on the RHS to enable inlining inside
        if let Expression::ParenthesizedExpression(p) = &mut node.right {
            node.right = p.expression.take_in(allocator);
            return;
        }

        // If RHS is an identifier, try to resolve through collected map and name-fallback
        let rhs_name = if let Expression::Identifier(id) = &node.right {
            Some(id.name.as_str().to_string())
        } else {
            None
        };
        
        if rhs_name.is_some() {
            // Resolve via symbol chain
            let mut current = node.right.clone_in(allocator);
            let mut replaced = false;
            loop {
                let Some(sym) = get_rhs_symbol_id(&current, scoping) else {
                    break;
                };
                let Some(mapped) = self.collected.get(&sym) else {
                    break;
                };
                // Do not inline object expressions as RHS
                if matches!(mapped, Expression::ObjectExpression(_)) {
                    break;
                }
                current = mapped.clone_in(allocator);
                // Apply as soon as it stops being an identifier
                if !matches!(current, Expression::Identifier(_)) {
                    node.right = current;
                    replaced = true;
                    break;
                }
            }
            // Fallback by name
            if !replaced {
                if let (Some(map), Some(name)) = (&self.collected_by_name, rhs_name) {
                    if let Some(mapped) = map.get(name.as_str()) {
                        if !matches!(mapped, Expression::ObjectExpression(_))
                            && SafetyChecker::is_safe_to_inline(mapped)
                        {
                            node.right = mapped.clone_in(allocator);
                        }
                    }
                }
            }
        }
    }
    fn enter_expression(&mut self, node: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Only process identifiers
        if !matches!(node, Expression::Identifier(_)) {
            return;
        }
        
        let scoping = ctx.scoping();
        let allocator = ctx.ast.allocator;

        // Try by symbol first
        if let Some(symbol_id) = get_rhs_symbol_id(node, scoping) {
            if let Some(collected_expr) = self.collected.get(&symbol_id) {
                if matches!(collected_expr, Expression::ObjectExpression(_)) {
                    return;
                }
                // Inline directly for zero-arg IIFEs collected as call expressions
                let inline_direct = matches!(
                    collected_expr,
                    Expression::CallExpression(call)
                        if call.arguments.is_empty() && matches!(
                            &call.callee,
                            Expression::FunctionExpression(_) | Expression::ParenthesizedExpression(_)
                        )
                );
                if inline_direct || SafetyChecker::is_safe_to_inline(collected_expr) {
                    *node = collected_expr.clone_in(allocator);
                }
                return;
            }
        }

        // Fallback by name when symbol is missing
        if let (Expression::Identifier(id), Some(map)) = (&*node, self.collected_by_name.as_ref()) {
            if let Some(collected_expr) = map.get(id.name.as_str()) {
                if matches!(collected_expr, Expression::ObjectExpression(_)) {
                    return;
                }
                let inline_direct = matches!(
                    collected_expr,
                    Expression::CallExpression(call)
                        if call.arguments.is_empty() && matches!(
                            &call.callee,
                            Expression::FunctionExpression(_) | Expression::ParenthesizedExpression(_)
                        )
                );
                if inline_direct || SafetyChecker::is_safe_to_inline(collected_expr) {
                    *node = collected_expr.clone_in(allocator);
                }
            }
        }
    }

    fn enter_variable_declarator(
        &mut self,
        node: &mut VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Convert uninitialized variables with collected values into initialized ones
        // Example: var w; ... (w = {}) ... → var w = {};
        if node.init.is_some() {
            return;
        }

        let Some(lhs_symbol_id) = get_lhs_symbol_id(node) else {
            return;
        };

        let allocator = ctx.ast.allocator;

        // If we have a collected value for this uninitialized variable, initialize it
        if let Some(collected_expr) = self.collected.get(&lhs_symbol_id) {
            // Only initialize with object expressions (identifiers will be inlined)
            if matches!(collected_expr, Expression::ObjectExpression(_)) {
                node.init = Some(collected_expr.clone_in(allocator));
            }
        }
    }

  
}