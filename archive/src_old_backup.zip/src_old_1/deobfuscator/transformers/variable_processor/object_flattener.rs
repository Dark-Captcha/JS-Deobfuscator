use oxc::{
    allocator::{Allocator, CloneIn, TakeIn, Vec as ArenaVec},
    ast::{
        NONE,
        ast::{
            BindingPatternKind, Expression, ObjectExpression, ObjectPropertyKind, PropertyKey,
            Statement, VariableDeclaration, VariableDeclarator,
        },
    },
    span::GetSpan,
};
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::FxHashMap;

use crate::deobfuscator::transformers::shared_utils::symbol_utils::{
    count_symbol_references, get_lhs_symbol_id,
};

/// Flattens constant object literals into individual variables.
///
/// Example:
/// ```js
/// var a = {S: 516, E: 494};     // Before
/// var a_S = 516; var a_E = 494; // After
/// a.S          → a_S            // Member access replaced
/// a["E"]       → a_E            // Computed access replaced
/// ```
#[derive(Default)]
pub struct Initializer<'a> {
    /// Stores flattened object properties: var_name → {prop_name → value}
    constant_objects: FxHashMap<String, FxHashMap<String, Expression<'a>>>,
}

// ============================================================================
// Traverse Implementation
// ============================================================================

impl<'a> Traverse<'a, ()> for Initializer<'a> {
    fn enter_expression(&mut self, node: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let (obj_name, prop_name) = match node {
            Expression::StaticMemberExpression(member) => {
                if let Expression::Identifier(obj_id) = &member.object {
                    (obj_id.name.as_str(), member.property.name.as_str())
                } else {
                    return;
                }
            }
            Expression::ComputedMemberExpression(member) => {
                if let (Expression::Identifier(obj_id), Expression::StringLiteral(lit)) =
                    (&member.object, &member.expression)
                {
                    (obj_id.name.as_str(), lit.value.as_str())
                } else {
                    return;
                }
            }
            _ => return,
        };

        // Replace member access with flattened variable reference
        if let Some(properties) = self.constant_objects.get(obj_name) {
            if properties.contains_key(prop_name) {
                let flattened_name = make_flattened_name(ctx.ast.allocator, obj_name, prop_name);
                *node = Expression::Identifier(
                    ctx.ast
                        .alloc_identifier_reference(node.span(), flattened_name),
                );
            }
        }
    }

    fn enter_statements(
        &mut self,
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut new_statements = ctx.ast.vec();

        for mut statement in statements.take_in(allocator) {
            if let Statement::VariableDeclaration(var_decl) = &mut statement {
                let (remaining, flattened) = self.process_variable_declaration(var_decl, ctx);

                // Add flattened declarations first
                for declarator in flattened {
                    let new_var_decl = ctx.ast.alloc(ctx.ast.variable_declaration(
                        var_decl.span,
                        var_decl.kind,
                        ctx.ast.vec1(declarator),
                        var_decl.declare,
                    ));
                    new_statements.push(Statement::VariableDeclaration(new_var_decl));
                }

                // Add remaining (non-flattened) declarators if any
                if !remaining.is_empty() {
                    var_decl.declarations = remaining;
                    new_statements.push(statement);
                }
            } else {
                new_statements.push(statement);
            }
        }

        *statements = new_statements;
    }
}

// ============================================================================
// Private Implementation
// ============================================================================

impl<'a> Initializer<'a> {
    /// Processes a variable declaration, splitting out flattenable objects.
    /// Returns: (remaining_declarators, flattened_declarators)
    fn process_variable_declaration(
        &mut self,
        var_decl: &mut VariableDeclaration<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> (
        ArenaVec<'a, VariableDeclarator<'a>>,
        ArenaVec<'a, VariableDeclarator<'a>>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut remaining = ctx.ast.vec();
        let mut flattened = ctx.ast.vec();

        for declarator in var_decl.declarations.take_in(allocator) {
            if let Some((var_name, props)) = self.try_flatten_object(&declarator, ctx) {
                // Create individual declarations for each property
                for (prop_name, prop_value) in &props {
                    let flattened_name = make_flattened_name(allocator, &var_name, prop_name);

                    let binding = ctx.ast.binding_pattern(
                        BindingPatternKind::BindingIdentifier(
                            ctx.ast
                                .alloc_binding_identifier(declarator.span, flattened_name),
                        ),
                        NONE,
                        false,
                    );

                    flattened.push(ctx.ast.variable_declarator(
                        declarator.span,
                        var_decl.kind,
                        binding,
                        Some(prop_value.clone_in(allocator)),
                        false,
                    ));
                }

                // Store for member expression replacement
                self.constant_objects.insert(var_name, props);
            } else {
                remaining.push(declarator);
            }
        }

        (remaining, flattened)
    }

    /// Attempts to flatten an object literal into individual variables.
    /// Returns Some((var_name, properties)) if successful.
    fn try_flatten_object(
        &self,
        declarator: &VariableDeclarator<'a>,
        ctx: &TraverseCtx<'a, ()>,
    ) -> Option<(String, FxHashMap<String, Expression<'a>>)> {
        let var_name = get_variable_name(declarator)?;

        // Must be initialized with object expression
        let Expression::ObjectExpression(obj_expr) = declarator.init.as_ref()? else {
            return None;
        };

        // Check if it's a constant (0 writes)
        let symbol_id = get_lhs_symbol_id(declarator)?;
        let write_count = count_symbol_references(ctx.scoping(), symbol_id, |r| r.is_write());
        if write_count != 0 {
            return None;
        }

        // Check if object can be flattened (all simple literal properties)
        if !is_flattenable_object(obj_expr) {
            return None;
        }

        // Collect properties
        let mut properties = FxHashMap::default();
        for prop in &obj_expr.properties {
            if let ObjectPropertyKind::ObjectProperty(obj_prop) = prop {
                if let Some(prop_key) = get_property_key(&obj_prop.key) {
                    properties.insert(
                        prop_key.to_string(),
                        obj_prop.value.clone_in(ctx.ast.allocator),
                    );
                }
            }
        }

        Some((var_name.to_string(), properties))
    }
}

// ============================================================================
// Static Helper Functions
// ============================================================================

/// Extracts variable name from a declarator
fn get_variable_name<'a>(declarator: &'a VariableDeclarator<'a>) -> Option<&'a str> {
    match &declarator.id.kind {
        BindingPatternKind::BindingIdentifier(ident) => Some(ident.name.as_str()),
        _ => None,
    }
}

/// Extracts property key as string from various property key types
fn get_property_key<'a>(key: &'a PropertyKey<'a>) -> Option<&'a str> {
    match key {
        PropertyKey::StringLiteral(lit) => Some(lit.value.as_str()),
        PropertyKey::StaticIdentifier(ident) => Some(ident.name.as_str()),
        PropertyKey::Identifier(ident) => Some(ident.name.as_str()),
        _ => None,
    }
}

/// Checks if expression is a simple literal value
fn is_literal_value(expr: &Expression) -> bool {
    matches!(
        expr,
        Expression::NumericLiteral(_)
            | Expression::StringLiteral(_)
            | Expression::BooleanLiteral(_)
    )
}

/// Checks if an object can be flattened (all properties are simple literals)
fn is_flattenable_object(obj_expr: &ObjectExpression) -> bool {
    if obj_expr.properties.is_empty() {
        return false;
    }

    obj_expr.properties.iter().all(|prop| {
        if let ObjectPropertyKind::ObjectProperty(obj_prop) = prop {
            get_property_key(&obj_prop.key).is_some() && is_literal_value(&obj_prop.value)
        } else {
            false
        }
    })
}

/// Creates a flattened variable name: obj_name + "_" + prop_name
fn make_flattened_name<'a>(allocator: &'a Allocator, obj_name: &str, prop_name: &str) -> &'a str {
    allocator.alloc_str(&format!("{}_{}", obj_name, prop_name))
}
