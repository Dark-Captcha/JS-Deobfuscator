//! Variable Processor
//!
//! Variable processing and inlining transformers.

pub mod dead_code_remover;
pub mod object_flattener;
pub mod orchestrator;
pub mod variable_collector;
pub mod variable_inliner;

pub use orchestrator::VariableTransformer;
