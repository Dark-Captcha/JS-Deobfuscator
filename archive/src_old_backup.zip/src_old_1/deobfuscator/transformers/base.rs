//! Transformer Trait
//!
//! Core trait for JavaScript AST transformations.

use anyhow::Result;
use oxc::{allocator::Allocator, ast::ast::Program, semantic::Scoping};

pub trait Transformer<'a> {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping>;
}
