use oxc::{
    allocator::Allocator,
    allocator::CloneIn,
    ast::ast::{Expression, ObjectExpression, Program, Statement},
    semantic::{Scoping, SymbolId},
};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::deobfuscator::transformers::Transformer;

/// Inlines object literal identifiers at use sites, and removes original declarations.
pub struct ObjectInlinerOnly;

impl<'a> Transformer<'a> for ObjectInlinerOnly {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> anyhow::Result<Scoping> {
        let mut collector = ObjectCollector {
            objects: FxHashMap::default(),
        };
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        let mut inliner = ObjectInlinerPass {
            objects: collector.objects,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        Ok(scoping)
    }
}

struct ObjectCollector<'a> {
    objects: FxHashMap<SymbolId, oxc::allocator::Box<'a, ObjectExpression<'a>>>,
}

impl<'a> Traverse<'a, ()> for ObjectCollector<'a> {
    fn enter_variable_declarator(
        &mut self,
        node: &mut oxc::ast::ast::VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        if let Some(init) = &node.init {
            if let Expression::ObjectExpression(obj_expr) = init {
                if let Some(id) = node.id.get_binding_identifier() {
                    if let Some(symbol_id) = id.symbol_id.get() {
                        self.objects
                            .insert(symbol_id, obj_expr.clone_in(ctx.ast.allocator));
                    }
                }
            }
        }
    }
}

struct ObjectInlinerPass<'a> {
    objects: FxHashMap<SymbolId, oxc::allocator::Box<'a, ObjectExpression<'a>>>,
}

impl<'a> Traverse<'a, ()> for ObjectInlinerPass<'a> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        if let Expression::Identifier(ident) = expr {
            let reference_id = ident.reference_id();
            if let Some(symbol_id) = ctx.scoping().get_reference(reference_id).symbol_id() {
                if let Some(obj_expr) = self.objects.get(&symbol_id) {
                    if !obj_expr.properties.is_empty() {
                        *expr = Expression::ObjectExpression(obj_expr.clone_in(ctx.ast.allocator));
                    }
                }
            }
        }
    }

    fn exit_statement(&mut self, stmt: &mut Statement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        if let Statement::VariableDeclaration(var_decl) = stmt {
            if var_decl.declarations.len() == 1 {
                if let Some(decl) = var_decl.declarations.first() {
                    if let Some(init) = &decl.init {
                        if let Expression::ObjectExpression(_) = init {
                            if let Some(id) = decl.id.get_binding_identifier() {
                                if let Some(symbol_id) = id.symbol_id.get() {
                                    if self.objects.contains_key(&symbol_id) {
                                        *stmt = Statement::EmptyStatement(
                                            ctx.ast.alloc_empty_statement(decl.span),
                                        );
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
