use anyhow::Result;
use oxc::{
    allocator::Allocator,
    ast::ast::*,
    semantic::{Scoping, SymbolId},
};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::deobfuscator::transformers::Transformer;
use crate::deobfuscator::transformers::shared_utils::string_search::StringSearcher;

/// Decodes ROT-N string functions with the specific pattern:
/// function _Ms(_t370) {
///     var _i60 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 13;
///     return _t370.replace(/[A-Za-z]/g, (function(_t371) {
///         return String.fromCharCode(_t371.charCodeAt(0) + (_t371.toUpperCase() <= "M" ? _i60 : -_i60));
///     }));
/// }
pub struct RotStringDecoder;

impl<'a> Transformer<'a> for RotStringDecoder {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping> {
        // Step 1: Collect ROT functions
        let mut collector = RotCollector {
            rot_functions: FxHashMap::default(),
        };
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        if collector.rot_functions.is_empty() {
            return Ok(scoping);
        }

        // Step 2: Apply ROT decoding to calls
        let mut applier = RotApplier {
            rot_functions: collector.rot_functions,
        };
        let scoping = traverse_mut(&mut applier, allocator, program, scoping, ());

        Ok(scoping)
    }
}

/// Collects ROT functions that match the specific pattern
struct RotCollector {
    rot_functions: FxHashMap<SymbolId, RotFunctionInfo>,
}

struct RotFunctionInfo {
    default_shift: i32,
}

impl<'a> Traverse<'a, ()> for RotCollector {
    fn enter_function(&mut self, node: &mut Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        if let Some(symbol_id) = node.id.as_ref().and_then(|id| id.symbol_id.get()) {
            if self.is_rot_function(node) {
                let default_shift = self.extract_default_shift(node);
                self.rot_functions
                    .insert(symbol_id, RotFunctionInfo { default_shift });
            }
        }
    }

    fn enter_variable_declarator(
        &mut self,
        node: &mut VariableDeclarator<'a>,
        _ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Handle: var Ms = function(...) { ... }
        let Some(init) = &node.init else { return };
        let Expression::FunctionExpression(func) = init else {
            return;
        };
        let Some(binding) = node.id.get_binding_identifier() else {
            return;
        };
        let Some(symbol_id) = binding.symbol_id.get() else {
            return;
        };

        if self.is_rot_function(&func) {
            let default_shift = self.extract_default_shift(&func);
            self.rot_functions
                .insert(symbol_id, RotFunctionInfo { default_shift });
        }
    }
}

impl<'a> RotCollector {
    /// Checks if a function matches the ROT pattern
    fn is_rot_function(&self, func: &Function<'a>) -> bool {
        // Heuristic markers requested by user: presence of "M" string and a ternary with numeric alternate 13
        let has_marker_m = if let Some(body) = &func.body {
            StringSearcher::search_in_statements(&body.statements, "M")
        } else {
            false
        };
        let has_default_13 = self.body_contains_conditional_numeric_alt(func, 13);
        has_marker_m && has_default_13
    }

    // (kept intentionally minimal; if needed later, restore detection of replace/regex)

    /// Extracts the default shift value from the function
    fn extract_default_shift(&self, func: &Function<'a>) -> i32 {
        // Look for: var _i60 = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 13;
        if let Some(body) = &func.body {
            for stmt in &body.statements {
                if let Statement::VariableDeclaration(var_decl) = stmt {
                    for decl in &var_decl.declarations {
                        if let Some(init) = &decl.init {
                            if let Expression::ConditionalExpression(cond) = init {
                                if let Expression::NumericLiteral(num) = &cond.alternate {
                                    return num.value as i32;
                                }
                            }
                        }
                    }
                }
            }
        }
        13 // Default fallback
    }

    fn body_contains_conditional_numeric_alt(&self, func: &Function<'a>, num: i32) -> bool {
        let Some(body) = &func.body else { return false };
        for stmt in &body.statements {
            if self.stmt_contains_conditional_numeric_alt(stmt, num) {
                return true;
            }
        }
        false
    }

    fn stmt_contains_conditional_numeric_alt(&self, stmt: &Statement<'a>, num: i32) -> bool {
        match stmt {
            Statement::ExpressionStatement(s) => {
                self.expr_contains_conditional_numeric_alt(&s.expression, num)
            }
            Statement::ReturnStatement(s) => s
                .argument
                .as_ref()
                .map(|e| self.expr_contains_conditional_numeric_alt(e, num))
                .unwrap_or(false),
            Statement::VariableDeclaration(s) => s.declarations.iter().any(|d| {
                d.init
                    .as_ref()
                    .map(|e| self.expr_contains_conditional_numeric_alt(e, num))
                    .unwrap_or(false)
            }),
            _ => false,
        }
    }

    fn expr_contains_conditional_numeric_alt(&self, expr: &Expression<'a>, num: i32) -> bool {
        match expr {
            Expression::ConditionalExpression(c) => {
                let alt_has = match &c.alternate {
                    Expression::NumericLiteral(n) => (n.value as i32) == num,
                    other => self.expr_contains_conditional_numeric_alt(other, num),
                };
                alt_has
                    || self.expr_contains_conditional_numeric_alt(&c.test, num)
                    || self.expr_contains_conditional_numeric_alt(&c.consequent, num)
            }
            Expression::CallExpression(c) => {
                self.expr_contains_conditional_numeric_alt(&c.callee, num)
                    || c.arguments.iter().any(|a| {
                        a.as_expression()
                            .map(|e| self.expr_contains_conditional_numeric_alt(e, num))
                            .unwrap_or(false)
                    })
            }
            Expression::BinaryExpression(b) => {
                self.expr_contains_conditional_numeric_alt(&b.left, num)
                    || self.expr_contains_conditional_numeric_alt(&b.right, num)
            }
            Expression::StaticMemberExpression(m) => {
                self.expr_contains_conditional_numeric_alt(&m.object, num)
            }
            Expression::ComputedMemberExpression(m) => {
                self.expr_contains_conditional_numeric_alt(&m.object, num)
                    || self.expr_contains_conditional_numeric_alt(&m.expression, num)
            }
            Expression::TemplateLiteral(t) => t
                .expressions
                .iter()
                .any(|e| self.expr_contains_conditional_numeric_alt(e, num)),
            Expression::ArrayExpression(a) => a.elements.iter().any(|el| {
                el.as_expression()
                    .map(|e| self.expr_contains_conditional_numeric_alt(e, num))
                    .unwrap_or(false)
            }),
            Expression::ObjectExpression(o) => o.properties.iter().any(|p| match p {
                ObjectPropertyKind::ObjectProperty(p) => {
                    self.expr_contains_conditional_numeric_alt(&p.value, num)
                }
                ObjectPropertyKind::SpreadProperty(p) => {
                    self.expr_contains_conditional_numeric_alt(&p.argument, num)
                }
            }),
            _ => false,
        }
    }
}

/// Applies ROT decoding to function calls
struct RotApplier {
    rot_functions: FxHashMap<SymbolId, RotFunctionInfo>,
}

impl<'a> Traverse<'a, ()> for RotApplier {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        if let Expression::CallExpression(call) = expr {
            if let Some(symbol_id) = self.get_callee_symbol_id(call, ctx.scoping()) {
                if let Some(rot_info) = self.rot_functions.get(&symbol_id) {
                    if let Some(first_arg) = call.arguments.first().and_then(|a| a.as_expression())
                    {
                        if let Expression::StringLiteral(str_lit) = first_arg {
                            // Get shift from second argument or use default
                            let shift = match call.arguments.get(1).and_then(|a| a.as_expression())
                            {
                                Some(Expression::NumericLiteral(n)) => n.value as i32,
                                _ => rot_info.default_shift,
                            };

                            // Decode the string
                            let decoded = rot_decode(str_lit.value.as_str(), shift);
                            let atom = ctx.ast.atom(decoded.as_str());
                            *expr = ctx.ast.expression_string_literal(str_lit.span, atom, None);
                        }
                    }
                }
            }
        }
    }
}

impl<'a> RotApplier {
    /// Gets the symbol ID of the callee function
    fn get_callee_symbol_id(
        &self,
        call: &CallExpression<'a>,
        scoping: &Scoping,
    ) -> Option<SymbolId> {
        if let Expression::Identifier(ident) = &call.callee {
            let reference_id = ident.reference_id();
            scoping.get_reference(reference_id).symbol_id()
        } else {
            None
        }
    }
}

/// ROT-N decode function
fn rot_decode(input: &str, shift: i32) -> String {
    let mut out = String::with_capacity(input.len());
    for ch in input.chars() {
        let code = ch as u32;
        let decoded = match ch {
            'A'..='Z' => rotate(code, 'A' as u32, shift),
            'a'..='z' => rotate(code, 'a' as u32, shift),
            _ => ch as u32,
        };
        out.push(char::from_u32(decoded).unwrap_or(ch));
    }
    out
}

fn rotate(code: u32, base: u32, shift: i32) -> u32 {
    let off = (code - base) as i32;
    let s = ((off + shift).rem_euclid(26)) as u32;
    base + s
}
