//! Proxy function inliner
//!
//! This module inlines string rotator proxy functions by resolving argument
//! transformations and removing intermediate proxy calls.

use anyhow::Result;
use oxc::{allocator::Allocator, ast::ast::Program, semantic::Scoping};
use oxc_traverse::traverse_mut;

use crate::deobfuscator::transformers::Transformer;

/// Inlines string rotator proxy functions by resolving argument transformations
///
/// This transformer detects proxy functions, resolves transformation chains,
/// and inlines them to direct calls to eliminate intermediate proxy layers.
pub struct ProxyFunctionInliner;

impl<'a> Transformer<'a> for ProxyFunctionInliner {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping> {
        // Pass 1: Collect all proxy functions and their transformations
        let mut collector = proxy_collector::ProxyCollector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        // Resolve proxy chains to get ultimate functions
        let proxy_map = chain_resolver::resolve_proxy_chains(&collector.proxies);

        // Pass 2: Inline all proxy calls
        let mut inliner = proxy_inliner::ProxyInliner { proxy_map };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        // Pass 3: Remove proxy function declarations
        let proxy_names: rustc_hash::FxHashSet<String> =
            collector.proxies.keys().cloned().collect();
        let mut cleaner = proxy_cleaner::ProxyCleaner { proxy_names };
        let scoping = traverse_mut(&mut cleaner, allocator, program, scoping, ());

        Ok(scoping)
    }
}

/// Proxy function collection and detection
mod proxy_collector {
    use oxc::{
        allocator::Vec as ArenaVec,
        ast::ast::{
            BindingPatternKind, CallExpression, Expression, FormalParameter, Function, Statement,
        },
    };
    use oxc_traverse::{Traverse, TraverseCtx};
    use rustc_hash::FxHashMap;

    /// Describes how a proxy function transforms its arguments before calling another function
    #[derive(Debug, Clone)]
    pub struct ProxyTransform {
        /// The target function being called
        pub target_name: String,
        /// Transformation for each output argument: (source_param_index, arithmetic_offset)
        pub arg_transforms: Vec<(usize, i64)>,
    }

    /// Maps proxy function names to their transformation info
    #[derive(Default)]
    pub struct ProxyCollector {
        pub proxies: FxHashMap<String, ProxyTransform>,
    }

    impl<'a> Traverse<'a, ()> for ProxyCollector {
        fn enter_function(&mut self, node: &mut Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
            // Detect proxy pattern: function with 2 params that returns a single call
            if let Some(transform) = detect_proxy_function(node) {
                if let Some(func_name) = &node.id {
                    self.proxies.insert(func_name.name.to_string(), transform);
                }
            }
        }
    }

    /// Detects if a function is a proxy and extracts its transformation
    fn detect_proxy_function(node: &Function) -> Option<ProxyTransform> {
        // Must have exactly 2 parameters
        if node.params.items.len() != 2 {
            return None;
        }

        // Extract parameter names
        let param_names = extract_param_names(&node.params.items)?;
        if param_names.len() != 2 {
            return None;
        }

        // Check body is a single return statement with a call
        let body = node.body.as_ref()?;
        if body.statements.len() != 1 {
            return None;
        }

        let Statement::ReturnStatement(ret_stmt) = &body.statements[0] else {
            return None;
        };

        let Expression::CallExpression(call_expr) = ret_stmt.argument.as_ref()? else {
            return None;
        };

        // Parse the call expression to extract transformations
        parse_proxy_call(call_expr, &param_names[0], &param_names[1])
    }

    /// Extracts parameter names from function parameters
    fn extract_param_names<'a>(params: &ArenaVec<'a, FormalParameter<'a>>) -> Option<Vec<String>> {
        params
            .iter()
            .map(|param| {
                if let BindingPatternKind::BindingIdentifier(ident) = &param.pattern.kind {
                    Some(ident.name.to_string())
                } else {
                    None
                }
            })
            .collect()
    }

    /// Parses a call expression to extract the target and argument transformations
    fn parse_proxy_call(
        call_expr: &CallExpression,
        param0_name: &str,
        param1_name: &str,
    ) -> Option<ProxyTransform> {
        // Extract target function name
        let Expression::Identifier(target_ident) = &call_expr.callee else {
            return None;
        };
        let target_name = target_ident.name.to_string();

        // Must have exactly 2 arguments
        if call_expr.arguments.len() != 2 {
            return None;
        }

        // Parse each argument transformation
        let mut arg_transforms = Vec::new();
        for arg in &call_expr.arguments {
            let (source_index, offset) =
                super::argument_parser::parse_argument_transform(arg, param0_name, param1_name)?;
            arg_transforms.push((source_index, offset));
        }

        Some(ProxyTransform {
            target_name,
            arg_transforms,
        })
    }
}

/// Argument parsing and transformation utilities
mod argument_parser {
    use oxc::ast::ast::{Argument, BinaryExpression, BinaryOperator, Expression, UnaryOperator};

    /// Parses an argument to determine which parameter it uses and any arithmetic offset
    pub fn parse_argument_transform(
        arg: &Argument,
        param0_name: &str,
        param1_name: &str,
    ) -> Option<(usize, i64)> {
        match arg {
            Argument::Identifier(ident) => {
                // Simple identifier reference
                get_param_index(&ident.name, param0_name, param1_name).map(|idx| (idx, 0))
            }
            Argument::BinaryExpression(bin_expr) => {
                // Try to parse as parameter-based arithmetic (e.g., v - -966)
                if let Some(result) = parse_binary_arithmetic(&**bin_expr, param0_name, param1_name)
                {
                    return Some(result);
                }

                // Otherwise, try to evaluate as pure constant expression (e.g., -650 - -926)
                if let Some(value) = extract_numeric_value(arg.as_expression()?) {
                    return Some((0, value));
                }

                None
            }
            Argument::NumericLiteral(lit) => {
                // Pure numeric literal
                Some((0, lit.value as i64))
            }
            Argument::UnaryExpression(_) => {
                // Handle negation like -123
                if let Some(value) = extract_numeric_value(arg.as_expression()?) {
                    Some((0, value))
                } else {
                    None
                }
            }
            _ => None,
        }
    }

    /// Recursively parses a binary expression to extract (param_index, offset)
    fn parse_binary_arithmetic(
        bin_expr: &BinaryExpression,
        param0_name: &str,
        param1_name: &str,
    ) -> Option<(usize, i64)> {
        // Parse left side (should contain the parameter reference)
        let (param_idx, base_offset) =
            parse_expression_for_param(&bin_expr.left, param0_name, param1_name)?;

        // Parse right side (should be a numeric value)
        let right_value = extract_numeric_value(&bin_expr.right)?;

        // Combine based on operator
        let total_offset = match bin_expr.operator {
            BinaryOperator::Addition => base_offset + right_value,
            BinaryOperator::Subtraction => base_offset - right_value,
            _ => return None, // Only + and - are supported
        };

        Some((param_idx, total_offset))
    }

    /// Parses an expression to find a parameter reference and any base offset
    fn parse_expression_for_param(
        expr: &Expression,
        param0_name: &str,
        param1_name: &str,
    ) -> Option<(usize, i64)> {
        match expr {
            Expression::Identifier(ident) => {
                get_param_index(&ident.name, param0_name, param1_name).map(|idx| (idx, 0))
            }
            Expression::BinaryExpression(bin_expr) => {
                parse_binary_arithmetic(bin_expr, param0_name, param1_name)
            }
            _ => None,
        }
    }

    /// Extracts a numeric value from an expression, handling negative numbers
    fn extract_numeric_value(expr: &Expression) -> Option<i64> {
        match expr {
            Expression::NumericLiteral(lit) => Some(lit.value as i64),
            Expression::UnaryExpression(un_expr) => {
                if un_expr.operator == UnaryOperator::UnaryNegation {
                    // Recursively evaluate the inner expression
                    let inner_value = extract_numeric_value(&un_expr.argument)?;
                    return Some(-inner_value);
                }
                None
            }
            Expression::BinaryExpression(bin_expr) => {
                // Constant folding: evaluate pure arithmetic expressions
                let left = extract_numeric_value(&bin_expr.left)?;
                let right = extract_numeric_value(&bin_expr.right)?;

                match bin_expr.operator {
                    BinaryOperator::Addition => Some(left + right),
                    BinaryOperator::Subtraction => Some(left - right),
                    BinaryOperator::Multiplication => Some(left * right),
                    BinaryOperator::Division => Some(left / right),
                    _ => None,
                }
            }
            _ => None,
        }
    }

    /// Returns the parameter index for a given name
    fn get_param_index(name: &str, param0_name: &str, param1_name: &str) -> Option<usize> {
        if name == param0_name {
            Some(0)
        } else if name == param1_name {
            Some(1)
        } else {
            None
        }
    }
}

/// Proxy chain resolution utilities
mod chain_resolver {
    use rustc_hash::FxHashMap;

    /// Maps proxy function names to their ultimate targets and combined transformations
    #[derive(Debug, Clone)]
    pub struct ResolvedProxy {
        /// The ultimate target function (end of the chain)
        pub ultimate_target: String,
        /// Combined transformations after resolving all proxy levels
        pub arg_transforms: Vec<(usize, i64)>,
    }

    /// Resolves chains of proxies to their ultimate targets
    pub fn resolve_proxy_chains(
        proxies: &FxHashMap<String, super::proxy_collector::ProxyTransform>,
    ) -> FxHashMap<String, ResolvedProxy> {
        let mut resolved = FxHashMap::default();

        for (proxy_name, transform) in proxies {
            let mut current_target = transform.target_name.clone();
            let mut combined_transforms = transform.arg_transforms.clone();
            let mut visited = vec![proxy_name.clone()];

            // Follow the chain until we reach a non-proxy (the ultimate function)
            while proxies.contains_key(&current_target) {
                // Detect circular references
                if visited.contains(&current_target) {
                    break;
                }
                visited.push(current_target.clone());

                let next_transform = &proxies[&current_target];

                // Combine transformations by composition
                combined_transforms =
                    combine_transforms(&combined_transforms, &next_transform.arg_transforms);

                current_target = next_transform.target_name.clone();
            }

            resolved.insert(
                proxy_name.clone(),
                ResolvedProxy {
                    ultimate_target: current_target,
                    arg_transforms: combined_transforms,
                },
            );
        }

        resolved
    }

    /// Combines two levels of argument transformations
    fn combine_transforms(
        current_transform: &[(usize, i64)],
        next_transform: &[(usize, i64)],
    ) -> Vec<(usize, i64)> {
        let mut combined = Vec::new();

        for (intermediate_param_idx, offset2) in next_transform {
            let (original_param_idx, offset1) = current_transform[*intermediate_param_idx];
            combined.push((original_param_idx, offset1 + offset2));
        }

        combined
    }
}

/// Proxy call inlining utilities
mod proxy_inliner {
    use oxc::ast::ast::{CallExpression, Expression};
    use oxc_traverse::{Traverse, TraverseCtx};
    use rustc_hash::FxHashMap;

    use super::chain_resolver::ResolvedProxy;

    /// Inlines proxy function calls by replacing them with direct calls
    pub struct ProxyInliner {
        pub proxy_map: FxHashMap<String, ResolvedProxy>,
    }

    impl<'a> Traverse<'a, ()> for ProxyInliner {
        fn enter_call_expression(
            &mut self,
            node: &mut CallExpression<'a>,
            ctx: &mut TraverseCtx<'a, ()>,
        ) {
            // Check if this is a call to a known proxy
            let Expression::Identifier(callee_ident) = &node.callee else {
                return;
            };

            let Some(resolved) = self.proxy_map.get(callee_ident.name.as_str()).cloned() else {
                return;
            };

            // Must have exactly 2 arguments (proxy functions always have 2 params)
            if node.arguments.len() != 2 {
                return;
            }

            // Transform arguments according to the resolved mapping
            super::argument_transformer::inline_proxy_call(node, &resolved, ctx);
        }
    }
}

/// Argument transformation utilities
mod argument_transformer {
    use oxc::{
        allocator::{Allocator, CloneIn, FromIn},
        ast::ast::{
            Argument, BinaryOperator, CallExpression, Expression, NumberBase, UnaryOperator,
        },
        span::{Atom, SPAN},
    };
    use oxc_traverse::TraverseCtx;

    use super::chain_resolver::ResolvedProxy;

    /// Replaces a proxy call with a direct call to the ultimate function
    pub fn inline_proxy_call<'a>(
        node: &mut CallExpression<'a>,
        resolved: &ResolvedProxy,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut new_args = ctx.ast.vec();

        // Build new arguments by applying transformations
        for (source_idx, offset) in &resolved.arg_transforms {
            let source_arg = &node.arguments[*source_idx];

            // Always apply offset (even if 0) to enable constant folding
            let new_arg = apply_offset(source_arg, *offset, allocator, ctx);
            new_args.push(new_arg);
        }

        // Replace callee and arguments
        let target_name = Atom::from_in(&resolved.ultimate_target, allocator);
        node.callee = Expression::Identifier(ctx.ast.alloc_identifier_reference(SPAN, target_name));
        node.arguments = new_args;
    }

    /// Applies an arithmetic offset to an argument, with constant folding when possible
    fn apply_offset<'a>(
        arg: &Argument<'a>,
        offset: i64,
        allocator: &'a Allocator,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> Argument<'a> {
        match arg {
            // Constant folding: numeric literal
            Argument::NumericLiteral(lit) => {
                let new_value = lit.value + offset as f64;
                ctx.ast
                    .expression_numeric_literal(SPAN, new_value, None, NumberBase::Decimal)
                    .into()
            }

            // Constant folding: unary negation
            Argument::UnaryExpression(un_expr) => {
                if un_expr.operator == UnaryOperator::UnaryNegation {
                    if let Expression::NumericLiteral(lit) = &un_expr.argument {
                        let new_value = -(lit.value as i64) + offset;
                        return fold_numeric_value(new_value, ctx);
                    }
                }
                // Can't fold, create binary expression
                create_binary_expression(arg, offset, allocator, ctx)
            }

            // Partial folding: binary expression
            Argument::BinaryExpression(bin_expr) => {
                // Try to extract numeric values from both sides
                let left_value = extract_numeric_value(&bin_expr.left);
                let right_value = extract_numeric_value(&bin_expr.right);

                // Full constant folding if both sides are numeric
                if let (Some(left_val), Some(right_val)) = (left_value, right_value) {
                    let result = match bin_expr.operator {
                        BinaryOperator::Addition => left_val + right_val + offset,
                        BinaryOperator::Subtraction => left_val - right_val + offset,
                        _ => return create_binary_expression(arg, offset, allocator, ctx),
                    };
                    return fold_numeric_value(result, ctx);
                }

                // Partial folding: combine offsets
                if let Expression::NumericLiteral(right_lit) = &bin_expr.right {
                    let existing_offset = right_lit.value as i64;
                    let combined = match bin_expr.operator {
                        BinaryOperator::Addition => existing_offset + offset,
                        BinaryOperator::Subtraction => -existing_offset + offset,
                        _ => return create_binary_expression(arg, offset, allocator, ctx),
                    };

                    return create_binary_from_expr(&bin_expr.left, combined, allocator, ctx);
                }

                create_binary_expression(arg, offset, allocator, ctx)
            }

            // Default: create binary expression
            _ => create_binary_expression(arg, offset, allocator, ctx),
        }
    }

    /// Folds a numeric value into a literal or unary expression
    fn fold_numeric_value<'a>(value: i64, ctx: &mut TraverseCtx<'a, ()>) -> Argument<'a> {
        if value >= 0 {
            ctx.ast
                .expression_numeric_literal(SPAN, value as f64, None, NumberBase::Decimal)
                .into()
        } else {
            ctx.ast
                .expression_unary(
                    SPAN,
                    UnaryOperator::UnaryNegation,
                    ctx.ast.expression_numeric_literal(
                        SPAN,
                        (-value) as f64,
                        None,
                        NumberBase::Decimal,
                    ),
                )
                .into()
        }
    }

    /// Creates a binary expression: `arg + offset` or `arg - offset`
    fn create_binary_expression<'a>(
        arg: &Argument<'a>,
        offset: i64,
        allocator: &'a Allocator,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> Argument<'a> {
        let left = match arg.as_expression() {
            Some(expr) => expr.clone_in(allocator),
            None => return convert_argument_to_expression(arg, allocator, offset, ctx),
        };
        create_binary_from_expr(&left, offset, allocator, ctx)
    }

    /// Creates a binary expression from an existing expression
    fn create_binary_from_expr<'a>(
        expr: &Expression<'a>,
        offset: i64,
        allocator: &'a Allocator,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> Argument<'a> {
        let left = expr.clone_in(allocator);

        if offset >= 0 {
            let right =
                ctx.ast
                    .expression_numeric_literal(SPAN, offset as f64, None, NumberBase::Decimal);
            ctx.ast
                .expression_binary(SPAN, left, BinaryOperator::Addition, right)
                .into()
        } else {
            let right = ctx.ast.expression_numeric_literal(
                SPAN,
                (-offset) as f64,
                None,
                NumberBase::Decimal,
            );
            ctx.ast
                .expression_binary(SPAN, left, BinaryOperator::Subtraction, right)
                .into()
        }
    }

    /// Converts an Argument to an Expression, using as_expression() when possible
    fn convert_argument_to_expression<'a>(
        arg: &Argument<'a>,
        allocator: &'a Allocator,
        offset: i64,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> Argument<'a> {
        // Try to use as_expression() first for supported types
        if let Some(expr) = arg.as_expression() {
            let cloned_expr = expr.clone_in(allocator);
            return create_binary_from_expr(&cloned_expr, offset, allocator, ctx);
        }

        // Fallback to manual conversion for unsupported types
        match arg {
            Argument::Identifier(ident) => {
                let expr = Expression::Identifier(ident.clone_in(allocator));
                create_binary_from_expr(&expr, offset, allocator, ctx)
            }
            Argument::NumericLiteral(lit) => {
                let expr = Expression::NumericLiteral(lit.clone_in(allocator));
                create_binary_from_expr(&expr, offset, allocator, ctx)
            }
            Argument::BinaryExpression(bin) => {
                let expr = Expression::BinaryExpression(bin.clone_in(allocator));
                create_binary_from_expr(&expr, offset, allocator, ctx)
            }
            Argument::UnaryExpression(un) => {
                let expr = Expression::UnaryExpression(un.clone_in(allocator));
                create_binary_from_expr(&expr, offset, allocator, ctx)
            }
            Argument::CallExpression(call) => {
                let expr = Expression::CallExpression(call.clone_in(allocator));
                create_binary_from_expr(&expr, offset, allocator, ctx)
            }
            _ => {
                // For unsupported types, create a simple binary expression
                // Convert to expression manually for unsupported types
                let left_expr = match arg {
                    Argument::Identifier(ident) => {
                        Expression::Identifier(ident.clone_in(allocator))
                    }
                    Argument::NumericLiteral(lit) => {
                        Expression::NumericLiteral(lit.clone_in(allocator))
                    }
                    Argument::BinaryExpression(bin) => {
                        Expression::BinaryExpression(bin.clone_in(allocator))
                    }
                    Argument::UnaryExpression(un) => {
                        Expression::UnaryExpression(un.clone_in(allocator))
                    }
                    Argument::CallExpression(call) => {
                        Expression::CallExpression(call.clone_in(allocator))
                    }
                    _ => panic!("Unsupported argument type: {:?}", arg),
                };
                create_binary_from_expr(&left_expr, offset, allocator, ctx)
            }
        }
    }

    /// Extracts a numeric value from an expression, handling negative numbers
    fn extract_numeric_value(expr: &Expression) -> Option<i64> {
        match expr {
            Expression::NumericLiteral(lit) => Some(lit.value as i64),
            Expression::UnaryExpression(un_expr) => {
                if un_expr.operator == UnaryOperator::UnaryNegation {
                    let inner_value = extract_numeric_value(&un_expr.argument)?;
                    return Some(-inner_value);
                }
                None
            }
            Expression::BinaryExpression(bin_expr) => {
                let left = extract_numeric_value(&bin_expr.left)?;
                let right = extract_numeric_value(&bin_expr.right)?;

                match bin_expr.operator {
                    BinaryOperator::Addition => Some(left + right),
                    BinaryOperator::Subtraction => Some(left - right),
                    BinaryOperator::Multiplication => Some(left * right),
                    BinaryOperator::Division => Some(left / right),
                    _ => None,
                }
            }
            _ => None,
        }
    }
}

/// Proxy function cleanup utilities
mod proxy_cleaner {
    use oxc::{allocator::Vec as ArenaVec, ast::ast::Statement};
    use oxc_traverse::{Traverse, TraverseCtx};

    /// Removes proxy function declarations after they've been inlined
    pub struct ProxyCleaner {
        pub proxy_names: rustc_hash::FxHashSet<String>,
    }

    impl<'a> Traverse<'a, ()> for ProxyCleaner {
        fn enter_statements(
            &mut self,
            stmts: &mut ArenaVec<'a, Statement<'a>>,
            _ctx: &mut TraverseCtx<'a, ()>,
        ) {
            stmts.retain(|stmt| {
                if let Statement::FunctionDeclaration(func) = stmt {
                    if let Some(id) = &func.id {
                        // Keep the function if it's NOT in our proxy list
                        return !self.proxy_names.contains(id.name.as_str());
                    }
                }
                true
            });
        }
    }
}
