//! XOR string decoder transformer
//!
//! This module inlines XOR decoder function calls by decoding at compile-time.
//! It follows a 3-pass pattern: Collect → Inline → Cleanup.

use anyhow::Result;
use oxc::{
    allocator::Allocator,
    ast::ast::Program,
    semantic::{Scoping, SymbolId},
};
use oxc_traverse::traverse_mut;
use rustc_hash::FxHashSet;

use crate::deobfuscator::transformers::Transformer;

/// Inlines XOR decoder function calls by decoding at compile-time
///
/// **Pattern Detected:**
/// ```js
/// function u(u) {
///     var n = v[u];  // cache check
///     if (n) f = n;
///     else {
///         for (var t = r(u), f = "", e = 0; e < t.length; ++e) {
///             var c = "Yztf4Fd".charCodeAt(e % 7);  // XOR key
///             f += String.fromCharCode(c ^ t.charCodeAt(e));
///         }
///         v[u] = f;  // cache result
///     }
///     return f;
/// }
/// u("MQ4AFkd8S3YZGwpYIwctFQZL")  // base64 decoded → XOR with key
/// ```
pub struct StringXorDecoder;

impl<'a> Transformer<'a> for StringXorDecoder {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping> {
        // Pass 1: Collect XOR decoder functions
        let mut collector = decoder_collector::XorDecoderCollector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        if collector.decoders.is_empty() {
            return Ok(scoping);
        }

        // Pass 2: Inline decoder calls
        let mut inliner = decoder_inliner::XorInliner {
            decoders: collector.decoders,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        // Pass 3: Remove decoder functions
        let decoder_symbols: FxHashSet<SymbolId> = inliner.decoders.keys().copied().collect();
        let mut cleaner = decoder_cleaner::DecoderCleaner { decoder_symbols };
        let scoping = traverse_mut(&mut cleaner, allocator, program, scoping, ());

        Ok(scoping)
    }
}

/// XOR decoder collection and detection
mod decoder_collector {
    use oxc::ast::ast::Function;
    use oxc::semantic::SymbolId;
    use oxc_traverse::{Traverse, TraverseCtx};
    use rustc_hash::FxHashMap;

    use super::xor_key_extractor::XorKeyExtractor;
    use crate::deobfuscator::transformers::shared_utils::ast_utils::AstUtils;

    /// Collects XOR decoder functions by detecting XOR patterns and extracting keys
    #[derive(Default)]
    pub struct XorDecoderCollector {
        /// Maps decoder function symbol → XOR key
        pub decoders: FxHashMap<SymbolId, String>,
    }

    impl<'a> Traverse<'a, ()> for XorDecoderCollector {
        fn enter_function(&mut self, node: &mut Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
            if let Some(xor_key) = XorKeyExtractor::detect_xor_decoder(node) {
                if let Some(symbol_id) = AstUtils::get_function_symbol_id(node) {
                    self.decoders.insert(symbol_id, xor_key);
                }
            }
        }
    }
}

/// XOR decoder call inlining
mod decoder_inliner {
    use oxc::{
        allocator::FromIn,
        ast::ast::{AssignmentTarget, BinaryOperator, CallExpression, Expression},
        semantic::{Scoping, SymbolId},
        span::{Atom, SPAN},
    };
    use oxc_traverse::{Traverse, TraverseCtx};
    use rustc_hash::FxHashMap;

    use super::xor_decoder::XorDecoder;
    use crate::deobfuscator::transformers::shared_utils::ast_utils::AstUtils;

    /// Inlines XOR decoder function calls
    #[derive(Default)]
    pub struct XorInliner {
        pub decoders: FxHashMap<SymbolId, String>,
    }

    impl<'a> Traverse<'a, ()> for XorInliner {
        fn enter_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
            // Proactively inline any decoder calls regardless of position in the tree
            if let Expression::CallExpression(call) = expr {
                if let Some(decoded) = self.try_inline_call(call, ctx.scoping()) {
                    let atom = Atom::from_in(decoded.as_str(), ctx.ast.allocator);
                    *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
                    return;
                }
            }
        }

        fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
            // Inline direct calls: u("base64...") -> "decoded"
            if let Expression::CallExpression(call) = expr {
                if let Some(decoded) = self.try_inline_call(call, ctx.scoping()) {
                    let atom = Atom::from_in(decoded.as_str(), ctx.ast.allocator);
                    *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
                    return;
                }
            }

            // Also handle decoder calls used as computed property keys: obj[u("...")] = ...
            if let Expression::ComputedMemberExpression(member) = expr {
                if let Expression::CallExpression(call) = &member.expression {
                    if let Some(decoded) = self.try_inline_call(call, ctx.scoping()) {
                        let atom = Atom::from_in(decoded.as_str(), ctx.ast.allocator);
                        let lit = ctx.ast.expression_string_literal(SPAN, atom, None);
                        // Replace only the key expression, keep the member intact
                        member.expression = lit;
                        return;
                    }
                }
            }

            // Handle left-hand side computed member in assignments: ({}[u("...")] = x, ...)
            if let Expression::AssignmentExpression(assign) = expr {
                if let AssignmentTarget::ComputedMemberExpression(member) = &mut assign.left {
                    if let Expression::CallExpression(call) = &member.expression {
                        if let Some(decoded) = self.try_inline_call(&call, ctx.scoping()) {
                            let atom = Atom::from_in(decoded.as_str(), ctx.ast.allocator);
                            let lit = ctx.ast.expression_string_literal(SPAN, atom, None);
                            member.expression = lit;
                            return;
                        }
                    }
                }
            }
        }
    }

    impl XorInliner {
        /// Attempts to inline an XOR decoder call
        fn try_inline_call(&self, call: &CallExpression, scoping: &Scoping) -> Option<String> {
            // Check if callee is a known decoder by SymbolId
            let symbol_id = AstUtils::get_callee_symbol_id(call, scoping)?;

            let xor_key = self.decoders.get(&symbol_id)?;

            // Get the first argument (base64-encoded string)
            let arg = AstUtils::get_first_argument(call)?;
            let encoded_str = match self.reduce_string_expression(arg) {
                Some(s) => s,
                _ => return None,
            };

            // Decode: base64 → XOR with key
            match XorDecoder::decode(encoded_str, xor_key) {
                Ok(decoded) => Some(decoded),
                Err(_) => None,
            }
        }

        /// Reduces complex string expressions to simple string literals
        fn reduce_string_expression<'b>(&self, expr: &'b Expression) -> Option<&'b str> {
            // Accept direct string literal
            if let Expression::StringLiteral(lit) = expr {
                return Some(lit.value.as_str());
            }
            // Parenthesized: ("...")
            if let Expression::ParenthesizedExpression(paren) = expr {
                return self.reduce_string_expression(&paren.expression);
            }
            // Sequence: (a, "...") take last
            if let Expression::SequenceExpression(seq) = expr {
                if let Some(last) = seq.expressions.last() {
                    return self.reduce_string_expression(last);
                }
            }
            // Binary + with both sides literals -> concat
            if let Expression::BinaryExpression(bin) = expr {
                if matches!(bin.operator, BinaryOperator::Addition) {
                    if let Some(left) = self.reduce_string_expression(&bin.left) {
                        if let Some(right) = self.reduce_string_expression(&bin.right) {
                            // Note: We only return a &str from existing literals; if both are literals,
                            // one of them is fine to return only if the other is empty. Otherwise bail.
                            if right.is_empty() {
                                return Some(left);
                            }
                            if left.is_empty() {
                                return Some(right);
                            }
                            return None;
                        }
                    }
                }
            }
            None
        }
    }
}

/// Decoder function cleanup
mod decoder_cleaner {
    use oxc::{allocator::Vec as ArenaVec, ast::ast::Statement, semantic::SymbolId};
    use oxc_traverse::{Traverse, TraverseCtx};
    use rustc_hash::FxHashSet;

    /// Removes decoder function declarations after they've been inlined
    #[derive(Default)]
    pub struct DecoderCleaner {
        pub decoder_symbols: FxHashSet<SymbolId>,
    }

    impl<'a> Traverse<'a, ()> for DecoderCleaner {
        fn enter_statements(
            &mut self,
            stmts: &mut ArenaVec<'a, Statement<'a>>,
            _ctx: &mut TraverseCtx<'a, ()>,
        ) {
            stmts.retain(|stmt| {
                if let Statement::FunctionDeclaration(func) = stmt {
                    if let Some(id) = &func.id {
                        if let Some(symbol_id) = id.symbol_id.get() {
                            return !self.decoder_symbols.contains(&symbol_id);
                        }
                    }
                }
                true
            });
        }
    }
}

/// XOR key extraction utilities
mod xor_key_extractor {
    use oxc::ast::ast::{BinaryOperator, Expression, Function, Statement};

    /// Extracts XOR keys from decoder functions
    pub struct XorKeyExtractor;

    impl XorKeyExtractor {
        /// Detects if a function is an XOR decoder by looking for XOR operator and charCodeAt pattern
        pub fn detect_xor_decoder(func: &Function) -> Option<String> {
            let body = func.body.as_ref()?;

            // Check if function has exactly 1 parameter
            if func.params.parameters_count() != 1 {
                return None;
            }

            // Look for XOR pattern and extract the key
            Self::extract_xor_key_from_statements(&body.statements)
        }

        /// Recursively searches for XOR key in statements
        fn extract_xor_key_from_statements(stmts: &[Statement]) -> Option<String> {
            for stmt in stmts {
                if let Some(key) = Self::extract_xor_key_from_statement(stmt) {
                    return Some(key);
                }
            }
            None
        }

        /// Extracts XOR key from a single statement
        fn extract_xor_key_from_statement(stmt: &Statement) -> Option<String> {
            match stmt {
                Statement::VariableDeclaration(var_decl) => {
                    for decl in &var_decl.declarations {
                        if let Some(init) = &decl.init {
                            if let Some(key) = Self::extract_xor_key_from_expression(init) {
                                return Some(key);
                            }
                        }
                    }
                }
                Statement::ForStatement(for_stmt) => {
                    // Check for XOR in loop body
                    if let Statement::BlockStatement(block) = &for_stmt.body {
                        if let Some(key) = Self::extract_xor_key_from_statements(&block.body) {
                            return Some(key);
                        }
                    }
                    // Also check single statement body
                    if let Some(key) = Self::extract_xor_key_from_statement(&for_stmt.body) {
                        return Some(key);
                    }
                }
                Statement::IfStatement(if_stmt) => {
                    if let Some(key) = Self::extract_xor_key_from_statement(&if_stmt.consequent) {
                        return Some(key);
                    }
                    if let Some(alt) = &if_stmt.alternate {
                        if let Some(key) = Self::extract_xor_key_from_statement(alt) {
                            return Some(key);
                        }
                    }
                }
                Statement::BlockStatement(block) => {
                    return Self::extract_xor_key_from_statements(&block.body);
                }
                Statement::ExpressionStatement(expr_stmt) => {
                    return Self::extract_xor_key_from_expression(&expr_stmt.expression);
                }
                _ => {}
            }
            None
        }

        /// Extracts XOR key from an expression
        fn extract_xor_key_from_expression(expr: &Expression) -> Option<String> {
            match expr {
                // Look for: "key".charCodeAt(e % keyLen) ^ something
                Expression::BinaryExpression(bin) => {
                    if matches!(bin.operator, BinaryOperator::BitwiseXOR) {
                        // Check left side for charCodeAt pattern
                        if let Some(key) = Self::extract_key_from_charcode_at(&bin.left) {
                            return Some(key);
                        }
                        // Check right side for charCodeAt pattern
                        if let Some(key) = Self::extract_key_from_charcode_at(&bin.right) {
                            return Some(key);
                        }
                    }
                    // Recursively check both sides
                    Self::extract_xor_key_from_expression(&bin.left)
                        .or_else(|| Self::extract_xor_key_from_expression(&bin.right))
                }
                Expression::CallExpression(call) => {
                    // Check for direct charCodeAt pattern
                    if let Some(key) = Self::extract_key_from_charcode_at(expr) {
                        return Some(key);
                    }
                    // Check arguments for nested expressions
                    for arg in &call.arguments {
                        if let Some(arg_expr) = arg.as_expression() {
                            if let Some(key) = Self::extract_xor_key_from_expression(arg_expr) {
                                return Some(key);
                            }
                        }
                    }
                    None
                }
                Expression::AssignmentExpression(assign) => {
                    Self::extract_xor_key_from_expression(&assign.right)
                }
                _ => None,
            }
        }

        /// Extracts the string from "key".charCodeAt(...) pattern
        fn extract_key_from_charcode_at(expr: &Expression) -> Option<String> {
            if let Expression::CallExpression(call) = expr {
                // Check if it's a charCodeAt call
                if let Expression::StaticMemberExpression(member) = &call.callee {
                    if member.property.name == "charCodeAt" {
                        // The object should be a string literal
                        if let Expression::StringLiteral(lit) = &member.object {
                            return Some(lit.value.to_string());
                        }
                    }
                }
            }
            None
        }
    }
}

/// XOR decoding utilities
mod xor_decoder {
    use anyhow::Result;

    /// XOR decoder implementation
    pub struct XorDecoder;

    impl XorDecoder {
        /// Decodes a base64-encoded string with XOR key
        pub fn decode(encoded: &str, xor_key: &str) -> Result<String> {
            // Custom base64 decode (mimics JavaScript atob)
            const BASE64_CHARS: &[u8] =
                b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

            let input = encoded.trim_end_matches('=');
            let mut bytes = Vec::new();

            // Process in groups of 4 base64 chars -> 3 bytes
            let chars: Vec<char> = input.chars().collect();
            for chunk in chars.chunks(4) {
                let mut buffer: u32 = 0;
                let mut count = 0;

                for &ch in chunk {
                    if let Some(val) = BASE64_CHARS.iter().position(|&c| c == ch as u8) {
                        buffer = (buffer << 6) | (val as u32);
                        count += 1;
                    } else {
                        return Err(anyhow::anyhow!("Invalid base64 character: {}", ch));
                    }
                }

                // Extract bytes based on how many chars we read
                match count {
                    4 => {
                        bytes.push((buffer >> 16) as u8);
                        bytes.push((buffer >> 8) as u8);
                        bytes.push(buffer as u8);
                    }
                    3 => {
                        bytes.push((buffer >> 10) as u8);
                        bytes.push((buffer >> 2) as u8);
                    }
                    2 => {
                        bytes.push((buffer >> 4) as u8);
                    }
                    _ => {}
                }
            }

            // XOR each byte with the key
            let mut result = String::with_capacity(bytes.len());
            for (i, byte) in bytes.iter().enumerate() {
                let key_char_code = xor_key.as_bytes()[i % xor_key.len()];
                let xor_byte = byte ^ key_char_code;
                // JavaScript's String.fromCharCode() creates a character from byte value (0-255)
                // This is equivalent to Latin-1/ISO-8859-1 encoding
                result.push(xor_byte as char);
            }

            Ok(result)
        }
    }
}
