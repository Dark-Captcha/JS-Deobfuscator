//! Base64 string decoder transformer
//!
//! This module inlines base64 decoder function calls by decoding at compile-time.
//! It follows a 3-pass pattern: Collect → Inline → Cleanup.

use anyhow::Result;
use oxc::{allocator::Allocator, ast::ast::Program, semantic::Scoping};
use oxc_traverse::traverse_mut;

use crate::deobfuscator::transformers::Transformer;

/// Inlines base64 decoder function calls by decoding at compile-time
///
/// **Pattern Detected:**
/// ```js
/// function Nw(r) {
///     return atob(r);  // or custom base64 decoder
/// }
/// Nw("Y29uc2VjdXRpdmVQcmVjaGVjaw==")  // → "consecutivePrecheck"
/// ```
pub struct StringBase64Decoder;

impl<'a> Transformer<'a> for StringBase64Decoder {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping> {
        // Pass 1: Collect base64 decoder functions
        let mut collector = decoder_collector::Base64DecoderCollector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        if collector.decoders.is_empty() {
            return Ok(scoping);
        }

        // Pass 2: Inline decoder calls
        let mut inliner = decoder_inliner::Base64Inliner {
            decoders: collector.decoders,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        // Pass 3: Remove decoder functions
        let decoder_symbols = inliner.decoders.clone();
        let mut cleaner = decoder_cleaner::DecoderCleaner { decoder_symbols };
        let scoping = traverse_mut(&mut cleaner, allocator, program, scoping, ());

        Ok(scoping)
    }
}

/// Base64 decoder collection and detection
mod decoder_collector {
    use oxc::ast::ast::Function;
    use oxc::semantic::SymbolId;
    use oxc_traverse::{Traverse, TraverseCtx};
    use rustc_hash::FxHashSet;

    use crate::deobfuscator::transformers::shared_utils::ast_utils::AstUtils;
    use crate::deobfuscator::transformers::shared_utils::string_search::StringSearcher;

    /// Collects base64 decoder functions by detecting base64 alphabet patterns
    #[derive(Default)]
    pub struct Base64DecoderCollector {
        /// Set of base64 decoder function symbols
        pub decoders: FxHashSet<SymbolId>,
    }

    impl<'a> Traverse<'a, ()> for Base64DecoderCollector {
        fn enter_function(&mut self, node: &mut Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
            if detect_base64_decoder(node) {
                if let Some(symbol_id) = AstUtils::get_function_symbol_id(node) {
                    self.decoders.insert(symbol_id);
                }
            }
        }
    }

    /// Detects if a function is a base64 decoder by looking for the base64 alphabet
    fn detect_base64_decoder(func: &Function) -> bool {
        const BASE64_ALPHABET: &str =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

        let body = func.body.as_ref();
        if body.is_none() {
            return false;
        }

        // Check if function has exactly 1 parameter
        if func.params.parameters_count() != 1 {
            return false;
        }

        // Recursively search for the base64 alphabet string
        if let Some(body) = body {
            StringSearcher::search_in_statements(&body.statements, BASE64_ALPHABET)
        } else {
            false
        }
    }
}

/// Base64 decoder call inlining
mod decoder_inliner {
    use oxc::{
        allocator::FromIn,
        ast::ast::{CallExpression, Expression},
        semantic::{Scoping, SymbolId},
        span::{Atom, SPAN},
    };
    use oxc_traverse::{Traverse, TraverseCtx};
    use rustc_hash::FxHashSet;

    use super::base64_decoder::Base64Decoder;
    use crate::deobfuscator::transformers::shared_utils::ast_utils::AstUtils;

    /// Inlines base64 decoder function calls
    #[derive(Default)]
    pub struct Base64Inliner {
        pub decoders: FxHashSet<SymbolId>,
    }

    impl<'a> Traverse<'a, ()> for Base64Inliner {
        fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
            if let Expression::CallExpression(call) = expr {
                if let Some(decoded) = self.try_inline_call(call, ctx.scoping()) {
                    let atom = Atom::from_in(decoded.as_str(), ctx.ast.allocator);
                    *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
                }
            }
        }
    }

    impl Base64Inliner {
        /// Attempts to inline a base64 decoder call
        fn try_inline_call(&self, call: &CallExpression, scoping: &Scoping) -> Option<String> {
            // Check if callee is a known decoder by SymbolId
            let symbol_id = AstUtils::get_callee_symbol_id(call, scoping)?;

            if !self.decoders.contains(&symbol_id) {
                return None;
            }

            // Get the first argument (base64 string)
            let arg = AstUtils::get_first_argument(call)?;
            let base64_str = AstUtils::extract_string_literal(arg)?;

            // Decode base64
            match Base64Decoder::decode(base64_str) {
                Ok(decoded) => Some(decoded),
                Err(_) => None,
            }
        }
    }
}

/// Decoder function cleanup
mod decoder_cleaner {
    use oxc::{allocator::Vec as ArenaVec, ast::ast::Statement, semantic::SymbolId};
    use oxc_traverse::{Traverse, TraverseCtx};
    use rustc_hash::FxHashSet;

    /// Removes decoder function declarations after they've been inlined
    #[derive(Default)]
    pub struct DecoderCleaner {
        pub decoder_symbols: FxHashSet<SymbolId>,
    }

    impl<'a> Traverse<'a, ()> for DecoderCleaner {
        fn enter_statements(
            &mut self,
            stmts: &mut ArenaVec<'a, Statement<'a>>,
            _ctx: &mut TraverseCtx<'a, ()>,
        ) {
            stmts.retain(|stmt| {
                if let Statement::FunctionDeclaration(func) = stmt {
                    if let Some(id) = &func.id {
                        if let Some(symbol_id) = id.symbol_id.get() {
                            return !self.decoder_symbols.contains(&symbol_id);
                        }
                    }
                }
                true
            });
        }
    }
}

/// Base64 decoding utilities
mod base64_decoder {
    use anyhow::Result;

    /// Base64 decoder implementation
    pub struct Base64Decoder;

    impl Base64Decoder {
        /// Decodes a base64 string to UTF-8
        pub fn decode(encoded: &str) -> Result<String> {
            const BASE64_CHARS: &[u8] =
                b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

            let input = encoded.trim_end_matches('=');
            let mut output = Vec::new();
            let mut buffer: u32 = 0;
            let mut bits = 0;

            for ch in input.chars() {
                let value = BASE64_CHARS
                    .iter()
                    .position(|&c| c == ch as u8)
                    .ok_or_else(|| anyhow::anyhow!("Invalid base64 character: {}", ch))?;

                buffer = (buffer << 6) | (value as u32);
                bits += 6;

                if bits >= 8 {
                    bits -= 8;
                    output.push((buffer >> bits) as u8);
                    buffer &= (1 << bits) - 1;
                }
            }

            String::from_utf8(output).map_err(|e| anyhow::anyhow!("Invalid UTF-8: {}", e))
        }
    }
}
