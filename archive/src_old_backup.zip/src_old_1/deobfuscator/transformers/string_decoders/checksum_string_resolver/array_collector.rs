//! Array collector for extracting string arrays from functions
//!
//! This module collects array contents from array functions that return string arrays.

use oxc::{
    ast::ast::{ArrayExpression, Expression, Function, Statement},
    semantic::SymbolId,
};
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::FxHashMap;
use rustc_hash::FxHashSet;

/// Collects string arrays from array functions
#[derive(Default)]
pub struct ArrayCollector {
    pub target_symbols: FxHashSet<SymbolId>,
    pub arrays: FxHashMap<SymbolId, Vec<String>>,
}

impl<'a> Traverse<'a, ()> for ArrayCollector {
    fn enter_function(&mut self, func: &mut Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        if let Some(id) = &func.id {
            if let Some(symbol_id) = id.symbol_id.get() {
                if self.target_symbols.contains(&symbol_id) {
                    if let Some(strings) = Self::extract_array_from_function(func) {
                        self.arrays.insert(symbol_id, strings);
                    }
                }
            }
        }
    }
}

impl ArrayCollector {
    /// Extracts string array from a function that returns an array
    fn extract_array_from_function(func: &Function) -> Option<Vec<String>> {
        let body = func.body.as_ref()?;

        // Look for array expressions in statements
        for stmt in &body.statements {
            // Pattern 1: return [...];
            if let Statement::ReturnStatement(ret) = stmt {
                if let Some(Expression::ArrayExpression(arr)) = &ret.argument {
                    return Self::extract_strings_from_array(arr);
                }
            }
            // Pattern 2: var arr = [...];
            else if let Statement::VariableDeclaration(var_decl) = stmt {
                for decl in &var_decl.declarations {
                    if let Some(Expression::ArrayExpression(arr)) = &decl.init {
                        return Self::extract_strings_from_array(arr);
                    }
                }
            }
        }

        None
    }

    /// Extracts strings from an array expression
    fn extract_strings_from_array(arr: &ArrayExpression) -> Option<Vec<String>> {
        let strings: Vec<String> = arr
            .elements
            .iter()
            .filter_map(|el| el.as_expression())
            .filter_map(|expr| {
                if let Expression::StringLiteral(lit) = expr {
                    Some(lit.value.to_string())
                } else {
                    None
                }
            })
            .collect();

        if !strings.is_empty() {
            Some(strings)
        } else {
            None
        }
    }
}
