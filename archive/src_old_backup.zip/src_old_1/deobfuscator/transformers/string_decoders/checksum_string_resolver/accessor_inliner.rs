//! Accessor inliner for replacing calls with string literals
//!
//! This module replaces accessor function calls with actual string literals
//! from the resolved rotated arrays.

use oxc::{
    allocator::FromIn,
    ast::ast::Expression,
    semantic::SymbolId,
    span::{Atom, SPAN},
};
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::FxHashMap;

use super::arithmetic_parser::ArithmeticParser;
use super::data_structures::AccessorInfo;
use super::string_decoder::StringDecoder;
use crate::deobfuscator::transformers::shared_utils::ast_utils::AstUtils;

/// Inlines accessor function calls with resolved string literals
#[derive(Default)]
pub struct AccessorInliner {
    pub rotated_arrays: FxHashMap<SymbolId, Vec<String>>,
    pub accessor_info: FxHashMap<SymbolId, AccessorInfo>,
    pub accessor_to_array: FxHashMap<SymbolId, SymbolId>,
}

impl AccessorInliner {
    /// Gets the string value for an accessor call
    fn get_string_value(&self, accessor_sym: SymbolId, index_arg: i32) -> Option<String> {
        // Find which array this accessor uses
        let array_sym = self.accessor_to_array.get(&accessor_sym)?;

        // Get the rotated array
        let array = self.rotated_arrays.get(array_sym)?;

        // Get accessor info (offset, base64)
        let info = self.accessor_info.get(&accessor_sym)?;

        // Calculate actual index: index_arg + offset
        let raw_index = index_arg + info.offset;

        // Handle negative indices with modulo
        let array_len = array.len() as i32;
        let adjusted_index = ((raw_index % array_len) + array_len) % array_len;
        let adjusted_index = adjusted_index as usize;

        // Get string (with bounds check)
        if adjusted_index >= array.len() {
            return None;
        }

        let string_val = &array[adjusted_index];

        // Decode if needed
        if info.has_base64_decoder {
            let decoded = StringDecoder::decode_custom_base64(string_val);
            let url_decoded = StringDecoder::url_decode(&decoded);
            Some(url_decoded)
        } else {
            Some(string_val.clone())
        }
    }
}

impl<'a> Traverse<'a, ()> for AccessorInliner {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Handle both CallExpression and BinaryExpression (for 'in' operator)
        match expr {
            // Direct function calls: _oh(471)
            Expression::CallExpression(call) => {
                // Check if callee is an identifier and get its symbol ID
                let scoping = ctx.scoping();
                if let Some(symbol_id) = AstUtils::get_callee_symbol_id(call, scoping) {
                    // Check if this is an accessor we know about
                    if self.accessor_info.contains_key(&symbol_id) {
                        // Extract the first argument (index)
                        if let Some(arg_expr) = call.arguments.first() {
                            if let Some(arg_expr) = arg_expr.as_expression() {
                                // Try to extract numeric value (with constant folding)
                                if let Some(index) =
                                    ArithmeticParser::evaluate_constant_expression(arg_expr)
                                {
                                    // Get the actual string value
                                    if let Some(string_value) =
                                        self.get_string_value(symbol_id, index)
                                    {
                                        // Replace the CallExpression with a StringLiteral
                                        let allocator = ctx.ast.allocator;
                                        let atom = Atom::from_in(&string_value, allocator);
                                        let string_lit = ctx.ast.string_literal(SPAN, atom, None);
                                        *expr =
                                            Expression::StringLiteral(ctx.ast.alloc(string_lit));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            _ => {}
        }
    }
}
