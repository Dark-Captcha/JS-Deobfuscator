//! Arithmetic expression parser
//!
//! This module parses complex arithmetic expressions into evaluation terms
//! for checksum calculation.

use oxc::ast::ast::{Argument, BinaryOperator, CallExpression, Expression, UnaryOperator};

use super::data_structures::{EvalTerm, TermFactor};

/// Parser for arithmetic expressions
pub struct ArithmeticParser;

impl ArithmeticParser {
    /// Parses an expression into a flat list of evaluation terms (sum of products)
    pub fn parse_to_eval_terms(expr: &Expression, coefficient: i64) -> Vec<EvalTerm> {
        match expr {
            // Addition: parse both sides as separate terms
            Expression::BinaryExpression(bin)
                if matches!(bin.operator, BinaryOperator::Addition) =>
            {
                let mut terms = Self::parse_to_eval_terms(&bin.left, coefficient);
                terms.extend(Self::parse_to_eval_terms(&bin.right, coefficient));
                terms
            }

            // Subtraction: right side gets negated coefficient
            Expression::BinaryExpression(bin)
                if matches!(bin.operator, BinaryOperator::Subtraction) =>
            {
                let mut terms = Self::parse_to_eval_terms(&bin.left, coefficient);
                terms.extend(Self::parse_to_eval_terms(&bin.right, -coefficient));
                terms
            }

            // Multiplication: parse as a product
            Expression::BinaryExpression(bin)
                if matches!(bin.operator, BinaryOperator::Multiplication) =>
            {
                Self::parse_product(expr, coefficient)
            }

            // Unary negation: negate the coefficient
            Expression::UnaryExpression(un)
                if matches!(un.operator, UnaryOperator::UnaryNegation) =>
            {
                Self::parse_to_eval_terms(&un.argument, -coefficient)
            }

            // Parenthesized: unwrap
            Expression::ParenthesizedExpression(paren) => {
                Self::parse_to_eval_terms(&paren.expression, coefficient)
            }

            // Default: try to parse as a single-factor term
            _ => {
                if let Some((factor, sign)) = Self::try_parse_factor(expr) {
                    vec![EvalTerm {
                        factors: vec![factor],
                        coefficient: coefficient * sign,
                    }]
                } else {
                    vec![]
                }
            }
        }
    }

    /// Parses a product expression into a single term with multiple factors
    /// Example: `(parseInt(...) / 1) * (parseInt(...) / 2)` becomes one term with 2 factors
    fn parse_product(expr: &Expression, mut coefficient: i64) -> Vec<EvalTerm> {
        let mut factors = Vec::new();
        Self::collect_factors(expr, &mut factors, &mut coefficient);

        if factors.is_empty() {
            vec![]
        } else {
            vec![EvalTerm {
                factors,
                coefficient,
            }]
        }
    }

    /// Recursively collects factors from a multiplication expression
    fn collect_factors(expr: &Expression, factors: &mut Vec<TermFactor>, coefficient: &mut i64) {
        match expr {
            // Multiplication: collect from both sides
            Expression::BinaryExpression(bin)
                if matches!(bin.operator, BinaryOperator::Multiplication) =>
            {
                Self::collect_factors(&bin.left, factors, coefficient);
                Self::collect_factors(&bin.right, factors, coefficient);
            }

            // Unary negation: flip the sign
            Expression::UnaryExpression(un)
                if matches!(un.operator, UnaryOperator::UnaryNegation) =>
            {
                *coefficient *= -1;
                Self::collect_factors(&un.argument, factors, coefficient);
            }

            // Parenthesized: unwrap
            Expression::ParenthesizedExpression(paren) => {
                Self::collect_factors(&paren.expression, factors, coefficient);
            }

            // Numeric literal: multiply into coefficient
            Expression::NumericLiteral(num) => {
                *coefficient *= num.value as i64;
            }

            // Division: parse as factor and handle any negation in numerator
            Expression::BinaryExpression(bin)
                if matches!(bin.operator, BinaryOperator::Division) =>
            {
                // Check if left side has negation
                let (inner_expr, sign) = Self::peel_negation(&bin.left);
                if let Some(args) = Self::extract_accessor_args_from_expr(inner_expr) {
                    let divisor = Self::evaluate_constant_expression(&bin.right).unwrap_or(1);
                    factors.push(TermFactor { args, divisor });
                    *coefficient *= sign;
                }
            }

            // Default: try to parse as a factor
            _ => {
                if let Some((factor, sign)) = Self::try_parse_factor(expr) {
                    factors.push(factor);
                    *coefficient *= sign;
                }
            }
        }
    }

    /// Peels off any unary negation and returns (inner_expr, sign_multiplier)
    fn peel_negation<'a>(expr: &'a Expression<'a>) -> (&'a Expression<'a>, i64) {
        match expr {
            Expression::UnaryExpression(un)
                if matches!(un.operator, UnaryOperator::UnaryNegation) =>
            {
                let (inner, sign) = Self::peel_negation(&un.argument);
                (inner, -sign)
            }
            Expression::ParenthesizedExpression(paren) => Self::peel_negation(&paren.expression),
            _ => (expr, 1),
        }
    }

    /// Tries to parse an expression as a single factor
    /// Handles: `parseInt(accessor(args)) / divisor` or just `accessor(args)`
    /// Returns (TermFactor, sign_multiplier) where sign is 1 or -1
    fn try_parse_factor(expr: &Expression) -> Option<(TermFactor, i64)> {
        match expr {
            // Division: left side is accessor call, right side is divisor
            Expression::BinaryExpression(bin)
                if matches!(bin.operator, BinaryOperator::Division) =>
            {
                // Peel negation from left side
                let (inner_expr, sign) = Self::peel_negation(&bin.left);
                let args = Self::extract_accessor_args_from_expr(inner_expr)?;
                let divisor = Self::evaluate_constant_expression(&bin.right)?;
                Some((TermFactor { args, divisor }, sign))
            }

            // Direct call: no division
            Expression::CallExpression(_) => {
                let (inner_expr, sign) = Self::peel_negation(expr);
                let args = Self::extract_accessor_args_from_expr(inner_expr)?;
                Some((TermFactor { args, divisor: 1 }, sign))
            }

            // Parenthesized: unwrap
            Expression::ParenthesizedExpression(paren) => Self::try_parse_factor(&paren.expression),

            _ => None,
        }
    }

    /// Extracts accessor args from an expression (unwraps calls, negations, parens)
    fn extract_accessor_args_from_expr(expr: &Expression) -> Option<(i32, i32)> {
        match expr {
            Expression::CallExpression(call) => Self::extract_accessor_args(call),
            Expression::ParenthesizedExpression(paren) => {
                Self::extract_accessor_args_from_expr(&paren.expression)
            }
            Expression::UnaryExpression(un)
                if matches!(un.operator, UnaryOperator::UnaryNegation) =>
            {
                // Skip the negation - it's handled at coefficient level
                Self::extract_accessor_args_from_expr(&un.argument)
            }
            _ => None,
        }
    }

    /// Extracts accessor arguments from a call: `parseInt(accessor(arg1, arg2))` or `accessor(arg1, arg2)`
    fn extract_accessor_args(call: &CallExpression) -> Option<(i32, i32)> {
        // Check if this is parseInt wrapping an accessor call
        if matches!(&call.callee, Expression::Identifier(_)) && call.arguments.len() == 1 {
            if let Some(arg_expr) = call.arguments.first()?.as_expression() {
                if let Expression::CallExpression(inner_call) = arg_expr {
                    return Self::extract_two_args(inner_call);
                }
            }
        }

        // Or it could be a direct accessor call
        Self::extract_two_args(call)
    }

    /// Extracts numeric arguments from a call expression (1 or 2 args)
    fn extract_two_args(call: &CallExpression) -> Option<(i32, i32)> {
        if call.arguments.is_empty() || call.arguments.len() > 2 {
            return None;
        }

        let arg1 = Self::extract_numeric_arg(&call.arguments[0])?;

        // Handle both 1-arg and 2-arg calls
        let arg2 = if call.arguments.len() == 2 {
            Self::extract_numeric_arg(&call.arguments[1])?
        } else {
            0 // Second arg defaults to 0 for single-argument calls
        };

        Some((arg1, arg2))
    }

    /// Extracts a numeric value from an argument (handles negation)
    fn extract_numeric_arg(arg: &Argument) -> Option<i32> {
        Self::evaluate_constant_expression(arg.as_expression()?)
    }

    /// Recursively evaluates constant arithmetic expressions
    pub fn evaluate_constant_expression(expr: &Expression) -> Option<i32> {
        match expr {
            Expression::NumericLiteral(num) => Some(num.value as i32),
            Expression::UnaryExpression(un)
                if matches!(un.operator, UnaryOperator::UnaryNegation) =>
            {
                let inner = Self::evaluate_constant_expression(&un.argument)?;
                Some(-inner)
            }
            Expression::BinaryExpression(bin) => {
                let left = Self::evaluate_constant_expression(&bin.left)?;
                let right = Self::evaluate_constant_expression(&bin.right)?;

                match bin.operator {
                    BinaryOperator::Addition => Some(left + right),
                    BinaryOperator::Subtraction => Some(left - right),
                    BinaryOperator::Multiplication => Some(left * right),
                    BinaryOperator::Division => Some(left / right),
                    _ => None,
                }
            }
            _ => None,
        }
    }
}
