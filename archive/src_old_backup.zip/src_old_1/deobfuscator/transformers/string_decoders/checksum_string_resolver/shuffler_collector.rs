//! Shuffler collector for detecting IIFE shufflers
//!
//! This module detects shuffler IIFEs and extracts their target values and accessor functions.

use oxc::{
    ast::ast::{BinaryOperator, CallExpression, Expression, FunctionBody, Statement},
    semantic::SymbolId,
};
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::FxHashMap;
use rustc_hash::FxHashSet;

use super::arithmetic_parser::ArithmeticParser;
use super::data_structures::{EvalTerm, ShufflerInfo};

/// Collects shuffler IIFEs and their target values
#[derive(Default)]
pub struct ShufflerCollector {
    /// Maps array symbol -> shuffler info
    pub shufflers: FxHashMap<SymbolId, ShufflerInfo>,
    /// Set of accessor function symbols found in shufflers
    pub accessor_functions: FxHashSet<SymbolId>,
}

impl<'a> Traverse<'a, ()> for ShufflerCollector {
    fn enter_call_expression(
        &mut self,
        node: &mut CallExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        self.detect_shuffler_pattern(node, ctx);
    }
}

impl ShufflerCollector {
    /// Detects the shuffler pattern:
    /// ```js
    /// (function(r, v) { /* body with if (TARGET === expr) */ })(arrayFunc)
    /// ```
    pub fn detect_shuffler_pattern(&mut self, call: &CallExpression, ctx: &TraverseCtx<'_, ()>) {
        // Check if callee is a function expression with exactly 2 parameters
        let func = match &call.callee {
            Expression::FunctionExpression(f) => f,
            Expression::ParenthesizedExpression(paren) => {
                if let Expression::FunctionExpression(f) = &paren.expression {
                    f
                } else {
                    return;
                }
            }
            _ => return,
        };

        // Must have exactly 2 parameters
        if func.params.items.len() != 2 {
            return;
        }

        // Must have exactly 1 argument (the array function)
        if call.arguments.len() != 1 {
            return;
        }

        // Extract array function symbol from the argument
        let array_symbol = match call.arguments[0].as_expression() {
            Some(Expression::Identifier(ident)) => ident
                .reference_id
                .get()
                .and_then(|rid| ctx.scoping().get_reference(rid).symbol_id()),
            _ => return,
        };

        let Some(array_sym) = array_symbol else {
            return;
        };

        // Parse the function body to extract target value and accessor function
        let Some(body) = &func.body else {
            return;
        };

        if let Some(shuffler_info) = self.parse_shuffler_body(body, ctx) {
            self.shufflers.insert(array_sym, shuffler_info);
        }
    }

    /// Parses the shuffler function body to extract:
    /// - Target value from: `if (TARGET === expr)`
    /// - Accessor function from parseInt calls
    /// - Arithmetic expression terms
    fn parse_shuffler_body(
        &mut self,
        body: &FunctionBody,
        ctx: &TraverseCtx<'_, ()>,
    ) -> Option<ShufflerInfo> {
        let mut target_value: Option<i64> = None;
        let mut accessor_symbol: Option<SymbolId> = None;
        let mut eval_terms: Vec<EvalTerm> = Vec::new();

        // Scan all statements looking for the if condition
        for stmt in &body.statements {
            self.scan_for_condition(
                stmt,
                &mut target_value,
                &mut accessor_symbol,
                &mut eval_terms,
                ctx,
            );
            if target_value.is_some() {
                break;
            }
        }

        let target = target_value?;

        Some(ShufflerInfo {
            target_value: target,
            accessor_function: accessor_symbol,
            eval_terms,
        })
    }

    /// Recursively scans statements for the `if (TARGET === expr)` pattern
    fn scan_for_condition(
        &mut self,
        stmt: &Statement,
        target_value: &mut Option<i64>,
        accessor_symbol: &mut Option<SymbolId>,
        eval_terms: &mut Vec<EvalTerm>,
        ctx: &TraverseCtx<'_, ()>,
    ) {
        match stmt {
            Statement::ForStatement(for_stmt) => {
                self.scan_for_condition(
                    &for_stmt.body,
                    target_value,
                    accessor_symbol,
                    eval_terms,
                    ctx,
                );
            }
            Statement::BlockStatement(block) => {
                for s in &block.body {
                    self.scan_for_condition(s, target_value, accessor_symbol, eval_terms, ctx);
                    if target_value.is_some() {
                        break;
                    }
                }
            }
            Statement::TryStatement(try_stmt) => {
                for s in &try_stmt.block.body {
                    self.scan_for_condition(s, target_value, accessor_symbol, eval_terms, ctx);
                    if target_value.is_some() {
                        break;
                    }
                }
            }
            Statement::IfStatement(if_stmt) => {
                // Check the condition for: TARGET === expr
                if let Expression::BinaryExpression(bin) = &if_stmt.test {
                    if matches!(bin.operator, BinaryOperator::StrictEquality) {
                        // Target is on the left, arithmetic on the right
                        if let Expression::NumericLiteral(num) = &bin.left {
                            *target_value = Some(num.value as i64);
                            *eval_terms = ArithmeticParser::parse_to_eval_terms(&bin.right, 1);
                            *accessor_symbol = self.extract_accessor_from_expr(&bin.right, ctx);
                        }
                        // Target is on the right, arithmetic on the left
                        else if let Expression::NumericLiteral(num) = &bin.right {
                            *target_value = Some(num.value as i64);
                            *eval_terms = ArithmeticParser::parse_to_eval_terms(&bin.left, 1);
                            *accessor_symbol = self.extract_accessor_from_expr(&bin.left, ctx);
                        }
                    }
                }
            }
            _ => {}
        }
    }

    /// Extracts the accessor function symbol from an arithmetic expression
    /// Looks for calls like `_Hs(...)` or `parseInt(_Hs(...))`
    fn extract_accessor_from_expr(
        &mut self,
        expr: &Expression,
        ctx: &TraverseCtx<'_, ()>,
    ) -> Option<SymbolId> {
        match expr {
            Expression::CallExpression(call) => {
                // Check for direct accessor call: _Hs(...)
                if let Expression::Identifier(ident) = &call.callee {
                    let sym = ident
                        .reference_id
                        .get()
                        .and_then(|rid| ctx.scoping().get_reference(rid).symbol_id());
                    if let Some(s) = sym {
                        self.accessor_functions.insert(s);
                        return Some(s);
                    }
                }

                // Check for parseInt(_Hs(...))
                if let Some(arg) = call.arguments.first() {
                    if let Some(arg_expr) = arg.as_expression() {
                        return self.extract_accessor_from_expr(arg_expr, ctx);
                    }
                }
            }
            Expression::BinaryExpression(bin) => {
                // Recursively check both sides
                if let Some(sym) = self.extract_accessor_from_expr(&bin.left, ctx) {
                    return Some(sym);
                }
                return self.extract_accessor_from_expr(&bin.right, ctx);
            }
            Expression::UnaryExpression(un) => {
                return self.extract_accessor_from_expr(&un.argument, ctx);
            }
            Expression::ParenthesizedExpression(paren) => {
                return self.extract_accessor_from_expr(&paren.expression, ctx);
            }
            _ => {}
        }
        None
    }
}
