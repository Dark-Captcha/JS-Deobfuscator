//! Accessor collector for extracting accessor function information
//!
//! This module collects accessor function info including offsets and base64 decoder detection.

use oxc::{
    ast::ast::{AssignmentOperator, BinaryOperator, Expression, Function, Statement},
    semantic::SymbolId,
};
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::FxHashMap;
use rustc_hash::FxHashSet;

use super::data_structures::AccessorInfo;
use crate::deobfuscator::transformers::shared_utils::string_search::StringSearcher;

/// Collects accessor function information
#[derive(Default)]
pub struct AccessorCollector {
    pub target_symbols: FxHashSet<SymbolId>,
    pub accessors: FxHashMap<SymbolId, AccessorInfo>,
}

impl<'a> Traverse<'a, ()> for AccessorCollector {
    fn enter_function(&mut self, func: &mut Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        if let Some(id) = &func.id {
            if let Some(symbol_id) = id.symbol_id.get() {
                if self.target_symbols.contains(&symbol_id) {
                    let offset = Self::extract_offset_from_accessor(func);
                    let has_base64_decoder = Self::detect_base64_decoder(func);

                    if let Some(offset) = offset {
                        self.accessors.insert(
                            symbol_id,
                            super::data_structures::AccessorInfo {
                                offset,
                                has_base64_decoder,
                            },
                        );
                    }
                }
            }
        }
    }
}

impl AccessorCollector {
    /// Detects if a function contains a base64 decoder
    /// by checking for the base64 alphabet string
    fn detect_base64_decoder(func: &Function) -> bool {
        const BASE64_ALPHABET: &str =
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";

        let body = func.body.as_ref();
        if body.is_none() {
            return false;
        }

        // Simple check: recursively search for string literals containing the base64 alphabet
        if let Some(body) = body {
            StringSearcher::search_in_statements(&body.statements, BASE64_ALPHABET)
        } else {
            false
        }
    }

    /// Extracts offset from accessor function by recursively searching for patterns:
    /// - `arr[idx -= offset]`
    /// - `arr[idx - offset]`
    fn extract_offset_from_accessor(func: &Function) -> Option<i32> {
        let body = func.body.as_ref()?;

        // Recursively search all statements for computed member expressions
        for stmt in &body.statements {
            if let Some(offset) = Self::search_statement_for_offset(stmt) {
                return Some(offset);
            }
        }

        None
    }

    /// Recursively searches a statement for offset patterns
    fn search_statement_for_offset(stmt: &Statement) -> Option<i32> {
        match stmt {
            Statement::ReturnStatement(ret) => ret
                .argument
                .as_ref()
                .and_then(|expr| Self::search_expression_for_offset(expr)),
            Statement::VariableDeclaration(var_decl) => {
                for decl in &var_decl.declarations {
                    if let Some(init) = &decl.init {
                        if let Some(offset) = Self::search_expression_for_offset(init) {
                            return Some(offset);
                        }
                    }
                }
                None
            }
            Statement::ExpressionStatement(expr_stmt) => {
                Self::search_expression_for_offset(&expr_stmt.expression)
            }
            Statement::BlockStatement(block) => {
                for s in &block.body {
                    if let Some(offset) = Self::search_statement_for_offset(s) {
                        return Some(offset);
                    }
                }
                None
            }
            _ => None,
        }
    }

    /// Recursively searches an expression for offset patterns
    fn search_expression_for_offset(expr: &Expression) -> Option<i32> {
        match expr {
            // Pattern: arr[idx -= offset] or arr[idx += offset]
            Expression::ComputedMemberExpression(mem) => {
                if let Expression::AssignmentExpression(assign) = &mem.expression {
                    match assign.operator {
                        AssignmentOperator::Subtraction => {
                            if let Expression::NumericLiteral(num) = &assign.right {
                                return Some(-(num.value as i32));
                            }
                        }
                        AssignmentOperator::Addition => {
                            if let Expression::NumericLiteral(num) = &assign.right {
                                return Some(num.value as i32);
                            }
                        }
                        _ => {}
                    }
                }
                // Pattern: arr[idx - offset]
                else if let Expression::BinaryExpression(bin) = &mem.expression {
                    if matches!(bin.operator, BinaryOperator::Subtraction) {
                        if let Expression::NumericLiteral(num) = &bin.right {
                            return Some(-(num.value as i32));
                        }
                    } else if matches!(bin.operator, BinaryOperator::Addition) {
                        if let Expression::NumericLiteral(num) = &bin.right {
                            return Some(num.value as i32);
                        }
                    }
                }
                // Recursively search the expression (might be wrapped)
                else {
                    return Self::search_expression_for_offset(&mem.expression);
                }
                None
            }

            // Recursively search nested expressions
            Expression::CallExpression(call) => {
                // Check callee (for self-modifying pattern)
                if let Some(offset) = Self::search_expression_for_offset(&call.callee) {
                    return Some(offset);
                }
                // Check arguments
                for arg in &call.arguments {
                    if let Some(arg_expr) = arg.as_expression() {
                        if let Some(offset) = Self::search_expression_for_offset(arg_expr) {
                            return Some(offset);
                        }
                    }
                }
                None
            }

            Expression::ParenthesizedExpression(paren) => {
                Self::search_expression_for_offset(&paren.expression)
            }

            Expression::AssignmentExpression(assign) => {
                // Extract offset from compound assignment: _v2 -= 225 or _v2 += 225
                match assign.operator {
                    AssignmentOperator::Subtraction => {
                        if let Expression::NumericLiteral(num) = &assign.right {
                            return Some(-(num.value as i32));
                        }
                    }
                    AssignmentOperator::Addition => {
                        if let Expression::NumericLiteral(num) = &assign.right {
                            return Some(num.value as i32);
                        }
                    }
                    _ => {}
                }
                // If not a compound assignment with numeric literal, search the right side
                Self::search_expression_for_offset(&assign.right)
            }

            Expression::FunctionExpression(func) => Self::extract_offset_from_accessor(func),

            _ => None,
        }
    }
}
