//! Checksum String Resolver
//!
//! Resolves rotated string arrays by solving checksum conditions.

use anyhow::Result;
use oxc::{
    allocator::Allocator,
    ast::ast::Program,
    semantic::{Scoping, SymbolId},
};
use oxc_traverse::traverse_mut;
use rustc_hash::FxHashMap;
use rustc_hash::FxHashSet;

pub struct StringArrayRotator;

impl<'a> Transformer<'a> for StringArrayRotator {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping> {
        let mut collector = shuffler_collector::ShufflerCollector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        let mut array_collector = array_collector::ArrayCollector {
            target_symbols: collector.shufflers.keys().copied().collect(),
            arrays: FxHashMap::default(),
        };
        let scoping = traverse_mut(&mut array_collector, allocator, program, scoping, ());

        let mut accessor_collector = accessor_collector::AccessorCollector {
            target_symbols: collector.accessor_functions.clone(),
            accessors: FxHashMap::default(),
        };
        let scoping = traverse_mut(&mut accessor_collector, allocator, program, scoping, ());

        let mut rotated_arrays: FxHashMap<SymbolId, Vec<String>> = FxHashMap::default();

        for (array_sym, shuffler_info) in &collector.shufflers {
            if let (Some(array), Some(accessor_sym)) = (
                array_collector.arrays.get(array_sym),
                shuffler_info.accessor_function,
            ) {
                if let Some(accessor_info) = accessor_collector.accessors.get(&accessor_sym) {
                    let rotation = rotation_resolver::find_rotation(
                        array,
                        accessor_info.offset,
                        shuffler_info.target_value,
                        &shuffler_info.eval_terms,
                        accessor_info.has_base64_decoder,
                    );

                    if let Some(rotation_amount) = rotation {
                        let rotated = rotation_resolver::rotate_array(array, rotation_amount);
                        rotated_arrays.insert(*array_sym, rotated);
                    }
                }
            }
        }

        if !rotated_arrays.is_empty() {
            let accessor_to_array: FxHashMap<SymbolId, SymbolId> = collector
                .shufflers
                .iter()
                .filter_map(|(array_sym, info)| info.accessor_function.map(|acc| (acc, *array_sym)))
                .collect();

            let accessor_symbols: FxHashSet<SymbolId> =
                accessor_collector.accessors.keys().copied().collect();

            let mut inliner = accessor_inliner::AccessorInliner {
                rotated_arrays,
                accessor_info: accessor_collector.accessors,
                accessor_to_array,
            };
            let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

            let mut symbols_to_remove: FxHashSet<SymbolId> =
                collector.shufflers.keys().copied().collect();
            symbols_to_remove.extend(accessor_symbols);

            let mut name_collector = dead_code_cleaner::FunctionNameCollector {
                target_symbols: collector.shufflers.keys().copied().collect(),
                names: FxHashSet::default(),
            };
            let scoping = traverse_mut(&mut name_collector, allocator, program, scoping, ());

            let mut cleaner = dead_code_cleaner::DeadCodeCleaner {
                symbols_to_remove,
                array_function_names: name_collector.names,
            };
            let scoping = traverse_mut(&mut cleaner, allocator, program, scoping, ());
            return Ok(scoping);
        }

        Ok(scoping)
    }
}

use crate::deobfuscator::transformers::Transformer;

mod accessor_collector;
mod accessor_inliner;
mod arithmetic_parser;
mod array_collector;
mod data_structures;
mod dead_code_cleaner;
mod rotation_resolver;
mod shuffler_collector;
mod string_decoder;
