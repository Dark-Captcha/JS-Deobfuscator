//! Dead code cleaner for removing unused functions and shufflers
//!
//! This module removes dead code including array functions, accessor functions,
//! and shuffler IIFEs after they've been inlined.

use oxc::{
    allocator::Vec as ArenaVec,
    ast::ast::{CallExpression, Expression, Function, Statement, UnaryOperator},
    semantic::SymbolId,
};
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::FxHashSet;

/// Collects function names for dead code detection
#[derive(Default)]
pub struct FunctionNameCollector {
    pub target_symbols: FxHashSet<SymbolId>,
    pub names: FxHashSet<String>,
}

/// Removes dead code including functions and shuffler IIFEs
#[derive(Default)]
pub struct DeadCodeCleaner {
    pub symbols_to_remove: FxHashSet<SymbolId>,
    pub array_function_names: FxHashSet<String>,
}

impl<'a> Traverse<'a, ()> for FunctionNameCollector {
    fn enter_function(&mut self, func: &mut Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        if let Some(id) = &func.id {
            if let Some(symbol_id) = id.symbol_id.get() {
                if self.target_symbols.contains(&symbol_id) {
                    self.names.insert(id.name.to_string());
                }
            }
        }
    }
}

impl<'a> Traverse<'a, ()> for DeadCodeCleaner {
    fn enter_statements(
        &mut self,
        stmts: &mut ArenaVec<'a, Statement<'a>>,
        _ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Remove statements that match our criteria
        stmts.retain(|stmt| {
            match stmt {
                // Remove function declarations for array/accessor functions
                Statement::FunctionDeclaration(func) => {
                    if let Some(id) = &func.id {
                        if let Some(symbol_id) = id.symbol_id.get() {
                            if self.symbols_to_remove.contains(&symbol_id) {
                                return false; // Remove this statement
                            }
                        }
                    }
                    true // Keep
                }

                // Remove shuffler IIFEs: !(function(...){...})(arrayFunc); or (function(...){...})(arrayFunc);
                Statement::ExpressionStatement(expr_stmt) => {
                    // Helper to check if a CallExpression is a shuffler IIFE
                    let is_shuffler_iife = |call: &CallExpression| -> bool {
                        // Check if the call argument is an identifier referencing an array function
                        if let Some(arg) = call.arguments.first() {
                            if let Some(arg_expr) = arg.as_expression() {
                                if let Expression::Identifier(ident) = arg_expr {
                                    return self.array_function_names.contains(ident.name.as_str());
                                }
                            }
                        }
                        false
                    };

                    // Pattern 1: !(function(...){...})(arrayFunc)
                    if let Expression::UnaryExpression(unary) = &expr_stmt.expression {
                        if matches!(unary.operator, UnaryOperator::LogicalNot) {
                            if let Expression::CallExpression(call) = &unary.argument {
                                if is_shuffler_iife(call) {
                                    return false; // Remove
                                }
                            }
                        }
                    }

                    // Pattern 2: (function(...){...})(arrayFunc)
                    if let Expression::CallExpression(call) = &expr_stmt.expression {
                        if is_shuffler_iife(call) {
                            return false; // Remove
                        }
                    }

                    true // Keep
                }

                _ => true, // Keep all other statements
            }
        });
    }
}
