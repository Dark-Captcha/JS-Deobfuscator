//! Data structures for checksum string resolver
//!
//! This module contains all the data structures used throughout the checksum
//! string resolution process.

use oxc::semantic::SymbolId;

/// Information about a detected shuffler IIFE
#[derive(Debug, Clone)]
pub struct ShufflerInfo {
    /// The target value to match (e.g., 238433)
    pub target_value: i64,
    /// The accessor function symbol (e.g., _Hs)
    pub accessor_function: Option<SymbolId>,
    /// The arithmetic terms to evaluate and sum
    pub eval_terms: Vec<EvalTerm>,
}

/// A term in the arithmetic expression to evaluate
/// Represents: `coefficient * product_of_factors`
#[derive(Debug, Clone)]
pub struct EvalTerm {
    /// Factors to multiply together (each is parseInt(accessor(args)) / divisor)
    pub factors: Vec<TermFactor>,
    /// Coefficient (handles sign and any scalar multiplication)
    pub coefficient: i64,
}

/// A single factor in a term product
#[derive(Debug, Clone)]
pub struct TermFactor {
    /// Arguments to pass to the accessor function
    pub args: (i32, i32),
    /// Divisor to apply after parsing the string
    pub divisor: i32,
}

/// Information about an accessor function
#[derive(Debug, Clone)]
pub struct AccessorInfo {
    /// The offset applied to the index (e.g., -225 from `v -= 225`)
    pub offset: i32,
    /// Whether this accessor has a base64 decoder
    pub has_base64_decoder: bool,
}

// Note: The actual collector structs are defined in their respective modules:
// - ShufflerCollector is in shuffler_collector.rs
// - ArrayCollector is in array_collector.rs
// - AccessorCollector is in accessor_collector.rs
// - AccessorInliner is in accessor_inliner.rs
// - FunctionNameCollector is in dead_code_cleaner.rs
// - DeadCodeCleaner is in dead_code_cleaner.rs
