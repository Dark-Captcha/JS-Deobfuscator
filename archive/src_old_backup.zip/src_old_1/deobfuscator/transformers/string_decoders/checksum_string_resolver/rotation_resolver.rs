//! Rotation resolver for finding correct array rotations
//!
//! This module resolves the correct rotation amount by simulating the shuffler logic.

use super::data_structures::EvalTerm;
use super::string_decoder::StringDecoder;

/// Finds the rotation amount by simulating the shuffler logic
/// Returns the number of rotations needed to match the target value
pub fn find_rotation(
    array: &[String],
    accessor_offset: i32,
    target_value: i64,
    eval_terms: &[EvalTerm],
    has_base64_decoder: bool,
) -> Option<usize> {
    // Create a mutable copy for rotation
    let mut rotated = array.to_vec();

    // Try rotations from 0 to array.len()
    let mut rotation = 0;
    loop {
        // Rotate FIRST (simulates n.push(n.shift()) at start of loop)
        if rotation > 0 && rotation <= array.len() {
            let first = rotated.remove(0);
            rotated.push(first);
        }

        // Then calculate checksum on rotated array
        let (checksum, _term_values) = evaluate_checksum_direct_with_terms(
            &rotated,
            accessor_offset,
            eval_terms,
            has_base64_decoder,
        );

        if checksum == target_value {
            break;
        }

        rotation += 1;
    }

    Some(rotation)
}

/// Evaluates the checksum on a (possibly rotated) array, returning (checksum, term_values)
fn evaluate_checksum_direct_with_terms(
    array: &[String],
    accessor_offset: i32,
    eval_terms: &[EvalTerm],
    has_base64_decoder: bool,
) -> (i64, Vec<i64>) {
    let mut sum: i64 = 0;
    let mut term_values = Vec::new();

    for term in eval_terms.iter() {
        let mut product: i64 = term.coefficient;

        for factor in term.factors.iter() {
            // Use the FIRST argument (args.0) as the index (the accessor modifies this param)
            let index = factor.args.0;

            // Apply accessor offset (NO rotation here - array is already rotated)
            let raw_index = index + accessor_offset;

            // Handle negative indices using modulo arithmetic
            let array_len = array.len() as i32;
            let adjusted_index = ((raw_index % array_len) + array_len) % array_len;
            let adjusted_index = adjusted_index as usize;

            // Get string from array (with bounds checking)
            if adjusted_index >= array.len() {
                product = 0;
                break;
            }

            let string_val = &array[adjusted_index];

            // Decode base64 if needed, then URL decode
            let final_val = if has_base64_decoder {
                let decoded = StringDecoder::decode_custom_base64(string_val);
                StringDecoder::url_decode(&decoded)
            } else {
                string_val.clone()
            };

            // Parse the string as an integer using JavaScript parseInt behavior
            let parsed = StringDecoder::parse_int_js(&final_val);

            // Divide by divisor
            let factor_value = parsed / (factor.divisor as i64);
            product *= factor_value;
        }

        term_values.push(product);
        sum += product;
    }

    (sum, term_values)
}

/// Rotates an array by pushing and shifting elements
pub fn rotate_array(array: &[String], amount: usize) -> Vec<String> {
    let mut rotated = array.to_vec();

    for _ in 0..amount {
        let first = rotated.remove(0);
        rotated.push(first);
    }

    rotated
}
