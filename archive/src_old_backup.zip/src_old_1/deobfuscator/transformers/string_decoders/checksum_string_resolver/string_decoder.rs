//! String decoder utilities for base64 and URL decoding
//!
//! This module provides utilities for decoding base64 and URL-encoded strings
//! used in the checksum string resolver.

/// String decoder implementation
pub struct StringDecoder;

impl StringDecoder {
    /// Custom base64 decoder matching the obfuscated JavaScript implementation
    pub fn decode_custom_base64(encoded: &str) -> String {
        const ALPHABET: &str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=";

        let mut decoded = String::new();
        let chars: Vec<char> = encoded.chars().collect();
        let mut i = 0;

        while i < chars.len() {
            let idx1 = ALPHABET.find(chars[i]).unwrap_or(0);
            i += 1;
            if i >= chars.len() {
                // Partial chunk - decode what we have
                let b1 = idx1 << 2;
                decoded.push(b1 as u8 as char);
                break;
            }

            let idx2 = ALPHABET.find(chars[i]).unwrap_or(0);
            i += 1;
            let b1 = (idx1 << 2) | (idx2 >> 4);
            decoded.push(b1 as u8 as char);
            if i >= chars.len() {
                break;
            }

            let idx3 = ALPHABET.find(chars[i]).unwrap_or(0);
            i += 1;
            let b2 = ((idx2 & 15) << 4) | (idx3 >> 2);
            if idx3 != 64 {
                decoded.push(b2 as u8 as char);
            }
            if i >= chars.len() {
                break;
            }

            let idx4 = ALPHABET.find(chars[i]).unwrap_or(0);
            i += 1;
            let b3 = ((idx3 & 3) << 6) | idx4;
            if idx4 != 64 {
                decoded.push(b3 as u8 as char);
            }
        }

        // URL decode (percent encoding)
        Self::url_decode(&decoded)
    }

    /// Simple URL decoder for percent-encoded strings
    pub fn url_decode(s: &str) -> String {
        let mut result = String::new();
        let chars: Vec<char> = s.chars().collect();
        let mut i = 0;

        while i < chars.len() {
            if chars[i] == '%' && i + 2 < chars.len() {
                // Parse hex digits
                let hex = format!("{}{}", chars[i + 1], chars[i + 2]);
                if let Ok(byte) = u8::from_str_radix(&hex, 16) {
                    result.push(byte as char);
                    i += 3;
                    continue;
                }
            }
            result.push(chars[i]);
            i += 1;
        }

        result
    }

    /// Mimics JavaScript's parseInt behavior: extracts LEADING digits only
    /// Examples:
    /// - "4082499gawKnJ" -> 4082499
    /// - "123abc" -> 123  
    /// - "abc123" -> 0 (no leading digits)
    pub fn parse_int_js(s: &str) -> i64 {
        let trimmed = s.trim_start();

        // Handle sign
        let (is_negative, start_pos) = if trimmed.starts_with('-') {
            (true, 1)
        } else if trimmed.starts_with('+') {
            (false, 1)
        } else {
            (false, 0)
        };

        // Extract leading digits
        let mut end_pos = start_pos;
        for (i, ch) in trimmed[start_pos..].char_indices() {
            if ch.is_ascii_digit() {
                end_pos = start_pos + i + 1;
            } else {
                break;
            }
        }

        // If no digits found, return 0
        if end_pos == start_pos {
            return 0;
        }

        // Parse the digit substring
        let digit_str = &trimmed[start_pos..end_pos];
        let value = digit_str.parse::<i64>().unwrap_or(0);

        if is_negative { -value } else { value }
    }
}
