use oxc::{
    allocator::Box as ArenaBox,
    allocator::{Allocator, CloneIn},
    ast::ast::{Expression, Program, StaticMemberExpression},
    semantic::Scoping,
};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};

use crate::deobfuscator::transformers::Transformer;

/// Converts computed member access to static member access safely.
pub struct MemberConverter;

impl<'a> Transformer<'a> for MemberConverter {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> anyhow::Result<Scoping> {
        let mut pass = MemberConverterPass;
        let scoping = traverse_mut(&mut pass, allocator, program, scoping, ());
        Ok(scoping)
    }
}

struct MemberConverterPass;

impl<'a> Traverse<'a, ()> for MemberConverterPass {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let _converted = try_convert_computed_member_to_static(expr, ctx);
    }
}

/// Attempts to convert a `ComputedMemberExpression` like `obj["prop"]` or `obj[`prop`]`
/// into a `StaticMemberExpression` `obj.prop` when it is safe. Returns true if converted.
fn try_convert_computed_member_to_static<'a>(
    expr: &mut Expression<'a>,
    ctx: &mut TraverseCtx<'a, ()>,
) -> bool {
    if let Expression::ComputedMemberExpression(member) = expr {
        // Plain string literal: obj["prop"]
        if let Expression::StringLiteral(lit) = &member.expression {
            let property_name = lit.value.as_str();
            if is_valid_identifier_name(property_name) {
                let new_member = StaticMemberExpression {
                    span: member.span,
                    object: member.object.clone_in(ctx.ast.allocator),
                    property: ctx
                        .ast
                        .identifier_name(lit.span, ctx.ast.allocator.alloc_str(property_name)),
                    optional: member.optional,
                };
                *expr = Expression::StaticMemberExpression(ArenaBox::new_in(
                    new_member,
                    ctx.ast.allocator,
                ));
                return true;
            }
        }

        // Template literal without expressions: obj[`prop`]
        if let Expression::TemplateLiteral(tpl) = &member.expression {
            if tpl.expressions.is_empty() && tpl.quasis.len() == 1 {
                let cooked = tpl.quasis[0].value.cooked.as_ref().map(|a| a.as_str());
                let raw = cooked.unwrap_or_else(|| tpl.quasis[0].value.raw.as_str());
                if is_valid_identifier_name(raw) {
                    let new_member = StaticMemberExpression {
                        span: member.span,
                        object: member.object.clone_in(ctx.ast.allocator),
                        property: ctx
                            .ast
                            .identifier_name(tpl.span, ctx.ast.allocator.alloc_str(raw)),
                        optional: member.optional,
                    };
                    *expr = Expression::StaticMemberExpression(ArenaBox::new_in(
                        new_member,
                        ctx.ast.allocator,
                    ));
                    return true;
                }
            }
        }
    }
    false
}

/// Validates if a string is a valid JavaScript identifier name
fn is_valid_identifier_name(name: &str) -> bool {
    let bytes = name.as_bytes();
    if bytes.is_empty() {
        return false;
    }

    let first = bytes[0] as char;
    if !(first == '_' || first == '$' || first.is_ascii_alphabetic()) {
        return false;
    }

    if !bytes[1..].iter().all(|b| {
        let c = *b as char;
        c == '_' || c == '$' || c.is_ascii_alphanumeric()
    }) {
        return false;
    }

    const RESERVED: &[&str] = &[
        "break",
        "case",
        "catch",
        "class",
        "const",
        "continue",
        "debugger",
        "default",
        "delete",
        "do",
        "else",
        "export",
        "extends",
        "finally",
        "for",
        "function",
        "if",
        "import",
        "in",
        "instanceof",
        "new",
        "return",
        "super",
        "switch",
        "this",
        "throw",
        "try",
        "typeof",
        "var",
        "void",
        "while",
        "with",
        "yield",
        "let",
        "static",
        "implements",
        "interface",
        "package",
        "private",
        "protected",
        "public",
        "enum",
        "await",
        "null",
        "true",
        "false",
    ];

    !RESERVED.contains(&name)
}
