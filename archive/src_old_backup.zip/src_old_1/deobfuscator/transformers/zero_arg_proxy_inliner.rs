use anyhow::Result;
use oxc::{
    allocator::{Allocator, CloneIn, Vec as ArenaVec},
    ast::ast::{
        BinaryOperator, CallExpression, Expression, Function, Program, Statement, UnaryOperator,
    },
    semantic::{Scoping, SymbolId},
};

use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::deobfuscator::transformers::Transformer;
use crate::deobfuscator::transformers::shared_utils::ast_utils::AstUtils;
use crate::deobfuscator::transformers::shared_utils::safety_checker::SafetyChecker;
use oxc::ast::AstBuilder;
use oxc::codegen::{Codegen, CodegenOptions};

/// Inlines zero-argument proxy functions that return simple expressions.
///
/// This transformer follows a 3-pass pattern:
/// 1. Collect: Find eligible proxy functions (zero args, single return)
/// 2. Inline: Replace function calls with their return expressions
/// 3. Clean: Remove unused function declarations
pub struct ProxyFunctionInliner;

impl<'a> Transformer<'a> for ProxyFunctionInliner {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping> {
        // Pass 1: Collect proxy functions
        let mut collector = ProxyCollector {
            proxies: FxHashMap::default(),
            func_srcs: FxHashMap::default(),
            source_text: program.source_text,
            program_span: program.span,
            program_source_type: program.source_type,
        };
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        if collector.proxies.is_empty() {
            return Ok(scoping);
        }

        // Pass 2: Inline function calls
        let mut inliner = ProxyInliner {
            proxies: collector.proxies,
            func_srcs: collector.func_srcs,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        // Pass 3: Remove unused declarations
        let mut cleaner = ProxyCleaner {
            symbols: inliner.proxies.keys().cloned().map(|k| (k, ())).collect(),
        };
        let scoping = traverse_mut(&mut cleaner, allocator, program, scoping, ());

        Ok(scoping)
    }
}

/// Collects eligible proxy functions for inlining
struct ProxyCollector<'a> {
    /// Maps function symbol IDs to their return expressions
    proxies: FxHashMap<SymbolId, Expression<'a>>,
    /// Zero-arg function declarations for possible function-expression replacement
    /// Pre-stringified function sources for zero-arg functions
    func_srcs: FxHashMap<SymbolId, &'a str>,
    /// Full source text for span slicing
    source_text: &'a str,
    /// Program span for codegen
    program_span: oxc::span::Span,
    /// Program source type for codegen
    program_source_type: oxc::span::SourceType,
}

impl<'a> Traverse<'a, ()> for ProxyCollector<'a> {
    fn enter_function(&mut self, node: &mut Function<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Collect any zero-argument function
        if self.is_eligible_proxy(node) {
            if let Some(symbol_id) = node.id.as_ref().and_then(|id| id.symbol_id.get()) {
                // Generate the deobfuscated function using codegen
                let func_clone = node.clone_in(ctx.ast.allocator);
                let func_box = oxc::allocator::Box::new_in(func_clone, ctx.ast.allocator);
                let expr = Expression::FunctionExpression(func_box);
                let stmt = oxc::ast::ast::Statement::ExpressionStatement(
                    AstBuilder::new(ctx.ast.allocator).alloc_expression_statement(node.span, expr),
                );
                let directives: ArenaVec<'a, oxc::ast::ast::Directive<'a>> =
                    ArenaVec::new_in(ctx.ast.allocator);
                let mut body: ArenaVec<'a, oxc::ast::ast::Statement<'a>> =
                    ArenaVec::new_in(ctx.ast.allocator);
                body.push(stmt);
                let program = AstBuilder::new(ctx.ast.allocator).program(
                    self.program_span,
                    self.program_source_type,
                    self.source_text,
                    ArenaVec::new_in(ctx.ast.allocator),
                    None,
                    directives,
                    body,
                );
                let src = Codegen::new()
                    .with_options(CodegenOptions::default())
                    .build(&program)
                    .code;
                let interned = ctx.ast.allocator.alloc_str(&src);
                self.func_srcs.insert(symbol_id, interned);
            }
        } else {
            // Extract the return expression
            if let Some(return_expr) = self.extract_return_expression(node, ctx.ast.allocator) {
                if let Some(symbol_id) = node.id.as_ref().and_then(|id| id.symbol_id.get()) {
                    self.proxies.insert(symbol_id, return_expr);
                }
            }
        }
    }
}

impl<'a> ProxyCollector<'a> {
    /// Checks if a function is eligible for inlining
    fn is_eligible_proxy(&self, node: &Function<'a>) -> bool {
        // Must have an identifier
        node.id.is_some()
        // Must have zero parameters
        && node.params.parameters_count() == 0
    }

    /// Extracts the return expression from a proxy function
    fn extract_return_expression(
        &self,
        node: &Function<'a>,
        allocator: &'a Allocator,
    ) -> Option<Expression<'a>> {
        let body = node.body.as_ref()?;
        let stmt = body.statements.first()?;

        if let Statement::ReturnStatement(ret) = stmt {
            ret.argument.as_ref().map(|expr| expr.clone_in(allocator))
        } else {
            None
        }
    }
}

/// Inlines proxy function calls with their return expressions
struct ProxyInliner<'a> {
    /// Maps function symbol IDs to their return expressions
    proxies: FxHashMap<SymbolId, Expression<'a>>,
    /// Pre-stringified function sources for zero-arg functions
    func_srcs: FxHashMap<SymbolId, &'a str>,
}

impl<'a> Traverse<'a, ()> for ProxyInliner<'a> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Stringify bare identifier references to zero-arg functions for key mapping
        if let Expression::Identifier(ident) = expr {
            let reference_id = ident.reference_id();
            if let Some(symbol_id) = ctx.scoping().get_reference(reference_id).symbol_id() {
                if let Some(src) = self.func_srcs.get(&symbol_id) {
                    let builder = AstBuilder::new(ctx.ast.allocator);
                    let lit = builder.alloc_string_literal(
                        ident.span,
                        ctx.ast.allocator.alloc_str(src),
                        None,
                    );
                    *expr = Expression::StringLiteral(lit);
                    return;
                }
            }
        }

        if let Expression::CallExpression(call) = expr {
            let mut replacement_expr: Option<Expression<'a>> = None;

            // Inline zero-arg IIFE of function/arrow when body returns simple/safe expression
            if call.arguments.is_empty() {
                if let Some(inlined) = try_inline_iife(call, ctx) {
                    *expr = inlined;
                    return;
                }
            }

            // Attempt precise inlining for collected zero-arg proxies
            if call.arguments.is_empty() {
                if let Some(symbol_id) = self.resolve_callee_symbol(call, ctx.scoping()) {
                    if let Some(replacement) = self.proxies.get(&symbol_id) {
                        if is_inline_safe_extended(replacement) {
                            replacement_expr = Some(replacement.clone_in(ctx.ast.allocator));
                        } else if let Some(src) = self.func_srcs.get(&symbol_id) {
                            // Replace with a StringLiteral containing the real function source
                            let builder = AstBuilder::new(ctx.ast.allocator);
                            let lit = builder.alloc_string_literal(
                                call.span,
                                ctx.ast.allocator.alloc_str(src),
                                None,
                            );
                            replacement_expr = Some(Expression::StringLiteral(lit));
                        }
                    }
                }
            }

            // Last resort: replace with bare identifier (function reference)
            if replacement_expr.is_none() && call.arguments.is_empty() {
                if let Expression::Identifier(ident) = &call.callee {
                    let ident_ref = ident.clone_in(ctx.ast.allocator);
                    replacement_expr = Some(Expression::Identifier(ident_ref));
                }
            }

            if let Some(new_expr) = replacement_expr {
                *expr = new_expr;
            }
        }
    }
}

impl<'a> ProxyInliner<'a> {
    /// Resolves the symbol ID of a function call's callee
    fn resolve_callee_symbol(
        &self,
        call: &CallExpression<'a>,
        scoping: &Scoping,
    ) -> Option<SymbolId> {
        AstUtils::get_callee_symbol_id(call, scoping)
    }
}

/// Try to inline a zero-arg IIFE if its body returns a safe/simple expression.
fn try_inline_iife<'a>(
    call: &CallExpression<'a>,
    ctx: &mut TraverseCtx<'a, ()>,
    ) -> Option<Expression<'a>> {
    // Extract callee as a function/arrow possibly parenthesized
    let callee = match &call.callee {
        Expression::ParenthesizedExpression(p) => &p.expression,
        other => other,
    };

    if let Expression::FunctionExpression(func) = callee {
        if func.params.items.is_empty() {
            let body = func.body.as_ref()?;
            let ret_stmt = body.statements.first()?;
            if let Statement::ReturnStatement(ret) = ret_stmt {
                if let Some(arg) = &ret.argument {
                    if SafetyChecker::is_safe_to_inline(arg) || is_inline_safe_extended(arg) {
                        return Some(arg.clone_in(ctx.ast.allocator));
                    }
                }
            }
        }
    }
    None
}

/// Removes unused proxy function declarations after inlining
struct ProxyCleaner {
    /// Set of symbol IDs to remove
    symbols: FxHashMap<SymbolId, ()>,
}

impl<'a> Traverse<'a, ()> for ProxyCleaner {
    fn enter_statements(
        &mut self,
        stmts: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        stmts.retain(|stmt| {
            if let Statement::FunctionDeclaration(func) = stmt {
                if let Some(symbol_id) = func.id.as_ref().and_then(|id| id.symbol_id.get()) {
                    if self.symbols.contains_key(&symbol_id) {
                        // Only remove if function has no remaining resolved references
                        let mut any_ref = false;
                        for _ in ctx.scoping().get_resolved_references(symbol_id) {
                            any_ref = true;
                            break;
                        }
                        return any_ref;
                    }
                }
            }
            true
        });
    }
}

/// A slightly more permissive safety check tailored for proxy inlining.
///
/// This allows simple string concatenations and equality checks without
/// performing deep call purity analysis, which is sufficient for common
/// zero-arg proxy patterns encountered in obfuscated bundles.
fn is_inline_safe_extended(expr: &Expression) -> bool {
    match expr {
        // Basic literals and identifiers
        Expression::StringLiteral(_)
        | Expression::NumericLiteral(_)
        | Expression::BooleanLiteral(_)
        | Expression::NullLiteral(_)
        | Expression::Identifier(_) => true,

        // Safe member reads (e.g., window.prop or window["..."])
        Expression::StaticMemberExpression(_) | Expression::ComputedMemberExpression(_) => true,

        // Logical not of a simple expression
        Expression::UnaryExpression(unary)
            if matches!(unary.operator, UnaryOperator::LogicalNot)
                && is_inline_safe_extended(&unary.argument) =>
        {
            true
        }

        // Equality/inequality comparisons of simple expressions
        Expression::BinaryExpression(binary)
            if matches!(
                binary.operator,
                BinaryOperator::StrictEquality
                    | BinaryOperator::Equality
                    | BinaryOperator::StrictInequality
                    | BinaryOperator::Inequality
            ) && is_inline_safe_extended(&binary.left)
                && is_inline_safe_extended(&binary.right) =>
        {
            true
        }

        // Allow simple string/number concatenations (e.g., "_" + literal + "handler")
        Expression::BinaryExpression(binary)
            if matches!(binary.operator, BinaryOperator::Addition)
                && is_inline_safe_extended(&binary.left)
                && is_inline_safe_extended(&binary.right) =>
        {
            true
        }

        // Parenthesized expressions defer to inner
        Expression::ParenthesizedExpression(p) => is_inline_safe_extended(&p.expression),

        _ => false,
    }
}
