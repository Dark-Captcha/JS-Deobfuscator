//! JavaScript code normalizer
//!
//! This module normalizes JavaScript code for better readability and analysis.
//! It performs various transformations to make the code structure more explicit.

use anyhow::Result;
use oxc::{
    allocator::{Allocator, Vec as ArenaVec},
    ast::ast::{Expression, Program, Statement},
    semantic::Scoping,
};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};

use crate::deobfuscator::transformers::Transformer;

/// Normalizes JavaScript code for better readability and analysis
///
/// Performs the following transformations:
/// 1. Hoist for-loop var declarations
/// 2. Split variable declarations  
/// 3. Split sequence expressions
/// 4. Normalize return statements
/// 5. Simplify negations
pub struct Normalizer;

impl<'a> Transformer<'a> for Normalizer {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping> {
        let mut visitor = NormalizerVisitor;
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(scoping)
    }
}

/// Main visitor that orchestrates all normalization steps
struct NormalizerVisitor;

impl<'a> Traverse<'a, ()> for NormalizerVisitor {
    fn exit_expression(&mut self, node: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        expression_simplifier::simplify_negated_expressions(node, ctx);
    }

    fn enter_statements(
        &mut self,
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        statement_normalizer::hoist_for_var_inits(statements, ctx);
    }

    fn exit_statements(
        &mut self,
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        statement_normalizer::split_variable_declarations(statements, ctx);
        statement_normalizer::split_sequence_expressions(statements, ctx);
        statement_normalizer::normalize_return_statements(statements, ctx);
    }
}

/// Statement-level normalization functions
mod statement_normalizer {
    use oxc::{
        allocator::{TakeIn, Vec as ArenaVec},
        ast::ast::{Expression, ForStatementInit, Statement},
    };
    use oxc_traverse::TraverseCtx;

    /// Hoists var declarations from for-loop initializers to before the loop
    pub fn hoist_for_var_inits<'a>(
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut hoisted_declarations = ctx.ast.vec();

        for (statement_index, statement) in statements.iter_mut().enumerate() {
            if let Statement::ForStatement(for_statement) = statement {
                if let Some(ForStatementInit::VariableDeclaration(var_decl)) =
                    &mut for_statement.init
                {
                    if var_decl.kind.is_var() && !var_decl.declarations.is_empty() {
                        let declarations = var_decl.declarations.take_in(allocator);
                        let hoisted_var_decl = ctx.ast.alloc_variable_declaration(
                            var_decl.span,
                            var_decl.kind,
                            declarations,
                            var_decl.declare,
                        );
                        hoisted_declarations.push((
                            statement_index,
                            Statement::VariableDeclaration(hoisted_var_decl),
                        ));
                        for_statement.init = None;
                    }
                }
            }
        }

        // Insert hoisted declarations before their loops
        for (original_index, hoisted_declaration) in hoisted_declarations.into_iter().rev() {
            statements.insert(original_index, hoisted_declaration);
        }
    }

    /// Splits multi-variable declarations into individual statements
    pub fn split_variable_declarations<'a>(
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut split_declarations = ctx.ast.vec();

        for (statement_index, statement) in statements.iter_mut().enumerate() {
            if let Statement::VariableDeclaration(var_decl) = statement {
                if var_decl.kind.is_var() && var_decl.declarations.len() > 1 {
                    let mut all_declarations = var_decl.declarations.take_in(allocator);
                    let first_declaration = ctx.ast.vec1(all_declarations.remove(0));

                    // Update the original declaration
                    let updated_var_decl = ctx.ast.alloc_variable_declaration(
                        var_decl.span,
                        var_decl.kind,
                        first_declaration,
                        var_decl.declare,
                    );
                    *var_decl = updated_var_decl;

                    // Create new declarations for remaining declarators
                    for remaining_declaration in all_declarations {
                        let single_declaration = ctx.ast.vec1(remaining_declaration);
                        let split_var_decl = ctx.ast.alloc_variable_declaration(
                            var_decl.span,
                            var_decl.kind,
                            single_declaration,
                            var_decl.declare,
                        );
                        split_declarations.push((
                            statement_index,
                            Statement::VariableDeclaration(split_var_decl),
                        ));
                    }
                }
            }
        }

        // Insert split declarations after the original
        for (original_index, split_statement) in split_declarations.into_iter().rev() {
            statements.insert(original_index + 1, split_statement);
        }
    }

    /// Splits sequence expressions into separate statements
    pub fn split_sequence_expressions<'a>(
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut split_statements = ctx.ast.vec();

        for (statement_index, statement) in statements.iter_mut().enumerate() {
            if let Statement::ExpressionStatement(expr_stmt) = statement {
                if let Expression::SequenceExpression(sequence_expr) = &mut expr_stmt.expression {
                    if sequence_expr.expressions.len() > 1 {
                        let mut all_expressions = sequence_expr.expressions.take_in(allocator);
                        let first_expression = all_expressions.remove(0);
                        expr_stmt.expression = ctx.ast.alloc(first_expression).take_in(allocator);

                        // Create new statements for remaining expressions
                        for remaining_expression in all_expressions {
                            split_statements.push((
                                statement_index,
                                Statement::ExpressionStatement(ctx.ast.alloc_expression_statement(
                                    expr_stmt.span,
                                    remaining_expression,
                                )),
                            ));
                        }
                    }
                }
            }
        }

        // Insert split statements after the original
        for (original_index, split_statement) in split_statements.into_iter().rev() {
            statements.insert(original_index + 1, split_statement);
        }
    }

    /// Normalizes return statements by extracting preceding expressions from sequences
    pub fn normalize_return_statements<'a>(
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut extracted_statements = ctx.ast.vec();

        for (statement_index, statement) in statements.iter_mut().enumerate() {
            if let Statement::ReturnStatement(return_stmt) = statement {
                if let Some(return_expression) = &mut return_stmt.argument {
                    // Extract sequence expression (with or without parentheses)
                    let sequence_expr = match return_expression {
                        Expression::SequenceExpression(seq) => Some(seq),
                        Expression::ParenthesizedExpression(paren) => {
                            if let Expression::SequenceExpression(seq) = &mut paren.expression {
                                Some(seq)
                            } else {
                                None
                            }
                        }
                        _ => None,
                    };

                    if let Some(sequence_expr) = sequence_expr {
                        if sequence_expr.expressions.len() > 1 {
                            let mut all_expressions = sequence_expr.expressions.take_in(allocator);
                            if let Some(final_return_expression) = all_expressions.pop() {
                                // Create statements for all expressions except the last
                                let preceding_statements = ctx.ast.vec_from_iter(
                                    all_expressions.into_iter().map(|expression| {
                                        ctx.ast.statement_expression(return_stmt.span, expression)
                                    }),
                                );

                                return_stmt.argument = Some(final_return_expression);

                                for preceding_statement in preceding_statements.into_iter() {
                                    extracted_statements
                                        .push((statement_index, preceding_statement));
                                }
                            }
                        }
                    }
                }
            }
        }

        // Insert extracted statements before the return
        for (original_index, extracted_statement) in extracted_statements.into_iter().rev() {
            statements.insert(original_index, extracted_statement);
        }
    }
}

/// Expression-level simplification functions
mod expression_simplifier {
    use oxc::ast::ast::{Expression, UnaryOperator};
    use oxc_traverse::TraverseCtx;

    /// Simplifies negated expressions by evaluating constant truthiness
    pub fn simplify_negated_expressions<'a>(
        expression: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let Expression::UnaryExpression(unary_expr) = expression else {
            return;
        };

        if unary_expr.operator != UnaryOperator::LogicalNot {
            return;
        }

        // Count consecutive NOT operators
        let (not_count, final_expr) = count_negations(&unary_expr.argument);

        // Determine base truthiness
        let Some(base_truthy) = get_truthiness(final_expr) else {
            return;
        };

        // Apply negations: odd count inverts the truthiness
        let result = (not_count % 2 == 1) != base_truthy;
        *expression = ctx.ast.expression_boolean_literal(unary_expr.span, result);
    }

    /// Counts consecutive logical NOT operators
    fn count_negations<'a>(mut expr: &'a Expression<'a>) -> (usize, &'a Expression<'a>) {
        let mut count = 1; // Start at 1 (we're already inside a NOT)

        while let Expression::UnaryExpression(unary) = expr {
            if unary.operator == UnaryOperator::LogicalNot {
                count += 1;
                expr = &unary.argument;
            } else {
                break;
            }
        }

        (count, expr)
    }

    /// Determines the truthiness of an expression (returns None if not constant)
    fn get_truthiness<'a>(expr: &'a Expression<'a>) -> Option<bool> {
        match expr {
            // Numbers: 0, -0, NaN are falsy; all others are truthy
            Expression::NumericLiteral(lit) => Some(lit.value != 0.0 && !lit.value.is_nan()),

            // Booleans: direct value
            Expression::BooleanLiteral(lit) => Some(lit.value),

            // Arrays and objects: always truthy (even empty)
            Expression::ArrayExpression(_) | Expression::ObjectExpression(_) => Some(true),

            // Strings: empty is falsy, non-empty is truthy
            Expression::StringLiteral(lit) => Some(!lit.value.is_empty()),

            // null: always falsy
            Expression::NullLiteral(_) => Some(false),

            // undefined: always falsy
            Expression::Identifier(ident) if ident.name == "undefined" => Some(false),

            // Parenthesized: recurse
            Expression::ParenthesizedExpression(paren) => get_truthiness(&paren.expression),

            // Unknown: cannot determine
            _ => None,
        }
    }
}
