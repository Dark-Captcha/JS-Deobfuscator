//! Control flow formatter
//!
//! This module wraps control flow statements with braces for consistency and clarity.
//! It ensures all control flow constructs have explicit block statements.

use anyhow::Result;
use oxc::{
    allocator::{Allocator, Vec as ArenaVec},
    ast::ast::{Program, Statement, SwitchCase},
    semantic::Scoping,
};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};

use crate::deobfuscator::transformers::Transformer;

/// Wraps control flow statements with braces for consistency and clarity
///
/// Transformations:
/// 1. If statements: Ensures both if and else blocks have braces
/// 2. For loops: Ensures loop body has braces
/// 3. While loops: Ensures loop body has braces
/// 4. Switch cases: Wraps multi-statement cases in blocks
pub struct BraceWrapper;

impl<'a> Transformer<'a> for BraceWrapper {
    fn transform(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<Scoping> {
        let mut visitor = BraceWrapperVisitor;
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(scoping)
    }
}

/// Main visitor that orchestrates all brace wrapping operations
struct BraceWrapperVisitor;

impl<'a> Traverse<'a, ()> for BraceWrapperVisitor {
    fn exit_switch_case(&mut self, node: &mut SwitchCase<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        switch_case_wrapper::wrap_switch_case(node, ctx);
    }

    fn exit_statements(
        &mut self,
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        control_flow_wrapper::wrap_control_flow_statements(statements, ctx);
    }
}

/// Control flow statement wrapping functions
mod control_flow_wrapper {
    use oxc::{
        allocator::{TakeIn, Vec as ArenaVec},
        ast::ast::{DoWhileStatement, ForStatement, IfStatement, Statement, WhileStatement},
        span::GetSpan,
    };
    use oxc_traverse::TraverseCtx;

    /// Wraps control flow statements (if, for, while) with braces
    pub fn wrap_control_flow_statements<'a>(
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        for statement in statements.iter_mut() {
            match statement {
                Statement::IfStatement(if_stmt) => {
                    wrap_if_statement(if_stmt, ctx);
                }
                Statement::ForStatement(for_stmt) => {
                    wrap_for_statement(for_stmt, ctx);
                }
                Statement::WhileStatement(while_stmt) => {
                    wrap_while_statement(while_stmt, ctx);
                }
                Statement::DoWhileStatement(do_while_stmt) => {
                    wrap_do_while_statement(do_while_stmt, ctx);
                }
                _ => {}
            }
        }
    }

    /// Wraps if statement consequent and alternate with braces
    fn wrap_if_statement<'a>(if_stmt: &mut IfStatement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Wrap consequent if not already a block
        if !matches!(if_stmt.consequent, Statement::BlockStatement(_)) {
            let consequent = if_stmt.consequent.take_in(ctx.ast.allocator);
            if_stmt.consequent = ctx
                .ast
                .statement_block(consequent.span(), ctx.ast.vec1(consequent));
        }

        // Wrap alternate (else) if exists and not already a block
        if let Some(alternate) = &mut if_stmt.alternate {
            if !matches!(
                *alternate,
                Statement::BlockStatement(_) | Statement::IfStatement(_)
            ) {
                let alternate_stmt = alternate.take_in(ctx.ast.allocator);
                *alternate = ctx
                    .ast
                    .statement_block(alternate_stmt.span(), ctx.ast.vec1(alternate_stmt));
            }
        }
    }

    /// Wraps for loop body with braces
    fn wrap_for_statement<'a>(for_stmt: &mut ForStatement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        if !matches!(for_stmt.body, Statement::BlockStatement(_)) {
            let body = for_stmt.body.take_in(ctx.ast.allocator);
            for_stmt.body = ctx.ast.statement_block(body.span(), ctx.ast.vec1(body));
        }
    }

    /// Wraps while loop body with braces
    fn wrap_while_statement<'a>(
        while_stmt: &mut WhileStatement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        if !matches!(while_stmt.body, Statement::BlockStatement(_)) {
            let body = while_stmt.body.take_in(ctx.ast.allocator);
            while_stmt.body = ctx.ast.statement_block(body.span(), ctx.ast.vec1(body));
        }
    }

    /// Wraps do-while loop body with braces
    fn wrap_do_while_statement<'a>(
        do_while_stmt: &mut DoWhileStatement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        if !matches!(do_while_stmt.body, Statement::BlockStatement(_)) {
            let body = do_while_stmt.body.take_in(ctx.ast.allocator);
            do_while_stmt.body = ctx.ast.statement_block(body.span(), ctx.ast.vec1(body));
        }
    }
}

/// Switch case wrapping functions
mod switch_case_wrapper {
    use oxc::{
        allocator::TakeIn,
        ast::ast::{Statement, SwitchCase},
    };
    use oxc_traverse::TraverseCtx;

    /// Wraps switch case consequents with braces if they have multiple statements
    pub fn wrap_switch_case<'a>(switch_case: &mut SwitchCase<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Skip empty cases
        if switch_case.consequent.is_empty() {
            return;
        }

        // If only one statement and it's already a block, skip
        if switch_case.consequent.len() == 1 {
            if matches!(&switch_case.consequent[0], Statement::BlockStatement(_)) {
                return;
            }
        }

        // Wrap multiple statements or single non-block statement
        if switch_case.consequent.len() > 1
            || !matches!(&switch_case.consequent[0], Statement::BlockStatement(_))
        {
            let case_statements = switch_case.consequent.take_in(ctx.ast.allocator);
            let block_statement = ctx.ast.statement_block(switch_case.span, case_statements);
            switch_case.consequent = ctx.ast.vec1(block_statement);
        }
    }
}
