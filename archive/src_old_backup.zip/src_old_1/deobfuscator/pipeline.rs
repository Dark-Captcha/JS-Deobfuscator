//! Deobfuscation Pipeline
//!
//! Multi-stage JavaScript deobfuscation pipeline with configurable transformations.

use anyhow::Result;
use oxc::{
    allocator::Allocator, ast::ast::Program, codegen::CodegenOptions, parser::Parser,
    span::SourceType,
};

use super::transformers::{
    Transformer,
    ast_formatters::{
        code_normalizer::Normalizer, control_flow_formatter::BraceWrapper,
        identifier_renamer::UniqueIdentifierRenamer,
    },
    const_inliner::ConstInliner, member_converter::MemberConverter,
    object_inliner_only::ObjectInlinerOnly,
    shared_utils::ast_utils::AstUtils,
    string_decoders::{
        base64_string_decoder::StringBase64Decoder, checksum_string_resolver::StringArrayRotator,
        proxy_function_inliner::ProxyFunctionInliner as StringRotatorProxyInliner,
        rot_string_decoder::RotStringDecoder, xor_string_decoder::StringXorDecoder,
    },
    variable_processor::VariableTransformer,
    zero_arg_proxy_inliner::ProxyFunctionInliner as ZeroArgProxyInliner,
};

#[derive(Default)]
pub struct Deobfuscator {
    codegen_options: CodegenOptions,
    source_type: SourceType,
}

impl Deobfuscator {
    pub fn deobfuscate(self, input_source: &str) -> Result<String> {
        let allocator = Allocator::new();
        let mut program = Parser::new(&allocator, input_source, self.source_type)
            .parse()
            .program;

        self.execute_pipeline(&allocator, &mut program)?;

        AstUtils::generate_code(&program, self.codegen_options.clone())
    }

    fn execute_pipeline<'a>(
        &self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
    ) -> Result<()> {
        self.run_ast_formatters(allocator, program)?;
        self.run_string_decoders(allocator, program)?;
        self.run_final_cleanup(allocator, program)?;
        Ok(())
    }

    fn run_ast_formatters<'a>(
        &self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
    ) -> Result<()> {
        tracing::info!("Running transformer 0: BraceWrapper");
        let mut transformer = BraceWrapper;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 1: Normalizer");
        let mut transformer = Normalizer;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 2: UniqueIdentifierRenamer");
        let mut transformer = UniqueIdentifierRenamer;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 3: VariableTransformer (logical_expressions: false)");
        let mut transformer = VariableTransformer {
            logical_expressions: false,
        };
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        Ok(())
    }

    fn run_string_decoders<'a>(
        &self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
    ) -> Result<()> {
        tracing::info!("Running transformer 4: StringRotatorProxyInliner");
        let mut transformer = StringRotatorProxyInliner;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 5: VariableTransformer (logical_expressions: false)");
        let mut transformer = VariableTransformer {
            logical_expressions: false,
        };
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 6: StringArrayRotator");
        let mut transformer = StringArrayRotator;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 7: StringXorDecoder");
        let mut transformer = StringXorDecoder;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 8: VariableTransformer (logical_expressions: false)");
        let mut transformer = VariableTransformer {
            logical_expressions: false,
        };
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 9: StringBase64Decoder");
        let mut transformer = StringBase64Decoder;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 10: RotStringDecoder");
        let mut transformer = RotStringDecoder;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 11: VariableTransformer (logical_expressions: false)");
        let mut transformer = VariableTransformer {
            logical_expressions: false,
        };
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        Ok(())
    }

    fn run_final_cleanup<'a>(
        &self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
    ) -> Result<()> {
        
        tracing::info!("Running transformer 12: MemberConverter");
        // Convert computed members to static at the very end
        let mut transformer = MemberConverter;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;
        
        tracing::info!("Running transformer 13: ObjectInlinerOnly");
        // Inline object literals first
        let mut transformer = ObjectInlinerOnly;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 14: ConstInliner");
        // Immediately inline simple constants (e.g., expose 3600)
        let mut transformer = ConstInliner;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 15: ZeroArgProxyInliner");
        let mut transformer = ZeroArgProxyInliner;
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        tracing::info!("Running transformer 16: VariableTransformer (logical_expressions: true) - final pass");
        let mut transformer = VariableTransformer {
            logical_expressions: true,
        };
        let scoping = AstUtils::build_scoping(program);
        transformer.transform(allocator, program, scoping)?;

        Ok(())
    }
}
