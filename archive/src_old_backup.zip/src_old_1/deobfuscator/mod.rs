//! JavaScript Deobfuscator
//!
//! Multi-stage JavaScript deobfuscation pipeline.

mod pipeline;
mod transformers;

pub use pipeline::Deobfuscator;
