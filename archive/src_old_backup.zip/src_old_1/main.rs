//! Dark Captcha CLI
//!
//! Main entry point for JavaScript deobfuscation and anti-bot analysis.

use anyhow::{Context, Result};
use dark_captcha::{anti_bots::perimeterx::solver::Client, deobfuscator::Deobfuscator};
use std::{env, fs, path::PathBuf};
use tracing_subscriber::EnvFilter;

const OUTPUT_DIR: &str = "outputs";
const OUTPUT_FILENAME: &str = "deobfuscated.js";

fn main() -> Result<()> {
    setup_logging()?;

    let input_path = get_input_path()?;
    let input_source = read_input_file(&input_path)?;

    let output_source = deobfuscate_input(&input_source)?;

    prepare_output_directory()?;

    let json_output = Client::solve(&output_source)?;
    write_payload_data(&json_output)?;

    write_output_file(&output_source)?;

    Ok(())
}

fn setup_logging() -> Result<()> {
    let env_filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info"));

    tracing_subscriber::fmt()
        .with_target(false)
        .with_env_filter(env_filter)
        .init();

    tracing::info!("Logging initialized");
    Ok(())
}

fn get_input_path() -> Result<PathBuf> {
    let input_path = env::args_os()
        .nth(1)
        .context("No input file argument provided")?;

    Ok(PathBuf::from(input_path))
}

fn read_input_file(input_path: &PathBuf) -> Result<String> {
    tracing::info!("Loading input file \"{}\"", input_path.display());

    let input_source = fs::read_to_string(input_path)
        .with_context(|| format!("Failed to read input file {:?}", input_path))?;

    tracing::info!(
        "Input file read successfully, size: {} bytes",
        input_source.len()
    );
    Ok(input_source)
}

fn deobfuscate_input(input_source: &str) -> Result<String> {
    let start_time = std::time::Instant::now();

    let deobfuscator = Deobfuscator::default();
    let output_source = deobfuscator
        .deobfuscate(input_source)
        .context("Failed to deobfuscate")?;

    let elapsed = start_time.elapsed();
    tracing::info!("Deobfuscation completed in {} ms", elapsed.as_millis());

    Ok(output_source)
}

fn prepare_output_directory() -> Result<()> {
    let output_dir = PathBuf::from(OUTPUT_DIR);

    if output_dir.exists() {
        fs::remove_dir_all(&output_dir).context("Failed to delete output directory")?;
    }

    fs::create_dir_all(&output_dir).with_context(|| {
        format!(
            "Failed to create output directory: {}",
            output_dir.display()
        )
    })?;

    Ok(())
}

fn write_output_file(output_source: &str) -> Result<()> {
    let output_dir = PathBuf::from(OUTPUT_DIR);
    let output_path = output_dir.join(OUTPUT_FILENAME);

    fs::write(&output_path, output_source)
        .with_context(|| format!("Failed to write output file: {}", output_path.display()))?;

    tracing::info!(
        "Output file created: {}, size: {} bytes",
        output_path.display(),
        output_source.len()
    );
    Ok(())
}

fn write_payload_data(json_output: &str) -> Result<()> {
    let output_dir = PathBuf::from(OUTPUT_DIR);
    let payload_path = output_dir.join("payload_data.json");

    fs::write(&payload_path, json_output).with_context(|| {
        format!(
            "Failed to write payload data file: {}",
            payload_path.display()
        )
    })?;

    tracing::info!("Payload data written to: {}", payload_path.display());
    Ok(())
}
