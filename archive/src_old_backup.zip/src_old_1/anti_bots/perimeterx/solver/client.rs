use crate::anti_bots::perimeterx::fingerprint_key_extractor::invisible::InvisibleMsftV1Extractor;
use anyhow::Result;

pub struct Client;

impl Client {
    pub fn solve(output_source: &str) -> Result<String> {
        let mut extractor = InvisibleMsftV1Extractor::default();
        extractor.source = output_source.to_string();
        let _payload = extractor.extract_raw_payload()?;
        let json_output = extractor.export_to_json()?;
        Ok(json_output)
    }
}
