//! Invisible Key Extractor
//!
//! Extractors for obfuscated key mappings in JavaScript output.

pub mod msft_1;

pub use msft_1::{InvisibleMsftV1Extractor, PayloadData, ExtractedPayload};
