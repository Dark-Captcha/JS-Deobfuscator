//! Microsoft Invisible v1 extractor (clean naming)
//!
//! Responsibility: extract payload field names (keys) used in the initial
//! call object and subsequent telemetry assignments, including location href,
//! iframe flag, platform, request sequence counter, perf timestamp, ttl,
//! start/end timestamps, session uuid, response text, xhr status flag, and
//! px root url.

use anyhow::Result;
use regex::{Regex, RegexBuilder};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PayloadData {
    pub location_href: String,
    pub is_iframe: String,
    pub navigator_platform: String,
    pub request_sequence_counter: String,
    pub performance_time_ms: String,
    pub ttl_seconds: String,
    pub start_timestamp: String,
    pub end_timestamp: String,
    pub session_uuid: String,
    pub response_text: String,
    pub xhr_status_flag: String,
    pub script_is_same_origin: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ExtractedPayload {
    pub t: String,
    pub d: PayloadData,
}

#[derive(Default)]
pub struct InvisibleMsftV1Extractor {
    pub source: String,
}

impl InvisibleMsftV1Extractor {
    pub fn extract_payload_data(&self) -> Result<PayloadData> {
        let mut d = PayloadData::default();
        if let Some((_, obj_text)) = find_initial_call_and_object(&self.source) {
            d.location_href = find_location_href_key_in_object(&obj_text).unwrap_or_default();
            d.is_iframe = find_is_iframe_key_in_object(&obj_text).unwrap_or_default();
            d.navigator_platform =
                find_navigator_platform_key_in_object(&obj_text).unwrap_or_default();
        }
        d.request_sequence_counter =
            find_request_sequence_counter_key_in_source(&self.source).unwrap_or_default();
        d.performance_time_ms =
            find_performance_time_key_in_source(&self.source).unwrap_or_default();
        d.ttl_seconds = find_ttl_seconds_key_in_source(&self.source).unwrap_or_default();
        d.start_timestamp = find_start_timestamp_key_in_source(&self.source).unwrap_or_default();
        d.end_timestamp =
            find_end_timestamp_key_in_source(&self.source, &d.start_timestamp).unwrap_or_default();
        d.session_uuid =
            find_session_uuid_key_in_source(&self.source).unwrap_or_default();
        d.response_text =
            find_response_text_key_in_source(&self.source).unwrap_or_default();
        d.xhr_status_flag = find_xhr_status_flag_key_in_source(&self.source, &d.response_text)
            .unwrap_or_default();
        d.script_is_same_origin = find_script_is_same_origin_key_in_source(&self.source).unwrap_or_default();
        Ok(d)
    }

    pub fn extract_raw_payload(&self) -> Result<ExtractedPayload> {
        let d = self.extract_payload_data()?;
        let t = find_initial_call_and_object(&self.source)
            .map(|(t, _)| t)
            .unwrap_or_default();
        Ok(ExtractedPayload { t, d })
    }

    pub fn export_to_json(&self) -> Result<String> {
        let raw = self.extract_raw_payload()?;
        Ok(serde_json::to_string_pretty(&raw)?)
    }
}

/// Find the target call and return `(t, object_text)`.
pub fn find_initial_call_and_object(src: &str) -> Option<(String, String)> {
    let call_re = compile_regex_dotall(RE_INITIAL_CALL_WITH_OBJECT)?;
    let prop_re = compile_regex(RE_OBJECT_PROP_DELIM)?;

    let mut last_match: Option<(String, String)> = None;
    for caps in call_re.captures_iter(src) {
        let obj = caps.name("obj").map(|m| m.as_str()).unwrap_or("");
        // Only consider objects with exactly 4 top-level properties
        let prop_count = prop_re.find_iter(obj).count();
        if prop_count == 4 {
            let t = caps.name("t").map(|m| m.as_str().to_string())?;
            last_match = Some((t, obj.to_string()));
        }
    }
    last_match
}

/// Match the property whose value references `location.href` and return its key.
fn find_location_href_key_in_object(obj: &str) -> Option<String> {
    let re = compile_regex(RE_LOCATION_HREF_PROP)?;
    re.captures(obj)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

/// Match the property whose value compares `window.self !== window.top` and return its key.
fn find_is_iframe_key_in_object(obj: &str) -> Option<String> {
    let re = compile_regex(RE_IS_IFRAME_PROP)?;
    re.captures(obj)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

/// Match the property whose value references `navigator.platform` and return its key.
fn find_navigator_platform_key_in_object(obj: &str) -> Option<String> {
    let re = compile_regex(RE_NAVIGATOR_PLATFORM_PROP)?;
    re.captures(obj)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

/// Match assignments like: `something["<key>"] = <identifier>++` and return the key.
fn find_request_sequence_counter_key_in_source(src: &str) -> Option<String> {
    let re = compile_regex(RE_REQUEST_SEQUENCE_COUNTER_ASSIGNMENT)?;
    re.captures(src)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

/// Match assignments like: `obj["<key>"] = ... performance.now() ...` or `... + new Date() ...` and return the key.
fn find_performance_time_key_in_source(src: &str) -> Option<String> {
    let re = compile_regex(RE_PERF_TIME_ASSIGNMENT)?;
    re.captures(src)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

/// Prefer assignments like: `.d["<key>"] = "... ? 3600 : ..."()`; return the last one.
fn find_ttl_seconds_key_in_source(src: &str) -> Option<String> {
    let re = compile_regex(RE_TTL_ASSIGNMENT)?;
    let mut last: Option<String> = None;
    for cap in re.captures_iter(src) {
        if let Some(m) = cap.get(1) {
            last = Some(m.as_str().to_string());
        }
    }
    last
}

/// Extract the start timestamp key from `if ( <word>( <any>.d["<key>"] = new Date().getTime(), <word> ) )`.
fn find_start_timestamp_key_in_source(src: &str) -> Option<String> {
    let re = compile_regex(RE_START_TS_IF_GUARDED_CALL)?;
    re.captures(src)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

fn find_end_timestamp_key_in_source(src: &str, start_key: &str) -> Option<String> {
    if start_key.is_empty() {
        return None;
    }
    // Find the first occurrence of the concrete start key, then slice after it.
    let idx = src.find(start_key)?;
    let after = &src[idx + start_key.len()..];

    let ts_re = compile_regex(RE_ANY_TS_ASSIGNMENT)?;
    ts_re
        .captures(after)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

fn find_session_uuid_key_in_source(src: &str) -> Option<String> {
    let re = compile_regex(RE_SESSION_UUID_ASSIGNMENT)?;
    re.captures(src)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

/// Match `.d["<key>"] = <ident>.responseText` and return the key.
fn find_response_text_key_in_source(src: &str) -> Option<String> {
    let re = compile_regex(RE_RESPONSE_TEXT_ASSIGNMENT)?;
    re.captures(src)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

/// After the response_text assignment, find a nearby `.d["<key>"] = 0` to infer the xhr status flag.
fn find_xhr_status_flag_key_in_source(src: &str, response_text_key: &str) -> Option<String> {
    if response_text_key.is_empty() {
        return None;
    }
    let idx = src.find(response_text_key)?;
    let after = &src[idx + response_text_key.len()..];
    let re = compile_regex(RE_ZERO_ASSIGNMENT)?;
    re.captures(after)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

/// Match `.d["<key>"] = "function ... _pxAbr ..."()`; returns the key for px root url.
fn find_script_is_same_origin_key_in_source(src: &str) -> Option<String> {
    let re = compile_regex(RE_SCRIPT_IS_SAME_ORIGIN_ASSIGNMENT)?;
    re.captures(src)
        .and_then(|c| c.get(1))
        .map(|m| m.as_str().to_string())
}

/// Centralized regex builders.
fn compile_regex(pattern: &str) -> Option<Regex> {
    RegexBuilder::new(pattern).build().ok()
}

fn compile_regex_dotall(pattern: &str) -> Option<Regex> {
    RegexBuilder::new(pattern)
        .dot_matches_new_line(true)
        .build()
        .ok()
}

const RE_INITIAL_CALL_WITH_OBJECT: &str =
    r#"\b\w+\(\s*\"(?P<t>[^\"]+)\"\s*,\s*(?P<obj>\{.*?\})\s*\)\s*;"#;
const RE_OBJECT_PROP_DELIM: &str = r#"\s*\"[^\"]+\"\s*:\s*"#;
const RE_LOCATION_HREF_PROP: &str = r#"\"([^\"]+)\"\s*:\s*[^,}]*location\.href"#;
const RE_IS_IFRAME_PROP: &str = r#"\"([^\"]+)\"\s*:\s*[^,}]*window\.self\s*!==\s*window\.top"#;
const RE_NAVIGATOR_PLATFORM_PROP: &str = r#"\"([^\"]+)\"\s*:\s*[^,}]*navigator\.platform"#;
const RE_REQUEST_SEQUENCE_COUNTER_ASSIGNMENT: &str = r#"\[\s*\"([^\"]+)\"\s*\]\s*=\s*\w+\+\+"#;
const RE_PERF_TIME_ASSIGNMENT: &str =
    r#"\[\s*\"([^\"]+)\"\s*\]\s*=\s*[^;]*(performance\.now\(\)|\+\s*new\s+Date\(\))"#;
const RE_TTL_ASSIGNMENT: &str =
    r#"\.d\s*\[\s*\"([^\"]+)\"\s*\]\s*=\s*\".*\?\s*3600\s*:.*\"\(\)"#;
const RE_START_TS_IF_GUARDED_CALL: &str = r#"if\s*\(\s*\w+\s*\(\s*[^\)]*?\.d\s*\[\s*\"([^\"]+)\"\s*\]\s*=\s*new\s+Date\(\)\s*\.\s*getTime\(\)\s*,\s*\w+\s*\)\s*\)"#;
const RE_ANY_TS_ASSIGNMENT: &str =
    r#"\.d\s*\[\s*\"([^\"]+)\"\s*\]\s*=\s*new\s+Date\(\)\s*\.\s*getTime\(\)"#;
const RE_SESSION_UUID_ASSIGNMENT: &str =
    r#"(?s)\.d\s*\[\s*\"([^\"]+)\"\s*\]\s*=\s*\".*?uuid.*?window\[\s*\\\"[^\\\"]*Uuid\\\"\s*\].*?\"\(\)"#;
const RE_RESPONSE_TEXT_ASSIGNMENT: &str =
    r#"\.d\s*\[\s*\"([^\"]+)\"\s*\]\s*=\s*\w+\.responseText"#;
const RE_ZERO_ASSIGNMENT: &str =
    r#"\.d\s*\[\s*\"([^\"]+)\"\s*\]\s*=\s*0\s*;"#;
const RE_SCRIPT_IS_SAME_ORIGIN_ASSIGNMENT: &str =
    r#"\.d\s*\[\s*\"([^\"]+)\"\s*\]\s*=\s*\"[^\"]*_pxAbr[^\"]*\"\(\)"#;
