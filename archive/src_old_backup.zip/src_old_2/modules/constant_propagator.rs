//! Constant propagation module.
//!
//! Two-phase transformation:
//! 1. Collect: Find all const/let declarations with literal initializers
//! 2. Apply: Inline references to those constants

use oxc::allocator::Allocator;
use oxc::ast::ast::{BindingPatternKind, Expression, Program, Statement, VariableDeclarationKind};
use oxc::semantic::{Scoping, SymbolId};
use oxc_traverse::{traverse_mut, Traverse, TraverseCtx};
use rustc_hash::FxHashMap;

use crate::core::{Module, ModuleResult};
use crate::utils::literal::LiteralValue;
use crate::utils::scoping::{get_binding_symbol, has_writes};

// ============================================================================
// ConstantPropagator Module
// ============================================================================

/// Constant propagation module.
///
/// Collects constant declarations and inlines their values at reference sites.
///
/// # Example
///
/// ```ignore
/// // Input
/// const x = 1;
/// const y = "hello";
/// console.log(x + 2, y);
///
/// // Output
/// const x = 1;
/// const y = "hello";
/// console.log(1 + 2, "hello");
/// ```
#[derive(Default)]
pub struct ConstantPropagator {
    /// Collected constants: symbol_id -> literal value
    constants: FxHashMap<SymbolId, LiteralValue>,
}

impl ConstantPropagator {
    pub fn new() -> Self {
        Self::default()
    }
}

impl Module for ConstantPropagator {
    fn name(&self) -> &'static str {
        "constant_propagator"
    }

    fn description(&self) -> &'static str {
        "Inlines constant variable values"
    }

    fn reset(&mut self) {
        self.constants.clear();
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> ModuleResult {
        self.reset();

        // Phase 1: Collect constants
        {
            let mut collector = ConstantCollector {
                constants: &mut self.constants,
                scoping: &scoping,
            };
            collector.collect(program);
        }

        if self.constants.is_empty() {
            return ModuleResult::unchanged();
        }

        tracing::debug!(
            target: "deob::module::constant_propagator",
            count = self.constants.len(),
            "collected constants"
        );

        // Phase 2: Apply inlining
        let mut inliner = ConstantInliner {
            constants: &self.constants,
            modifications: 0,
        };

        traverse_mut(&mut inliner, allocator, program, scoping, ());

        tracing::debug!(
            target: "deob::module::constant_propagator",
            modifications = inliner.modifications,
            "inlined constants"
        );

        ModuleResult::changed(inliner.modifications)
    }
}

// ============================================================================
// Collector
// ============================================================================

/// Collects constant declarations.
struct ConstantCollector<'c, 's> {
    constants: &'c mut FxHashMap<SymbolId, LiteralValue>,
    scoping: &'s Scoping,
}

impl<'c, 's> ConstantCollector<'c, 's> {
    fn collect(&mut self, program: &Program) {
        for stmt in &program.body {
            self.visit_statement(stmt);
        }
    }

    fn visit_statement(&mut self, stmt: &Statement) {
        match stmt {
            Statement::VariableDeclaration(var_decl) => {
                // Only const and let (not var)
                if var_decl.kind == VariableDeclarationKind::Var {
                    return;
                }

                for decl in &var_decl.declarations {
                    // Simple binding only (not destructuring)
                    let BindingPatternKind::BindingIdentifier(binding) = &decl.id.kind else {
                        continue;
                    };

                    let Some(symbol_id) = get_binding_symbol(binding) else {
                        continue;
                    };

                    // Check for writes
                    if has_writes(self.scoping, symbol_id) {
                        continue;
                    }

                    // Get initializer
                    let Some(init) = &decl.init else {
                        continue;
                    };

                    // Extract literal
                    if let Some(value) = LiteralValue::from_expr(init) {
                        self.constants.insert(symbol_id, value);
                    }
                }
            }
            Statement::BlockStatement(block) => {
                for s in &block.body {
                    self.visit_statement(s);
                }
            }
            Statement::IfStatement(if_stmt) => {
                self.visit_statement(&if_stmt.consequent);
                if let Some(alt) = &if_stmt.alternate {
                    self.visit_statement(alt);
                }
            }
            Statement::WhileStatement(while_stmt) => {
                self.visit_statement(&while_stmt.body);
            }
            Statement::ForStatement(for_stmt) => {
                self.visit_statement(&for_stmt.body);
            }
            Statement::FunctionDeclaration(func) => {
                if let Some(body) = &func.body {
                    for s in &body.statements {
                        self.visit_statement(s);
                    }
                }
            }
            _ => {}
        }
    }
}

// ============================================================================
// Inliner
// ============================================================================

/// Inlines constant references.
struct ConstantInliner<'c> {
    constants: &'c FxHashMap<SymbolId, LiteralValue>,
    modifications: usize,
}

impl<'a, 'c> Traverse<'a, ()> for ConstantInliner<'c> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let Expression::Identifier(ident) = expr else {
            return;
        };

        // Get symbol from scoping in traverse context
        let Some(ref_id) = ident.reference_id.get() else {
            return;
        };

        let Some(symbol_id) = ctx.scoping().get_reference(ref_id).symbol_id() else {
            return;
        };

        let Some(value) = self.constants.get(&symbol_id) else {
            return;
        };

        // Save name before replacing
        let name = ident.name.to_string();

        *expr = value.clone().into_expr(&ctx.ast);
        self.modifications += 1;

        tracing::trace!(
            target: "deob::module::constant_propagator",
            %name,
            "inlined"
        );
    }
}
