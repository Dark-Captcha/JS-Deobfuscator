//! Two-phase transformation modules.
//!
//! Modules are more powerful than passes - they can maintain state
//! and perform multi-phase transformations (collect → apply).
//!
//! - [`ConstantPropagator`] — Collect constants, inline references

mod constant_propagator;

pub use constant_propagator::ConstantPropagator;
