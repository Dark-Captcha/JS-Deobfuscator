//! Utility functions for deobfuscation.
//!
//! # Literal Operations
//!
//! Use the [`literal`] module for all literal value operations:
//!
//! ```ignore
//! use crate::utils::literal;
//!
//! // Extract values
//! let n = literal::number(&expr)?;
//! let s = literal::string(&expr)?;
//! let b = literal::boolean(&expr)?;
//!
//! // Check truthiness
//! if literal::is_truthy(&expr) == Some(true) { ... }
//!
//! // Create expressions
//! *expr = literal::make_number(42.0, &ctx.ast);
//! *expr = literal::make_string("hello", &ctx.ast);
//!
//! // Array operations
//! let elements = literal::array_elements(&expr)?;
//!
//! // Type checking
//! if literal::is_literal(&expr) { ... }
//! ```
//!
//! # Scoping
//!
//! Use [`scoping`] for symbol resolution and reference tracking.
//!
//! # Side Effects
//!
//! Use [`side_effects`] for side effect analysis.

// ============================================================================
// Modules
// ============================================================================

pub mod format;
pub mod literal;
pub mod scoping;
pub mod side_effects;

// ============================================================================
// Re-exports
// ============================================================================

pub use literal::LiteralValue;
pub use scoping::{get_binding_symbol, get_reference_symbol, has_reads, has_writes};
pub use side_effects::is_side_effect_free;
