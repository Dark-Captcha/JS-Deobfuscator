//! JavaScript value formatting utilities.
//!
//! Converts Rust values to their JavaScript string representations.

/// Format a number as JavaScript would.
///
/// Handles NaN, Infinity, integers, and floats.
pub fn number_to_string(n: f64) -> String {
    if n.is_nan() {
        "NaN".to_string()
    } else if n.is_infinite() {
        if n.is_sign_positive() {
            "Infinity".to_string()
        } else {
            "-Infinity".to_string()
        }
    } else if n == 0.0 {
        "0".to_string()
    } else if n.fract() == 0.0 && n.abs() < 1e15 {
        format!("{}", n as i64)
    } else {
        format!("{}", n)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_number_to_string() {
        assert_eq!(number_to_string(42.0), "42");
        assert_eq!(number_to_string(-5.0), "-5");
        assert_eq!(number_to_string(3.14), "3.14");
        assert_eq!(number_to_string(0.0), "0");
        assert_eq!(number_to_string(f64::NAN), "NaN");
        assert_eq!(number_to_string(f64::INFINITY), "Infinity");
        assert_eq!(number_to_string(f64::NEG_INFINITY), "-Infinity");
    }
}
