//! Constant inlining pass.
//!
//! This pass is a placeholder. For proper constant inlining, use the
//! [`ConstantPropagator`](crate::modules::ConstantPropagator) module instead,
//! which implements a two-phase collect-then-apply pattern.

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

use crate::utils::scoping::{get_reference_symbol, has_writes};

// ============================================================================
// ConstantInline Pass
// ============================================================================

/// Placeholder pass for constant inlining.
///
/// This single-pass approach cannot access declarations from reference sites.
/// Use [`ConstantPropagator`](crate::modules::ConstantPropagator) module instead.
#[derive(Default)]
pub struct ConstantInline;

impl ConstantInline {
    /// Transform expression. Returns 1 if modified, 0 otherwise.
    ///
    /// Note: This is a placeholder - actual inlining requires two-phase approach.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        // Check if this is an identifier reference
        let Expression::Identifier(ident) = expr else {
            return 0;
        };

        let scoping = ctx.scoping();

        // Get the symbol this identifier refers to
        let Some(symbol_id) = get_reference_symbol(scoping, ident) else {
            return 0;
        };

        // Check if symbol has writes (not safe to inline)
        if has_writes(scoping, symbol_id) {
            return 0;
        }

        // Cannot access declaration from here - use ConstantPropagator module
        0
    }
}
