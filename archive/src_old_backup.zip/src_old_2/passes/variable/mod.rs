//! Variable transformation passes.
//!
//! These passes require scoping information to safely inline variables.
//!
//! - [`ConstantInline`] — `const x = 1; use(x)` → `use(1)`
//! - [`AliasInline`] — `var a = b; use(a)` → `use(b)` (when b is constant)

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod constant_inline;

pub use constant_inline::ConstantInline;

// ============================================================================
// Variable Group
// ============================================================================

/// Group of all variable transformation passes.
#[derive(Default)]
pub struct Variable {
    constant_inline: ConstantInline,
}

impl Variable {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform expression through all variable passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        self.constant_inline.transform(expr, ctx)
    }
}
