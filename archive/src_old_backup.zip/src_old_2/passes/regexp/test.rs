//! RegExp.test pass.

use oxc::ast::ast::{Expression, RegExpFlags};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `/pattern/.test("string")` → boolean
#[derive(Default)]
pub struct Test;

impl Test {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else { return 0 };
        let Expression::StaticMemberExpression(member) = &call.callee else { return 0 };
        if member.property.name.as_str() != "test" { return 0 }
        if call.arguments.len() != 1 { return 0 }

        let Expression::RegExpLiteral(regex) = &member.object else { return 0 };
        
        let Some(test_str) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::string) else { return 0 };

        // Get pattern from raw string
        let Some(raw) = &regex.raw else { return 0 };
        let s = raw.as_str();
        
        // Extract pattern from /pattern/flags
        let Some(end) = s.rfind('/') else { return 0 };
        if end == 0 { return 0 }
        let pattern = &s[1..end];
        
        let flags = regex.regex.flags;
        
        // Skip if has complex flags we can't easily handle
        if flags.contains(RegExpFlags::U) || flags.contains(RegExpFlags::V) || flags.contains(RegExpFlags::Y) {
            return 0;
        }

        // Try to compile and test the regex
        let regex_str = if flags.contains(RegExpFlags::I) {
            format!("(?i){}", pattern)
        } else {
            pattern.to_string()
        };

        let Ok(re) = regex::Regex::new(&regex_str) else { return 0 };
        
        let result = re.is_match(test_str);

        *expr = ctx.ast.expression_boolean_literal(SPAN, result);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::regexp::RegExp;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(RegExp);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }
        let mut visitor = Visitor(RegExp::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_regexp_test_true() {
        assert_eq!(transform("/abc/.test(\"xabcy\")"), "true;\n");
    }

    #[test]
    fn test_regexp_test_false() {
        assert_eq!(transform("/abc/.test(\"xyz\")"), "false;\n");
    }
}
