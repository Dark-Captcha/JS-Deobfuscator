//! RegExp passes.
//!
//! - [`Test`] — `/abc/.test("xabcy")` → `true`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod test;

pub use test::Test;

/// Group of all RegExp passes.
#[derive(Default)]
pub struct RegExp {
    test: Test,
}

impl RegExp {
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        self.test.transform(expr, ctx)
    }
}
