//! Array method passes.
//!
//! - [`Length`] — `[1,2,3].length` → `3`
//! - [`Join`] — `[1,2,3].join(",")` → `"1,2,3"`
//! - [`At`] — `[1,2,3].at(1)` → `2`
//! - [`IndexOf`] — `[1,2,3].indexOf(2)` → `1`
//! - [`LastIndexOf`] — `[1,2,1].lastIndexOf(1)` → `2`
//! - [`Includes`] — `[1,2,3].includes(2)` → `true`
//! - [`Slice`] — `[1,2,3].slice(1)` → `[2,3]`
//! - [`Concat`] — `[1].concat([2])` → `[1,2]`
//! - [`Reverse`] — `[1,2,3].reverse()` → `[3,2,1]`
//! - [`ToString`] — `[1,2,3].toString()` → `"1,2,3"`
//! - [`Flat`] — `[[1],[2]].flat()` → `[1,2]`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod at;
mod concat;
mod flat;
mod includes;
mod index_of;
mod join;
mod length;
mod reverse;
mod slice;
mod to_string;

pub use at::At;
pub use concat::Concat;
pub use flat::Flat;
pub use includes::Includes;
pub use index_of::{IndexOf, LastIndexOf};
pub use join::Join;
pub use length::Length;
pub use reverse::Reverse;
pub use slice::Slice;
pub use to_string::ToString;

// ============================================================================
// Array Group
// ============================================================================

/// Group of all array evaluation passes.
#[derive(Default)]
pub struct Array {
    at: At,
    concat: Concat,
    flat: Flat,
    includes: Includes,
    index_of: IndexOf,
    last_index_of: LastIndexOf,
    join: Join,
    length: Length,
    reverse: Reverse,
    slice: Slice,
    to_string: ToString,
}

impl Array {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform expression through all array passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.at.transform(expr, ctx);
        mods += self.concat.transform(expr, ctx);
        mods += self.flat.transform(expr, ctx);
        mods += self.includes.transform(expr, ctx);
        mods += self.index_of.transform(expr, ctx);
        mods += self.last_index_of.transform(expr, ctx);
        mods += self.join.transform(expr, ctx);
        mods += self.length.transform(expr, ctx);
        mods += self.reverse.transform(expr, ctx);
        mods += self.slice.transform(expr, ctx);
        mods += self.to_string.transform(expr, ctx);
        mods
    }
}
