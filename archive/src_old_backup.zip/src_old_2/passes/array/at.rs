//! Array at pass.

use oxc::allocator::CloneIn;
use oxc::ast::ast::{Argument, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// At Pass
// ============================================================================

/// Evaluates array at: `[1, 2, 3].at(1)` → `2`
///
/// Handles negative indices: `[1, 2, 3].at(-1)` → `3`
#[derive(Default)]
pub struct At;

impl At {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "at" {
            return 0;
        }

        let Some(elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        // All elements must be literals for safe replacement
        if !elements.iter().all(|e| literal::is_literal(e)) {
            return 0;
        }

        // Get index (required)
        let Some(idx) = call.arguments.first().and_then(|a| match a {
            Argument::NumericLiteral(n) => Some(n.value),
            _ => a.as_expression().and_then(literal::number),
        }) else {
            return 0;
        };

        let len = elements.len() as i64;
        let idx = idx as i64;

        // Handle negative index
        let actual_idx = if idx < 0 { len + idx } else { idx };

        if actual_idx < 0 || actual_idx >= len {
            return 0;
        }

        let element = elements[actual_idx as usize];
        *expr = element.clone_in(ctx.ast.allocator);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::array::Array;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Array);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Array::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_at_positive() {
        assert_eq!(transform("[1, 2, 3].at(1);"), "2;\n");
    }

    #[test]
    fn test_at_negative() {
        assert_eq!(transform("[1, 2, 3].at(-1);"), "3;\n");
    }

    #[test]
    fn test_at_first() {
        assert_eq!(transform("[1, 2, 3].at(0);"), "1;\n");
    }

    #[test]
    fn test_at_out_of_bounds() {
        let result = transform("[1, 2, 3].at(5);");
        assert!(result.contains("at"));
    }
}
