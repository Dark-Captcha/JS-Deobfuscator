//! Array concat pass.

use oxc::allocator::CloneIn;
use oxc::ast::ast::{Argument, ArrayExpressionElement, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Concat Pass
// ============================================================================

/// Evaluates array concat: `[1].concat([2])` → `[1, 2]`
#[derive(Default)]
pub struct Concat;

impl Concat {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "concat" {
            return 0;
        }

        let Some(base_elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        if !base_elements.iter().all(|e| literal::is_literal(e)) {
            return 0;
        }

        let mut all_elements: Vec<&Expression> = base_elements;

        for arg in &call.arguments {
            match arg {
                Argument::SpreadElement(_) => return 0,
                _ => {
                    if let Some(arg_expr) = arg.as_expression() {
                        if let Some(arr_elements) = literal::array_elements(arg_expr) {
                            if !arr_elements.iter().all(|e| literal::is_literal(e)) {
                                return 0;
                            }
                            all_elements.extend(arr_elements);
                        } else if literal::is_literal(arg_expr) {
                            all_elements.push(arg_expr);
                        } else {
                            return 0;
                        }
                    } else {
                        return 0;
                    }
                }
            }
        }

        let mut new_elements = ctx.ast.vec();
        for elem in all_elements {
            let copied = elem.clone_in(ctx.ast.allocator);
            new_elements.push(ArrayExpressionElement::from(copied));
        }

        *expr = ctx.ast.expression_array(SPAN, new_elements);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::array::Array;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Array);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Array::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_concat_arrays() {
        let result = transform("[1].concat([2, 3]);");
        assert!(result.contains("1"));
        assert!(result.contains("2"));
        assert!(result.contains("3"));
    }

    #[test]
    fn test_concat_multiple() {
        let result = transform("[1].concat([2], [3]);");
        assert!(result.contains("1"));
        assert!(result.contains("2"));
        assert!(result.contains("3"));
    }

    #[test]
    fn test_concat_value() {
        let result = transform("[1].concat(2);");
        assert!(result.contains("1"));
        assert!(result.contains("2"));
    }
}
