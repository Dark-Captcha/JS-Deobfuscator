//! Array slice pass.

use oxc::allocator::CloneIn;
use oxc::ast::ast::{Argument, ArrayExpressionElement, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Slice Pass
// ============================================================================

/// Evaluates array slice: `[1, 2, 3].slice(1)` → `[2, 3]`
#[derive(Default)]
pub struct Slice;

impl Slice {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "slice" {
            return 0;
        }

        let Some(elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        if !elements.iter().all(|e| literal::is_literal(e)) {
            return 0;
        }

        let len = elements.len() as i64;

        let start = call
            .arguments
            .first()
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value as i64),
                _ => a.as_expression().and_then(literal::number).map(|n| n as i64),
            })
            .unwrap_or(0);

        let end = call
            .arguments
            .get(1)
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value as i64),
                _ => a.as_expression().and_then(literal::number).map(|n| n as i64),
            })
            .unwrap_or(len);

        let start_idx = if start < 0 {
            (len + start).max(0) as usize
        } else {
            (start as usize).min(len as usize)
        };

        let end_idx = if end < 0 {
            (len + end).max(0) as usize
        } else {
            (end as usize).min(len as usize)
        };

        let mut new_elements = ctx.ast.vec();
        if start_idx < end_idx {
            for elem in &elements[start_idx..end_idx] {
                let copied = (*elem).clone_in(ctx.ast.allocator);
                new_elements.push(ArrayExpressionElement::from(copied));
            }
        }

        *expr = ctx.ast.expression_array(SPAN, new_elements);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::array::Array;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Array);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Array::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_slice_one_arg() {
        let result = transform("[1, 2, 3].slice(1);");
        assert!(result.contains("2"));
        assert!(result.contains("3"));
        assert!(!result.contains("1,"));
    }

    #[test]
    fn test_slice_two_args() {
        let result = transform("[1, 2, 3, 4].slice(1, 3);");
        assert!(result.contains("2"));
        assert!(result.contains("3"));
    }

    #[test]
    fn test_slice_negative() {
        let result = transform("[1, 2, 3].slice(-2);");
        assert!(result.contains("2"));
        assert!(result.contains("3"));
    }

    #[test]
    fn test_slice_empty() {
        let result = transform("[1, 2, 3].slice(3);");
        assert_eq!(result.trim(), "[];");
    }
}
