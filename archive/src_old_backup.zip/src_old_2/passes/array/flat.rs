//! Array flat pass.

use oxc::allocator::CloneIn;
use oxc::ast::ast::{Argument, ArrayExpressionElement, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Flat Pass
// ============================================================================

/// Evaluates array flat: `[[1], [2]].flat()` → `[1, 2]`
#[derive(Default)]
pub struct Flat;

impl Flat {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "flat" {
            return 0;
        }

        let Some(elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        let depth = call
            .arguments
            .first()
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value as usize),
                _ => a.as_expression().and_then(literal::number).map(|n| n as usize),
            })
            .unwrap_or(1);

        if depth > 10 {
            return 0;
        }

        let flattened = flatten_array(&elements, depth);

        if !flattened.iter().all(|e| literal::is_literal(e)) {
            return 0;
        }

        let mut new_elements = ctx.ast.vec();
        for elem in flattened {
            let copied = elem.clone_in(ctx.ast.allocator);
            new_elements.push(ArrayExpressionElement::from(copied));
        }

        *expr = ctx.ast.expression_array(SPAN, new_elements);

        1
    }
}

fn flatten_array<'a>(elements: &[&'a Expression<'a>], depth: usize) -> Vec<&'a Expression<'a>> {
    if depth == 0 {
        return elements.to_vec();
    }

    let mut result = Vec::new();
    for elem in elements {
        if let Some(inner) = literal::array_elements(elem) {
            result.extend(flatten_array(&inner, depth - 1));
        } else {
            result.push(*elem);
        }
    }
    result
}

#[cfg(test)]
mod tests {
    use crate::passes::array::Array;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Array);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Array::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_flat_default() {
        let result = transform("[[1], [2], [3]].flat();");
        assert!(result.contains("1"));
        assert!(result.contains("2"));
        assert!(result.contains("3"));
        assert!(!result.contains("[["));
    }

    #[test]
    fn test_flat_depth_2() {
        let result = transform("[[[1]], [[2]]].flat(2);");
        assert!(result.contains("1"));
        assert!(result.contains("2"));
    }

    #[test]
    fn test_flat_mixed() {
        let result = transform("[1, [2, 3]].flat();");
        assert!(result.contains("1"));
        assert!(result.contains("2"));
        assert!(result.contains("3"));
    }
}
