//! Array reverse pass.

use oxc::allocator::CloneIn;
use oxc::ast::ast::{ArrayExpressionElement, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Reverse Pass
// ============================================================================

/// Evaluates array reverse on literals: `[1, 2, 3].reverse()` → `[3, 2, 1]`
#[derive(Default)]
pub struct Reverse;

impl Reverse {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "reverse" {
            return 0;
        }

        if !call.arguments.is_empty() {
            return 0;
        }

        let Some(elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        if !elements.iter().all(|e| literal::is_literal(e)) {
            return 0;
        }

        let mut new_elements = ctx.ast.vec();
        for elem in elements.into_iter().rev() {
            let copied = elem.clone_in(ctx.ast.allocator);
            new_elements.push(ArrayExpressionElement::from(copied));
        }

        *expr = ctx.ast.expression_array(SPAN, new_elements);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::array::Array;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Array);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Array::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_reverse() {
        let result = transform("[1, 2, 3].reverse();");
        let pos_3 = result.find('3').unwrap();
        let pos_2 = result.find('2').unwrap();
        let pos_1 = result.find('1').unwrap();
        assert!(pos_3 < pos_2);
        assert!(pos_2 < pos_1);
    }

    #[test]
    fn test_reverse_strings() {
        let result = transform("[\"a\", \"b\", \"c\"].reverse();");
        let pos_c = result.find("\"c\"").unwrap();
        let pos_b = result.find("\"b\"").unwrap();
        let pos_a = result.find("\"a\"").unwrap();
        assert!(pos_c < pos_b);
        assert!(pos_b < pos_a);
    }

    #[test]
    fn test_reverse_empty() {
        let result = transform("[].reverse();");
        assert_eq!(result.trim(), "[];");
    }
}
