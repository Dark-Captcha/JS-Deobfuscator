//! Array indexOf and lastIndexOf passes.

use oxc::ast::ast::{Argument, Expression, NumberBase};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// IndexOf Pass
// ============================================================================

/// Evaluates array indexOf: `[1, 2, 3].indexOf(2)` → `1`
#[derive(Default)]
pub struct IndexOf;

impl IndexOf {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "indexOf" {
            return 0;
        }

        let Some(elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        let Some(search) = call.arguments.first() else {
            return 0;
        };

        let from_idx = call
            .arguments
            .get(1)
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value as i64),
                _ => a.as_expression().and_then(literal::number).map(|n| n as i64),
            })
            .unwrap_or(0);

        let len = elements.len() as i64;
        let start = if from_idx < 0 {
            (len + from_idx).max(0) as usize
        } else {
            from_idx as usize
        };

        let result = find_element_index(&elements, search, start, false);

        *expr = ctx.ast.expression_numeric_literal(SPAN, result as f64, None, NumberBase::Decimal);

        1
    }
}

// ============================================================================
// LastIndexOf Pass
// ============================================================================

/// Evaluates array lastIndexOf: `[1, 2, 1].lastIndexOf(1)` → `2`
#[derive(Default)]
pub struct LastIndexOf;

impl LastIndexOf {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "lastIndexOf" {
            return 0;
        }

        let Some(elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        let Some(search) = call.arguments.first() else {
            return 0;
        };

        let len = elements.len() as i64;

        let from_idx = call
            .arguments
            .get(1)
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value as i64),
                _ => a.as_expression().and_then(literal::number).map(|n| n as i64),
            })
            .unwrap_or(len - 1);

        let start = if from_idx < 0 {
            (len + from_idx) as usize
        } else {
            from_idx.min(len - 1) as usize
        };

        let result = find_element_index(&elements, search, start, true);

        *expr = ctx.ast.expression_numeric_literal(SPAN, result as f64, None, NumberBase::Decimal);

        1
    }
}

fn find_element_index(elements: &[&Expression], search: &Argument, start: usize, reverse: bool) -> i64 {
    let search_expr = match search {
        Argument::SpreadElement(_) => return -1,
        _ => search.as_expression(),
    };

    let Some(search_expr) = search_expr else {
        return -1;
    };

    if reverse {
        for i in (0..=start.min(elements.len().saturating_sub(1))).rev() {
            if elements_equal(elements[i], search_expr) {
                return i as i64;
            }
        }
    } else {
        for (i, elem) in elements.iter().enumerate().skip(start) {
            if elements_equal(elem, search_expr) {
                return i as i64;
            }
        }
    }

    -1
}

fn elements_equal(a: &Expression, b: &Expression) -> bool {
    match (a, b) {
        (Expression::NumericLiteral(a), Expression::NumericLiteral(b)) => a.value == b.value,
        (Expression::StringLiteral(a), Expression::StringLiteral(b)) => a.value == b.value,
        (Expression::BooleanLiteral(a), Expression::BooleanLiteral(b)) => a.value == b.value,
        (Expression::NullLiteral(_), Expression::NullLiteral(_)) => true,
        (Expression::Identifier(a), Expression::Identifier(b))
            if a.name == "undefined" && b.name == "undefined" =>
        {
            true
        }
        (Expression::ParenthesizedExpression(a), b) => elements_equal(&a.expression, b),
        (a, Expression::ParenthesizedExpression(b)) => elements_equal(a, &b.expression),
        _ => {
            if let (Some(a_num), Some(b_num)) = (literal::number(a), literal::number(b)) {
                return a_num == b_num;
            }
            if let (Some(a_str), Some(b_str)) = (literal::string(a), literal::string(b)) {
                return a_str == b_str;
            }
            if let (Some(a_bool), Some(b_bool)) = (literal::boolean(a), literal::boolean(b)) {
                return a_bool == b_bool;
            }
            false
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::array::Array;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Array);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Array::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_index_of_found() {
        assert_eq!(transform("[1, 2, 3].indexOf(2);"), "1;\n");
    }

    #[test]
    fn test_index_of_not_found() {
        assert_eq!(transform("[1, 2, 3].indexOf(5);"), "-1;\n");
    }

    #[test]
    fn test_index_of_string() {
        assert_eq!(transform("[\"a\", \"b\"].indexOf(\"b\");"), "1;\n");
    }

    #[test]
    fn test_last_index_of() {
        assert_eq!(transform("[1, 2, 1].lastIndexOf(1);"), "2;\n");
    }

    #[test]
    fn test_last_index_of_not_found() {
        assert_eq!(transform("[1, 2, 3].lastIndexOf(5);"), "-1;\n");
    }
}
