//! Array length pass.

use oxc::ast::ast::{Expression, NumberBase};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Length Pass
// ============================================================================

/// Evaluates array length: `[1, 2, 3].length` → `3`
#[derive(Default)]
pub struct Length;

impl Length {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::StaticMemberExpression(member) = expr else {
            return 0;
        };

        if member.property.name.as_str() != "length" {
            return 0;
        }

        let Some(elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        let len = elements.len() as f64;
        *expr = ctx.ast.expression_numeric_literal(SPAN, len, None, NumberBase::Decimal);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::array::Array;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Array);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Array::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_length() {
        assert_eq!(transform("[1, 2, 3].length;"), "3;\n");
    }

    #[test]
    fn test_length_empty() {
        assert_eq!(transform("[].length;"), "0;\n");
    }

    #[test]
    fn test_length_strings() {
        assert_eq!(transform("[\"a\", \"b\"].length;"), "2;\n");
    }
}
