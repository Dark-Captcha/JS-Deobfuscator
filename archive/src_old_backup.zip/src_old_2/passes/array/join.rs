//! Array join pass.

use oxc::ast::ast::{Argument, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::format::number_to_string;
use crate::utils::literal;

// ============================================================================
// Join Pass
// ============================================================================

/// Evaluates array join: `[1, 2, 3].join(",")` → `"1,2,3"`
#[derive(Default)]
pub struct Join;

impl Join {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "join" {
            return 0;
        }

        let Some(elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        let separator = call
            .arguments
            .first()
            .and_then(|a| match a {
                Argument::StringLiteral(lit) => Some(lit.value.as_str()),
                _ => a.as_expression().and_then(literal::string),
            })
            .unwrap_or(",");

        let mut parts = Vec::new();
        for elem in elements {
            let Some(s) = element_to_string(elem) else {
                return 0;
            };
            parts.push(s);
        }

        let result = parts.join(separator);
        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

fn element_to_string(expr: &Expression) -> Option<String> {
    match expr {
        Expression::NumericLiteral(n) => Some(number_to_string(n.value)),
        Expression::StringLiteral(s) => Some(s.value.to_string()),
        Expression::BooleanLiteral(b) => Some(b.value.to_string()),
        Expression::NullLiteral(_) => Some(String::new()),
        Expression::Identifier(id) if id.name == "undefined" => Some(String::new()),
        Expression::ParenthesizedExpression(paren) => element_to_string(&paren.expression),
        Expression::UnaryExpression(_) => literal::number(expr).map(number_to_string),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::array::Array;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Array);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Array::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_join_default() {
        assert_eq!(transform("[1, 2, 3].join();"), "(\"1,2,3\");\n");
    }

    #[test]
    fn test_join_custom() {
        assert_eq!(transform("[1, 2, 3].join(\"-\");"), "(\"1-2-3\");\n");
    }

    #[test]
    fn test_join_empty() {
        assert_eq!(transform("[1, 2, 3].join(\"\");"), "(\"123\");\n");
    }

    #[test]
    fn test_join_strings() {
        assert_eq!(transform("[\"a\", \"b\"].join(\",\");"), "(\"a,b\");\n");
    }
}
