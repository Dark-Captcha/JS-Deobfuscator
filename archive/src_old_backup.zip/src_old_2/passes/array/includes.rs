//! Array includes pass.

use oxc::ast::ast::{Argument, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Includes Pass
// ============================================================================

/// Evaluates array includes: `[1, 2, 3].includes(2)` → `true`
#[derive(Default)]
pub struct Includes;

impl Includes {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "includes" {
            return 0;
        }

        let Some(elements) = literal::array_elements(&member.object) else {
            return 0;
        };

        let Some(search) = call.arguments.first() else {
            return 0;
        };

        let from_idx = call
            .arguments
            .get(1)
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value as i64),
                _ => a.as_expression().and_then(literal::number).map(|n| n as i64),
            })
            .unwrap_or(0);

        let len = elements.len() as i64;
        let start = if from_idx < 0 {
            (len + from_idx).max(0) as usize
        } else {
            from_idx as usize
        };

        let result = check_includes(&elements, search, start);

        *expr = ctx.ast.expression_boolean_literal(SPAN, result);

        1
    }
}

fn check_includes(elements: &[&Expression], search: &Argument, start: usize) -> bool {
    let search_expr = match search {
        Argument::SpreadElement(_) => return false,
        _ => search.as_expression(),
    };

    let Some(search_expr) = search_expr else {
        return false;
    };

    for elem in elements.iter().skip(start) {
        if elements_equal(elem, search_expr) {
            return true;
        }
    }

    false
}

fn elements_equal(a: &Expression, b: &Expression) -> bool {
    match (a, b) {
        (Expression::NumericLiteral(a), Expression::NumericLiteral(b)) => {
            if a.value.is_nan() && b.value.is_nan() {
                true
            } else {
                a.value == b.value
            }
        }
        (Expression::StringLiteral(a), Expression::StringLiteral(b)) => a.value == b.value,
        (Expression::BooleanLiteral(a), Expression::BooleanLiteral(b)) => a.value == b.value,
        (Expression::NullLiteral(_), Expression::NullLiteral(_)) => true,
        (Expression::Identifier(a), Expression::Identifier(b))
            if a.name == "undefined" && b.name == "undefined" =>
        {
            true
        }
        (Expression::ParenthesizedExpression(a), b) => elements_equal(&a.expression, b),
        (a, Expression::ParenthesizedExpression(b)) => elements_equal(a, &b.expression),
        _ => {
            if let (Some(a_num), Some(b_num)) = (literal::number(a), literal::number(b)) {
                if a_num.is_nan() && b_num.is_nan() {
                    return true;
                }
                return a_num == b_num;
            }
            if let (Some(a_str), Some(b_str)) = (literal::string(a), literal::string(b)) {
                return a_str == b_str;
            }
            if let (Some(a_bool), Some(b_bool)) = (literal::boolean(a), literal::boolean(b)) {
                return a_bool == b_bool;
            }
            false
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::array::Array;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Array);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Array::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_includes_true() {
        assert_eq!(transform("[1, 2, 3].includes(2);"), "true;\n");
    }

    #[test]
    fn test_includes_false() {
        assert_eq!(transform("[1, 2, 3].includes(5);"), "false;\n");
    }

    #[test]
    fn test_includes_string() {
        assert_eq!(transform("[\"a\", \"b\"].includes(\"b\");"), "true;\n");
    }

    #[test]
    fn test_includes_from_index() {
        assert_eq!(transform("[1, 2, 3].includes(1, 1);"), "false;\n");
    }
}
