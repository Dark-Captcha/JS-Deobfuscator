//! JSON.stringify pass.

use oxc::ast::ast::{ArrayExpressionElement, Expression, ObjectPropertyKind, PropertyKey};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `JSON.stringify(value)` → JSON string (for simple literals only)
#[derive(Default)]
pub struct Stringify;

impl Stringify {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "stringify" {
            return 0;
        }

        let Expression::Identifier(obj) = &member.object else {
            return 0;
        };

        if obj.name.as_str() != "JSON" {
            return 0;
        }

        if call.arguments.is_empty() || call.arguments.len() > 1 {
            return 0; // Don't handle replacer/space args
        }

        let Some(arg_expr) = call.arguments.first().and_then(|a| a.as_expression()) else {
            return 0;
        };

        let Some(json_str) = expr_to_json(arg_expr) else {
            return 0;
        };

        let atom = ctx.ast.atom(&json_str);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

fn expr_to_json(expr: &Expression) -> Option<String> {
    match expr {
        Expression::NullLiteral(_) => Some("null".to_string()),
        Expression::BooleanLiteral(b) => Some(if b.value { "true" } else { "false" }.to_string()),
        Expression::NumericLiteral(n) => {
            if n.value.is_nan() || n.value.is_infinite() {
                Some("null".to_string()) // JSON.stringify(NaN) = "null"
            } else {
                Some(serde_json::to_string(&n.value).ok()?)
            }
        }
        Expression::StringLiteral(s) => {
            Some(serde_json::to_string(s.value.as_str()).ok()?)
        }
        Expression::ArrayExpression(arr) => {
            if arr.elements.len() > 100 {
                return None;
            }
            let mut parts = Vec::new();
            for elem in &arr.elements {
                match elem {
                    ArrayExpressionElement::Elision(_) => parts.push("null".to_string()),
                    _ => {
                        let e = elem.as_expression()?;
                        parts.push(expr_to_json(e)?);
                    }
                }
            }
            Some(format!("[{}]", parts.join(",")))
        }
        Expression::ObjectExpression(obj) => {
            if obj.properties.len() > 50 {
                return None;
            }
            let mut parts = Vec::new();
            for prop in &obj.properties {
                let ObjectPropertyKind::ObjectProperty(p) = prop else {
                    return None; // Spread not supported
                };
                if p.computed || p.method || p.shorthand {
                    return None;
                }
                let key = match &p.key {
                    PropertyKey::StaticIdentifier(id) => id.name.to_string(),
                    PropertyKey::StringLiteral(s) => s.value.to_string(),
                    _ => return None,
                };
                let value = expr_to_json(&p.value)?;
                parts.push(format!("{}:{}", serde_json::to_string(&key).ok()?, value));
            }
            Some(format!("{{{}}}", parts.join(",")))
        }
        Expression::Identifier(id) if id.name == "undefined" => {
            None // JSON.stringify(undefined) = undefined (not a string)
        }
        Expression::ParenthesizedExpression(p) => expr_to_json(&p.expression),
        Expression::UnaryExpression(_) => {
            // Handle negative numbers
            if let Some(n) = literal::number(expr) {
                if n.is_nan() || n.is_infinite() {
                    Some("null".to_string())
                } else {
                    Some(serde_json::to_string(&n).ok()?)
                }
            } else {
                None
            }
        }
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::passes::json::Json;
    use oxc::allocator::Allocator;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Json);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Json::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_stringify_number() {
        // serde_json serializes integers as floats, and codegen wraps in parens
        let result = transform("JSON.stringify(42)");
        assert!(result.contains("42") && result.contains("\""));
    }

    #[test]
    fn test_stringify_string() {
        let result = transform("JSON.stringify(\"hello\")");
        assert!(result.contains("hello"));
    }

    #[test]
    fn test_stringify_bool() {
        let result = transform("JSON.stringify(true)");
        assert!(result.contains("true"));
    }

    #[test]
    fn test_stringify_null() {
        let result = transform("JSON.stringify(null)");
        assert!(result.contains("null"));
    }

    #[test]
    fn test_stringify_array() {
        let result = transform("JSON.stringify([1,2,3])");
        // serde_json serializes as [1.0,2.0,3.0] for floats
        assert!(result.contains("1") && result.contains("2") && result.contains("3"));
    }
}
