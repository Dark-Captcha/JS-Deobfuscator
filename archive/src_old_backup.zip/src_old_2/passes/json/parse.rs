//! JSON.parse pass.

use oxc::ast::ast::{Argument, ArrayExpressionElement, Expression, PropertyKey, PropertyKind};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `JSON.parse(str)` → parsed value (for simple literals only)
#[derive(Default)]
pub struct Parse;

impl Parse {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "parse" {
            return 0;
        }

        let Expression::Identifier(obj) = &member.object else {
            return 0;
        };

        if obj.name.as_str() != "JSON" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(input) = call.arguments.first().and_then(|a| match a {
            Argument::StringLiteral(s) => Some(s.value.as_str()),
            _ => a.as_expression().and_then(literal::string),
        }) else {
            return 0;
        };

        // Parse JSON and convert to AST
        let Ok(value) = serde_json::from_str::<serde_json::Value>(input) else {
            return 0;
        };

        let Some(result) = json_to_expr(&value, ctx) else {
            return 0;
        };

        *expr = result;

        1
    }
}

fn json_to_expr<'a>(value: &serde_json::Value, ctx: &mut TraverseCtx<'a, ()>) -> Option<Expression<'a>> {
    match value {
        serde_json::Value::Null => Some(ctx.ast.expression_null_literal(SPAN)),
        serde_json::Value::Bool(b) => Some(ctx.ast.expression_boolean_literal(SPAN, *b)),
        serde_json::Value::Number(n) => {
            let f = n.as_f64()?;
            Some(literal::make_number(f, &ctx.ast))
        }
        serde_json::Value::String(s) => {
            let atom = ctx.ast.atom(s);
            Some(ctx.ast.expression_string_literal(SPAN, atom, None))
        }
        serde_json::Value::Array(arr) => {
            if arr.len() > 100 {
                return None; // Too large
            }
            let mut elements = ctx.ast.vec();
            for item in arr {
                let elem = json_to_expr(item, ctx)?;
                elements.push(ArrayExpressionElement::from(elem));
            }
            Some(ctx.ast.expression_array(SPAN, elements))
        }
        serde_json::Value::Object(obj) => {
            if obj.len() > 50 {
                return None; // Too large
            }
            let mut properties = ctx.ast.vec();
            for (key, val) in obj {
                let key_atom = ctx.ast.atom(key);
                let key_expr = ctx.ast.expression_string_literal(SPAN, key_atom, None);
                let value_expr = json_to_expr(val, ctx)?;
                
                let prop = ctx.ast.object_property_kind_object_property(
                    SPAN,
                    PropertyKind::Init,
                    PropertyKey::from(key_expr),
                    value_expr,
                    false, // method
                    false, // shorthand
                    false, // computed
                );
                properties.push(prop);
            }
            Some(ctx.ast.expression_object(SPAN, properties))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::passes::json::Json;
    use oxc::allocator::Allocator;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Json);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Json::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_parse_number() {
        let result = transform("JSON.parse(\"42\")");
        assert!(result.contains("42"));
    }

    #[test]
    fn test_parse_string() {
        let result = transform("JSON.parse('\"hello\"')");
        assert!(result.contains("hello"));
    }

    #[test]
    fn test_parse_bool() {
        let result = transform("JSON.parse(\"true\")");
        assert!(result.contains("true"));
    }

    #[test]
    fn test_parse_null() {
        let result = transform("JSON.parse(\"null\")");
        assert!(result.contains("null"));
    }

    #[test]
    fn test_parse_array() {
        let result = transform("JSON.parse(\"[1,2,3]\")");
        assert!(result.contains("1") && result.contains("2") && result.contains("3"));
    }
}
