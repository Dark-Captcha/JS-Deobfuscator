//! JSON method passes.
//!
//! - [`Parse`] — `JSON.parse('{"a":1}')` → object literal
//! - [`Stringify`] — `JSON.stringify({a:1})` → `'{"a":1}'`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod parse;
mod stringify;

pub use parse::Parse;
pub use stringify::Stringify;

// ============================================================================
// JSON Group
// ============================================================================

/// Group of all JSON method passes.
#[derive(Default)]
pub struct Json {
    parse: Parse,
    stringify: Stringify,
}

impl Json {
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.parse.transform(expr, ctx);
        mods += self.stringify.transform(expr, ctx);
        mods
    }
}
