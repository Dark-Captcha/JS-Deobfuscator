//! Boolean AND literal pass.

use oxc::ast::ast::{Expression, LogicalOperator};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates boolean AND with literals: `true && false` → `false`
#[derive(Default)]
pub struct AndLiteral;

impl AndLiteral {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::LogicalExpression(logic) = expr else {
            return 0;
        };

        if logic.operator != LogicalOperator::And {
            return 0;
        }

        let Some(left) = literal::boolean(&logic.left) else {
            return 0;
        };
        let Some(right) = literal::boolean(&logic.right) else {
            return 0;
        };

        let result = left && right;
        *expr = ctx.ast.expression_boolean_literal(SPAN, result);

        1
    }
}
