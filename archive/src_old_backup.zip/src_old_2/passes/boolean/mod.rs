//! Boolean evaluation passes.
//!
//! - [`Not`] — `!true` → `false`
//! - [`AndLiteral`] — `true && false` → `false`
//! - [`OrLiteral`] — `true || false` → `true`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod and_literal;
mod not;
mod or_literal;

pub use and_literal::AndLiteral;
pub use not::Not;
pub use or_literal::OrLiteral;

// ============================================================================
// Boolean Group
// ============================================================================

/// Group of all boolean evaluation passes.
#[derive(Default)]
pub struct Boolean {
    not: Not,
    and_literal: AndLiteral,
    or_literal: OrLiteral,
}

impl Boolean {
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.not.transform(expr, ctx);
        mods += self.and_literal.transform(expr, ctx);
        mods += self.or_literal.transform(expr, ctx);
        mods
    }
}
