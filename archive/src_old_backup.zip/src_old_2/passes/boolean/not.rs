//! Boolean NOT pass.

use oxc::ast::ast::{Expression, UnaryOperator};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates boolean NOT: `!true` → `false`
#[derive(Default)]
pub struct Not;

impl Not {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::UnaryExpression(unary) = expr else {
            return 0;
        };

        if unary.operator != UnaryOperator::LogicalNot {
            return 0;
        }

        let Some(value) = literal::boolean(&unary.argument) else {
            return 0;
        };

        let result = !value;
        *expr = ctx.ast.expression_boolean_literal(SPAN, result);

        1
    }
}
