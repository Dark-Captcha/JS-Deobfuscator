//! Unsigned right shift pass.

use oxc::ast::ast::{BinaryOperator, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates unsigned right shift: `-1 >>> 0` → `4294967295`
#[derive(Default)]
pub struct ShiftRightUnsigned;

impl ShiftRightUnsigned {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else {
            return 0;
        };

        if bin.operator != BinaryOperator::ShiftRightZeroFill {
            return 0;
        }

        let Some(left) = literal::number(&bin.left) else {
            return 0;
        };
        let Some(right) = literal::number(&bin.right) else {
            return 0;
        };

        let left_u32 = left as i32 as u32;
        let shift = (right as u32) & 0x1f;
        let result = (left_u32 >> shift) as f64;

        *expr = literal::make_number(result, &ctx.ast);

        1
    }
}
