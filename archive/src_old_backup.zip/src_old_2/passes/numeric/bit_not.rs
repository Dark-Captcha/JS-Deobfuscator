//! Bitwise NOT pass.

use oxc::ast::ast::{Expression, UnaryOperator};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates bitwise NOT: `~5` → `-6`
#[derive(Default)]
pub struct BitNot;

impl BitNot {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::UnaryExpression(unary) = expr else {
            return 0;
        };

        if unary.operator != UnaryOperator::BitwiseNot {
            return 0;
        }

        let Some(value) = literal::number(&unary.argument) else {
            return 0;
        };

        let value_i32 = value as i32;
        let result = (!value_i32) as f64;

        *expr = literal::make_number(result, &ctx.ast);

        1
    }
}
