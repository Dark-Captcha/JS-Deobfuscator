//! Left shift pass.

use oxc::ast::ast::{BinaryOperator, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates left shift: `1 << 2` → `4`
#[derive(Default)]
pub struct ShiftLeft;

impl ShiftLeft {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else {
            return 0;
        };

        if bin.operator != BinaryOperator::ShiftLeft {
            return 0;
        }

        let Some(left) = literal::number(&bin.left) else {
            return 0;
        };
        let Some(right) = literal::number(&bin.right) else {
            return 0;
        };

        let left_i32 = left as i32;
        let shift = (right as u32) & 0x1f;
        let result = (left_i32 << shift) as f64;

        *expr = literal::make_number(result, &ctx.ast);

        1
    }
}
