//! Numeric multiplication pass.

use oxc::ast::ast::{BinaryOperator, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates numeric multiplication: `2 * 3` → `6`
#[derive(Default)]
pub struct Mul;

impl Mul {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else {
            return 0;
        };

        if bin.operator != BinaryOperator::Multiplication {
            return 0;
        }

        let Some(left) = literal::number(&bin.left) else {
            return 0;
        };
        let Some(right) = literal::number(&bin.right) else {
            return 0;
        };

        let result = left * right;
        *expr = literal::make_number(result, &ctx.ast);

        1
    }
}
