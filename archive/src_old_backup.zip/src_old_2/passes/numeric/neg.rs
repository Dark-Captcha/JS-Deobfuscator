//! Numeric negation pass.

use oxc::ast::ast::{Expression, UnaryOperator};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Simplifies double negation: `--5` → `5`, `-(-5)` → `5`
#[derive(Default)]
pub struct Neg;

impl Neg {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::UnaryExpression(outer) = expr else {
            return 0;
        };

        if outer.operator != UnaryOperator::UnaryNegation {
            return 0;
        }

        // Check for double negation: -(-x) or --x
        if let Expression::UnaryExpression(inner) = &outer.argument
            && inner.operator == UnaryOperator::UnaryNegation
            && let Some(value) = literal::number(&inner.argument)
        {
            *expr = literal::make_number(value, &ctx.ast);
            return 1;
        }

        0
    }
}
