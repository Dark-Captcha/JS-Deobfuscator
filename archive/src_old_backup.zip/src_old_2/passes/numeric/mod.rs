//! Numeric evaluation passes.
//!
//! These passes evaluate numeric operations on literal values:
//!
//! - [`Add`] — `1 + 2` → `3`
//! - [`Sub`] — `3 - 1` → `2`
//! - [`Mul`] — `2 * 3` → `6`
//! - [`Div`] — `6 / 2` → `3`
//! - [`Neg`] — `-(5)` → `-5` (double negation)
//! - [`Mod`] — `5 % 2` → `1`
//! - [`Pow`] — `2 ** 3` → `8`
//! - [`BitAnd`] — `5 & 3` → `1`
//! - [`BitOr`] — `5 | 3` → `7`
//! - [`BitXor`] — `5 ^ 3` → `6`
//! - [`BitNot`] — `~5` → `-6`
//! - [`ShiftLeft`] — `1 << 2` → `4`
//! - [`ShiftRight`] — `4 >> 1` → `2`
//! - [`ShiftRightUnsigned`] — `-1 >>> 0` → `4294967295`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

// ============================================================================
// Modules
// ============================================================================

mod add;
mod bit_and;
mod bit_not;
mod bit_or;
mod bit_xor;
mod div;
mod mod_;
mod mul;
mod neg;
mod pow;
mod shift_left;
mod shift_right;
mod shift_right_unsigned;
mod sub;

// ============================================================================
// Re-exports
// ============================================================================

pub use add::Add;
pub use bit_and::BitAnd;
pub use bit_not::BitNot;
pub use bit_or::BitOr;
pub use bit_xor::BitXor;
pub use div::Div;
pub use mod_::Mod;
pub use mul::Mul;
pub use neg::Neg;
pub use pow::Pow;
pub use shift_left::ShiftLeft;
pub use shift_right::ShiftRight;
pub use shift_right_unsigned::ShiftRightUnsigned;
pub use sub::Sub;

// ============================================================================
// Numeric Group
// ============================================================================

/// Group of all numeric evaluation passes.
#[derive(Default)]
pub struct Numeric {
    add: Add,
    sub: Sub,
    mul: Mul,
    div: Div,
    mod_: Mod,
    pow: Pow,
    neg: Neg,
    bit_and: BitAnd,
    bit_or: BitOr,
    bit_xor: BitXor,
    bit_not: BitNot,
    shift_left: ShiftLeft,
    shift_right: ShiftRight,
    shift_right_unsigned: ShiftRightUnsigned,
}

impl Numeric {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform expression through all numeric passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.add.transform(expr, ctx);
        mods += self.sub.transform(expr, ctx);
        mods += self.mul.transform(expr, ctx);
        mods += self.div.transform(expr, ctx);
        mods += self.mod_.transform(expr, ctx);
        mods += self.pow.transform(expr, ctx);
        mods += self.neg.transform(expr, ctx);
        mods += self.bit_and.transform(expr, ctx);
        mods += self.bit_or.transform(expr, ctx);
        mods += self.bit_xor.transform(expr, ctx);
        mods += self.bit_not.transform(expr, ctx);
        mods += self.shift_left.transform(expr, ctx);
        mods += self.shift_right.transform(expr, ctx);
        mods += self.shift_right_unsigned.transform(expr, ctx);
        mods
    }
}
