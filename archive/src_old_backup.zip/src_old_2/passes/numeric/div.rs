//! Numeric division pass.

use oxc::ast::ast::{BinaryOperator, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates numeric division: `6 / 2` → `3`
///
/// # Special cases
///
/// - Division by zero: unchanged (returns Infinity/-Infinity/NaN in JS)
/// - Result is Infinity/NaN: unchanged (keep original for clarity)
#[derive(Default)]
pub struct Div;

impl Div {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else {
            return 0;
        };

        if bin.operator != BinaryOperator::Division {
            return 0;
        }

        let Some(left) = literal::number(&bin.left) else {
            return 0;
        };
        let Some(right) = literal::number(&bin.right) else {
            return 0;
        };

        // Don't evaluate division by zero
        if right == 0.0 {
            return 0;
        }

        let result = left / right;

        // Don't replace with Infinity or NaN
        if result.is_infinite() || result.is_nan() {
            return 0;
        }

        *expr = literal::make_number(result, &ctx.ast);

        1
    }
}
