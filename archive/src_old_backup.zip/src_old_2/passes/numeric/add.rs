//! Numeric addition pass.

use oxc::ast::ast::{BinaryOperator, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Add Pass
// ============================================================================

/// Evaluates numeric addition: `1 + 2` → `3`
///
/// # Handles
///
/// - Direct literals: `1 + 2`
/// - Negative numbers: `-1 + 2`
/// - Parenthesized: `(1) + (2)`
///
/// # Does NOT handle
///
/// - String concatenation: `"a" + "b"` (use string::Concat)
/// - Mixed types: `1 + "2"`
#[derive(Default)]
pub struct Add;

impl Add {
    /// Transform expression. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else {
            return 0;
        };

        if bin.operator != BinaryOperator::Addition {
            return 0;
        }

        let Some(left) = literal::number(&bin.left) else {
            return 0;
        };
        let Some(right) = literal::number(&bin.right) else {
            return 0;
        };

        let result = left + right;
        *expr = literal::make_number(result, &ctx.ast);

        1
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    use crate::passes::numeric::Numeric;

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Numeric);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(
                &mut self,
                expr: &mut Expression<'a>,
                ctx: &mut TraverseCtx<'a, ()>,
            ) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Numeric::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_simple_addition() {
        assert_eq!(transform("1 + 2"), "3;\n");
    }

    #[test]
    fn test_negative_numbers() {
        assert_eq!(transform("-1 + 3"), "2;\n");
    }

    #[test]
    fn test_result_negative() {
        assert_eq!(transform("1 + -5"), "-4;\n");
    }

    #[test]
    fn test_floats() {
        assert_eq!(transform("1.5 + 2.5"), "4;\n");
    }

    #[test]
    fn test_not_addition() {
        assert_eq!(transform("1 - 2"), "-1;\n");
    }

    #[test]
    fn test_non_numeric() {
        assert_eq!(transform("x + 2"), "x + 2;\n");
    }
}
