//! Bitwise AND pass.

use oxc::ast::ast::{BinaryOperator, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates bitwise AND: `5 & 3` → `1`
#[derive(Default)]
pub struct BitAnd;

impl BitAnd {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else {
            return 0;
        };

        if bin.operator != BinaryOperator::BitwiseAnd {
            return 0;
        }

        let Some(left) = literal::number(&bin.left) else {
            return 0;
        };
        let Some(right) = literal::number(&bin.right) else {
            return 0;
        };

        let left_i32 = left as i32;
        let right_i32 = right as i32;
        let result = (left_i32 & right_i32) as f64;

        *expr = literal::make_number(result, &ctx.ast);

        1
    }
}
