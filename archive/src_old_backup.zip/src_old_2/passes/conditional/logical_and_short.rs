//! Logical AND short-circuit pass.

use oxc::allocator::TakeIn;
use oxc::ast::ast::{Expression, LogicalOperator};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// LogicalAndShort Pass
// ============================================================================

/// Short-circuits logical AND: `false && x` → `false`
#[derive(Default)]
pub struct LogicalAndShort;

impl LogicalAndShort {
    /// Transform expression. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::LogicalExpression(logic) = expr else {
            return 0;
        };

        if logic.operator != LogicalOperator::And {
            return 0;
        }

        let Some(left_truthy) = literal::is_truthy(&logic.left) else {
            return 0;
        };

        // false && x → false (returns left)
        // true && x → x (returns right)
        let replacement = if left_truthy {
            logic.right.take_in(ctx.ast.allocator)
        } else {
            logic.left.take_in(ctx.ast.allocator)
        };

        *expr = replacement;

        tracing::trace!(
            target: "deob::pass::conditional_logical_and_short",
            left_truthy,
            "short-circuited"
        );

        1
    }
}
