//! Conditional simplification passes.
//!
//! - [`Ternary`] — `true ? a : b` → `a`
//! - [`LogicalAndShort`] — `false && x` → `false`
//! - [`LogicalOrShort`] — `true || x` → `true`
//! - [`NullishCoalesce`] — `null ?? x` → `x`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod logical_and_short;
mod logical_or_short;
mod nullish_coalesce;
mod ternary;

pub use logical_and_short::LogicalAndShort;
pub use logical_or_short::LogicalOrShort;
pub use nullish_coalesce::NullishCoalesce;
pub use ternary::Ternary;

// ============================================================================
// Conditional Group
// ============================================================================

/// Group of all conditional simplification passes.
#[derive(Default)]
pub struct Conditional {
    ternary: Ternary,
    logical_and_short: LogicalAndShort,
    logical_or_short: LogicalOrShort,
    nullish_coalesce: NullishCoalesce,
}

impl Conditional {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform expression through all conditional passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.ternary.transform(expr, ctx);
        mods += self.logical_and_short.transform(expr, ctx);
        mods += self.logical_or_short.transform(expr, ctx);
        mods += self.nullish_coalesce.transform(expr, ctx);
        mods
    }
}
