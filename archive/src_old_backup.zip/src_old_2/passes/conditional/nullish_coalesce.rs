//! Nullish coalescing pass.

use oxc::allocator::TakeIn;
use oxc::ast::ast::{Expression, LogicalOperator};
use oxc_traverse::TraverseCtx;

// ============================================================================
// NullishCoalesce Pass
// ============================================================================

/// Simplifies nullish coalescing: `null ?? x` → `x`, `5 ?? x` → `5`
#[derive(Default)]
pub struct NullishCoalesce;

impl NullishCoalesce {
    /// Transform expression. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::LogicalExpression(logic) = expr else {
            return 0;
        };

        if logic.operator != LogicalOperator::Coalesce {
            return 0;
        }

        let is_nullish = is_nullish_literal(&logic.left);

        let replacement = match is_nullish {
            Some(true) => logic.right.take_in(ctx.ast.allocator),
            Some(false) => logic.left.take_in(ctx.ast.allocator),
            None => return 0,
        };

        *expr = replacement;
        1
    }
}

/// Check if expression is null or undefined literal
fn is_nullish_literal(expr: &Expression) -> Option<bool> {
    match expr {
        Expression::NullLiteral(_) => Some(true),
        Expression::Identifier(id) if id.name == "undefined" => Some(true),
        Expression::NumericLiteral(_)
        | Expression::StringLiteral(_)
        | Expression::BooleanLiteral(_)
        | Expression::ArrayExpression(_)
        | Expression::ObjectExpression(_) => Some(false),
        Expression::ParenthesizedExpression(p) => is_nullish_literal(&p.expression),
        _ => None,
    }
}
