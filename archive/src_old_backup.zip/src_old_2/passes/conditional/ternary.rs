//! Ternary conditional pass.

use oxc::allocator::TakeIn;
use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Ternary Pass
// ============================================================================

/// Simplifies ternary with known condition: `true ? a : b` → `a`
#[derive(Default)]
pub struct Ternary;

impl Ternary {
    /// Transform expression. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::ConditionalExpression(cond) = expr else {
            return 0;
        };

        let Some(test_value) = literal::is_truthy(&cond.test) else {
            return 0;
        };

        let replacement = if test_value {
            cond.consequent.take_in(ctx.ast.allocator)
        } else {
            cond.alternate.take_in(ctx.ast.allocator)
        };

        *expr = replacement;

        tracing::trace!(
            target: "deob::pass::conditional_ternary",
            test_value,
            "simplified"
        );

        1
    }
}
