//! Logical OR short-circuit pass.

use oxc::allocator::TakeIn;
use oxc::ast::ast::{Expression, LogicalOperator};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// LogicalOrShort Pass
// ============================================================================

/// Short-circuits logical OR: `true || x` → `true`
#[derive(Default)]
pub struct LogicalOrShort;

impl LogicalOrShort {
    /// Transform expression. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::LogicalExpression(logic) = expr else {
            return 0;
        };

        if logic.operator != LogicalOperator::Or {
            return 0;
        }

        let Some(left_truthy) = literal::is_truthy(&logic.left) else {
            return 0;
        };

        // true || x → true (returns left)
        // false || x → x (returns right)
        let replacement = if left_truthy {
            logic.left.take_in(ctx.ast.allocator)
        } else {
            logic.right.take_in(ctx.ast.allocator)
        };

        *expr = replacement;

        tracing::trace!(
            target: "deob::pass::conditional_logical_or_short",
            left_truthy,
            "short-circuited"
        );

        1
    }
}
