//! Transformation passes.
//!
//! This module contains all atomic transformation passes organized by category:
//!
//! - [`numeric`] — Numeric evaluation (add, sub, mul, bitwise, shifts)
//! - [`boolean`] — Boolean evaluation (not, and, or)
//! - [`string`] — String evaluation (concat, charAt, length)
//! - [`array`] — Array evaluation (length, join, at, indexOf, includes, slice, concat, reverse)
//! - [`compare`] — Comparison evaluation (===, !==, <, <=, >, >=)
//! - [`typeof_`] — Typeof evaluation
//! - [`conditional`] — Conditional simplification (ternary, logical short-circuit)
//! - [`expression`] — Expression simplification (parentheses, sequences, void)
//! - [`dead`] — Dead code removal (debugger, empty statements)
//! - [`control`] — Control flow simplification (if constant, while false)
//! - [`variable`] — Variable transformations (constant inlining)
//! - [`math`] — Math methods (floor, ceil, round, abs, min, max, pow, sqrt, sign, trunc)
//! - [`parse`] — Parse functions (parseInt, parseFloat)
//! - [`encoding`] — Encoding functions (atob, btoa)
//! - [`json`] — JSON methods (parse, stringify)
//! - [`object`] — Object methods (keys, values, entries)
//! - [`number`] — Number methods (isNaN, isFinite, isInteger)
//! - [`uri`] — URI encoding (encodeURI, decodeURI, encodeURIComponent, decodeURIComponent)
//!
//! # Usage
//!
//! ```ignore
//! use dark_captcha::core::Engine;
//!
//! let engine = Engine::new();
//! ```

// ============================================================================
// Modules
// ============================================================================

pub mod array;
pub mod boolean;
pub mod coercion;
pub mod compare;
pub mod conditional;
pub mod control;
pub mod dead;
pub mod encoding;
pub mod expression;
pub mod json;
pub mod math;
pub mod number;
pub mod numeric;
pub mod object;
pub mod parse;
pub mod regexp;
pub mod string;
pub mod typeof_;
pub mod uri;
pub mod variable;
