//! encodeURI pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `encodeURI(str)` → encoded string
#[derive(Default)]
pub struct EncodeUri;

impl EncodeUri {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::Identifier(callee) = &call.callee else {
            return 0;
        };

        if callee.name.as_str() != "encodeURI" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(s) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::string) else {
            return 0;
        };

        let encoded = encode_uri(s);

        let atom = ctx.ast.atom(&encoded);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
        1
    }
}

fn encode_uri(s: &str) -> String {
    // encodeURI doesn't encode: A-Z a-z 0-9 - _ . ! ~ * ' ( ) ; / ? : @ & = + $ , #
    let mut result = String::with_capacity(s.len() * 3);
    
    for c in s.chars() {
        if c.is_ascii_alphanumeric() 
            || "-_.!~*'()".contains(c)
            || ";/?:@&=+$,#".contains(c) 
        {
            result.push(c);
        } else if c as u32 <= 0x7F {
            result.push_str(&format!("%{:02X}", c as u8));
        } else {
            // UTF-8 encode non-ASCII
            let mut buf = [0u8; 4];
            let encoded = c.encode_utf8(&mut buf);
            for byte in encoded.bytes() {
                result.push_str(&format!("%{:02X}", byte));
            }
        }
    }
    
    result
}

#[cfg(test)]
mod tests {
    use crate::passes::uri::Uri;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Uri);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Uri::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_encode_uri_space() {
        let result = transform("encodeURI(\" \")");
        assert!(result.contains("%20"));
    }

    #[test]
    fn test_encode_uri_preserves_slash() {
        // encodeURI should preserve /
        let result = transform("encodeURI(\"/path\")");
        assert!(result.contains("/path"));
    }
}
