//! URI encoding/decoding passes.
//!
//! - [`DecodeUri`] — `decodeURI("%20")` → `" "`
//! - [`EncodeUri`] — `encodeURI(" ")` → `"%20"`
//! - [`DecodeUriComponent`] — `decodeURIComponent("%20")` → `" "`
//! - [`EncodeUriComponent`] — `encodeURIComponent(" ")` → `"%20"`
//! - [`Escape`] — `escape(" ")` → `"%20"`
//! - [`Unescape`] — `unescape("%20")` → `" "`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod decode_uri;
mod decode_uri_component;
mod encode_uri;
mod encode_uri_component;
mod escape;
mod unescape;

pub use decode_uri::DecodeUri;
pub use decode_uri_component::DecodeUriComponent;
pub use encode_uri::EncodeUri;
pub use encode_uri_component::EncodeUriComponent;
pub use escape::Escape;
pub use unescape::Unescape;

/// Group of all URI encoding passes.
#[derive(Default)]
pub struct Uri {
    decode_uri: DecodeUri,
    encode_uri: EncodeUri,
    decode_uri_component: DecodeUriComponent,
    encode_uri_component: EncodeUriComponent,
    escape: Escape,
    unescape: Unescape,
}

impl Uri {
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.decode_uri.transform(expr, ctx);
        mods += self.encode_uri.transform(expr, ctx);
        mods += self.decode_uri_component.transform(expr, ctx);
        mods += self.encode_uri_component.transform(expr, ctx);
        mods += self.escape.transform(expr, ctx);
        mods += self.unescape.transform(expr, ctx);
        mods
    }
}
