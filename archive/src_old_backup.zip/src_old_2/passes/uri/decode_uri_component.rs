//! decodeURIComponent pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `decodeURIComponent(str)` → decoded string
#[derive(Default)]
pub struct DecodeUriComponent;

impl DecodeUriComponent {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::Identifier(callee) = &call.callee else {
            return 0;
        };

        if callee.name.as_str() != "decodeURIComponent" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(s) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::string) else {
            return 0;
        };

        // decodeURIComponent decodes everything
        let Some(decoded) = decode_uri_component(s) else {
            return 0;
        };

        let atom = ctx.ast.atom(&decoded);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
        1
    }
}

fn decode_uri_component(s: &str) -> Option<String> {
    let mut result = String::with_capacity(s.len());
    let mut bytes = Vec::new();
    let mut chars = s.chars().peekable();
    
    while let Some(c) = chars.next() {
        if c == '%' {
            let hex: String = chars.by_ref().take(2).collect();
            if hex.len() != 2 {
                return None;
            }
            let byte = u8::from_str_radix(&hex, 16).ok()?;
            bytes.push(byte);
        } else {
            if !bytes.is_empty() {
                result.push_str(&String::from_utf8_lossy(&bytes));
                bytes.clear();
            }
            result.push(c);
        }
    }
    
    if !bytes.is_empty() {
        result.push_str(&String::from_utf8_lossy(&bytes));
    }
    
    Some(result)
}

#[cfg(test)]
mod tests {
    use crate::passes::uri::Uri;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Uri);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Uri::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_decode_uri_component_space() {
        let result = transform("decodeURIComponent(\"%20\")");
        assert!(result.contains(" "));
    }

    #[test]
    fn test_decode_uri_component_slash() {
        // decodeURIComponent decodes %2F to /
        let result = transform("decodeURIComponent(\"%2F\")");
        assert!(result.contains("/"));
    }
}
