//! decodeURI pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `decodeURI(str)` → decoded string
#[derive(Default)]
pub struct DecodeUri;

impl DecodeUri {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::Identifier(callee) = &call.callee else {
            return 0;
        };

        if callee.name.as_str() != "decodeURI" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(s) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::string) else {
            return 0;
        };

        // decodeURI doesn't decode: ; / ? : @ & = + $ , #
        let Some(decoded) = decode_uri(s) else {
            return 0;
        };

        let atom = ctx.ast.atom(&decoded);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
        1
    }
}

fn decode_uri(s: &str) -> Option<String> {
    // decodeURI preserves these characters even if encoded
    let reserved = ";/?:@&=+$,#";
    
    let mut result = String::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    
    while let Some(c) = chars.next() {
        if c == '%' {
            let hex: String = chars.by_ref().take(2).collect();
            if hex.len() != 2 {
                return None; // Malformed
            }
            let byte = u8::from_str_radix(&hex, 16).ok()?;
            let decoded_char = byte as char;
            
            // decodeURI doesn't decode reserved characters
            if reserved.contains(decoded_char) {
                result.push('%');
                result.push_str(&hex.to_uppercase());
            } else {
                result.push(decoded_char);
            }
        } else {
            result.push(c);
        }
    }
    
    Some(result)
}

#[cfg(test)]
mod tests {
    use crate::passes::uri::Uri;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Uri);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Uri::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_decode_uri_space() {
        let result = transform("decodeURI(\"%20\")");
        assert!(result.contains(" "));
    }

    #[test]
    fn test_decode_uri_preserves_reserved() {
        // decodeURI should preserve %2F (/)
        let result = transform("decodeURI(\"%2F\")");
        assert!(result.contains("%2F") || result.contains("/"));
    }
}
