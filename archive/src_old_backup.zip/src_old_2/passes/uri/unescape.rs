//! unescape pass (deprecated but still used).

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `unescape(str)` → unescaped string
#[derive(Default)]
pub struct Unescape;

impl Unescape {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else { return 0 };
        let Expression::Identifier(callee) = &call.callee else { return 0 };
        if callee.name.as_str() != "unescape" { return 0 }
        if call.arguments.len() != 1 { return 0 }

        let Some(s) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::string) else { return 0 };

        let Some(decoded) = unescape_string(s) else { return 0 };
        let atom = ctx.ast.atom(&decoded);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
        1
    }
}

fn unescape_string(s: &str) -> Option<String> {
    let mut result = String::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    
    while let Some(c) = chars.next() {
        if c == '%' {
            if chars.peek() == Some(&'u') {
                // %uXXXX format
                chars.next(); // consume 'u'
                let hex: String = chars.by_ref().take(4).collect();
                if hex.len() != 4 {
                    return None;
                }
                let code = u32::from_str_radix(&hex, 16).ok()?;
                result.push(char::from_u32(code)?);
            } else {
                // %XX format
                let hex: String = chars.by_ref().take(2).collect();
                if hex.len() != 2 {
                    return None;
                }
                let byte = u8::from_str_radix(&hex, 16).ok()?;
                result.push(byte as char);
            }
        } else {
            result.push(c);
        }
    }
    
    Some(result)
}

#[cfg(test)]
mod tests {
    use crate::passes::uri::Uri;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(Uri);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }
        let mut visitor = Visitor(Uri::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_unescape() {
        let result = transform("unescape(\"%20\")");
        assert!(result.contains(" "));
    }
}
