//! Comparison evaluation passes.
//!
//! - [`StrictEq`] — `1 === 1` → `true`
//! - [`StrictNeq`] — `1 !== 2` → `true`
//! - [`Lt`] — `1 < 2` → `true`
//! - [`Lte`] — `1 <= 2` → `true`
//! - [`Gt`] — `2 > 1` → `true`
//! - [`Gte`] — `2 >= 1` → `true`
//! - [`LooseEq`] — `1 == "1"` → `true`
//! - [`LooseNeq`] — `1 != "2"` → `true`
//! - [`InOperator`] — `"a" in {a:1}` → `true`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod gt;
mod gte;
mod in_operator;
mod loose_eq;
mod loose_neq;
mod lt;
mod lte;
mod strict_eq;
mod strict_neq;

pub use gt::Gt;
pub use gte::Gte;
pub use in_operator::InOperator;
pub use loose_eq::LooseEq;
pub use loose_neq::LooseNeq;
pub use lt::Lt;
pub use lte::Lte;
pub use strict_eq::StrictEq;
pub use strict_neq::StrictNeq;

// ============================================================================
// Compare Group
// ============================================================================

/// Group of all comparison evaluation passes.
#[derive(Default)]
pub struct Compare {
    strict_eq: StrictEq,
    strict_neq: StrictNeq,
    loose_eq: LooseEq,
    loose_neq: LooseNeq,
    in_operator: InOperator,
    lt: Lt,
    lte: Lte,
    gt: Gt,
    gte: Gte,
}

impl Compare {
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.strict_eq.transform(expr, ctx);
        mods += self.strict_neq.transform(expr, ctx);
        mods += self.loose_eq.transform(expr, ctx);
        mods += self.loose_neq.transform(expr, ctx);
        mods += self.in_operator.transform(expr, ctx);
        mods += self.lt.transform(expr, ctx);
        mods += self.lte.transform(expr, ctx);
        mods += self.gt.transform(expr, ctx);
        mods += self.gte.transform(expr, ctx);
        mods
    }
}
