//! Strict inequality pass.

use oxc::ast::ast::{BinaryOperator, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal::LiteralValue;

/// Evaluates strict inequality: `1 !== 2` → `true`
#[derive(Default)]
pub struct StrictNeq;

impl StrictNeq {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else {
            return 0;
        };

        if bin.operator != BinaryOperator::StrictInequality {
            return 0;
        }

        let Some(left) = LiteralValue::from_expr(&bin.left) else {
            return 0;
        };
        let Some(right) = LiteralValue::from_expr(&bin.right) else {
            return 0;
        };

        let result = left != right;
        *expr = ctx.ast.expression_boolean_literal(SPAN, result);

        1
    }
}
