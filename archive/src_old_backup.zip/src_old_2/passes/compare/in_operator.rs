//! `in` operator pass.

use oxc::ast::ast::{BinaryOperator, Expression, ObjectPropertyKind, PropertyKey};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `"a" in {a:1}` → `true`
#[derive(Default)]
pub struct InOperator;

impl InOperator {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else { return 0 };
        if bin.operator != BinaryOperator::In { return 0 }

        // Get the key to check
        let key = if let Some(s) = literal::string(&bin.left) {
            s.to_string()
        } else if let Some(n) = literal::number(&bin.left) {
            if n.fract() == 0.0 {
                format!("{}", n as i64)
            } else {
                return 0;
            }
        } else {
            return 0;
        };

        // Check if right side is an object literal
        let Expression::ObjectExpression(obj) = &bin.right else { return 0 };

        let mut found = false;
        for prop in &obj.properties {
            let ObjectPropertyKind::ObjectProperty(p) = prop else { continue };
            
            let prop_key = match &p.key {
                PropertyKey::StaticIdentifier(id) => id.name.to_string(),
                PropertyKey::StringLiteral(s) => s.value.to_string(),
                PropertyKey::NumericLiteral(n) => {
                    if n.value.fract() == 0.0 {
                        format!("{}", n.value as i64)
                    } else {
                        n.value.to_string()
                    }
                }
                _ => continue,
            };
            
            if prop_key == key {
                found = true;
                break;
            }
        }

        *expr = ctx.ast.expression_boolean_literal(SPAN, found);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::compare::Compare;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(Compare);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }
        let mut visitor = Visitor(Compare::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_in_true() {
        assert_eq!(transform("\"a\" in {a:1}"), "true;\n");
    }

    #[test]
    fn test_in_false() {
        assert_eq!(transform("\"b\" in {a:1}"), "false;\n");
    }

    #[test]
    fn test_in_numeric_key() {
        assert_eq!(transform("0 in {0: \"x\"}"), "true;\n");
    }
}
