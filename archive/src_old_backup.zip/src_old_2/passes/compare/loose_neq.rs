//! Loose inequality (!=) pass.

use oxc::ast::ast::{BinaryOperator, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `a != b` with type coercion
#[derive(Default)]
pub struct LooseNeq;

impl LooseNeq {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else { return 0 };
        if bin.operator != BinaryOperator::Inequality { return 0 }

        let Some(result) = loose_equals(&bin.left, &bin.right) else { return 0 };
        *expr = ctx.ast.expression_boolean_literal(SPAN, !result);
        1
    }
}

fn loose_equals(left: &Expression, right: &Expression) -> Option<bool> {
    match (left, right) {
        (Expression::NullLiteral(_), Expression::NullLiteral(_)) => return Some(true),
        (Expression::Identifier(id), Expression::NullLiteral(_)) if id.name == "undefined" => return Some(true),
        (Expression::NullLiteral(_), Expression::Identifier(id)) if id.name == "undefined" => return Some(true),
        (Expression::Identifier(l), Expression::Identifier(r)) if l.name == "undefined" && r.name == "undefined" => return Some(true),
        _ => {}
    }

    let left_num = literal::number(left);
    let right_num = literal::number(right);
    let left_str = literal::string(left);
    let right_str = literal::string(right);
    let left_bool = literal::boolean(left);
    let right_bool = literal::boolean(right);

    if let (Some(l), Some(r)) = (left_num, right_num) {
        return Some(l == r);
    }
    if let (Some(l), Some(r)) = (left_str, right_str) {
        return Some(l == r);
    }
    if let (Some(l), Some(r)) = (left_bool, right_bool) {
        return Some(l == r);
    }

    if let (Some(n), Some(s)) = (left_num, right_str) {
        if let Ok(s_num) = s.trim().parse::<f64>() {
            return Some(n == s_num);
        }
        return Some(false);
    }
    if let (Some(s), Some(n)) = (left_str, right_num) {
        if let Ok(s_num) = s.trim().parse::<f64>() {
            return Some(s_num == n);
        }
        return Some(false);
    }

    if let Some(b) = left_bool {
        let b_num = if b { 1.0 } else { 0.0 };
        if let Some(n) = right_num {
            return Some(b_num == n);
        }
    }
    if let Some(b) = right_bool {
        let b_num = if b { 1.0 } else { 0.0 };
        if let Some(n) = left_num {
            return Some(n == b_num);
        }
    }

    None
}

#[cfg(test)]
mod tests {
    use crate::passes::compare::Compare;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(Compare);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }
        let mut visitor = Visitor(Compare::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_loose_neq() {
        assert_eq!(transform("1 != \"1\""), "false;\n");
    }
}
