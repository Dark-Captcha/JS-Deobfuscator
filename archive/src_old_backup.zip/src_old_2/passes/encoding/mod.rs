//! Encoding/decoding function passes.
//!
//! - [`Atob`] — `atob("aGVsbG8=")` → `"hello"`
//! - [`Btoa`] — `btoa("hello")` → `"aGVsbG8="`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod atob;
mod btoa;

pub use atob::Atob;
pub use btoa::Btoa;

// ============================================================================
// Encoding Group
// ============================================================================

/// Group of all encoding/decoding passes.
#[derive(Default)]
pub struct Encoding {
    atob: Atob,
    btoa: Btoa,
}

impl Encoding {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform expression through all encoding passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.atob.transform(expr, ctx);
        mods += self.btoa.transform(expr, ctx);
        mods
    }
}
