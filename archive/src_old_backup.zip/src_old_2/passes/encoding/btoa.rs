//! btoa (base64 encode) pass.

use oxc::ast::ast::{Argument, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `btoa(string)` → base64 encoded string
#[derive(Default)]
pub struct Btoa;

impl Btoa {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::Identifier(id) = &call.callee else {
            return 0;
        };

        if id.name.as_str() != "btoa" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(input) = call.arguments.first().and_then(|a| match a {
            Argument::StringLiteral(s) => Some(s.value.to_string()),
            _ => a.as_expression().and_then(literal::string).map(|s| s.to_string()),
        }) else {
            return 0;
        };

        // Check all chars are Latin-1 (0-255)
        if input.chars().any(|c| c as u32 > 255) {
            return 0;
        }

        let encoded = base64_encode(&input);

        let atom = ctx.ast.atom(&encoded);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

/// Simple base64 encoder (Latin-1 only, like browser btoa)
fn base64_encode(input: &str) -> String {
    const ALPHABET: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    let bytes: Vec<u8> = input.chars().map(|c| c as u8).collect();
    let mut output = String::new();

    for chunk in bytes.chunks(3) {
        let b0 = chunk[0] as u32;
        let b1 = chunk.get(1).map(|&b| b as u32).unwrap_or(0);
        let b2 = chunk.get(2).map(|&b| b as u32).unwrap_or(0);

        let n = (b0 << 16) | (b1 << 8) | b2;

        output.push(ALPHABET[(n >> 18) as usize & 0x3f] as char);
        output.push(ALPHABET[(n >> 12) as usize & 0x3f] as char);

        if chunk.len() > 1 {
            output.push(ALPHABET[(n >> 6) as usize & 0x3f] as char);
        } else {
            output.push('=');
        }

        if chunk.len() > 2 {
            output.push(ALPHABET[n as usize & 0x3f] as char);
        } else {
            output.push('=');
        }
    }

    output
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::passes::encoding::Encoding;
    use oxc::allocator::Allocator;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Encoding);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Encoding::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_btoa_hello() {
        assert_eq!(transform("btoa(\"hello\")"), "(\"aGVsbG8=\");\n");
    }

    #[test]
    fn test_btoa_world() {
        assert_eq!(transform("btoa(\"world\")"), "(\"d29ybGQ=\");\n");
    }

    #[test]
    fn test_btoa_empty() {
        assert_eq!(transform("btoa(\"\")"), "(\"\");\n");
    }
}
