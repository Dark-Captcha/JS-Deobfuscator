//! Parenthesized expression unwrap pass.

use oxc::allocator::TakeIn;
use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

// ============================================================================
// ParenthesizedUnwrap Pass
// ============================================================================

/// Unwraps unnecessary parentheses: `(x)` → `x`
///
/// This pass removes parenthesized expressions when they don't affect
/// semantics. The traversal is bottom-up, so nested parens like `((x))`
/// are handled automatically across iterations.
///
/// # Examples
///
/// ```ignore
/// (42)        → 42
/// ("hello")   → "hello"
/// (x)         → x
/// ((1 + 2))   → 1 + 2  (after multiple iterations)
/// ```
#[derive(Default)]
pub struct ParenthesizedUnwrap;

impl ParenthesizedUnwrap {
    /// Transform expression. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::ParenthesizedExpression(paren) = expr else {
            return 0;
        };

        // Take the inner expression
        let inner = paren.expression.take_in(ctx.ast.allocator);

        tracing::trace!(
            target: "deob::pass::expression_parenthesized_unwrap",
            "unwrapped"
        );

        *expr = inner;

        1
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use crate::passes::expression::ExpressionGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::{Expression, Statement};
    use oxc::codegen::Codegen;
    use oxc::parser::{ParseOptions, Parser};
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        // Enable preserve_parens to actually test parenthesis unwrapping
        let options = ParseOptions {
            preserve_parens: true,
            ..Default::default()
        };
        let ret = Parser::new(&allocator, source, source_type)
            .with_options(options)
            .parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(ExpressionGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(
                &mut self,
                expr: &mut Expression<'a>,
                ctx: &mut TraverseCtx<'a, ()>,
            ) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(ExpressionGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    fn transform_check_ast(source: &str) -> bool {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let options = ParseOptions {
            preserve_parens: true,
            ..Default::default()
        };
        let ret = Parser::new(&allocator, source, source_type)
            .with_options(options)
            .parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(ExpressionGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(
                &mut self,
                expr: &mut Expression<'a>,
                ctx: &mut TraverseCtx<'a, ()>,
            ) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(ExpressionGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        // Check that no ParenthesizedExpression remains in AST
        if let Some(Statement::ExpressionStatement(stmt)) = program.body.first() {
            !matches!(stmt.expression, Expression::ParenthesizedExpression(_))
        } else {
            false
        }
    }

    #[test]
    fn test_simple_unwrap() {
        assert_eq!(transform("(42);"), "42;\n");
    }

    #[test]
    fn test_string_unwrap() {
        // Codegen adds parens back for strings in statement position (directive safety)
        // But the AST should not have ParenthesizedExpression
        assert!(transform_check_ast("(\"hello\");"));
    }

    #[test]
    fn test_identifier_unwrap() {
        assert_eq!(transform("(x);"), "x;\n");
    }

    #[test]
    fn test_nested_unwrap() {
        assert_eq!(transform("((42));"), "42;\n");
    }

    #[test]
    fn test_expression_unwrap() {
        assert_eq!(transform("(1 + 2);"), "1 + 2;\n");
    }

    #[test]
    fn test_in_binary() {
        assert_eq!(transform("(1) + (2);"), "1 + 2;\n");
    }
}
