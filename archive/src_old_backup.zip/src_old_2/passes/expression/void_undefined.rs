//! Void to undefined pass.

use oxc::ast::ast::{Expression, UnaryOperator};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// VoidUndefined Pass
// ============================================================================

/// Converts `void 0` to `undefined` identifier.
///
/// `void <expr>` always evaluates to `undefined`. When the operand is
/// side-effect-free (like `0`), we can replace with `undefined`.
///
/// # Examples
///
/// ```ignore
/// void 0          → undefined
/// void 1          → undefined
/// void "x"        → undefined
/// void foo()      → void foo()  // keep, foo() has side effects
/// ```
#[derive(Default)]
pub struct VoidUndefined;

impl VoidUndefined {
    /// Transform expression. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::UnaryExpression(unary) = expr else {
            return 0;
        };

        if unary.operator != UnaryOperator::Void {
            return 0;
        }

        // Check if argument is side-effect-free
        // For now, only handle numeric literals (most common: void 0)
        if literal::number(&unary.argument).is_none() {
            // Could extend to other side-effect-free expressions
            // but void 0 is the most common pattern
            return 0;
        }

        // Replace with undefined identifier
        *expr = Expression::Identifier(ctx.ast.alloc_identifier_reference(unary.span, "undefined"));

        tracing::trace!(
            target: "deob::pass::expression_void_undefined",
            "converted to undefined"
        );

        1
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use crate::passes::expression::ExpressionGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(ExpressionGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(
                &mut self,
                expr: &mut Expression<'a>,
                ctx: &mut TraverseCtx<'a, ()>,
            ) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(ExpressionGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_void_zero() {
        assert_eq!(transform("void 0;"), "undefined;\n");
    }

    #[test]
    fn test_void_one() {
        assert_eq!(transform("void 1;"), "undefined;\n");
    }

    #[test]
    fn test_void_negative() {
        assert_eq!(transform("void -1;"), "undefined;\n");
    }

    #[test]
    fn test_void_call_unchanged() {
        // foo() has side effects, keep void
        let result = transform("void foo();");
        assert!(result.contains("void"));
    }
}
