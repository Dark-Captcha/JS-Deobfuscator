//! Expression simplification passes.
//!
//! - [`ParenthesizedUnwrap`] — `(x)` → `x`
//! - [`SequenceSimplify`] — `(a, b, c)` → `c` (if a,b side-effect-free)
//! - [`VoidUndefined`] — `void 0` → `undefined`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod parenthesized_unwrap;
mod sequence_simplify;
mod void_undefined;

pub use parenthesized_unwrap::ParenthesizedUnwrap;
pub use sequence_simplify::SequenceSimplify;
pub use void_undefined::VoidUndefined;

// ============================================================================
// Expression Group
// ============================================================================

/// Group of all expression simplification passes.
#[derive(Default)]
pub struct ExpressionGroup {
    parenthesized_unwrap: ParenthesizedUnwrap,
    sequence_simplify: SequenceSimplify,
    void_undefined: VoidUndefined,
}

impl ExpressionGroup {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform expression through all expression passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.parenthesized_unwrap.transform(expr, ctx);
        mods += self.sequence_simplify.transform(expr, ctx);
        mods += self.void_undefined.transform(expr, ctx);
        mods
    }
}
