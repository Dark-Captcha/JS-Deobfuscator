//! Sequence expression simplification pass.

use oxc::allocator::TakeIn;
use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

use crate::utils::side_effects::is_side_effect_free;

// ============================================================================
// SequenceSimplify Pass
// ============================================================================

/// Simplifies sequence expressions by removing side-effect-free prefixes.
///
/// A sequence expression `(a, b, c)` evaluates all expressions left-to-right
/// and returns the last value. If prefix expressions have no side effects,
/// they can be removed.
///
/// # Examples
///
/// ```ignore
/// (1, 2, 3)           → 3           // all literals, keep last
/// (a, b, c)           → (a, b, c)   // unknown side effects, keep all
/// (1, x, 3)           → (x, 3)      // 1 is side-effect-free
/// (foo(), 1)          → (foo(), 1)  // foo() may have side effects
/// ```
#[derive(Default)]
pub struct SequenceSimplify;

impl SequenceSimplify {
    /// Transform expression. Returns number of removed expressions.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::SequenceExpression(seq) = expr else {
            return 0;
        };

        // Need at least 2 expressions
        if seq.expressions.len() < 2 {
            return 0;
        }

        // Find first expression with potential side effects (or last one)
        let mut first_effectful_idx = seq.expressions.len() - 1; // Always keep last

        for (i, e) in seq.expressions.iter().enumerate() {
            if i == seq.expressions.len() - 1 {
                break; // Always keep last
            }
            if !is_side_effect_free(e) {
                first_effectful_idx = i;
                break;
            }
        }

        // If we can remove some prefix expressions
        if first_effectful_idx > 0 {
            let removed_count = first_effectful_idx;

            // Take all expressions
            let mut exprs = seq.expressions.take_in(ctx.ast.allocator);

            // Remove side-effect-free prefix
            let kept: Vec<_> = exprs.drain(first_effectful_idx..).collect();

            if kept.len() == 1 {
                // Single expression left — unwrap sequence
                let single = kept.into_iter().next().unwrap();
                *expr = single;
            } else {
                // Multiple expressions — rebuild sequence
                let mut new_exprs = ctx.ast.vec();
                for e in kept {
                    new_exprs.push(e);
                }
                *expr = ctx.ast.expression_sequence(seq.span, new_exprs);
            }

            tracing::trace!(
                target: "deob::pass::expression_sequence_simplify",
                removed = removed_count,
                "simplified"
            );

            return removed_count;
        }

        // Check if sequence has only one expression (shouldn't happen but handle it)
        if seq.expressions.len() == 1 {
            let single = seq.expressions.take_in(ctx.ast.allocator).pop().unwrap();
            *expr = single;
            return 1;
        }

        0
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use crate::passes::expression::ExpressionGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(ExpressionGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(
                &mut self,
                expr: &mut Expression<'a>,
                ctx: &mut TraverseCtx<'a, ()>,
            ) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(ExpressionGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_all_literals() {
        assert_eq!(transform("(1, 2, 3);"), "3;\n");
    }

    #[test]
    fn test_prefix_literal() {
        // x might have side effects when read (getter), so we keep it
        // But 1 is definitely side-effect-free
        let result = transform("(1, x);");
        assert_eq!(result, "x;\n");
    }

    #[test]
    fn test_multiple_literals() {
        assert_eq!(transform("(1, 2, 3, 4, 5);"), "5;\n");
    }

    #[test]
    fn test_keep_effectful() {
        // foo() might have side effects
        let result = transform("(foo(), 1);");
        assert!(result.contains("foo()"));
    }
}
