//! Debugger statement removal pass.

use oxc::ast::ast::Statement;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

// ============================================================================
// DebuggerRemove Pass
// ============================================================================

/// Removes debugger statements: `debugger;` → (removed)
#[derive(Default)]
pub struct DebuggerRemove;

impl DebuggerRemove {
    /// Transform statement. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        stmt: &mut Statement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        if matches!(stmt, Statement::DebuggerStatement(_)) {
            *stmt = ctx.ast.statement_empty(SPAN);
            return 1;
        }
        0
    }
}
