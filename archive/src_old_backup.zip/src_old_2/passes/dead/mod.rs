//! Dead code removal passes.
//!
//! - [`DebuggerRemove`] — Remove `debugger;` statements
//! - [`EmptyStatementRemove`] — Remove empty `;` statements

use oxc::allocator::Vec as ArenaVec;
use oxc::ast::ast::Statement;
use oxc_traverse::TraverseCtx;

mod debugger_remove;
mod empty_statement_remove;

pub use debugger_remove::DebuggerRemove;
pub use empty_statement_remove::EmptyStatementRemove;

// ============================================================================
// Dead Group
// ============================================================================

/// Group of all dead code removal passes.
#[derive(Default)]
pub struct Dead {
    debugger_remove: DebuggerRemove,
    empty_statement_remove: EmptyStatementRemove,
}

impl Dead {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform statement through dead code passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_statement<'a>(
        &mut self,
        stmt: &mut Statement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        self.debugger_remove.transform(stmt, ctx)
    }

    /// Transform statement list to remove empty statements.
    /// Returns number of removed statements.
    #[inline]
    pub fn exit_statements<'a>(
        &mut self,
        stmts: &mut ArenaVec<'a, Statement<'a>>,
        _ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        self.empty_statement_remove.transform_stmts(stmts)
    }
}
