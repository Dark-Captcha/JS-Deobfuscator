//! Empty statement removal pass.
//!
//! Note: This pass removes empty statements from statement lists.

use oxc::allocator::Vec as ArenaVec;
use oxc::ast::ast::Statement;

// ============================================================================
// EmptyStatementRemove Pass
// ============================================================================

/// Removes empty statements from statement lists: `;` → (removed)
#[derive(Default)]
pub struct EmptyStatementRemove;

impl EmptyStatementRemove {
    /// Transform statement list. Returns number of removed statements.
    #[inline]
    pub fn transform_stmts<'a>(&mut self, stmts: &mut ArenaVec<'a, Statement<'a>>) -> usize {
        let before = stmts.len();
        stmts.retain(|stmt| !matches!(stmt, Statement::EmptyStatement(_)));
        let after = stmts.len();
        before - after
    }

    /// Check if a statement is empty
    #[inline]
    pub fn is_empty(stmt: &Statement) -> bool {
        matches!(stmt, Statement::EmptyStatement(_))
    }
}
