//! If statement with constant condition pass.

use oxc::allocator::TakeIn;
use oxc::ast::ast::Statement;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// IfConstant Pass
// ============================================================================

/// Simplifies if with constant condition: `if(true){a}else{b}` → `a`
#[derive(Default)]
pub struct IfConstant;

impl IfConstant {
    /// Transform statement. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        stmt: &mut Statement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Statement::IfStatement(if_stmt) = stmt else {
            return 0;
        };

        let Some(test_value) = literal::is_truthy(&if_stmt.test) else {
            return 0;
        };

        let replacement = if test_value {
            if_stmt.consequent.take_in(ctx.ast.allocator)
        } else if let Some(alt) = &mut if_stmt.alternate {
            alt.take_in(ctx.ast.allocator)
        } else {
            ctx.ast.statement_empty(SPAN)
        };

        *stmt = replacement;

        tracing::trace!(
            target: "deob::pass::control_if_constant",
            test_value,
            "simplified"
        );

        1
    }
}
