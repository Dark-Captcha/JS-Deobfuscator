//! While false removal pass.

use oxc::ast::ast::Statement;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// WhileFalse Pass
// ============================================================================

/// Removes while loops with false condition: `while(false){}` → (removed)
#[derive(Default)]
pub struct WhileFalse;

impl WhileFalse {
    /// Transform statement. Returns 1 if modified, 0 otherwise.
    #[inline]
    pub fn transform<'a>(
        &mut self,
        stmt: &mut Statement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Statement::WhileStatement(while_stmt) = stmt else {
            return 0;
        };

        let Some(test_value) = literal::is_truthy(&while_stmt.test) else {
            return 0;
        };

        if !test_value {
            *stmt = ctx.ast.statement_empty(SPAN);
            return 1;
        }

        0
    }
}
