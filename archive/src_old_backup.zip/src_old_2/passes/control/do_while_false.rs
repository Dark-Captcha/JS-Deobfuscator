//! do-while(false) unwrap pass.
//!
//! `do { body } while(false)` → `body`

use oxc::ast::ast::Statement;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Unwraps `do { body } while(false)` → body
#[derive(Default)]
pub struct DoWhileFalse;

impl DoWhileFalse {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        stmt: &mut Statement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Statement::DoWhileStatement(do_while) = stmt else { return 0 };
        
        // Check if condition is false
        let is_false = match &do_while.test {
            oxc::ast::ast::Expression::BooleanLiteral(b) => !b.value,
            oxc::ast::ast::Expression::NumericLiteral(n) => n.value == 0.0,
            _ => {
                if let Some(b) = literal::boolean(&do_while.test) {
                    !b
                } else {
                    false
                }
            }
        };

        if !is_false { return 0 }

        // Replace with the body
        // Note: We need to clone the body statement
        use oxc::allocator::CloneIn;
        *stmt = do_while.body.clone_in(ctx.ast.allocator);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::control::Control;
    use oxc::allocator::Allocator;
    use oxc::allocator::Vec as ArenaVec;
    use oxc::ast::ast::Statement;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(Control);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_statement(&mut self, stmt: &mut Statement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_statement(stmt, ctx);
            }
            fn exit_statements(&mut self, stmts: &mut ArenaVec<'a, Statement<'a>>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_statements(stmts, ctx);
            }
        }
        let mut visitor = Visitor(Control::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_do_while_false() {
        let result = transform("do { x = 1; } while(false)");
        assert!(result.contains("x = 1"));
        assert!(!result.contains("while"));
        assert!(!result.contains("do"));
    }
}
