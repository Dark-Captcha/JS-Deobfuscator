//! Unreachable code removal pass.
//!
//! Removes statements after:
//! - `return`
//! - `throw`
//! - `break`
//! - `continue`

use oxc::allocator::Vec as ArenaVec;
use oxc::ast::ast::Statement;
use oxc_traverse::TraverseCtx;

/// Removes unreachable statements after control flow terminators
#[derive(Default)]
pub struct Unreachable;

impl Unreachable {
    #[inline]
    pub fn exit_statements<'a>(
        &mut self,
        stmts: &mut ArenaVec<'a, Statement<'a>>,
        _ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut terminator_idx = None;
        
        for (i, stmt) in stmts.iter().enumerate() {
            if is_terminator(stmt) {
                terminator_idx = Some(i);
                break;
            }
        }
        
        let Some(idx) = terminator_idx else { return 0 };
        
        // Count how many statements to remove
        let to_remove = stmts.len() - idx - 1;
        if to_remove == 0 {
            return 0;
        }
        
        // Truncate to keep only statements up to and including terminator
        stmts.truncate(idx + 1);
        
        to_remove
    }
}

fn is_terminator(stmt: &Statement) -> bool {
    matches!(
        stmt,
        Statement::ReturnStatement(_)
            | Statement::ThrowStatement(_)
            | Statement::BreakStatement(_)
            | Statement::ContinueStatement(_)
    )
}

#[cfg(test)]
mod tests {
    use crate::passes::control::Control;
    use oxc::allocator::Allocator;
    use oxc::allocator::Vec as ArenaVec;
    use oxc::ast::ast::Statement;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(Control);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_statement(&mut self, stmt: &mut Statement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_statement(stmt, ctx);
            }
            fn exit_statements(&mut self, stmts: &mut ArenaVec<'a, Statement<'a>>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_statements(stmts, ctx);
            }
        }
        let mut visitor = Visitor(Control::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_unreachable_after_return() {
        let result = transform("function f() { return 1; x = 2; }");
        assert!(result.contains("return 1"));
        assert!(!result.contains("x = 2"));
    }

    #[test]
    fn test_unreachable_after_throw() {
        let result = transform("function f() { throw new Error(); x = 2; }");
        assert!(result.contains("throw"));
        assert!(!result.contains("x = 2"));
    }
}
