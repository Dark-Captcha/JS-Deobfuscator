//! Control flow simplification passes.
//!
//! - [`IfConstant`] — `if(true){a}else{b}` → `a`
//! - [`WhileFalse`] — `while(false){}` → (removed)
//! - [`Unreachable`] — removes code after return/throw/break/continue
//! - [`ForFalse`] — `for(;false;){}` → (removed)
//! - [`DoWhileFalse`] — `do{}while(false)` → unwrap body

use oxc::allocator::Vec as ArenaVec;
use oxc::ast::ast::Statement;
use oxc_traverse::TraverseCtx;

mod do_while_false;
mod for_false;
mod if_constant;
mod unreachable;
mod while_false;

pub use do_while_false::DoWhileFalse;
pub use for_false::ForFalse;
pub use if_constant::IfConstant;
pub use unreachable::Unreachable;
pub use while_false::WhileFalse;

// ============================================================================
// Control Group
// ============================================================================

/// Group of all control flow simplification passes.
#[derive(Default)]
pub struct Control {
    if_constant: IfConstant,
    while_false: WhileFalse,
    for_false: ForFalse,
    do_while_false: DoWhileFalse,
    unreachable: Unreachable,
}

impl Control {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform statement through all control passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_statement<'a>(
        &mut self,
        stmt: &mut Statement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.if_constant.transform(stmt, ctx);
        mods += self.while_false.transform(stmt, ctx);
        mods += self.for_false.transform(stmt, ctx);
        mods += self.do_while_false.transform(stmt, ctx);
        mods
    }

    /// Transform statement list for unreachable code removal.
    #[inline]
    pub fn exit_statements<'a>(
        &mut self,
        stmts: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        self.unreachable.exit_statements(stmts, ctx)
    }
}
