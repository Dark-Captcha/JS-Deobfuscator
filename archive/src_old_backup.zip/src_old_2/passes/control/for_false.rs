//! for(;false;) removal pass.
//!
//! `for(;false;) { body }` → (removed)

use oxc::ast::ast::Statement;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Removes `for(;false;) { body }` → empty
#[derive(Default)]
pub struct ForFalse;

impl ForFalse {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        stmt: &mut Statement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Statement::ForStatement(for_stmt) = stmt else { return 0 };
        
        // Check if test condition is false
        let Some(test) = &for_stmt.test else { return 0 };
        
        let is_false = match test {
            oxc::ast::ast::Expression::BooleanLiteral(b) => !b.value,
            oxc::ast::ast::Expression::NumericLiteral(n) => n.value == 0.0,
            _ => {
                if let Some(b) = literal::boolean(test) {
                    !b
                } else {
                    false
                }
            }
        };

        if !is_false { return 0 }

        // Replace with empty statement
        *stmt = ctx.ast.statement_empty(SPAN);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::control::Control;
    use oxc::allocator::Allocator;
    use oxc::allocator::Vec as ArenaVec;
    use oxc::ast::ast::Statement;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(Control);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_statement(&mut self, stmt: &mut Statement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_statement(stmt, ctx);
            }
            fn exit_statements(&mut self, stmts: &mut ArenaVec<'a, Statement<'a>>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_statements(stmts, ctx);
            }
        }
        let mut visitor = Visitor(Control::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_for_false() {
        let result = transform("for(;false;) { x = 1; }");
        assert!(!result.contains("for"));
        assert!(!result.contains("x = 1"));
    }
}
