//! Type coercion passes for JSFuck-style deobfuscation.
//!
//! - [`UnaryPlus`] — `+[]` → `0`, `+""` → `0`, `+true` → `1`
//! - [`NotArray`] — `![]` → `false`, `!![]` → `true`
//! - [`NotString`] — `!""` → `true`, `!"x"` → `false`
//! - [`NotNumber`] — `!0` → `true`, `!1` → `false`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod not_coerce;
mod unary_plus;

pub use not_coerce::NotCoerce;
pub use unary_plus::UnaryPlus;

/// Group of all coercion passes.
#[derive(Default)]
pub struct Coercion {
    unary_plus: UnaryPlus,
    not_coerce: NotCoerce,
}

impl Coercion {
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.unary_plus.transform(expr, ctx);
        mods += self.not_coerce.transform(expr, ctx);
        mods
    }
}
