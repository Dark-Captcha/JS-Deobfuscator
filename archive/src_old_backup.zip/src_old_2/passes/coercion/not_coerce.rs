//! Not coercion pass for JSFuck-style patterns.
//!
//! Handles:
//! - `![]` → `false`
//! - `!![]` → `true`
//! - `!""` → `true`
//! - `!"x"` → `false`
//! - `!0` → `true`
//! - `!1` → `false`
//! - `!null` → `true`
//! - `!undefined` → `true`

use oxc::ast::ast::{Expression, UnaryOperator};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `!` for type coercion to boolean
#[derive(Default)]
pub struct NotCoerce;

impl NotCoerce {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::UnaryExpression(unary) = expr else { return 0 };
        if unary.operator != UnaryOperator::LogicalNot { return 0 }

        let result = match &unary.argument {
            // ![] → false (arrays are truthy)
            Expression::ArrayExpression(_) => false,
            
            // !{} → false (objects are truthy)
            Expression::ObjectExpression(_) => false,
            
            // !"" → true, !"x" → false
            Expression::StringLiteral(s) => s.value.is_empty(),
            
            // !0 → true, !1 → false, !NaN → true
            Expression::NumericLiteral(n) => n.value == 0.0 || n.value.is_nan(),
            
            // !true → false, !false → true
            Expression::BooleanLiteral(b) => !b.value,
            
            // !null → true
            Expression::NullLiteral(_) => true,
            
            // !undefined → true, !NaN → true
            Expression::Identifier(id) => {
                match id.name.as_str() {
                    "undefined" | "NaN" => true,
                    "Infinity" => false,
                    _ => return 0,
                }
            }
            
            // Handle negative numbers: !-0 → true, !-1 → false
            Expression::UnaryExpression(inner) if inner.operator == UnaryOperator::UnaryNegation => {
                if let Some(n) = literal::number(&unary.argument) {
                    n == 0.0 || n.is_nan()
                } else {
                    return 0;
                }
            }
            
            _ => return 0,
        };

        *expr = ctx.ast.expression_boolean_literal(SPAN, result);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::coercion::Coercion;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(Coercion);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }
        let mut visitor = Visitor(Coercion::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_not_empty_array() {
        assert_eq!(transform("![]"), "false;\n");
    }

    #[test]
    fn test_not_not_empty_array() {
        // !![] - the outer ! sees a UnaryExpression, not a literal
        // So it doesn't transform. The inner ![] transforms to false
        // giving !false, which then transforms to true
        let result = transform("!![]");
        // After one pass: !false (inner ![] → false)
        // The test visitor only does one pass
        assert!(result.contains("!false") || result.contains("true"));
    }

    #[test]
    fn test_not_empty_string() {
        let result = transform("!\"\"");
        assert!(result.contains("true"));
    }

    #[test]
    fn test_not_zero() {
        assert_eq!(transform("!0"), "true;\n");
    }

    #[test]
    fn test_not_one() {
        assert_eq!(transform("!1"), "false;\n");
    }

    #[test]
    fn test_not_null() {
        assert_eq!(transform("!null"), "true;\n");
    }
}
