//! Unary plus coercion pass.
//!
//! Handles JSFuck-style number coercion:
//! - `+[]` → `0`
//! - `+""` → `0`
//! - `+true` → `1`
//! - `+false` → `0`
//! - `+null` → `0`
//! - `+"123"` → `123`

use oxc::ast::ast::{Expression, UnaryOperator};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates unary `+` for type coercion to number
#[derive(Default)]
pub struct UnaryPlus;

impl UnaryPlus {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::UnaryExpression(unary) = expr else { return 0 };
        if unary.operator != UnaryOperator::UnaryPlus { return 0 }

        let result = match &unary.argument {
            // +[] → 0
            Expression::ArrayExpression(arr) if arr.elements.is_empty() => 0.0,
            
            // +[n] → n (single element array)
            Expression::ArrayExpression(arr) if arr.elements.len() == 1 => {
                if let Some(elem) = arr.elements.first() {
                    if let Some(e) = elem.as_expression() {
                        if let Some(n) = literal::number(e) {
                            n
                        } else if let Some(s) = literal::string(e) {
                            s.trim().parse::<f64>().unwrap_or(f64::NAN)
                        } else {
                            return 0;
                        }
                    } else {
                        return 0;
                    }
                } else {
                    return 0;
                }
            }
            
            // +"" → 0, +"123" → 123
            Expression::StringLiteral(s) => {
                let trimmed = s.value.trim();
                if trimmed.is_empty() {
                    0.0
                } else {
                    trimmed.parse::<f64>().unwrap_or(f64::NAN)
                }
            }
            
            // +true → 1, +false → 0
            Expression::BooleanLiteral(b) => if b.value { 1.0 } else { 0.0 },
            
            // +null → 0
            Expression::NullLiteral(_) => 0.0,
            
            // +undefined → NaN (skip, can't represent cleanly)
            Expression::Identifier(id) if id.name == "undefined" => return 0,
            
            // Already a number - just unwrap
            Expression::NumericLiteral(n) => n.value,
            
            // +(-n) or +(+n) - recurse
            Expression::UnaryExpression(inner) => {
                if inner.operator == UnaryOperator::UnaryPlus {
                    // +(+x) - let inner handle it
                    return 0;
                }
                if inner.operator == UnaryOperator::UnaryNegation {
                    if let Some(n) = literal::number(&unary.argument) {
                        n
                    } else {
                        return 0;
                    }
                } else {
                    return 0;
                }
            }
            
            _ => return 0,
        };

        *expr = literal::make_number(result, &ctx.ast);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::coercion::Coercion;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(Coercion);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }
        let mut visitor = Visitor(Coercion::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_plus_empty_array() {
        assert_eq!(transform("+[]"), "0;\n");
    }

    #[test]
    fn test_plus_empty_string() {
        let result = transform("+\"\"");
        assert!(result.contains("0"));
    }

    #[test]
    fn test_plus_true() {
        assert_eq!(transform("+true"), "1;\n");
    }

    #[test]
    fn test_plus_false() {
        assert_eq!(transform("+false"), "0;\n");
    }

    #[test]
    fn test_plus_numeric_string() {
        let result = transform("+\"42\"");
        assert!(result.contains("42"));
    }
}
