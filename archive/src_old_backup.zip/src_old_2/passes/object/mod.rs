//! Object method passes.
//!
//! - [`Keys`] — `Object.keys({a:1})` → `["a"]`
//! - [`Values`] — `Object.values({a:1})` → `[1]`
//! - [`Entries`] — `Object.entries({a:1})` → `[["a",1]]`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod entries;
mod keys;
mod values;

pub use entries::Entries;
pub use keys::Keys;
pub use values::Values;

// ============================================================================
// Object Group
// ============================================================================

/// Group of all Object method passes.
#[derive(Default)]
pub struct Object {
    keys: Keys,
    values: Values,
    entries: Entries,
}

impl Object {
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.keys.transform(expr, ctx);
        mods += self.values.transform(expr, ctx);
        mods += self.entries.transform(expr, ctx);
        mods
    }
}
