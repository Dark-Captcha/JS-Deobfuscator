//! Object.keys pass.

use oxc::ast::ast::{ArrayExpressionElement, Expression, ObjectPropertyKind, PropertyKey};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

/// Evaluates `Object.keys(obj)` → array of keys
#[derive(Default)]
pub struct Keys;

impl Keys {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "keys" {
            return 0;
        }

        let Expression::Identifier(obj) = &member.object else {
            return 0;
        };

        if obj.name.as_str() != "Object" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(arg_expr) = call.arguments.first().and_then(|a| a.as_expression()) else {
            return 0;
        };

        let Expression::ObjectExpression(obj_expr) = arg_expr else {
            return 0;
        };

        if obj_expr.properties.len() > 100 {
            return 0;
        }

        let mut elements = ctx.ast.vec();
        for prop in &obj_expr.properties {
            let ObjectPropertyKind::ObjectProperty(p) = prop else {
                return 0; // Spread not supported
            };
            if p.computed {
                return 0;
            }
            let key_str = match &p.key {
                PropertyKey::StaticIdentifier(id) => id.name.to_string(),
                PropertyKey::StringLiteral(s) => s.value.to_string(),
                PropertyKey::NumericLiteral(n) => n.value.to_string(),
                _ => return 0,
            };
            let atom = ctx.ast.atom(&key_str);
            let lit = ctx.ast.expression_string_literal(SPAN, atom, None);
            elements.push(ArrayExpressionElement::from(lit));
        }

        *expr = ctx.ast.expression_array(SPAN, elements);

        1
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::passes::object::Object;
    use oxc::allocator::Allocator;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Object);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Object::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_keys_simple() {
        assert_eq!(transform("Object.keys({a:1, b:2})"), "[\"a\", \"b\"];\n");
    }

    #[test]
    fn test_keys_empty() {
        assert_eq!(transform("Object.keys({})"), "[];\n");
    }
}
