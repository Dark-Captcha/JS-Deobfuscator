//! Object.entries pass.

use oxc::allocator::CloneIn;
use oxc::ast::ast::{ArrayExpressionElement, Expression, ObjectPropertyKind, PropertyKey};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `Object.entries(obj)` → array of [key, value] pairs (literals only)
#[derive(Default)]
pub struct Entries;

impl Entries {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "entries" {
            return 0;
        }

        let Expression::Identifier(obj) = &member.object else {
            return 0;
        };

        if obj.name.as_str() != "Object" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(arg_expr) = call.arguments.first().and_then(|a| a.as_expression()) else {
            return 0;
        };

        let Expression::ObjectExpression(obj_expr) = arg_expr else {
            return 0;
        };

        if obj_expr.properties.len() > 100 {
            return 0;
        }

        let mut outer_elements = ctx.ast.vec();
        for prop in &obj_expr.properties {
            let ObjectPropertyKind::ObjectProperty(p) = prop else {
                return 0;
            };
            if p.computed {
                return 0;
            }
            // Only handle literal values
            if !literal::is_literal(&p.value) {
                return 0;
            }

            let key_str = match &p.key {
                PropertyKey::StaticIdentifier(id) => id.name.to_string(),
                PropertyKey::StringLiteral(s) => s.value.to_string(),
                PropertyKey::NumericLiteral(n) => n.value.to_string(),
                _ => return 0,
            };

            let mut inner_elements = ctx.ast.vec();
            let key_atom = ctx.ast.atom(&key_str);
            let key_lit = ctx.ast.expression_string_literal(SPAN, key_atom, None);
            inner_elements.push(ArrayExpressionElement::from(key_lit));

            let value_cloned = p.value.clone_in(ctx.ast.allocator);
            inner_elements.push(ArrayExpressionElement::from(value_cloned));

            let inner_array = ctx.ast.expression_array(SPAN, inner_elements);
            outer_elements.push(ArrayExpressionElement::from(inner_array));
        }

        *expr = ctx.ast.expression_array(SPAN, outer_elements);

        1
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::passes::object::Object;
    use oxc::allocator::Allocator;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Object);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Object::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_entries_simple() {
        let result = transform("Object.entries({a:1, b:2})");
        assert!(result.contains("[\"a\", 1]"));
        assert!(result.contains("[\"b\", 2]"));
    }

    #[test]
    fn test_entries_empty() {
        assert_eq!(transform("Object.entries({})"), "[];\n");
    }
}
