//! parseInt pass.

use oxc::ast::ast::{Argument, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `parseInt(str)` and `parseInt(str, radix)` → integer
#[derive(Default)]
pub struct ParseInt;

impl ParseInt {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        // Check for parseInt or Number.parseInt
        let is_parse_int = match &call.callee {
            Expression::Identifier(id) => id.name.as_str() == "parseInt",
            Expression::StaticMemberExpression(member) => {
                if let Expression::Identifier(obj) = &member.object {
                    obj.name.as_str() == "Number" && member.property.name.as_str() == "parseInt"
                } else {
                    false
                }
            }
            _ => false,
        };

        if !is_parse_int {
            return 0;
        }

        if call.arguments.is_empty() || call.arguments.len() > 2 {
            return 0;
        }

        let Some(input) = call.arguments.first().and_then(|a| match a {
            Argument::StringLiteral(s) => Some(s.value.as_str()),
            _ => a.as_expression().and_then(literal::string),
        }) else {
            return 0;
        };

        let radix = call
            .arguments
            .get(1)
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value as u32),
                _ => a.as_expression().and_then(literal::number).map(|n| n as u32),
            })
            .unwrap_or(10);

        if !(2..=36).contains(&radix) {
            return 0;
        }

        // Trim whitespace and handle sign
        let trimmed = input.trim();
        if trimmed.is_empty() {
            return 0;
        }

        let (sign, rest) = if let Some(s) = trimmed.strip_prefix('-') {
            (-1i64, s)
        } else if let Some(s) = trimmed.strip_prefix('+') {
            (1i64, s)
        } else {
            (1i64, trimmed)
        };

        // Handle 0x prefix for radix 16
        let (actual_radix, num_str) = if radix == 16 {
            if let Some(s) = rest.strip_prefix("0x").or_else(|| rest.strip_prefix("0X")) {
                (16, s)
            } else {
                (16, rest)
            }
        } else if radix == 10 && (rest.starts_with("0x") || rest.starts_with("0X")) {
            // parseInt("0xff") with no radix uses 10, but 0x prefix means hex
            let s = rest.strip_prefix("0x").or_else(|| rest.strip_prefix("0X")).unwrap();
            (16, s)
        } else {
            (radix, rest)
        };

        // Parse only valid characters for the radix
        let mut result: i64 = 0;
        let mut found_digit = false;

        for c in num_str.chars() {
            let digit = match c {
                '0'..='9' => c as u32 - '0' as u32,
                'a'..='z' => c as u32 - 'a' as u32 + 10,
                'A'..='Z' => c as u32 - 'A' as u32 + 10,
                _ => break, // Stop at first invalid char
            };

            if digit >= actual_radix {
                break;
            }

            found_digit = true;
            result = result * actual_radix as i64 + digit as i64;
        }

        if !found_digit {
            return 0; // NaN case
        }

        let final_result = (sign * result) as f64;

        *expr = literal::make_number(final_result, &ctx.ast);

        1
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::passes::parse::Parse;
    use oxc::allocator::Allocator;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Parse);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Parse::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_parse_int_basic() {
        assert_eq!(transform("parseInt(\"42\")"), "42;\n");
    }

    #[test]
    fn test_parse_int_hex() {
        assert_eq!(transform("parseInt(\"ff\", 16)"), "255;\n");
    }

    #[test]
    fn test_parse_int_hex_prefix() {
        assert_eq!(transform("parseInt(\"0xff\", 16)"), "255;\n");
    }

    #[test]
    fn test_parse_int_negative() {
        assert_eq!(transform("parseInt(\"-42\")"), "-42;\n");
    }

    #[test]
    fn test_parse_int_binary() {
        assert_eq!(transform("parseInt(\"1010\", 2)"), "10;\n");
    }

    #[test]
    fn test_parse_int_stops_at_invalid() {
        assert_eq!(transform("parseInt(\"42abc\")"), "42;\n");
    }
}
