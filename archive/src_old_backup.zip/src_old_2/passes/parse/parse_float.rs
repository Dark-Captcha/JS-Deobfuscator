//! parseFloat pass.

use oxc::ast::ast::{Argument, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `parseFloat(str)` → float
#[derive(Default)]
pub struct ParseFloat;

impl ParseFloat {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        // Check for parseFloat or Number.parseFloat
        let is_parse_float = match &call.callee {
            Expression::Identifier(id) => id.name.as_str() == "parseFloat",
            Expression::StaticMemberExpression(member) => {
                if let Expression::Identifier(obj) = &member.object {
                    obj.name.as_str() == "Number" && member.property.name.as_str() == "parseFloat"
                } else {
                    false
                }
            }
            _ => false,
        };

        if !is_parse_float {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(input) = call.arguments.first().and_then(|a| match a {
            Argument::StringLiteral(s) => Some(s.value.as_str()),
            _ => a.as_expression().and_then(literal::string),
        }) else {
            return 0;
        };

        let trimmed = input.trim_start();
        if trimmed.is_empty() {
            return 0; // NaN
        }

        // Find the longest valid float prefix
        let mut end = 0;
        let mut has_digit = false;
        let mut has_dot = false;
        let mut has_exp = false;
        let chars: Vec<char> = trimmed.chars().collect();

        // Handle sign
        if end < chars.len() && (chars[end] == '+' || chars[end] == '-') {
            end += 1;
        }

        // Parse digits and decimal
        while end < chars.len() {
            let c = chars[end];
            if c.is_ascii_digit() {
                has_digit = true;
                end += 1;
            } else if c == '.' && !has_dot && !has_exp {
                has_dot = true;
                end += 1;
            } else if (c == 'e' || c == 'E') && has_digit && !has_exp {
                has_exp = true;
                end += 1;
                // Handle exponent sign
                if end < chars.len() && (chars[end] == '+' || chars[end] == '-') {
                    end += 1;
                }
                // Must have at least one digit after exponent
                if end >= chars.len() || !chars[end].is_ascii_digit() {
                    // Invalid exponent, backtrack
                    end -= if chars[end - 1] == '+' || chars[end - 1] == '-' { 2 } else { 1 };
                    break;
                }
            } else {
                break;
            }
        }

        if !has_digit {
            return 0; // NaN
        }

        let num_str: String = chars[..end].iter().collect();
        let Ok(result) = num_str.parse::<f64>() else {
            return 0;
        };

        if result.is_nan() || result.is_infinite() {
            return 0;
        }

        *expr = literal::make_number(result, &ctx.ast);

        1
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::passes::parse::Parse;
    use oxc::allocator::Allocator;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Parse);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Parse::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_parse_float_basic() {
        assert_eq!(transform("parseFloat(\"3.14\")"), "3.14;\n");
    }

    #[test]
    fn test_parse_float_integer() {
        assert_eq!(transform("parseFloat(\"42\")"), "42;\n");
    }

    #[test]
    fn test_parse_float_negative() {
        assert_eq!(transform("parseFloat(\"-3.14\")"), "-3.14;\n");
    }

    #[test]
    fn test_parse_float_scientific() {
        assert_eq!(transform("parseFloat(\"1e2\")"), "100;\n");
    }

    #[test]
    fn test_parse_float_stops_at_invalid() {
        assert_eq!(transform("parseFloat(\"3.14abc\")"), "3.14;\n");
    }
}
