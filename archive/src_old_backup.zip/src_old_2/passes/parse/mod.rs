//! Parse/Number function passes.
//!
//! - [`ParseInt`] — `parseInt("42")` → `42`
//! - [`ParseIntRadix`] — `parseInt("ff", 16)` → `255`
//! - [`ParseFloat`] — `parseFloat("3.14")` → `3.14`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod parse_float;
mod parse_int;

pub use parse_float::ParseFloat;
pub use parse_int::ParseInt;

// ============================================================================
// Parse Group
// ============================================================================

/// Group of all parse function passes.
#[derive(Default)]
pub struct Parse {
    parse_int: ParseInt,
    parse_float: ParseFloat,
}

impl Parse {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform expression through all parse passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.parse_int.transform(expr, ctx);
        mods += self.parse_float.transform(expr, ctx);
        mods
    }
}
