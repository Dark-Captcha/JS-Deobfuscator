//! String trim passes.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Trim Pass
// ============================================================================

/// Evaluates string trim: `" hello ".trim()` → `"hello"`
#[derive(Default)]
pub struct Trim;

impl Trim {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "trim" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        if !call.arguments.is_empty() {
            return 0;
        }

        let result = s.trim();
        let atom = ctx.ast.atom(result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}


// ============================================================================
// TrimStart Pass
// ============================================================================

/// Evaluates string trimStart: `" hello".trimStart()` → `"hello"`
#[derive(Default)]
pub struct TrimStart;

impl TrimStart {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        let method = member.property.name.as_str();
        if method != "trimStart" && method != "trimLeft" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        if !call.arguments.is_empty() {
            return 0;
        }

        let result = s.trim_start();
        let atom = ctx.ast.atom(result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

// ============================================================================
// TrimEnd Pass
// ============================================================================

/// Evaluates string trimEnd: `"hello ".trimEnd()` → `"hello"`
#[derive(Default)]
pub struct TrimEnd;

impl TrimEnd {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        let method = member.property.name.as_str();
        if method != "trimEnd" && method != "trimRight" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        if !call.arguments.is_empty() {
            return 0;
        }

        let result = s.trim_end();
        let atom = ctx.ast.atom(result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_trim() {
        assert_eq!(transform("\" hello \".trim();"), "(\"hello\");\n");
    }

    #[test]
    fn test_trim_start() {
        assert_eq!(transform("\" hello\".trimStart();"), "(\"hello\");\n");
    }

    #[test]
    fn test_trim_left() {
        assert_eq!(transform("\" hello\".trimLeft();"), "(\"hello\");\n");
    }

    #[test]
    fn test_trim_end() {
        assert_eq!(transform("\"hello \".trimEnd();"), "(\"hello\");\n");
    }

    #[test]
    fn test_trim_right() {
        assert_eq!(transform("\"hello \".trimRight();"), "(\"hello\");\n");
    }
}
