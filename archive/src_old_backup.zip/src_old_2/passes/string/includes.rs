//! String includes/startsWith/endsWith passes.

use oxc::ast::ast::{Argument, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Includes Pass
// ============================================================================

/// Evaluates string includes: `"hello".includes("ell")` → `true`
#[derive(Default)]
pub struct Includes;

impl Includes {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "includes" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        let Some(search) = call.arguments.first().and_then(|a| match a {
            Argument::StringLiteral(lit) => Some(lit.value.as_str()),
            _ => a.as_expression().and_then(literal::string),
        }) else {
            return 0;
        };

        let start = call
            .arguments
            .get(1)
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value),
                _ => a.as_expression().and_then(literal::number),
            })
            .unwrap_or(0.0);

        let start = start.max(0.0) as usize;

        let result = if start >= s.len() {
            false
        } else {
            s[start..].contains(search)
        };

        *expr = ctx.ast.expression_boolean_literal(SPAN, result);

        1
    }
}

// ============================================================================
// StartsWith Pass
// ============================================================================

/// Evaluates string startsWith: `"hello".startsWith("he")` → `true`
#[derive(Default)]
pub struct StartsWith;

impl StartsWith {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "startsWith" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        let Some(search) = call.arguments.first().and_then(|a| match a {
            Argument::StringLiteral(lit) => Some(lit.value.as_str()),
            _ => a.as_expression().and_then(literal::string),
        }) else {
            return 0;
        };

        let start = call
            .arguments
            .get(1)
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value),
                _ => a.as_expression().and_then(literal::number),
            })
            .unwrap_or(0.0);

        let start = start.max(0.0) as usize;

        let result = if start >= s.len() {
            search.is_empty()
        } else {
            s[start..].starts_with(search)
        };

        *expr = ctx.ast.expression_boolean_literal(SPAN, result);

        1
    }
}

// ============================================================================
// EndsWith Pass
// ============================================================================

/// Evaluates string endsWith: `"hello".endsWith("lo")` → `true`
#[derive(Default)]
pub struct EndsWith;

impl EndsWith {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "endsWith" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        let Some(search) = call.arguments.first().and_then(|a| match a {
            Argument::StringLiteral(lit) => Some(lit.value.as_str()),
            _ => a.as_expression().and_then(literal::string),
        }) else {
            return 0;
        };

        let end = call
            .arguments
            .get(1)
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value),
                _ => a.as_expression().and_then(literal::number),
            });

        let result = match end {
            Some(end) => {
                let end = end.max(0.0) as usize;
                if end > s.len() {
                    s.ends_with(search)
                } else {
                    s[..end].ends_with(search)
                }
            }
            None => s.ends_with(search),
        };

        *expr = ctx.ast.expression_boolean_literal(SPAN, result);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_includes_true() {
        assert_eq!(transform("\"hello\".includes(\"ell\");"), "true;\n");
    }

    #[test]
    fn test_includes_false() {
        assert_eq!(transform("\"hello\".includes(\"xyz\");"), "false;\n");
    }

    #[test]
    fn test_starts_with_true() {
        assert_eq!(transform("\"hello\".startsWith(\"he\");"), "true;\n");
    }

    #[test]
    fn test_starts_with_false() {
        assert_eq!(transform("\"hello\".startsWith(\"lo\");"), "false;\n");
    }

    #[test]
    fn test_ends_with_true() {
        assert_eq!(transform("\"hello\".endsWith(\"lo\");"), "true;\n");
    }

    #[test]
    fn test_ends_with_false() {
        assert_eq!(transform("\"hello\".endsWith(\"he\");"), "false;\n");
    }
}
