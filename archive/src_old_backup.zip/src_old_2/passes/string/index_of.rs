//! String indexOf and lastIndexOf passes.

use oxc::ast::ast::{Argument, Expression, NumberBase};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// IndexOf Pass
// ============================================================================

/// Evaluates string indexOf: `"hello".indexOf("l")` → `2`
#[derive(Default)]
pub struct IndexOf;

impl IndexOf {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "indexOf" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        let Some(search) = call.arguments.first().and_then(|a| match a {
            Argument::StringLiteral(lit) => Some(lit.value.as_str()),
            _ => a.as_expression().and_then(literal::string),
        }) else {
            return 0;
        };

        let start = call
            .arguments
            .get(1)
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value),
                _ => a.as_expression().and_then(literal::number),
            })
            .unwrap_or(0.0);

        let start = start.max(0.0) as usize;

        let result = if start >= s.len() {
            -1
        } else {
            s[start..].find(search).map(|i| (i + start) as i64).unwrap_or(-1)
        };

        *expr = ctx.ast.expression_numeric_literal(SPAN, result as f64, None, NumberBase::Decimal);

        1
    }
}

// ============================================================================
// LastIndexOf Pass
// ============================================================================

/// Evaluates string lastIndexOf: `"hello".lastIndexOf("l")` → `3`
#[derive(Default)]
pub struct LastIndexOf;

impl LastIndexOf {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "lastIndexOf" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        let Some(search) = call.arguments.first().and_then(|a| match a {
            Argument::StringLiteral(lit) => Some(lit.value.as_str()),
            _ => a.as_expression().and_then(literal::string),
        }) else {
            return 0;
        };

        let result = s.rfind(search).map(|i| i as i64).unwrap_or(-1);

        *expr = ctx.ast.expression_numeric_literal(SPAN, result as f64, None, NumberBase::Decimal);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_index_of() {
        assert_eq!(transform("\"hello\".indexOf(\"l\");"), "2;\n");
    }

    #[test]
    fn test_index_of_not_found() {
        assert_eq!(transform("\"hello\".indexOf(\"x\");"), "-1;\n");
    }

    #[test]
    fn test_index_of_with_start() {
        assert_eq!(transform("\"hello\".indexOf(\"l\", 3);"), "3;\n");
    }

    #[test]
    fn test_last_index_of() {
        assert_eq!(transform("\"hello\".lastIndexOf(\"l\");"), "3;\n");
    }

    #[test]
    fn test_last_index_of_not_found() {
        assert_eq!(transform("\"hello\".lastIndexOf(\"x\");"), "-1;\n");
    }
}
