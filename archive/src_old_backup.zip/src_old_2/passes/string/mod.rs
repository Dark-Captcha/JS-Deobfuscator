//! String evaluation passes.
//!
//! - [`Concat`] — `"a" + "b"` → `"ab"`
//! - [`CharAt`] — `"abc"[0]` → `"a"`
//! - [`Length`] — `"abc".length` → `3`
//! - [`Slice`] — `"hello".slice(1, 3)` → `"el"`
//! - [`Substring`] — `"hello".substring(1, 3)` → `"el"`
//! - [`Substr`] — `"hello".substr(1, 2)` → `"el"`
//! - [`FromCharCode`] — `String.fromCharCode(65)` → `"A"`
//! - [`CharCodeAt`] — `"A".charCodeAt(0)` → `65`
//! - [`ToLowerCase`] — `"ABC".toLowerCase()` → `"abc"`
//! - [`ToUpperCase`] — `"abc".toUpperCase()` → `"ABC"`
//! - [`Trim`] — `" x ".trim()` → `"x"`
//! - [`TrimStart`] — `" x".trimStart()` → `"x"`
//! - [`TrimEnd`] — `"x ".trimEnd()` → `"x"`
//! - [`IndexOf`] — `"hello".indexOf("l")` → `2`
//! - [`LastIndexOf`] — `"hello".lastIndexOf("l")` → `3`
//! - [`Includes`] — `"hello".includes("ell")` → `true`
//! - [`StartsWith`] — `"hello".startsWith("he")` → `true`
//! - [`EndsWith`] — `"hello".endsWith("lo")` → `true`
//! - [`Repeat`] — `"ab".repeat(3)` → `"ababab"`
//! - [`Split`] — `"a,b".split(",")` → `["a", "b"]`
//! - [`Replace`] — `"hello".replace("l", "x")` → `"hexlo"`
//! - [`ReplaceAll`] — `"hello".replaceAll("l", "x")` → `"hexxo"`
//! - [`At`] — `"abc".at(1)` → `"b"`
//! - [`PadStart`] — `"5".padStart(2, "0")` → `"05"`
//! - [`PadEnd`] — `"5".padEnd(2, "0")` → `"50"`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod at;
mod char_at;
mod char_code_at;
mod concat;
mod from_char_code;
mod includes;
mod index_of;
mod length;
mod pad_end;
mod pad_start;
mod repeat;
mod replace;
mod slice;
mod split;
mod substr;
mod substring;
mod to_lower_case;
mod to_upper_case;
mod trim;

pub use at::At;
pub use char_at::CharAt;
pub use char_code_at::CharCodeAt;
pub use concat::Concat;
pub use from_char_code::FromCharCode;
pub use includes::{EndsWith, Includes, StartsWith};
pub use index_of::{IndexOf, LastIndexOf};
pub use length::Length;
pub use pad_end::PadEnd;
pub use pad_start::PadStart;
pub use repeat::Repeat;
pub use replace::{Replace, ReplaceAll};
pub use slice::Slice;
pub use split::Split;
pub use substr::Substr;
pub use substring::Substring;
pub use to_lower_case::ToLowerCase;
pub use to_upper_case::ToUpperCase;
pub use trim::{Trim, TrimEnd, TrimStart};

// ============================================================================
// String Group
// ============================================================================

/// Group of all string evaluation passes.
#[derive(Default)]
pub struct StringGroup {
    at: At,
    char_at: CharAt,
    char_code_at: CharCodeAt,
    concat: Concat,
    from_char_code: FromCharCode,
    includes: Includes,
    starts_with: StartsWith,
    ends_with: EndsWith,
    index_of: IndexOf,
    last_index_of: LastIndexOf,
    length: Length,
    pad_start: PadStart,
    pad_end: PadEnd,
    repeat: Repeat,
    replace: Replace,
    replace_all: ReplaceAll,
    slice: Slice,
    split: Split,
    substr: Substr,
    substring: Substring,
    to_lower_case: ToLowerCase,
    to_upper_case: ToUpperCase,
    trim: Trim,
    trim_start: TrimStart,
    trim_end: TrimEnd,
}

impl StringGroup {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform expression through all string passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.at.transform(expr, ctx);
        mods += self.char_at.transform(expr, ctx);
        mods += self.char_code_at.transform(expr, ctx);
        mods += self.concat.transform(expr, ctx);
        mods += self.from_char_code.transform(expr, ctx);
        mods += self.includes.transform(expr, ctx);
        mods += self.starts_with.transform(expr, ctx);
        mods += self.ends_with.transform(expr, ctx);
        mods += self.index_of.transform(expr, ctx);
        mods += self.last_index_of.transform(expr, ctx);
        mods += self.length.transform(expr, ctx);
        mods += self.pad_start.transform(expr, ctx);
        mods += self.pad_end.transform(expr, ctx);
        mods += self.repeat.transform(expr, ctx);
        mods += self.replace.transform(expr, ctx);
        mods += self.replace_all.transform(expr, ctx);
        mods += self.slice.transform(expr, ctx);
        mods += self.split.transform(expr, ctx);
        mods += self.substr.transform(expr, ctx);
        mods += self.substring.transform(expr, ctx);
        mods += self.to_lower_case.transform(expr, ctx);
        mods += self.to_upper_case.transform(expr, ctx);
        mods += self.trim.transform(expr, ctx);
        mods += self.trim_start.transform(expr, ctx);
        mods += self.trim_end.transform(expr, ctx);
        mods
    }
}
