//! String.fromCharCode pass.

use oxc::ast::ast::{Argument, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// FromCharCode Pass
// ============================================================================

/// Evaluates String.fromCharCode: `String.fromCharCode(65)` → `"A"`
#[derive(Default)]
pub struct FromCharCode;

impl FromCharCode {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        let Expression::Identifier(obj) = &member.object else {
            return 0;
        };

        if obj.name.as_str() != "String" || member.property.name.as_str() != "fromCharCode" {
            return 0;
        }

        if call.arguments.is_empty() {
            let atom = ctx.ast.atom("");
            *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
            return 1;
        }

        let mut chars = Vec::new();
        for arg in &call.arguments {
            let code = match arg {
                Argument::NumericLiteral(n) => Some(n.value),
                _ => arg.as_expression().and_then(literal::number),
            };

            let Some(code) = code else {
                return 0;
            };

            let code = code as u32;
            if code > 0xFFFF {
                return 0;
            }

            if let Some(c) = char::from_u32(code) {
                chars.push(c);
            } else {
                return 0;
            }
        }

        let result: String = chars.into_iter().collect();
        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_single_char() {
        assert_eq!(transform("String.fromCharCode(65);"), "(\"A\");\n");
    }

    #[test]
    fn test_multiple_chars() {
        assert_eq!(transform("String.fromCharCode(65, 66, 67);"), "(\"ABC\");\n");
    }

    #[test]
    fn test_empty() {
        assert_eq!(transform("String.fromCharCode();"), "(\"\");\n");
    }

    #[test]
    fn test_special_char() {
        assert_eq!(transform("String.fromCharCode(10);"), "(\"\\n\");\n");
    }
}
