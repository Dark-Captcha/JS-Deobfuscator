//! String substring pass.

use oxc::ast::ast::{Argument, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Substring Pass
// ============================================================================

/// Evaluates string substring: `"hello".substring(1, 3)` → `"el"`
#[derive(Default)]
pub struct Substring;

impl Substring {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "substring" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        let Some(start) = call.arguments.first().and_then(|a| {
            if let Argument::NumericLiteral(n) = a {
                Some(n.value)
            } else {
                a.as_expression().and_then(literal::number)
            }
        }) else {
            return 0;
        };

        let end = call.arguments.get(1).and_then(|a| {
            if let Argument::NumericLiteral(n) = a {
                Some(n.value)
            } else {
                a.as_expression().and_then(literal::number)
            }
        });

        let len = s.chars().count();
        let chars: Vec<char> = s.chars().collect();

        let mut start_idx = start.max(0.0) as usize;
        let mut end_idx = match end {
            Some(e) => e.max(0.0) as usize,
            None => len,
        };

        start_idx = start_idx.min(len);
        end_idx = end_idx.min(len);

        if start_idx > end_idx {
            std::mem::swap(&mut start_idx, &mut end_idx);
        }

        let result: String = chars[start_idx..end_idx].iter().collect();
        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_substring_two_args() {
        assert_eq!(transform("\"hello\".substring(1, 3);"), "(\"el\");\n");
    }

    #[test]
    fn test_substring_one_arg() {
        assert_eq!(transform("\"hello\".substring(1);"), "(\"ello\");\n");
    }

    #[test]
    fn test_substring_swapped() {
        assert_eq!(transform("\"hello\".substring(3, 1);"), "(\"el\");\n");
    }

    #[test]
    fn test_substring_negative() {
        assert_eq!(transform("\"hello\".substring(-2);"), "(\"hello\");\n");
    }
}
