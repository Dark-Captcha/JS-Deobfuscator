//! String toUpperCase pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// ToUpperCase Pass
// ============================================================================

/// Evaluates string toUpperCase: `"abc".toUpperCase()` → `"ABC"`
#[derive(Default)]
pub struct ToUpperCase;

impl ToUpperCase {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "toUpperCase" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        if !call.arguments.is_empty() {
            return 0;
        }

        let result = s.to_uppercase();
        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}
