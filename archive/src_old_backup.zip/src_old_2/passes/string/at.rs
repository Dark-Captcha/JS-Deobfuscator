//! String.at pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `"abc".at(1)` → `"b"`
#[derive(Default)]
pub struct At;

impl At {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else { return 0 };
        let Expression::StaticMemberExpression(member) = &call.callee else { return 0 };
        if member.property.name.as_str() != "at" { return 0 }
        if call.arguments.len() != 1 { return 0 }

        let Some(s) = literal::string(&member.object) else { return 0 };
        let Some(idx) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::number) else { return 0 };

        let idx = idx as i64;
        let chars: Vec<char> = s.chars().collect();
        let len = chars.len() as i64;

        // Handle negative indices
        let actual_idx = if idx < 0 { len + idx } else { idx };

        if actual_idx < 0 || actual_idx >= len {
            // Return undefined - but we can't easily represent that, so skip
            return 0;
        }

        let result = chars[actual_idx as usize].to_string();
        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }
        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_at_positive() {
        let result = transform("\"abc\".at(1)");
        assert!(result.contains("b"));
    }

    #[test]
    fn test_at_negative() {
        let result = transform("\"abc\".at(-1)");
        assert!(result.contains("c"));
    }
}
