//! String length pass.

use oxc::ast::ast::{Expression, NumberBase};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Length Pass
// ============================================================================

/// Evaluates string length: `"abc".length` → `3`
#[derive(Default)]
pub struct Length;

impl Length {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::StaticMemberExpression(member) = expr else {
            return 0;
        };

        if member.property.name != "length" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        // JavaScript uses UTF-16 code units for length
        let result = s.encode_utf16().count() as f64;
        *expr = ctx.ast.expression_numeric_literal(SPAN, result, None, NumberBase::Decimal);

        1
    }
}
