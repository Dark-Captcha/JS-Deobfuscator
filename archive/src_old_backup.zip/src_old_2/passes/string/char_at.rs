//! String charAt / index access pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// CharAt Pass
// ============================================================================

/// Evaluates string index access: `"abc"[0]` → `"a"`
#[derive(Default)]
pub struct CharAt;

impl CharAt {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::ComputedMemberExpression(member) = expr else {
            return 0;
        };

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };
        let Some(idx) = literal::number(&member.expression) else {
            return 0;
        };

        let idx = idx as usize;
        let chars: Vec<char> = s.chars().collect();

        if idx >= chars.len() {
            return 0;
        }

        let result = chars[idx].to_string();
        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}
