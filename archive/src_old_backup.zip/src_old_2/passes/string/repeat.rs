//! String repeat pass.

use oxc::ast::ast::{Argument, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Repeat Pass
// ============================================================================

/// Evaluates string repeat: `"ab".repeat(3)` → `"ababab"`
#[derive(Default)]
pub struct Repeat;

impl Repeat {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "repeat" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        let Some(count) = call.arguments.first().and_then(|a| match a {
            Argument::NumericLiteral(n) => Some(n.value),
            _ => a.as_expression().and_then(literal::number),
        }) else {
            return 0;
        };

        if count < 0.0 || count.is_nan() || count.is_infinite() {
            return 0;
        }

        let count = count as usize;

        if count > 10000 || s.len() * count > 100000 {
            return 0;
        }

        let result = s.repeat(count);
        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_repeat() {
        assert_eq!(transform("\"ab\".repeat(3);"), "(\"ababab\");\n");
    }

    #[test]
    fn test_repeat_zero() {
        assert_eq!(transform("\"ab\".repeat(0);"), "(\"\");\n");
    }

    #[test]
    fn test_repeat_one() {
        assert_eq!(transform("\"ab\".repeat(1);"), "(\"ab\");\n");
    }
}
