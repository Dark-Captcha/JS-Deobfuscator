//! String concatenation pass.

use oxc::ast::ast::{BinaryOperator, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Concat Pass
// ============================================================================

/// Evaluates string concatenation: `"a" + "b"` → `"ab"`
#[derive(Default)]
pub struct Concat;

impl Concat {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::BinaryExpression(bin) = expr else {
            return 0;
        };

        if bin.operator != BinaryOperator::Addition {
            return 0;
        }

        let Some(left) = literal::string(&bin.left) else {
            return 0;
        };
        let Some(right) = literal::string(&bin.right) else {
            return 0;
        };

        let result = format!("{}{}", left, right);

        tracing::trace!(
            target: "deob::pass::string_concat",
            %left,
            %right,
            %result,
            "evaluated"
        );

        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}
