//! String slice pass.

use oxc::ast::ast::{Argument, Expression};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// Slice Pass
// ============================================================================

/// Evaluates string slice: `"hello".slice(1, 3)` → `"el"`
#[derive(Default)]
pub struct Slice;

impl Slice {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "slice" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        let Some(start) = call.arguments.first().and_then(|a| {
            if let Argument::NumericLiteral(n) = a {
                Some(n.value)
            } else {
                a.as_expression().and_then(literal::number)
            }
        }) else {
            return 0;
        };

        let end = call.arguments.get(1).and_then(|a| {
            if let Argument::NumericLiteral(n) = a {
                Some(n.value)
            } else {
                a.as_expression().and_then(literal::number)
            }
        });

        let len = s.chars().count() as i64;
        let chars: Vec<char> = s.chars().collect();

        let start_idx = if start < 0.0 {
            (len + start as i64).max(0) as usize
        } else {
            (start as usize).min(len as usize)
        };

        let end_idx = match end {
            Some(e) if e < 0.0 => (len + e as i64).max(0) as usize,
            Some(e) => (e as usize).min(len as usize),
            None => len as usize,
        };

        if start_idx >= end_idx {
            let atom = ctx.ast.atom("");
            *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
            return 1;
        }

        let result: String = chars[start_idx..end_idx].iter().collect();
        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_slice_two_args() {
        assert_eq!(transform("\"hello\".slice(1, 3);"), "(\"el\");\n");
    }

    #[test]
    fn test_slice_one_arg() {
        assert_eq!(transform("\"hello\".slice(1);"), "(\"ello\");\n");
    }

    #[test]
    fn test_slice_negative() {
        assert_eq!(transform("\"hello\".slice(-2);"), "(\"lo\");\n");
    }

    #[test]
    fn test_slice_negative_both() {
        assert_eq!(transform("\"hello\".slice(-3, -1);"), "(\"ll\");\n");
    }

    #[test]
    fn test_slice_empty() {
        assert_eq!(transform("\"hello\".slice(3, 1);"), "(\"\");\n");
    }
}
