//! String.padStart pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `"5".padStart(2, "0")` → `"05"`
#[derive(Default)]
pub struct PadStart;

impl PadStart {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else { return 0 };
        let Expression::StaticMemberExpression(member) = &call.callee else { return 0 };
        if member.property.name.as_str() != "padStart" { return 0 }
        if call.arguments.is_empty() || call.arguments.len() > 2 { return 0 }

        let Some(s) = literal::string(&member.object) else { return 0 };
        let Some(target_len) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::number) else { return 0 };

        let target_len = target_len as usize;
        let pad_str = if call.arguments.len() == 2 {
            call.arguments.get(1).and_then(|a| a.as_expression()).and_then(literal::string).unwrap_or(" ")
        } else {
            " "
        };

        if pad_str.is_empty() || s.len() >= target_len {
            let atom = ctx.ast.atom(s);
            *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
            return 1;
        }

        let pad_needed = target_len - s.len();
        let mut result = String::with_capacity(target_len);
        
        let mut remaining = pad_needed;
        while remaining > 0 {
            let take = remaining.min(pad_str.len());
            result.push_str(&pad_str[..take]);
            remaining -= take;
        }
        result.push_str(s);

        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }
        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_pad_start() {
        let result = transform("\"5\".padStart(2, \"0\")");
        assert!(result.contains("05"));
    }

    #[test]
    fn test_pad_start_default() {
        let result = transform("\"5\".padStart(3)");
        assert!(result.contains("  5"));
    }
}
