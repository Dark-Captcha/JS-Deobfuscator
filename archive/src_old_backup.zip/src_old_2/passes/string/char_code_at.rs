//! String charCodeAt pass.

use oxc::ast::ast::{Argument, Expression, NumberBase};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

// ============================================================================
// CharCodeAt Pass
// ============================================================================

/// Evaluates string charCodeAt: `"A".charCodeAt(0)` → `65`
#[derive(Default)]
pub struct CharCodeAt;

impl CharCodeAt {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "charCodeAt" {
            return 0;
        }

        let Some(s) = literal::string(&member.object) else {
            return 0;
        };

        let idx = call
            .arguments
            .first()
            .and_then(|a| match a {
                Argument::NumericLiteral(n) => Some(n.value),
                _ => a.as_expression().and_then(literal::number),
            })
            .unwrap_or(0.0);

        let idx = idx as usize;
        let chars: Vec<char> = s.chars().collect();

        if idx >= chars.len() {
            return 0;
        }

        let code = chars[idx] as u32;
        *expr = ctx.ast.expression_numeric_literal(SPAN, code as f64, None, NumberBase::Decimal);

        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::string::StringGroup;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(StringGroup);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(StringGroup::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_char_code_at() {
        assert_eq!(transform("\"A\".charCodeAt(0);"), "65;\n");
    }

    #[test]
    fn test_char_code_at_default() {
        assert_eq!(transform("\"ABC\".charCodeAt();"), "65;\n");
    }

    #[test]
    fn test_char_code_at_index() {
        assert_eq!(transform("\"ABC\".charCodeAt(2);"), "67;\n");
    }

    #[test]
    fn test_char_code_at_out_of_bounds() {
        let result = transform("\"A\".charCodeAt(5);");
        assert!(result.contains("charCodeAt"));
    }
}
