//! Global isFinite pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `isFinite(x)` → boolean
/// Note: Global isFinite coerces to number first, unlike Number.isFinite
#[derive(Default)]
pub struct GlobalIsFinite;

impl GlobalIsFinite {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::Identifier(callee) = &call.callee else {
            return 0;
        };

        if callee.name.as_str() != "isFinite" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(arg_expr) = call.arguments.first().and_then(|a| a.as_expression()) else {
            return 0;
        };

        // Global isFinite coerces to number first
        let result = match arg_expr {
            Expression::Identifier(id) => {
                match id.name.as_str() {
                    "NaN" | "Infinity" => false,
                    "undefined" => false, // Number(undefined) = NaN
                    _ => return 0,
                }
            }
            Expression::NullLiteral(_) => true, // Number(null) = 0
            Expression::BooleanLiteral(_) => true, // Number(true/false) = 1/0
            Expression::StringLiteral(s) => {
                let trimmed = s.value.trim();
                if trimmed.is_empty() {
                    true // "" -> 0
                } else if let Ok(n) = trimmed.parse::<f64>() {
                    n.is_finite()
                } else {
                    false // Non-numeric string -> NaN
                }
            }
            Expression::ArrayExpression(arr) => {
                if arr.elements.is_empty() {
                    true // [] -> 0
                } else if arr.elements.len() == 1 {
                    if let Some(elem) = arr.elements.first() {
                        if let Some(e) = elem.as_expression() {
                            if let Some(n) = literal::number(e) {
                                n.is_finite()
                            } else if let Expression::StringLiteral(s) = e {
                                let trimmed = s.value.trim();
                                if trimmed.is_empty() {
                                    true
                                } else if let Ok(n) = trimmed.parse::<f64>() {
                                    n.is_finite()
                                } else {
                                    false
                                }
                            } else {
                                return 0;
                            }
                        } else {
                            return 0;
                        }
                    } else {
                        return 0;
                    }
                } else {
                    false // Multiple elements -> NaN
                }
            }
            Expression::ObjectExpression(_) => false, // {} -> NaN
            _ => {
                if let Some(n) = literal::number(arg_expr) {
                    n.is_finite()
                } else {
                    return 0;
                }
            }
        };

        *expr = ctx.ast.expression_boolean_literal(SPAN, result);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::number::Number;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Number);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Number::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_global_is_finite_true() {
        assert_eq!(transform("isFinite(42)"), "true;\n");
    }

    #[test]
    fn test_global_is_finite_infinity() {
        assert_eq!(transform("isFinite(Infinity)"), "false;\n");
    }

    #[test]
    fn test_global_is_finite_null() {
        // isFinite(null) = true (null -> 0)
        assert_eq!(transform("isFinite(null)"), "true;\n");
    }

    #[test]
    fn test_global_is_finite_string() {
        // isFinite("123") = true
        let result = transform("isFinite(\"123\")");
        assert!(result.contains("true"));
    }
}
