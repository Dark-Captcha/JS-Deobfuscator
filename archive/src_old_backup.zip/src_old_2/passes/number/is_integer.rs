//! Number.isInteger pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `Number.isInteger(x)` → boolean
#[derive(Default)]
pub struct IsInteger;

impl IsInteger {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "isInteger" {
            return 0;
        }

        let Expression::Identifier(obj) = &member.object else {
            return 0;
        };

        if obj.name.as_str() != "Number" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(arg_expr) = call.arguments.first().and_then(|a| a.as_expression()) else {
            return 0;
        };

        let result = match arg_expr {
            Expression::Identifier(id) => {
                match id.name.as_str() {
                    "NaN" | "Infinity" | "undefined" => false,
                    _ => return 0,
                }
            }
            _ => {
                if let Some(n) = literal::number(arg_expr) {
                    n.is_finite() && n.trunc() == n
                } else {
                    // Non-numeric types return false
                    match arg_expr {
                        Expression::StringLiteral(_) => false,
                        Expression::BooleanLiteral(_) => false,
                        Expression::NullLiteral(_) => false,
                        Expression::ArrayExpression(_) => false,
                        Expression::ObjectExpression(_) => false,
                        _ => return 0,
                    }
                }
            }
        };

        *expr = ctx.ast.expression_boolean_literal(SPAN, result);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::number::Number;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Number);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Number::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_is_integer_true() {
        assert_eq!(transform("Number.isInteger(42)"), "true;\n");
    }

    #[test]
    fn test_is_integer_false_float() {
        assert_eq!(transform("Number.isInteger(3.14)"), "false;\n");
    }

    #[test]
    fn test_is_integer_false_nan() {
        assert_eq!(transform("Number.isInteger(NaN)"), "false;\n");
    }
}
