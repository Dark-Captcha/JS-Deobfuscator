//! Number.toString pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `(255).toString(16)` → `"ff"`
#[derive(Default)]
pub struct ToString;

impl ToString {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else { return 0 };
        let Expression::StaticMemberExpression(member) = &call.callee else { return 0 };
        if member.property.name.as_str() != "toString" { return 0 }

        let Some(n) = literal::number(&member.object) else { return 0 };

        let radix = if call.arguments.is_empty() {
            10
        } else {
            let Some(r) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::number) else { return 0 };
            r as u32
        };

        if !(2..=36).contains(&radix) { return 0 }

        let result = if radix == 10 {
            if n.fract() == 0.0 && n.abs() < i64::MAX as f64 {
                format!("{}", n as i64)
            } else {
                format!("{}", n)
            }
        } else {
            // Only handle integers for non-decimal radix
            if n.fract() != 0.0 || n.abs() >= i64::MAX as f64 { return 0 }
            let n_int = n as i64;
            if n_int < 0 {
                format!("-{}", to_radix_string((-n_int) as u64, radix))
            } else {
                to_radix_string(n_int as u64, radix)
            }
        };

        let atom = ctx.ast.atom(&result);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
        1
    }
}

fn to_radix_string(mut n: u64, radix: u32) -> String {
    if n == 0 { return "0".to_string() }
    
    let digits = "0123456789abcdefghijklmnopqrstuvwxyz";
    let mut result = String::new();
    
    while n > 0 {
        let digit = (n % radix as u64) as usize;
        result.insert(0, digits.chars().nth(digit).unwrap());
        n /= radix as u64;
    }
    
    result
}

#[cfg(test)]
mod tests {
    use crate::passes::number::Number;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();
        struct Visitor(Number);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }
        let mut visitor = Visitor(Number::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());
        Codegen::new().build(&program).code
    }

    #[test]
    fn test_to_string_hex() {
        let result = transform("(255).toString(16)");
        assert!(result.contains("ff"));
    }

    #[test]
    fn test_to_string_binary() {
        let result = transform("(5).toString(2)");
        assert!(result.contains("101"));
    }

    #[test]
    fn test_to_string_decimal() {
        let result = transform("(42).toString()");
        assert!(result.contains("42"));
    }
}
