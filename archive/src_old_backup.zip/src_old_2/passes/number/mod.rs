//! Number method passes.
//!
//! - [`IsNaN`] — `Number.isNaN(NaN)` → `true`
//! - [`IsFinite`] — `Number.isFinite(1)` → `true`
//! - [`IsInteger`] — `Number.isInteger(1)` → `true`
//! - [`GlobalIsNaN`] — `isNaN(NaN)` → `true`
//! - [`GlobalIsFinite`] — `isFinite(1)` → `true`
//! - [`ToFixed`] — `(3.14).toFixed(1)` → `"3.1"`
//! - [`ToString`] — `(255).toString(16)` → `"ff"`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod global_is_finite;
mod global_is_nan;
mod is_finite;
mod is_integer;
mod is_nan;
mod to_fixed;
mod to_string;

pub use global_is_finite::GlobalIsFinite;
pub use global_is_nan::GlobalIsNaN;
pub use is_finite::IsFinite;
pub use is_integer::IsInteger;
pub use is_nan::IsNaN;
pub use to_fixed::ToFixed;
pub use to_string::ToString;

/// Group of all Number method passes.
#[derive(Default)]
pub struct Number {
    is_nan: IsNaN,
    is_finite: IsFinite,
    is_integer: IsInteger,
    global_is_nan: GlobalIsNaN,
    global_is_finite: GlobalIsFinite,
    to_fixed: ToFixed,
    to_string: ToString,
}

impl Number {
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.is_nan.transform(expr, ctx);
        mods += self.is_finite.transform(expr, ctx);
        mods += self.is_integer.transform(expr, ctx);
        mods += self.global_is_nan.transform(expr, ctx);
        mods += self.global_is_finite.transform(expr, ctx);
        mods += self.to_fixed.transform(expr, ctx);
        mods += self.to_string.transform(expr, ctx);
        mods
    }
}
