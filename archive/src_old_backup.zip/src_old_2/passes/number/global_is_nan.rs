//! Global isNaN pass.

use oxc::ast::ast::Expression;
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `isNaN(x)` → boolean
/// Note: Global isNaN coerces to number first, unlike Number.isNaN
#[derive(Default)]
pub struct GlobalIsNaN;

impl GlobalIsNaN {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::Identifier(callee) = &call.callee else {
            return 0;
        };

        if callee.name.as_str() != "isNaN" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(arg_expr) = call.arguments.first().and_then(|a| a.as_expression()) else {
            return 0;
        };

        // Global isNaN coerces to number first
        let result = match arg_expr {
            Expression::Identifier(id) => {
                match id.name.as_str() {
                    "NaN" => true,
                    "undefined" => true, // Number(undefined) = NaN
                    "Infinity" => false,
                    _ => return 0,
                }
            }
            Expression::NullLiteral(_) => false, // Number(null) = 0
            Expression::BooleanLiteral(_) => false, // Number(true/false) = 1/0
            Expression::StringLiteral(s) => {
                // isNaN("") = false (empty string -> 0)
                // isNaN("123") = false
                // isNaN("hello") = true
                let trimmed = s.value.trim();
                if trimmed.is_empty() {
                    false
                } else {
                    trimmed.parse::<f64>().is_err()
                }
            }
            Expression::ArrayExpression(arr) => {
                // isNaN([]) = false ([] -> "" -> 0)
                // isNaN([1]) = false ([1] -> "1" -> 1)
                // isNaN([1,2]) = true ([1,2] -> "1,2" -> NaN)
                if arr.elements.is_empty() {
                    false
                } else if arr.elements.len() == 1 {
                    if let Some(elem) = arr.elements.first() {
                        if let Some(e) = elem.as_expression() {
                            if let Some(n) = literal::number(e) {
                                n.is_nan()
                            } else if let Expression::StringLiteral(s) = e {
                                let trimmed = s.value.trim();
                                if trimmed.is_empty() {
                                    false
                                } else {
                                    trimmed.parse::<f64>().is_err()
                                }
                            } else {
                                return 0;
                            }
                        } else {
                            return 0;
                        }
                    } else {
                        return 0;
                    }
                } else {
                    true // Multiple elements -> NaN
                }
            }
            Expression::ObjectExpression(_) => true, // {} -> NaN
            _ => {
                if let Some(n) = literal::number(arg_expr) {
                    n.is_nan()
                } else {
                    return 0;
                }
            }
        };

        *expr = ctx.ast.expression_boolean_literal(SPAN, result);
        1
    }
}

#[cfg(test)]
mod tests {
    use crate::passes::number::Number;
    use oxc::allocator::Allocator;
    use oxc::ast::ast::Expression;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Number);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Number::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_global_is_nan_true() {
        assert_eq!(transform("isNaN(NaN)"), "true;\n");
    }

    #[test]
    fn test_global_is_nan_undefined() {
        assert_eq!(transform("isNaN(undefined)"), "true;\n");
    }

    #[test]
    fn test_global_is_nan_string() {
        // isNaN("hello") = true (coerces to NaN)
        let result = transform("isNaN(\"hello\")");
        assert!(result.contains("true"));
    }

    #[test]
    fn test_global_is_nan_numeric_string() {
        // isNaN("123") = false
        let result = transform("isNaN(\"123\")");
        assert!(result.contains("false"));
    }

    #[test]
    fn test_global_is_nan_number() {
        assert_eq!(transform("isNaN(42)"), "false;\n");
    }
}
