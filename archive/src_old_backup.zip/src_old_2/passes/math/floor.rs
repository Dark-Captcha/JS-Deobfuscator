//! Math.floor pass.

use oxc::ast::ast::{Argument, Expression};
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `Math.floor(x)` → floor value
#[derive(Default)]
pub struct Floor;

impl Floor {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else {
            return 0;
        };

        let Expression::StaticMemberExpression(member) = &call.callee else {
            return 0;
        };

        if member.property.name.as_str() != "floor" {
            return 0;
        }

        let Expression::Identifier(obj) = &member.object else {
            return 0;
        };

        if obj.name.as_str() != "Math" {
            return 0;
        }

        if call.arguments.len() != 1 {
            return 0;
        }

        let Some(value) = call.arguments.first().and_then(|a| match a {
            Argument::NumericLiteral(n) => Some(n.value),
            _ => a.as_expression().and_then(literal::number),
        }) else {
            return 0;
        };

        let result = value.floor();

        if result.is_infinite() || result.is_nan() {
            return 0;
        }

        *expr = literal::make_number(result, &ctx.ast);

        1
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::passes::math::Math;
    use oxc::allocator::Allocator;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;
    use oxc_traverse::{traverse_mut, TraverseCtx};

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let mut program = Parser::new(&allocator, source, SourceType::mjs())
            .parse()
            .program;

        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        struct Visitor(Math);
        impl<'a> oxc_traverse::Traverse<'a, ()> for Visitor {
            fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
                self.0.exit_expression(expr, ctx);
            }
        }

        let mut visitor = Visitor(Math::new());
        traverse_mut(&mut visitor, &allocator, &mut program, scoping, ());

        Codegen::new().build(&program).code
    }

    #[test]
    fn test_floor_positive() {
        assert_eq!(transform("Math.floor(1.5)"), "1;\n");
    }

    #[test]
    fn test_floor_negative() {
        assert_eq!(transform("Math.floor(-1.5)"), "-2;\n");
    }

    #[test]
    fn test_floor_integer() {
        assert_eq!(transform("Math.floor(5)"), "5;\n");
    }
}
