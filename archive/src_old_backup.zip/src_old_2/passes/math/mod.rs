//! Math method passes.
//!
//! - [`Floor`] — `Math.floor(1.5)` → `1`
//! - [`Ceil`] — `Math.ceil(1.5)` → `2`
//! - [`Round`] — `Math.round(1.5)` → `2`
//! - [`Abs`] — `Math.abs(-5)` → `5`
//! - [`Min`] — `Math.min(1,2,3)` → `1`
//! - [`Max`] — `Math.max(1,2,3)` → `3`
//! - [`Pow`] — `Math.pow(2,3)` → `8`
//! - [`Sqrt`] — `Math.sqrt(4)` → `2`
//! - [`Sign`] — `Math.sign(-5)` → `-1`
//! - [`Trunc`] — `Math.trunc(1.5)` → `1`
//! - [`Sin`] — `Math.sin(0)` → `0`
//! - [`Cos`] — `Math.cos(0)` → `1`
//! - [`Tan`] — `Math.tan(0)` → `0`
//! - [`Log`] — `Math.log(1)` → `0`
//! - [`Exp`] — `Math.exp(0)` → `1`
//! - [`Imul`] — `Math.imul(2,3)` → `6`
//! - [`Clz32`] — `Math.clz32(1)` → `31`
//! - [`Fround`] — `Math.fround(1.5)` → float32
//! - [`Hypot`] — `Math.hypot(3,4)` → `5`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod abs;
mod ceil;
mod clz32;
mod cos;
mod exp;
mod floor;
mod fround;
mod hypot;
mod imul;
mod log;
mod max;
mod min;
mod pow;
mod round;
mod sign;
mod sin;
mod sqrt;
mod tan;
mod trunc;

pub use abs::Abs;
pub use ceil::Ceil;
pub use clz32::Clz32;
pub use cos::Cos;
pub use exp::Exp;
pub use floor::Floor;
pub use fround::Fround;
pub use hypot::Hypot;
pub use imul::Imul;
pub use log::Log;
pub use max::Max;
pub use min::Min;
pub use pow::Pow;
pub use round::Round;
pub use sign::Sign;
pub use sin::Sin;
pub use sqrt::Sqrt;
pub use tan::Tan;
pub use trunc::Trunc;

// ============================================================================
// Math Group
// ============================================================================

/// Group of all Math method passes.
#[derive(Default)]
pub struct Math {
    floor: Floor,
    ceil: Ceil,
    round: Round,
    abs: Abs,
    min: Min,
    max: Max,
    pow: Pow,
    sqrt: Sqrt,
    sign: Sign,
    trunc: Trunc,
    sin: Sin,
    cos: Cos,
    tan: Tan,
    log: Log,
    exp: Exp,
    imul: Imul,
    clz32: Clz32,
    fround: Fround,
    hypot: Hypot,
}

impl Math {
    pub fn new() -> Self {
        Self::default()
    }

    /// Transform expression through all math passes.
    /// Returns number of modifications.
    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let mut mods = 0;
        mods += self.floor.transform(expr, ctx);
        mods += self.ceil.transform(expr, ctx);
        mods += self.round.transform(expr, ctx);
        mods += self.abs.transform(expr, ctx);
        mods += self.min.transform(expr, ctx);
        mods += self.max.transform(expr, ctx);
        mods += self.pow.transform(expr, ctx);
        mods += self.sqrt.transform(expr, ctx);
        mods += self.sign.transform(expr, ctx);
        mods += self.trunc.transform(expr, ctx);
        mods += self.sin.transform(expr, ctx);
        mods += self.cos.transform(expr, ctx);
        mods += self.tan.transform(expr, ctx);
        mods += self.log.transform(expr, ctx);
        mods += self.exp.transform(expr, ctx);
        mods += self.imul.transform(expr, ctx);
        mods += self.clz32.transform(expr, ctx);
        mods += self.fround.transform(expr, ctx);
        mods += self.hypot.transform(expr, ctx);
        mods
    }
}
