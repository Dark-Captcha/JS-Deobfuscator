//! Math.hypot pass.

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `Math.hypot(a, b, ...)` → sqrt(a² + b² + ...)
#[derive(Default)]
pub struct Hypot;

impl Hypot {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else { return 0 };
        let Expression::StaticMemberExpression(member) = &call.callee else { return 0 };
        if member.property.name.as_str() != "hypot" { return 0 }
        let Expression::Identifier(obj) = &member.object else { return 0 };
        if obj.name.as_str() != "Math" { return 0 }

        if call.arguments.is_empty() {
            *expr = literal::make_number(0.0, &ctx.ast);
            return 1;
        }

        let mut sum_sq = 0.0;
        for arg in &call.arguments {
            let Some(n) = arg.as_expression().and_then(literal::number) else { return 0 };
            sum_sq += n * n;
        }

        let result = sum_sq.sqrt();
        *expr = literal::make_number(result, &ctx.ast);
        1
    }
}
