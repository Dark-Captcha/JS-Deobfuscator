//! Math.fround pass.

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `Math.fround(x)` → nearest 32-bit float
#[derive(Default)]
pub struct Fround;

impl Fround {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else { return 0 };
        let Expression::StaticMemberExpression(member) = &call.callee else { return 0 };
        if member.property.name.as_str() != "fround" { return 0 }
        let Expression::Identifier(obj) = &member.object else { return 0 };
        if obj.name.as_str() != "Math" { return 0 }
        if call.arguments.len() != 1 { return 0 }

        let Some(n) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::number) else { return 0 };

        // Convert to f32 and back to f64
        let result = (n as f32) as f64;

        *expr = literal::make_number(result, &ctx.ast);
        1
    }
}
