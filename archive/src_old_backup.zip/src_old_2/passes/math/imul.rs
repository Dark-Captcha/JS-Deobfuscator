//! Math.imul pass.

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

use crate::utils::literal;

/// Evaluates `Math.imul(a, b)` → 32-bit integer multiplication
#[derive(Default)]
pub struct Imul;

impl Imul {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::CallExpression(call) = expr else { return 0 };
        let Expression::StaticMemberExpression(member) = &call.callee else { return 0 };
        if member.property.name.as_str() != "imul" { return 0 }
        let Expression::Identifier(obj) = &member.object else { return 0 };
        if obj.name.as_str() != "Math" { return 0 }
        if call.arguments.len() != 2 { return 0 }

        let Some(a) = call.arguments.first().and_then(|a| a.as_expression()).and_then(literal::number) else { return 0 };
        let Some(b) = call.arguments.get(1).and_then(|a| a.as_expression()).and_then(literal::number) else { return 0 };

        // Math.imul performs 32-bit integer multiplication
        let a_i32 = a as i32;
        let b_i32 = b as i32;
        let result = a_i32.wrapping_mul(b_i32) as f64;

        *expr = literal::make_number(result, &ctx.ast);
        1
    }
}
