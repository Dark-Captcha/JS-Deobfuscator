//! Typeof literal pass.

use oxc::ast::ast::{Expression, UnaryOperator};
use oxc::span::SPAN;
use oxc_traverse::TraverseCtx;

/// Evaluates typeof on literals: `typeof "x"` → `"string"`
#[derive(Default)]
pub struct Literal;

impl Literal {
    #[inline]
    pub fn transform<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        let Expression::UnaryExpression(unary) = expr else {
            return 0;
        };

        if unary.operator != UnaryOperator::Typeof {
            return 0;
        }

        let Some(type_str) = get_typeof(&unary.argument) else {
            return 0;
        };

        let atom = ctx.ast.atom(type_str);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);

        1
    }
}

fn get_typeof(expr: &Expression) -> Option<&'static str> {
    match expr {
        Expression::StringLiteral(_) => Some("string"),
        Expression::NumericLiteral(_) => Some("number"),
        Expression::BooleanLiteral(_) => Some("boolean"),
        Expression::NullLiteral(_) => Some("object"), // typeof null === "object"
        Expression::Identifier(id) if id.name == "undefined" => Some("undefined"),
        Expression::FunctionExpression(_) | Expression::ArrowFunctionExpression(_) => {
            Some("function")
        }
        Expression::ArrayExpression(_) | Expression::ObjectExpression(_) => Some("object"),
        Expression::BigIntLiteral(_) => Some("bigint"),
        Expression::ParenthesizedExpression(p) => get_typeof(&p.expression),
        Expression::UnaryExpression(u) => match u.operator {
            UnaryOperator::UnaryNegation | UnaryOperator::UnaryPlus => Some("number"),
            UnaryOperator::LogicalNot => Some("boolean"),
            UnaryOperator::Void => Some("undefined"),
            _ => None,
        },
        _ => None,
    }
}
