//! Typeof evaluation passes.
//!
//! - [`Literal`] — `typeof "x"` → `"string"`

use oxc::ast::ast::Expression;
use oxc_traverse::TraverseCtx;

mod literal;

pub use literal::Literal;

// ============================================================================
// Typeof Group
// ============================================================================

/// Group of all typeof evaluation passes.
#[derive(Default)]
pub struct Typeof {
    literal: Literal,
}

impl Typeof {
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn exit_expression<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> usize {
        self.literal.transform(expr, ctx)
    }
}
