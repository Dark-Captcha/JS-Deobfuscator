//! Universal JavaScript Deobfuscator
//!
//! A high-accuracy JavaScript deobfuscator built on OXC.
//!
//! # Architecture
//!
//! The deobfuscator uses a two-layer architecture:
//!
//! - **Core** — Processes pure JavaScript language constructs
//! - **Extensions** — Handles obfuscator-specific patterns
//!
//! # Quick Start
//!
//! ```ignore
//! use dark_captcha::core::Engine;
//!
//! // Create engine
//! let engine = Engine::new();
//!
//! // Parse and transform
//! let allocator = oxc::allocator::Allocator::default();
//! let mut program = parse(source, &allocator);
//! let result = engine.run(&allocator, &mut program)?;
//!
//! // Generate output
//! let output = codegen(&program);
//! ```
//!
//! # Modules
//!
//! - [`core`] — Engine, transformer
//! - [`passes`] — Atomic transformation passes (grouped by category)
//! - [`modules`] — Two-phase transformation modules
//! - [`utils`] — Helper functions

// ============================================================================
// Modules
// ============================================================================

pub mod core;
pub mod modules;
pub mod passes;
pub mod utils;

// ============================================================================
// Re-exports for convenience
// ============================================================================

pub use core::{Engine, EngineConfig, EngineResult, Module, ModuleResult, PureJsTransformer};
