//! Core deobfuscation engine.
//!
//! This module provides the foundational components for JavaScript deobfuscation:
//!
//! - [`PureJsTransformer`] - Static dispatch transformer with all passes
//! - [`Module`] - Trait for two-phase transformations
//! - [`Engine`] - Convergence loop executor
//!
//! # Architecture
//!
//! The core uses a **convergence loop** pattern:
//!
//! ```text
//! for each iteration:
//!     rebuild scoping (fresh symbol/reference info)
//!     run PureJsTransformer (all passes, static dispatch)
//!     if no modifications: break (converged)
//! ```
//!
//! Passes are **atomic** — each does ONE transformation (e.g., `1 + 2 → 3`).
//! The bottom-up traversal ensures children are simplified before parents.
//!
//! Passes receive `TraverseCtx` from OXC which provides:
//! - `ctx.ast` — AstBuilder for creating nodes
//! - `ctx.scoping()` — Symbol/reference information

// ============================================================================
// Modules
// ============================================================================

mod engine;
mod error;
mod module;
mod transformer;

// ============================================================================
// Re-exports
// ============================================================================

pub use engine::{Engine, EngineConfig, EngineResult};
pub use error::EngineError;
pub use module::{Module, ModuleResult};
pub use transformer::PureJsTransformer;
