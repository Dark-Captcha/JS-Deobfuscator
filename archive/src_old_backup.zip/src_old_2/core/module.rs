//! Module trait for two-phase transformations.
//!
//! Unlike atomic passes which are stateless and run on individual nodes,
//! [`Module`] can maintain state across a full traversal and perform
//! multi-phase transformations (collect → apply).

use oxc::allocator::Allocator;
use oxc::ast::ast::Program;
use oxc::semantic::Scoping;

// ============================================================================
// ModuleResult
// ============================================================================

/// Result of running a module.
#[derive(Debug)]
pub struct ModuleResult {
    /// Number of modifications made.
    pub modifications: usize,

    /// Updated scoping (if module changes symbols).
    pub scoping: Option<Scoping>,
}

impl ModuleResult {
    /// Create result with modifications.
    pub fn changed(modifications: usize) -> Self {
        Self {
            modifications,
            scoping: None,
        }
    }

    /// Create unchanged result.
    pub fn unchanged() -> Self {
        Self {
            modifications: 0,
            scoping: None,
        }
    }

    /// Set scoping.
    pub fn with_scoping(mut self, scoping: Scoping) -> Self {
        self.scoping = Some(scoping);
        self
    }
}

// ============================================================================
// Module Trait
// ============================================================================

/// A transformation module that can maintain state.
///
/// Unlike atomic passes, modules can:
/// - Maintain state across traversals
/// - Perform multi-phase transformations
/// - Rebuild scoping when needed
///
/// # Example
///
/// ```ignore
/// pub struct ConstantPropagator {
///     constants: FxHashMap<SymbolId, LiteralValue>,
/// }
///
/// impl Module for ConstantPropagator {
///     fn name(&self) -> &'static str { "constant_propagator" }
///
///     fn transform<'a>(
///         &mut self,
///         allocator: &'a Allocator,
///         program: &mut Program<'a>,
///         scoping: Scoping,
///     ) -> ModuleResult {
///         // Phase 1: Collect constants
///         self.collect(program, &scoping);
///
///         // Phase 2: Apply inlining
///         let mods = self.apply(allocator, program, &scoping);
///
///         ModuleResult::changed(mods)
///     }
/// }
/// ```
pub trait Module: Send + Sync {
    /// Unique identifier for logging.
    fn name(&self) -> &'static str;

    /// Human-readable description.
    fn description(&self) -> &'static str {
        ""
    }

    /// Does this module change symbol structure?
    ///
    /// If true, scoping will be rebuilt after this module runs.
    fn changes_symbols(&self) -> bool {
        false
    }

    /// Transform the program.
    ///
    /// This method has full control over traversal and can perform
    /// multi-phase transformations.
    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> ModuleResult;

    /// Reset state for new iteration.
    fn reset(&mut self) {}
}
