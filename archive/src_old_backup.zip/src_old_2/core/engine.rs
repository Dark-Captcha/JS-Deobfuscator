//! Deobfuscation engine with convergence loop.

use std::time::{Duration, Instant};

use oxc::allocator::Allocator;
use oxc::ast::ast::Program;
use oxc::semantic::SemanticBuilder;
use oxc_traverse::traverse_mut;

use super::error::EngineError;
use super::transformer::PureJsTransformer;

// ============================================================================
// EngineConfig
// ============================================================================

/// Engine configuration.
#[derive(Debug, Clone)]
pub struct EngineConfig {
    /// Maximum iterations before stopping.
    /// Prevents infinite loops.
    pub max_iterations: usize,
}

impl Default for EngineConfig {
    fn default() -> Self {
        Self {
            max_iterations: 100,
        }
    }
}

impl EngineConfig {
    /// Create config with max iterations.
    pub fn with_max_iterations(mut self, max: usize) -> Self {
        self.max_iterations = max;
        self
    }
}

// ============================================================================
// EngineResult
// ============================================================================

/// Result of running the engine.
#[derive(Debug)]
pub struct EngineResult {
    /// Number of iterations executed.
    pub iterations: usize,

    /// Total modifications across all iterations.
    pub total_modifications: usize,

    /// Modifications per iteration.
    pub modifications_per_iteration: Vec<usize>,

    /// Whether convergence was reached.
    pub converged: bool,

    /// Time elapsed.
    pub elapsed: Duration,
}

impl EngineResult {
    /// Check if successful (converged).
    pub fn is_success(&self) -> bool {
        self.converged
    }
}

// ============================================================================
// Engine
// ============================================================================

/// The deobfuscation engine.
///
/// Runs passes in a convergence loop until no modifications.
///
/// # Example
///
/// ```ignore
/// let engine = Engine::new();
///
/// let allocator = Allocator::default();
/// let mut program = parse(source, &allocator);
/// let result = engine.run(&allocator, &mut program)?;
///
/// if result.converged {
///     println!("Converged in {} iterations", result.iterations);
/// }
/// ```
#[derive(Default)]
pub struct Engine {
    config: EngineConfig,
}

impl Engine {
    /// Create engine with default configuration.
    pub fn new() -> Self {
        Self::default()
    }

    /// Set configuration.
    #[must_use]
    pub fn with_config(mut self, config: EngineConfig) -> Self {
        self.config = config;
        self
    }

    /// Run deobfuscation on program.
    #[tracing::instrument(
        skip(self, allocator, program),
        fields(max_iterations = self.config.max_iterations)
    )]
    pub fn run<'a>(
        &self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
    ) -> Result<EngineResult, EngineError> {
        let start = Instant::now();
        let mut total_modifications = 0;
        let mut modifications_per_iteration = Vec::new();
        let mut converged = false;

        tracing::info!(target: "deob::engine", "starting deobfuscation");

        for iteration in 0..self.config.max_iterations {
            let iter_span = tracing::info_span!(target: "deob::engine", "iteration", n = iteration);
            let _guard = iter_span.enter();

            // Build scoping once per iteration
            tracing::debug!(target: "deob::engine", "building scoping");
            let semantic = SemanticBuilder::new().build(program).semantic;
            let scoping = semantic.into_scoping();

            // Run all passes via static dispatch transformer
            let mut transformer = PureJsTransformer::new();
            traverse_mut(&mut transformer, allocator, program, scoping, ());

            let iter_mods = transformer.modifications();

            tracing::info!(
                target: "deob::engine",
                modifications = iter_mods,
                "iteration complete"
            );

            total_modifications += iter_mods;
            modifications_per_iteration.push(iter_mods);

            // Check convergence
            if iter_mods == 0 {
                tracing::info!(target: "deob::engine", iterations = iteration + 1, "converged");
                converged = true;
                break;
            }
        }

        if !converged {
            tracing::warn!(
                target: "deob::engine",
                max = self.config.max_iterations,
                "max iterations reached without convergence"
            );
        }

        let elapsed = start.elapsed();
        tracing::info!(
            target: "deob::engine",
            total_modifications,
            iterations = modifications_per_iteration.len(),
            elapsed_ms = elapsed.as_millis(),
            "deobfuscation complete"
        );

        Ok(EngineResult {
            iterations: modifications_per_iteration.len(),
            total_modifications,
            modifications_per_iteration,
            converged,
            elapsed,
        })
    }
}
