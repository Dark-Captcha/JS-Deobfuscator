//! Pure JavaScript transformer using static dispatch.
//!
//! This transformer replaces the dynamic dispatch `PassVisitor` with
//! statically dispatched pass groups for better performance.

use oxc::allocator::Vec as ArenaVec;
use oxc::ast::ast::{Expression, Statement};
use oxc_traverse::{Traverse, TraverseCtx};

use crate::passes::array::Array;
use crate::passes::boolean::Boolean;
use crate::passes::coercion::Coercion;
use crate::passes::compare::Compare;
use crate::passes::conditional::Conditional;
use crate::passes::control::Control;
use crate::passes::dead::Dead;
use crate::passes::encoding::Encoding;
use crate::passes::expression::ExpressionGroup;
use crate::passes::json::Json;
use crate::passes::math::Math;
use crate::passes::number::Number;
use crate::passes::numeric::Numeric;
use crate::passes::object::Object;
use crate::passes::parse::Parse;
use crate::passes::regexp::RegExp;
use crate::passes::string::StringGroup;
use crate::passes::typeof_::Typeof;
use crate::passes::uri::Uri;
use crate::passes::variable::Variable;

// ============================================================================
// PureJsTransformer
// ============================================================================

/// Static dispatch transformer for pure JavaScript simplification.
///
/// Groups all passes by category and runs them via direct method calls
/// instead of dynamic dispatch through trait objects.
///
/// # Example
///
/// ```ignore
/// use oxc_traverse::traverse_mut;
///
/// let mut transformer = PureJsTransformer::new();
/// traverse_mut(&mut transformer, allocator, program, scoping, ());
/// let modifications = transformer.modifications;
/// ```
#[derive(Default)]
pub struct PureJsTransformer {
    // Expression passes
    numeric: Numeric,
    string: StringGroup,
    array: Array,
    boolean: Boolean,
    coercion: Coercion,
    compare: Compare,
    conditional: Conditional,
    encoding: Encoding,
    expression: ExpressionGroup,
    json: Json,
    math: Math,
    number: Number,
    object: Object,
    parse: Parse,
    regexp: RegExp,
    typeof_: Typeof,
    uri: Uri,
    variable: Variable,

    // Statement passes
    control: Control,
    dead: Dead,

    /// Total modifications made during traversal.
    pub modifications: usize,
}

impl PureJsTransformer {
    /// Create a new transformer with all passes enabled.
    pub fn new() -> Self {
        Self::default()
    }

    /// Get the number of modifications made.
    #[inline]
    pub fn modifications(&self) -> usize {
        self.modifications
    }

    /// Reset modification count for a new traversal.
    #[inline]
    pub fn reset(&mut self) {
        self.modifications = 0;
    }
}

impl<'a> Traverse<'a, ()> for PureJsTransformer {
    /// Transform expressions (bottom-up).
    ///
    /// Called after all children have been visited.
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Run all expression-level passes
        self.modifications += self.numeric.exit_expression(expr, ctx);
        self.modifications += self.string.exit_expression(expr, ctx);
        self.modifications += self.array.exit_expression(expr, ctx);
        self.modifications += self.boolean.exit_expression(expr, ctx);
        self.modifications += self.coercion.exit_expression(expr, ctx);
        self.modifications += self.compare.exit_expression(expr, ctx);
        self.modifications += self.conditional.exit_expression(expr, ctx);
        self.modifications += self.encoding.exit_expression(expr, ctx);
        self.modifications += self.expression.exit_expression(expr, ctx);
        self.modifications += self.json.exit_expression(expr, ctx);
        self.modifications += self.math.exit_expression(expr, ctx);
        self.modifications += self.number.exit_expression(expr, ctx);
        self.modifications += self.object.exit_expression(expr, ctx);
        self.modifications += self.parse.exit_expression(expr, ctx);
        self.modifications += self.regexp.exit_expression(expr, ctx);
        self.modifications += self.typeof_.exit_expression(expr, ctx);
        self.modifications += self.uri.exit_expression(expr, ctx);
        self.modifications += self.variable.exit_expression(expr, ctx);
    }

    /// Transform statements (bottom-up).
    fn exit_statement(&mut self, stmt: &mut Statement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Run all statement-level passes
        self.modifications += self.control.exit_statement(stmt, ctx);
        self.modifications += self.dead.exit_statement(stmt, ctx);
    }

    /// Transform statement lists.
    ///
    /// Used for removing empty statements and unreachable code.
    fn exit_statements(
        &mut self,
        stmts: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        self.modifications += self.dead.exit_statements(stmts, ctx);
        self.modifications += self.control.exit_statements(stmts, ctx);
    }
}
