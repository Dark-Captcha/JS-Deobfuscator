//! Error types for the deobfuscation engine.

use thiserror::Error;

// ============================================================================
// EngineError
// ============================================================================

/// Errors that can occur during engine execution.
#[derive(Debug, Error)]
pub enum EngineError {
    /// Parsing failed.
    #[error("parse error: {message}")]
    ParseError { message: String },

    /// Scoping build failed.
    #[error("scoping error: {message}")]
    ScopingError { message: String },
}

impl EngineError {
    /// Create parse error.
    pub fn parse_error(message: impl Into<String>) -> Self {
        Self::ParseError {
            message: message.into(),
        }
    }

    /// Create scoping error.
    pub fn scoping_error(message: impl Into<String>) -> Self {
        Self::ScopingError {
            message: message.into(),
        }
    }
}
