//! Convert `function f(...) { ... }` calls into arrow IIFEs.
//!
//! This is **custom** and intentionally not fully semantics-preserving (arrow `this`/`arguments`
//! differences). It is meant for keyfetcher workflows where we want to "flatten" code by turning
//! helper functions into immediately-invoked expressions.
//!
//! Transformations:
//!   1. Immediate call: function f(a, b) { ... }; f(x, y); → ((a, b) => { ... })(x, y);
//!   2. Call in assignment: function f() { ... }; obj["key"] = f(); → obj["key"] = (() => { ... })();
//!   3. Call in sequence: function f() { ... }; (a = f(), b); → (a = (() => { ... })(), b);
//!
//! The original function declaration statement is removed after all calls are inlined.

use oxc::allocator::{Allocator, CloneIn};
use oxc::ast::ast::{Argument, Expression, FormalParameterKind, Program, Statement};
use oxc::semantic::{Scoping, SymbolId};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::{FxHashMap, FxHashSet};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};

/// Keyfetcher transformer: convert function+call into arrow IIFE.
pub struct FnToArrowIifeInliner;

impl Module for FnToArrowIifeInliner {
    fn name(&self) -> &'static str {
        "KeyFetcherFnToArrowIifeInliner"
    }

    fn changes_symbols(&self) -> bool {
        true // removes function declarations
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Two-pass approach:
        // Pass 1: Collect function declarations
        // Pass 2: Inline calls to those functions as arrow IIFEs
        let mut collector = FunctionCollector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());
        
        if collector.functions.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }
        
        let mut inliner = CallInliner {
            functions: collector.functions,
            inlined_functions: FxHashSet::default(),
            modifications: 0,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());
        
        Ok(TransformResult {
            modifications: inliner.modifications,
            scoping,
        })
    }
}

// ============================================================================
// Pass 1: Collect function declarations
// ============================================================================

#[derive(Default)]
struct FunctionCollector<'a> {
    functions: FxHashMap<SymbolId, FunctionInfo<'a>>,
}

struct FunctionInfo<'a> {
    params: oxc::allocator::Box<'a, oxc::ast::ast::FormalParameters<'a>>,
    body: oxc::allocator::Box<'a, oxc::ast::ast::FunctionBody<'a>>,
    async_flag: bool,
}

impl<'a> Traverse<'a, ()> for FunctionCollector<'a> {
    fn enter_statements(
        &mut self,
        stmts: &mut oxc::allocator::Vec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Collect function declarations from statements
        for stmt in stmts.iter() {
            if let Statement::FunctionDeclaration(func_decl) = stmt {
                let Some(func_id) = func_decl.id.as_ref() else { continue };
                let Some(func_sym) = func_id.symbol_id.get() else { continue };
                
                if func_decl.generator {
                    continue; // Arrow functions cannot be generators
                }
                
                let Some(body) = func_decl.body.as_ref() else { continue };
                
                // Clone function info for later use
                let params = func_decl.params.clone_in(ctx.ast.allocator);
                let body = body.clone_in(ctx.ast.allocator);
                
                self.functions.insert(func_sym, FunctionInfo {
                    params,
                    body,
                    async_flag: func_decl.r#async,
                });
            }
        }
    }
}

// ============================================================================
// Pass 2: Inline calls as arrow IIFEs
// ============================================================================

struct CallInliner<'a> {
    functions: FxHashMap<SymbolId, FunctionInfo<'a>>,
    inlined_functions: FxHashSet<SymbolId>, // Track which functions were actually inlined
    modifications: usize,
}

impl<'a> CallInliner<'a> {
    /// Recursively find and inline CallExpression in nested expressions (e.g., !!_st2())
    fn try_inline_call_in_expr(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) -> bool {
        match expr {
            Expression::CallExpression(call) => {
                if let Expression::Identifier(callee_ident) = &call.callee {
                    if let Some(call_ref) = callee_ident.reference_id.get() {
                        if let Some(call_sym) = ctx.scoping().get_reference(call_ref).symbol_id() {
                            if let Some(func_info) = self.functions.get(&call_sym) {
                                // Convert function to arrow IIFE
                                let mut params_box = (*func_info.params).clone_in(ctx.ast.allocator);
                                params_box.kind = FormalParameterKind::ArrowFormalParameters;
                                let body_box = (*func_info.body).clone_in(ctx.ast.allocator);
                                
                                let arrow = ctx.ast.expression_arrow_function(
                                    call.span,
                                    false,
                                    func_info.async_flag,
                                    None::<oxc::allocator::Box<'a, oxc::ast::ast::TSTypeParameterDeclaration<'a>>>,
                                    params_box,
                                    None::<oxc::allocator::Box<'a, oxc::ast::ast::TSTypeAnnotation<'a>>>,
                                    body_box,
                                );
                                let arrow_paren = ctx.ast.expression_parenthesized(call.span, arrow);
                                
                                let args: oxc::allocator::Vec<'a, Argument<'a>> = call.arguments.clone_in(ctx.ast.allocator);
                                let type_args = call.type_arguments.clone_in(ctx.ast.allocator);
                                
                                let new_call = ctx.ast.expression_call(
                                    call.span,
                                    arrow_paren,
                                    type_args,
                                    args,
                                    call.optional,
                                );
                                
                                *expr = new_call;
                                self.inlined_functions.insert(call_sym);
                                self.modifications += 1;
                                return true;
                            }
                        }
                    }
                }
            }
            Expression::UnaryExpression(unary) => {
                // Recursively check the argument
                if self.try_inline_call_in_expr(&mut unary.argument, ctx) {
                    return true;
                }
            }
            Expression::BinaryExpression(bin) => {
                if self.try_inline_call_in_expr(&mut bin.left, ctx) {
                    return true;
                }
                if self.try_inline_call_in_expr(&mut bin.right, ctx) {
                    return true;
                }
            }
            Expression::LogicalExpression(logic) => {
                if self.try_inline_call_in_expr(&mut logic.left, ctx) {
                    return true;
                }
                if self.try_inline_call_in_expr(&mut logic.right, ctx) {
                    return true;
                }
            }
            Expression::ConditionalExpression(cond) => {
                if self.try_inline_call_in_expr(&mut cond.test, ctx) {
                    return true;
                }
                if self.try_inline_call_in_expr(&mut cond.consequent, ctx) {
                    return true;
                }
                if self.try_inline_call_in_expr(&mut cond.alternate, ctx) {
                    return true;
                }
            }
            _ => {}
        }
        false
    }
}

impl<'a> Traverse<'a, ()> for CallInliner<'a> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Handle CallExpression directly
        if let Expression::CallExpression(call) = expr {
            if let Expression::Identifier(callee_ident) = &call.callee {
                if let Some(call_ref) = callee_ident.reference_id.get() {
                    if let Some(call_sym) = ctx.scoping().get_reference(call_ref).symbol_id() {
                        if let Some(func_info) = self.functions.get(&call_sym) {
                            // Convert function to arrow IIFE
                            let mut params_box = (*func_info.params).clone_in(ctx.ast.allocator);
                            params_box.kind = FormalParameterKind::ArrowFormalParameters;
                            let body_box = (*func_info.body).clone_in(ctx.ast.allocator);
                            
                            let arrow = ctx.ast.expression_arrow_function(
                                call.span,
                                false,
                                func_info.async_flag,
                                None::<oxc::allocator::Box<'a, oxc::ast::ast::TSTypeParameterDeclaration<'a>>>,
                                params_box,
                                None::<oxc::allocator::Box<'a, oxc::ast::ast::TSTypeAnnotation<'a>>>,
                                body_box,
                            );
                            let arrow_paren = ctx.ast.expression_parenthesized(call.span, arrow);
                            
                            let args: oxc::allocator::Vec<'a, Argument<'a>> = call.arguments.clone_in(ctx.ast.allocator);
                            let type_args = call.type_arguments.clone_in(ctx.ast.allocator);
                            
                            let new_call = ctx.ast.expression_call(
                                call.span,
                                arrow_paren,
                                type_args,
                                args,
                                call.optional,
                            );
                            
                            *expr = new_call;
                            self.inlined_functions.insert(call_sym);
                            self.modifications += 1;
                            return;
                        }
                    }
                }
            }
        }
        
        // Helper to recursively find and inline CallExpression in nested expressions
        self.try_inline_call_in_expr(expr, ctx);
    }
    
    fn exit_statements(
        &mut self,
        stmts: &mut oxc::allocator::Vec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Remove function declarations that we've inlined
        let mut new_stmts = ctx.ast.vec();
        for stmt in stmts.iter() {
            if let Statement::FunctionDeclaration(func_decl) = stmt {
                let Some(func_id) = func_decl.id.as_ref() else {
                    new_stmts.push(stmt.clone_in(ctx.ast.allocator));
                    continue;
                };
                let Some(func_sym) = func_id.symbol_id.get() else {
                    new_stmts.push(stmt.clone_in(ctx.ast.allocator));
                    continue;
                };
                
                // Only remove if we actually inlined this function (had at least one call replaced)
                if self.inlined_functions.contains(&func_sym) {
                    continue; // Skip this function declaration
                }
            }
            new_stmts.push(stmt.clone_in(ctx.ast.allocator));
        }
        *stmts = new_stmts;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    #[test]
    fn converts_function_decl_plus_call_to_arrow_iife() {
        let source = r#"
function a(x) { return x + 1; }
a(2);
"#;
        let allocator = Allocator::default();
        let ret = Parser::new(&allocator, source, SourceType::mjs()).parse();
        assert!(ret.errors.is_empty(), "Parse errors: {:?}", ret.errors);
        let mut program = ret.program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        let mut module = FnToArrowIifeInliner;
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        assert_eq!(result.modifications, 1);

        let code = Codegen::new().build(&program).code;
        assert!(
            code.contains("=>") && code.contains(")(2)") && !code.contains("function a"),
            "unexpected output: {}",
            code
        );
    }
    
    #[test]
    fn converts_function_call_in_assignment() {
        let source = r#"
function f() { return 42; }
var obj = {};
obj["key"] = f();
"#;
        let allocator = Allocator::default();
        let ret = Parser::new(&allocator, source, SourceType::mjs()).parse();
        assert!(ret.errors.is_empty(), "Parse errors: {:?}", ret.errors);
        let mut program = ret.program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        let mut module = FnToArrowIifeInliner;
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        assert!(result.modifications > 0);

        let code = Codegen::new().build(&program).code;
        assert!(
            code.contains("=>") && !code.contains("function f"),
            "unexpected output: {}",
            code
        );
    }
}
