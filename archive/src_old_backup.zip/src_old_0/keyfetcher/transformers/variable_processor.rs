//! Keyfetcher variable processor (custom).
//!
//! Focus: aggressively simplify common PerimeterX-style obfuscation patterns that hide values inside
//! comma-operator sequences and parenthesized assignments, e.g.:
//! - `(r = -221, v = -206, Kv(r, v))` → `Kv(-221, -206)`
//! - `(m = "x")` → `"x"` (or `m` + later inline)
//!
//! This is **not** a universal, semantics-perfect transform. It is meant for key extraction.

use oxc::allocator::{Allocator, CloneIn, TakeIn};
use oxc::ast::ast::{AssignmentTarget, Expression, ParenthesizedExpression, Program, VariableDeclarator};
use oxc::semantic::{Scoping, SymbolId};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::{FxHashMap, FxHashSet};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::eval::is_safe_expr;

/// Custom keyfetcher transformer: collect simple assignments and inline uses.
pub struct KeyfetcherVariableProcessor;

impl Module for KeyfetcherVariableProcessor {
    fn name(&self) -> &'static str {
        "KeyfetcherVariableProcessor"
    }

    fn changes_symbols(&self) -> bool {
        true // may initialize previously-uninitialized declarators
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Pass 1: collect + simplify (sequence / parenthesized assignments).
        let mut collector = Collector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        if collector.collected.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        // Pass 2: apply inlining and initialize `{}`-style collected objects.
        let mut applier = Applier {
            collected: collector.collected,
            modifications: 0,
        };
        let scoping = traverse_mut(&mut applier, allocator, program, scoping, ());

        Ok(TransformResult {
            modifications: collector.modifications + applier.modifications,
            scoping,
        })
    }
}

#[derive(Default)]
struct Collector<'a> {
    collected: FxHashMap<SymbolId, Expression<'a>>,
    uninitialized: FxHashSet<SymbolId>,
    modifications: usize,
}

impl<'a> Collector<'a> {
    fn rhs_is_collectable(rhs: &Expression<'a>) -> bool {
        matches!(
            rhs,
            Expression::Identifier(_)
                | Expression::StringLiteral(_)
                | Expression::NumericLiteral(_)
                | Expression::BooleanLiteral(_)
                | Expression::NullLiteral(_)
                | Expression::UnaryExpression(_)
                | Expression::ObjectExpression(_)
        ) || (matches!(rhs, Expression::CallExpression(_)) && is_safe_expr(rhs))
    }

    fn collect_assignment(
        &mut self,
        target: &oxc::allocator::Box<'a, oxc::ast::ast::IdentifierReference<'a>>,
        rhs: &Expression<'a>,
        ctx: &TraverseCtx<'a, ()>,
    ) -> bool {
        let Some(ref_id) = target.reference_id.get() else { return false };
        let Some(symbol_id) = ctx.scoping().get_reference(ref_id).symbol_id() else { return false };
        if !self.uninitialized.contains(&symbol_id) {
            return false;
        }
        if !Self::rhs_is_collectable(rhs) {
            return false;
        }
        self.collected
            .insert(symbol_id, rhs.clone_in(ctx.ast.allocator));
        true
    }
}

impl<'a> Traverse<'a, ()> for Collector<'a> {
    fn enter_variable_declarator(
        &mut self,
        node: &mut VariableDeclarator<'a>,
        _ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Track uninitialized variables: `var x;`
        if node.init.is_some() {
            return;
        }
        let Some(binding) = node.id.get_binding_identifier() else { return };
        let Some(symbol_id) = binding.symbol_id.get() else { return };
        self.uninitialized.insert(symbol_id);
    }

    fn enter_expression(&mut self, node: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Process sequence expressions: (r = -221, v = -206, Kv(r, v))
        let Expression::SequenceExpression(seq) = node else { return };

        let allocator = ctx.ast.allocator;
        let mut new_exprs = ctx.ast.vec();
        let mut removed_any = false;

        for expr in seq.expressions.take_in(allocator) {
            // Collect `x = RHS` for uninitialized vars and drop from the sequence.
            if let Expression::AssignmentExpression(assign) = &expr
                && assign.operator == oxc::ast::ast::AssignmentOperator::Assign
                && let AssignmentTarget::AssignmentTargetIdentifier(id) = &assign.left
                && self.collect_assignment(id, &assign.right, ctx)
            {
                removed_any = true;
                continue;
            }

            new_exprs.push(expr);
        }

        // If we removed assignments, apply the new sequence.
        if removed_any {
            seq.expressions = new_exprs;
            self.modifications += 1;

            // Unwrap `(x)` if only one expression remains.
            if seq.expressions.len() == 1 {
                let mut tmp = seq.expressions.take_in(allocator);
                if let Some(remaining) = tmp.pop() {
                    *node = remaining;
                } else {
                    // Empty sequence is invalid; keep as-is.
                    seq.expressions = tmp;
                }
            }
        } else {
            // Put back unchanged
            seq.expressions = new_exprs;
        }
    }

    fn enter_parenthesized_expression(
        &mut self,
        node: &mut ParenthesizedExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Handle assignments like (m = u) or (w = {})
        let Expression::AssignmentExpression(assign) = &node.expression else { return };
        if assign.operator != oxc::ast::ast::AssignmentOperator::Assign {
            return;
        }
        let AssignmentTarget::AssignmentTargetIdentifier(id) = &assign.left else { return };
        if !self.collect_assignment(id, &assign.right, ctx) {
            return;
        }

        // Replace `(m = rhs)` with just `m` (will be inlined later).
        node.expression = Expression::Identifier(id.clone_in(ctx.ast.allocator));
        self.modifications += 1;
    }
}

struct Applier<'a> {
    collected: FxHashMap<SymbolId, Expression<'a>>,
    modifications: usize,
}

impl<'a> Applier<'a> {
    fn resolve_chain(&self, mut expr: Expression<'a>, ctx: &TraverseCtx<'a, ()>) -> Expression<'a> {
        // Follow identifier → identifier chains to collapse `a = b; b = "x";`.
        let mut seen: FxHashSet<SymbolId> = FxHashSet::default();
        for _ in 0..32 {
            let Expression::Identifier(id) = &expr else { break };
            let Some(ref_id) = id.reference_id.get() else { break };
            let Some(sym) = ctx.scoping().get_reference(ref_id).symbol_id() else { break };
            if !seen.insert(sym) {
                break; // cycle
            }
            let Some(next) = self.collected.get(&sym) else { break };
            expr = next.clone_in(ctx.ast.allocator);
        }
        expr
    }

    fn should_inline(expr: &Expression<'a>) -> bool {
        // Do NOT inline object literals (avoid duplicating objects).
        if matches!(expr, Expression::ObjectExpression(_)) {
            return false;
        }
        matches!(
            expr,
            Expression::Identifier(_)
                | Expression::StringLiteral(_)
                | Expression::NumericLiteral(_)
                | Expression::BooleanLiteral(_)
                | Expression::NullLiteral(_)
                | Expression::UnaryExpression(_)
        ) || is_safe_expr(expr)
    }
}

impl<'a> Traverse<'a, ()> for Applier<'a> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let Expression::Identifier(id) = expr else { return };
        let Some(ref_id) = id.reference_id.get() else { return };
        let Some(sym) = ctx.scoping().get_reference(ref_id).symbol_id() else { return };
        let Some(mapped) = self.collected.get(&sym) else { return };

        let resolved = self.resolve_chain(mapped.clone_in(ctx.ast.allocator), ctx);
        if Self::should_inline(&resolved) {
            *expr = resolved;
            self.modifications += 1;
        }
    }

    fn enter_variable_declarator(
        &mut self,
        node: &mut VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Initialize `var w;` to `var w = {};` when we collected `(w = {})`.
        if node.init.is_some() {
            return;
        }
        let Some(binding) = node.id.get_binding_identifier() else { return };
        let Some(sym) = binding.symbol_id.get() else { return };
        let Some(mapped) = self.collected.get(&sym) else { return };

        if matches!(mapped, Expression::ObjectExpression(_)) {
            node.init = Some(mapped.clone_in(ctx.ast.allocator));
            self.modifications += 1;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    fn transform(source: &str) -> String {
        let allocator = Allocator::default();
        let ret = Parser::new(&allocator, source, SourceType::mjs()).parse();
        assert!(ret.errors.is_empty(), "Parse errors: {:?}", ret.errors);
        let mut program = ret.program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        let mut module = KeyfetcherVariableProcessor;
        let _ = module.transform(&allocator, &mut program, scoping).unwrap();
        Codegen::new().build(&program).code
    }

    #[test]
    fn sequence_assignments_get_removed_and_inlined() {
        let code = transform(
            r#"
var r; var v;
function Kv(a, b) { return a + b; }
console.log((r = -221, v = -206, Kv(r, v)));
"#,
        );
        assert!(
            !code.contains("r =") && !code.contains("v ="),
            "expected assignments removed, got: {}",
            code
        );
        assert!(
            code.contains("Kv(-221, -206)") || code.contains("Kv(-221,-206)"),
            "expected args inlined, got: {}",
            code
        );
    }

    #[test]
    fn paren_assignment_to_object_initializes_declarator() {
        let code = transform(
            r#"
var w;
console.log((w = {}));
"#,
        );
        assert!(
            code.contains("var w = {}") || code.contains("var w={}"),
            "expected var initialized, got: {}",
            code
        );
        assert!(code.contains("console.log(w)"), "expected log(w), got: {}", code);
    }
}


