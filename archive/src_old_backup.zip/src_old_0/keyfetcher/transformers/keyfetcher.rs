//! Keyfetcher "one-shot" transformer.
//!
//! This is a **custom** pipeline module that runs the keyfetcher transforms in a fixed order:
//! 1) Convert `function f(){...}; f(...);` into an arrow IIFE.
//!
//! NOTE: Additional keyfetcher-specific simplifications (like comma-operator assignment collection)
//! live in separate modules (e.g. `KeyfetcherVariableProcessor`) and are intentionally not part of
//! this default transformer anymore.

use oxc::allocator::Allocator;
use oxc::ast::ast::Program;
use oxc::semantic::Scoping;

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::utils::ast::build_scoping;

use super::FnToArrowIifeInliner;

/// Keyfetcher pipeline transformer (custom, not registered in universal pipeline).
pub struct KeyfetcherTransformer;

impl Module for KeyfetcherTransformer {
    fn name(&self) -> &'static str {
        "KeyfetcherTransformer"
    }

    fn changes_symbols(&self) -> bool {
        true
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // fn → arrow IIFE + inline adjacent call.
        // Run in a loop until convergence (no more changes)
        let mut total_mods = 0;
        let mut fn_to_iife = FnToArrowIifeInliner;
        
        loop {
            let current_scoping = build_scoping(program);
            let res = fn_to_iife.transform(allocator, program, current_scoping)?;
            if res.modifications == 0 {
                break;
            }
            total_mods += res.modifications;
        }

        Ok(TransformResult {
            modifications: total_mods,
            scoping: build_scoping(program),
        })
    }
}


