//! Keyfetcher (custom tooling).
//!
//! This folder is **NOT** part of the universal deobfuscation pipeline.
//! It contains project-specific transforms used to extract PerimeterX keys.

pub mod transformers;

pub use transformers::KeyfetcherTransformer;


