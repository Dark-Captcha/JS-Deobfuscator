//! CLI interface for the JavaScript deobfuscator.

use std::fs;
use std::path::PathBuf;

use clap::Parser;
use tracing_subscriber::EnvFilter;

use dark_captcha::Deobfuscator;

#[derive(Parser)]
#[command(name = "dark-captcha")]
#[command(about = "Universal JavaScript Deobfuscator")]
struct Cli {
    /// Input JavaScript file
    #[arg(short, long)]
    input: PathBuf,

    /// Output file (defaults to stdout)
    #[arg(short, long)]
    output: Option<PathBuf>,

    /// Maximum passes before stopping
    #[arg(short, long, default_value = "100")]
    max_passes: usize,

    /// Enable verbose logging
    #[arg(short, long)]
    verbose: bool,
}

fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();

    // Set up logging
    let filter = if cli.verbose {
        EnvFilter::new("debug")
    } else {
        EnvFilter::new("info")
    };
    tracing_subscriber::fmt().with_env_filter(filter).init();

    // Read input
    let source = fs::read_to_string(&cli.input)?;
    tracing::info!("Read {} bytes from {:?}", source.len(), cli.input);

    // Run deobfuscator
    let mut deobfuscator = Deobfuscator::new().with_max_passes(cli.max_passes);

    let result = deobfuscator.deobfuscate(&source)?;

    // Report statistics
    tracing::info!(
        "Completed in {} passes, {} modifications, {:.2}ms",
        result.passes,
        result.total_modifications,
        result.elapsed.as_secs_f64() * 1000.0
    );

    // Write output
    if let Some(output_path) = cli.output {
        fs::write(&output_path, &result.code)?;
        tracing::info!("Wrote {} bytes to {:?}", result.code.len(), output_path);
    } else {
        println!("{}", result.code);
    }

    Ok(())
}
