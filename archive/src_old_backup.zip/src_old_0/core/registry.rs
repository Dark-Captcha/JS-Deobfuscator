//! Module registry for managing and ordering transformation modules.

use crate::modules::{
    BraceWrapper, ForVarHoister, IdentifierRenamer, MemberSimplifier, StatementSplitter,
    StringArrayPostCleaner,
};

use super::module::Module;

/// Registry for managing and ordering modules.
pub struct ModuleRegistry {
    modules: Vec<Box<dyn Module>>,
}

impl ModuleRegistry {
    /// Create an empty registry.
    pub fn new() -> Self {
        Self {
            modules: Vec::new(),
        }
    }

    /// Register a module.
    pub fn register(&mut self, module: impl Module + 'static) {
        self.modules.push(Box::new(module));
    }

    /// Create a registry with formatters only (run once before/after deob loop).
    /// These modules normalize the code structure to make other transformations easier.
    pub fn formatters() -> Self {
        // use crate::modules::*;

        let mut registry = Self::new();

        registry.register(IdentifierRenamer);
        registry.register(BraceWrapper);
        registry.register(ForVarHoister);
        registry.register(StatementSplitter);
        // Final polish: convert obj["prop"] → obj.prop where possible.
        registry.register(MemberSimplifier);

        registry
    }

    /// Formatters + final cleanups (run once AFTER the deob loop).
    ///
    /// This is used to do safe "final output polish" that would be unsafe during the convergence loop.
    pub fn post_formatters() -> Self {
        let mut registry = Self::new();

        registry.register(IdentifierRenamer);
        registry.register(BraceWrapper);
        registry.register(ForVarHoister);
        registry.register(StatementSplitter);

        // Remove leftover string-array artifacts (shufflers/arrays/accessors) after convergence.
        registry.register(StringArrayPostCleaner);

        // Final polish: convert obj["prop"] → obj.prop where possible.
        registry.register(MemberSimplifier);

        registry
    }

    /// Create a registry with deobfuscation modules (run in convergence loop).
    pub fn deobfuscators() -> Self {
        use crate::modules::*;

        let mut registry = Self::new();

        // String array decoder should run early to resolve obfuscated strings
        registry.register(StringArrayDecoder);

        // Core deobfuscation modules:
        registry.register(ConstantPropagator);
        registry.register(AliasInliner);
        registry.register(MemberSimplifier);
        registry.register(ObjectFlattener);
        registry.register(ProxyInliner);
        registry.register(IifeOptimizer);
        // Eval-based inlining of local decoder function calls (XOR/Base64/ROT/custom)
        registry.register(EvalCallInliner::new());
        registry.register(SequenceSimplifier);
        registry.register(DeadCodeEliminator);
        registry.register(StaticEvaluator::new());
        registry.register(ControlFlowDeflattener::new());

        registry
    }

    /// Iterate over registered modules.
    pub fn iter(&self) -> impl Iterator<Item = &dyn Module> {
        self.modules.iter().map(|m| m.as_ref())
    }

    /// Iterate over registered modules mutably.
    pub fn iter_mut(&mut self) -> impl Iterator<Item = &mut Box<dyn Module>> {
        self.modules.iter_mut()
    }
}

impl Default for ModuleRegistry {
    fn default() -> Self {
        Self::new()
    }
}
