//! Module trait definition for transformation modules.

use oxc::allocator::Allocator;
use oxc::ast::ast::Program;
use oxc::semantic::Scoping;

use super::error::Result;

/// Result of a module transformation.
pub struct TransformResult {
    /// Number of AST nodes modified.
    pub modifications: usize,
    /// Updated scoping after transformation.
    pub scoping: Scoping,
}

/// Core trait for all deobfuscation modules.
///
/// Each module performs a specific transformation on the AST and reports
/// how many modifications were made. The engine uses this count to determine
/// when convergence has been reached.
pub trait Module: Send + Sync {
    /// Human-readable name for logging and CLI.
    fn name(&self) -> &'static str;

    /// Whether this module changes the symbol table (requires scoping rebuild).
    ///
    /// Return `true` if the module adds/removes variable or function declarations.
    fn changes_symbols(&self) -> bool {
        false
    }

    /// Execute transformation on the AST.
    ///
    /// Takes ownership of scoping and returns updated scoping.
    /// Returns the number of modifications made. The engine will continue
    /// running passes until all modules return zero modifications.
    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult>;
}
