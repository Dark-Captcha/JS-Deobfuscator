//! Main deobfuscation engine with convergence loop.

use std::time::{Duration, Instant};

use oxc::allocator::Allocator;
use oxc::parser::Parser;
use oxc::span::SourceType;

use super::error::{DeobfuscateError, Result};
use super::registry::ModuleRegistry;
use crate::utils::ast::{build_scoping, generate_code};

/// Result of deobfuscation.
pub struct DeobfuscateResult {
    /// The deobfuscated code.
    pub code: String,
    /// Number of passes executed.
    pub passes: usize,
    /// Total modifications across all passes.
    pub total_modifications: usize,
    /// Time elapsed during deobfuscation.
    pub elapsed: Duration,
}

/// Main deobfuscation engine.
pub struct Deobfuscator {
    max_passes: usize,
}

impl Deobfuscator {
    /// Create a new deobfuscator.
    pub fn new() -> Self {
        Self { max_passes: 100 }
    }

    /// Set the maximum number of passes before stopping.
    pub fn with_max_passes(mut self, max: usize) -> Self {
        self.max_passes = max;
        self
    }

    /// Run deobfuscation: formatters (once) → deob loop (converge) → formatters (once).
    pub fn deobfuscate(&mut self, source: &str) -> Result<DeobfuscateResult> {
        let start = Instant::now();
        let mut total_modifications = 0;
        let mut current_source = source.to_string();

        // STEP 1: Run formatters ONCE before deob loop
        tracing::info!("Running formatters (pre-deob)...");
        let fmt_mods = Self::run_pass(&mut ModuleRegistry::formatters(), &mut current_source)?;
        total_modifications += fmt_mods;
        tracing::info!("Formatters (pre-deob): {} modifications", fmt_mods);

        // STEP 2: Run deobfuscation loop until convergence
        tracing::info!("Starting deobfuscation loop...");
        let mut deobfuscators = ModuleRegistry::deobfuscators();
        let mut passes = 0;

        loop {
            let pass_mods = Self::run_pass(&mut deobfuscators, &mut current_source)?;
            passes += 1;
            total_modifications += pass_mods;

            if pass_mods == 0 {
                tracing::info!("Deobfuscation converged after {} passes", passes);
                break;
            }

            if passes >= self.max_passes {
                tracing::warn!(
                    "Max passes ({}) reached without convergence",
                    self.max_passes
                );
                break;
            }
        }

        // STEP 3: Run formatters ONCE after deob loop (cleanup)
        tracing::info!("Running formatters (post-deob)...");
        let post_fmt_mods =
            Self::run_pass(&mut ModuleRegistry::post_formatters(), &mut current_source)?;
        total_modifications += post_fmt_mods;
        tracing::info!("Formatters (post-deob): {} modifications", post_fmt_mods);

        Ok(DeobfuscateResult {
            code: current_source,
            passes,
            total_modifications,
            elapsed: start.elapsed(),
        })
    }

    /// Run a single pass with the given registry.
    fn run_pass(registry: &mut ModuleRegistry, source: &mut String) -> Result<usize> {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();

        // Parse
        let parser_ret = Parser::new(&allocator, source, source_type).parse();
        if !parser_ret.errors.is_empty() {
            return Err(DeobfuscateError::ParseError(
                parser_ret
                    .errors
                    .iter()
                    .map(|e| e.to_string())
                    .collect::<Vec<_>>()
                    .join("; "),
            ));
        }

        let mut program = parser_ret.program;

        // Run all modules
        let mut modifications = 0;

        for module in registry.iter_mut() {
            // Rebuild scoping before each module for fresh symbol info
            let scoping = build_scoping(&program);
            let result = module.transform(&allocator, &mut program, scoping)?;
            tracing::info!("{}: {} modifications", module.name(), result.modifications);
            modifications += result.modifications;
        }

        // Generate code
        *source = generate_code(&program);

        Ok(modifications)
    }
}

impl Default for Deobfuscator {
    fn default() -> Self {
        Self::new()
    }
}

/// Helper function to run a single module (for testing).
pub fn run_single_module(registry: ModuleRegistry, source: &str) -> Result<DeobfuscateResult> {
    let start = Instant::now();
    let mut current_source = source.to_string();

    let mut registry = registry;
    let modifications = Deobfuscator::run_pass(&mut registry, &mut current_source)?;

    Ok(DeobfuscateResult {
        code: current_source,
        passes: 1,
        total_modifications: modifications,
        elapsed: start.elapsed(),
    })
}
