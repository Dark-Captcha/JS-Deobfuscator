//! Core engine and orchestration components.

pub mod engine;
pub mod error;
pub mod module;
pub mod registry;
