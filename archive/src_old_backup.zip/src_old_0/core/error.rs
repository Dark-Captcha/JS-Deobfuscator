//! Error types for the deobfuscator.

use thiserror::Error;

/// Errors that can occur during deobfuscation.
#[derive(Error, Debug)]
pub enum DeobfuscateError {
    #[error("Parse error: {0}")]
    ParseError(String),

    #[error("Module '{module}' failed: {message}")]
    ModuleError { module: String, message: String },

    #[error("Max passes ({0}) exceeded without convergence")]
    MaxPassesExceeded(usize),

    #[error("IO error: {0}")]
    IoError(#[from] std::io::Error),
}

pub type Result<T> = std::result::Result<T, DeobfuscateError>;
