//! JavaScript evaluation module using deno_core (V8 runtime).
//!
//! Provides safe compile-time evaluation of JavaScript expressions
//! for deobfuscation purposes.

mod convert;
mod runtime;
mod safety;
mod web_stub;

pub use convert::{expr_to_code, value_to_expr};
pub use runtime::{EvalError, JsEvaluator};
pub use safety::is_safe_expr;
