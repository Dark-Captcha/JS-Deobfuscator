//! AST conversion utilities.
//!
//! Convert between AST expressions and JavaScript code strings,
//! and between JSON values and AST expressions.

use oxc::allocator::Allocator;
use oxc::ast::ast::{Expression, NumberBase};
use oxc::codegen::Codegen;
use oxc::span::SPAN;

/// Convert AST Expression to JavaScript code string.
pub fn expr_to_code(expr: &Expression) -> String {
    let mut codegen = Codegen::new();
    codegen.print_expression(expr);
    codegen.into_source_text()
}

/// Convert JSON Value to AST Expression.
/// Returns None for unsupported types (undefined, functions, objects).
pub fn value_to_expr<'a>(
    value: serde_json::Value,
    allocator: &'a Allocator,
) -> Option<Expression<'a>> {
    let ast = oxc::ast::AstBuilder::new(allocator);

    match value {
        serde_json::Value::String(s) => {
            let s = allocator.alloc_str(&s);
            Some(ast.expression_string_literal(SPAN, s, None))
        }

        serde_json::Value::Number(n) => {
            if let Some(i) = n.as_i64() {
                Some(ast.expression_numeric_literal(SPAN, i as f64, None, NumberBase::Decimal))
            } else {
                n.as_f64()
                    .map(|f| ast.expression_numeric_literal(SPAN, f, None, NumberBase::Decimal))
            }
        }

        serde_json::Value::Bool(b) => Some(ast.expression_boolean_literal(SPAN, b)),

        serde_json::Value::Null => Some(ast.expression_null_literal(SPAN)),

        serde_json::Value::Array(arr) => {
            let mut elements = ast.vec();
            for item in arr.into_iter() {
                if let Some(expr) = value_to_expr(item, allocator) {
                    elements.push(oxc::ast::ast::ArrayExpressionElement::from(expr));
                } else {
                    return None; // Unsupported element type
                }
            }
            Some(ast.expression_array(SPAN, elements))
        }

        // Objects are not supported (too complex for deobfuscation)
        serde_json::Value::Object(_) => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::parser::Parser;
    use oxc::span::SourceType;

    fn parse_and_codegen(code: &str) -> String {
        let allocator = Allocator::default();
        let source_type = SourceType::cjs();
        let ret = Parser::new(&allocator, code, source_type).parse();
        // Handle directives (string literals at start)
        if let Some(directive) = ret.program.directives.first() {
            let ast = oxc::ast::AstBuilder::new(&allocator);
            let s = allocator.alloc_str(&directive.expression.value);
            let expr = ast.expression_string_literal(SPAN, s, None);
            return expr_to_code(&expr);
        }
        if let Some(stmt) = ret.program.body.first() {
            if let oxc::ast::ast::Statement::ExpressionStatement(expr_stmt) = stmt {
                return expr_to_code(&expr_stmt.expression);
            }
        }
        String::new()
    }

    #[test]
    fn test_expr_to_code_string() {
        assert_eq!(parse_and_codegen(r#""hello""#), r#""hello""#);
    }

    #[test]
    fn test_expr_to_code_number() {
        assert_eq!(parse_and_codegen("42"), "42");
        assert_eq!(parse_and_codegen("3.14"), "3.14");
    }

    #[test]
    fn test_expr_to_code_call() {
        assert_eq!(
            parse_and_codegen(r#"atob("SGVsbG8=")"#),
            r#"atob("SGVsbG8=")"#
        );
    }

    #[test]
    fn test_value_to_expr_string() {
        let allocator = Allocator::default();
        let value = serde_json::json!("hello");
        let expr = value_to_expr(value, &allocator).unwrap();
        assert_eq!(expr_to_code(&expr), r#""hello""#);
    }

    #[test]
    fn test_value_to_expr_number() {
        let allocator = Allocator::default();
        let value = serde_json::json!(42);
        let expr = value_to_expr(value, &allocator).unwrap();
        assert_eq!(expr_to_code(&expr), "42");
    }

    #[test]
    fn test_value_to_expr_float() {
        let allocator = Allocator::default();
        let value = serde_json::json!(3.14);
        let expr = value_to_expr(value, &allocator).unwrap();
        assert_eq!(expr_to_code(&expr), "3.14");
    }

    #[test]
    fn test_value_to_expr_boolean() {
        let allocator = Allocator::default();
        let value = serde_json::json!(true);
        let expr = value_to_expr(value, &allocator).unwrap();
        assert_eq!(expr_to_code(&expr), "true");
    }

    #[test]
    fn test_value_to_expr_null() {
        let allocator = Allocator::default();
        let value = serde_json::Value::Null;
        let expr = value_to_expr(value, &allocator).unwrap();
        assert_eq!(expr_to_code(&expr), "null");
    }

    #[test]
    fn test_value_to_expr_array() {
        let allocator = Allocator::default();
        let value = serde_json::json!([1, 2, 3]);
        let expr = value_to_expr(value, &allocator).unwrap();
        // Codegen may add formatting, just check it contains the values
        let code = expr_to_code(&expr);
        assert!(code.contains("1"));
        assert!(code.contains("2"));
        assert!(code.contains("3"));
    }

    #[test]
    fn test_value_to_expr_object_returns_none() {
        let allocator = Allocator::default();
        let value = serde_json::json!({"key": "value"});
        assert!(value_to_expr(value, &allocator).is_none());
    }
}
