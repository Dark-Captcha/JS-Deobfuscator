//! Minimal web stub extension providing atob/btoa and other browser APIs.
//!
//! This is a lightweight alternative to deno_web that only provides
//! the APIs needed for deobfuscation.

use base64::prelude::*;
use deno_core::{Extension, extension, op2};
use deno_error::JsErrorBox;

/// Base64 decode (atob)
#[op2]
#[string]
fn op_base64_atob(#[string] data: String) -> Result<String, JsErrorBox> {
    // Browser `atob` accepts unpadded base64 (length % 4 == 2/3) and returns a binary string
    // (Latin-1), not UTF-8. We emulate that here.
    let mut s = data;
    // Remove ASCII whitespace (best-effort compatibility).
    s.retain(|c| !c.is_ascii_whitespace());
    match s.len() % 4 {
        0 => {}
        1 => {
            return Err(JsErrorBox::type_error(
                "Invalid base64: Invalid input length",
            ));
        }
        2 => s.push_str("=="),
        3 => s.push('='),
        _ => unreachable!(),
    }

    let decoded = BASE64_STANDARD
        .decode(&s)
        .map_err(|e| JsErrorBox::type_error(format!("Invalid base64: {}", e)))?;
    // Convert bytes to a binary string (0..=255 codepoints).
    Ok(decoded.into_iter().map(|b| b as char).collect())
}

/// Base64 encode (btoa)
#[op2]
#[string]
fn op_base64_btoa(#[string] data: String) -> Result<String, JsErrorBox> {
    // btoa only accepts Latin1 characters (0-255)
    for c in data.chars() {
        if c as u32 > 255 {
            return Err(JsErrorBox::type_error(
                "The string to be encoded contains characters outside of the Latin1 range.",
            ));
        }
    }
    let bytes: Vec<u8> = data.chars().map(|c| c as u8).collect();
    Ok(BASE64_STANDARD.encode(bytes))
}

extension!(
    web_stub,
    ops = [op_base64_atob, op_base64_btoa],
    esm_entry_point = "ext:web_stub/init.js",
    esm = [dir "src/eval/web_stub", "init.js"],
);

pub fn init() -> Extension {
    web_stub::init()
}
