// Web stub initialization - provides atob/btoa to global scope
import { op_base64_atob, op_base64_btoa } from "ext:core/ops";

// Minimal browser-ish globals many obfuscators expect.
// Keep these extremely small/no-op: we want decoding to work, not a real DOM/network.
if (typeof globalThis.window === "undefined") globalThis.window = globalThis;
if (typeof globalThis.self === "undefined") globalThis.self = globalThis;
if (typeof globalThis.global === "undefined") globalThis.global = globalThis;
if (typeof globalThis.console === "undefined") {
    globalThis.console = {
        log() {},
        dir() {},
        info() {},
        warn() {},
        error() {},
        debug() {},
        trace() {},
        table() {},
    };
}

globalThis.atob = function atob(data) {
    if (arguments.length === 0) {
        throw new TypeError("Failed to execute 'atob': 1 argument required, but only 0 present.");
    }
    return op_base64_atob(String(data));
};

globalThis.btoa = function btoa(data) {
    if (arguments.length === 0) {
        throw new TypeError("Failed to execute 'btoa': 1 argument required, but only 0 present.");
    }
    return op_base64_btoa(String(data));
};
