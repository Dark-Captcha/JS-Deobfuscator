//! JsRuntime wrapper for JavaScript evaluation.
//!
//! Uses deno_core (V8) with a custom web_stub extension for browser APIs.

use crate::eval::web_stub;
use deno_core::{JsRuntime, RuntimeOptions, serde_v8, v8};
use thiserror::Error;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{mpsc, Arc};
use std::time::Duration;

/// Errors that can occur during JavaScript evaluation.
#[derive(Debug, Error)]
pub enum EvalError {
    #[error("JavaScript syntax error: {0}")]
    SyntaxError(String),

    #[error("Runtime error: {0}")]
    RuntimeError(String),

    #[error("Evaluation timed out after {0}ms")]
    Timeout(u64),

    #[error("Result serialization failed: {0}")]
    SerializationError(String),
}

/// Wrapper around deno_core JsRuntime for safe JavaScript evaluation.
pub struct JsEvaluator {
    runtime: JsRuntime,
    #[allow(dead_code)]
    timeout_ms: u64,
}

impl JsEvaluator {
    /// Create a new evaluator with default timeout (1000ms).
    pub fn new() -> Self {
        Self::with_timeout(1000)
    }

    /// Create with custom timeout.
    pub fn with_timeout(timeout_ms: u64) -> Self {
        let runtime = JsRuntime::new(RuntimeOptions {
            extensions: vec![web_stub::init()],
            ..Default::default()
        });

        Self {
            runtime,
            timeout_ms,
        }
    }

    /// Execute JavaScript code for side effects (definitions, IIFEs, etc.).
    ///
    /// Unlike `eval`, this does **not** attempt to serialize the return value.
    pub fn execute(&mut self, code: &str) -> Result<(), EvalError> {
        self.execute_script_with_timeout(code)?;
        Ok(())
    }

    /// Evaluate JavaScript code and return result as JSON Value.
    pub fn eval(&mut self, code: &str) -> Result<serde_json::Value, EvalError> {
        let global = self.execute_script_with_timeout(code)?;

        deno_core::scope!(scope, &mut self.runtime);
        let local = v8::Local::new(scope, global);

        // serde_v8 can panic on some V8 value kinds (observed in the wild). Never let that abort
        // the whole deobfuscation process.
        let res = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            serde_v8::from_v8(scope, local)
        }));
        match res {
            Ok(Ok(v)) => Ok(v),
            Ok(Err(e)) => Err(EvalError::SerializationError(e.to_string())),
            Err(_) => Err(EvalError::SerializationError(
                "serde_v8 panicked while serializing result".to_string(),
            )),
        }
    }

    /// Evaluate and return as String if result is a string.
    pub fn eval_to_string(&mut self, code: &str) -> Option<String> {
        match self.eval(code) {
            Ok(serde_json::Value::String(s)) => Some(s),
            _ => None,
        }
    }

    /// Evaluate and return as f64 if result is a number.
    pub fn eval_to_number(&mut self, code: &str) -> Option<f64> {
        match self.eval(code) {
            Ok(serde_json::Value::Number(n)) => n.as_f64(),
            _ => None,
        }
    }

    fn execute_script_with_timeout(
        &mut self,
        code: &str,
    ) -> Result<v8::Global<v8::Value>, EvalError> {
        // Fast path: no timeout requested.
        if self.timeout_ms == 0 {
            return self
                .runtime
                .execute_script("<eval>", code.to_string())
                .map_err(|e| classify_error(e.to_string()));
        }

        // Spawn a watchdog thread that terminates V8 execution after the timeout.
        // Use a channel so the watchdog can be cancelled immediately when eval completes.
        let (tx_done, rx_done) = mpsc::channel::<()>();
        let timed_out = Arc::new(AtomicBool::new(false));
        let timed_out_watchdog = timed_out.clone();

        // Thread-safe handle to the isolate (usable from another thread).
        let isolate_handle = self.runtime.v8_isolate().thread_safe_handle();
        let timeout_ms = self.timeout_ms;

        let watchdog = std::thread::spawn(move || {
            if rx_done.recv_timeout(Duration::from_millis(timeout_ms)).is_err() {
                timed_out_watchdog.store(true, Ordering::SeqCst);
                isolate_handle.terminate_execution();
            }
        });

        // Run the script on the current thread.
        let result = self.runtime.execute_script("<eval>", code.to_string());

        // Tell watchdog we're done (if it already fired, this is fine).
        let _ = tx_done.send(());
        let _ = watchdog.join();

        // If we timed out, clear the termination flag so the runtime is usable again.
        if timed_out.load(Ordering::SeqCst) {
            self.runtime.v8_isolate().cancel_terminate_execution();
            return Err(EvalError::Timeout(timeout_ms));
        }

        result.map_err(|e| classify_error(e.to_string()))
    }
}

fn classify_error(msg: String) -> EvalError {
    // Best-effort classification (deno_core wraps V8 errors into AnyError).
    if msg.contains("SyntaxError") {
        EvalError::SyntaxError(msg)
    } else {
        EvalError::RuntimeError(msg)
    }
}

impl Default for JsEvaluator {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_eval_string() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval(r#""hello""#).unwrap();
        assert_eq!(result, serde_json::Value::String("hello".to_string()));
    }

    #[test]
    fn test_eval_number() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval("42").unwrap();
        assert_eq!(result, serde_json::json!(42));
    }

    #[test]
    fn test_eval_boolean() {
        let mut eval = JsEvaluator::new();
        assert_eq!(eval.eval("true").unwrap(), serde_json::json!(true));
        assert_eq!(eval.eval("false").unwrap(), serde_json::json!(false));
    }

    #[test]
    fn test_eval_null() {
        let mut eval = JsEvaluator::new();
        assert_eq!(eval.eval("null").unwrap(), serde_json::Value::Null);
    }

    #[test]
    fn test_eval_array() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval("[1, 2, 3]").unwrap();
        assert_eq!(result, serde_json::json!([1, 2, 3]));
    }

    #[test]
    fn test_eval_atob() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#"atob("SGVsbG8=")"#);
        assert_eq!(result, Some("Hello".to_string()));
    }

    #[test]
    fn test_eval_atob_world() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#"atob("SGVsbG8gV29ybGQ=")"#);
        assert_eq!(result, Some("Hello World".to_string()));
    }

    #[test]
    fn test_eval_btoa() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#"btoa("Hello")"#);
        assert_eq!(result, Some("SGVsbG8=".to_string()));
    }

    #[test]
    fn test_eval_string_method() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#""hello".toUpperCase()"#);
        assert_eq!(result, Some("HELLO".to_string()));
    }

    #[test]
    fn test_eval_parse_int() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_number(r#"parseInt("ff", 16)"#);
        assert_eq!(result, Some(255.0));
    }

    #[test]
    fn test_eval_parse_float() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_number(r#"parseFloat("3.14")"#);
        assert_eq!(result, Some(3.14));
    }

    #[test]
    fn test_eval_invalid_syntax() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval("function(");
        assert!(result.is_err());
    }

    #[test]
    fn test_eval_to_string_returns_none_for_number() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string("42");
        assert_eq!(result, None);
    }

    #[test]
    fn test_eval_to_number_returns_none_for_string() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_number(r#""hello""#);
        assert_eq!(result, None);
    }

    #[test]
    fn test_eval_string_from_char_code() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#"String.fromCharCode(72, 101, 108, 108, 111)"#);
        assert_eq!(result, Some("Hello".to_string()));
    }

    #[test]
    fn test_eval_array_reverse_join() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#""olleh".split("").reverse().join("")"#);
        assert_eq!(result, Some("hello".to_string()));
    }

    #[test]
    fn test_eval_decode_uri_component() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#"decodeURIComponent("%48%65%6C%6C%6F")"#);
        assert_eq!(result, Some("Hello".to_string()));
    }

    #[test]
    fn test_eval_encode_uri_component() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#"encodeURIComponent("Hello World")"#);
        assert_eq!(result, Some("Hello%20World".to_string()));
    }

    #[test]
    fn test_eval_unescape() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#"unescape("%48%65%6C%6C%6F")"#);
        assert_eq!(result, Some("Hello".to_string()));
    }

    #[test]
    fn test_eval_math_floor() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_number("Math.floor(3.7)");
        assert_eq!(result, Some(3.0));
    }

    #[test]
    fn test_eval_math_abs() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_number("Math.abs(-5)");
        assert_eq!(result, Some(5.0));
    }

    #[test]
    fn test_eval_number_to_string() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string("(255).toString(16)");
        assert_eq!(result, Some("ff".to_string()));
    }

    #[test]
    fn test_eval_chained_string_methods() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#""  hello  ".trim().toUpperCase()"#);
        assert_eq!(result, Some("HELLO".to_string()));
    }

    #[test]
    fn test_eval_array_join() {
        let mut eval = JsEvaluator::new();
        let result = eval.eval_to_string(r#"[1, 2, 3].join("-")"#);
        assert_eq!(result, Some("1-2-3".to_string()));
    }

    #[test]
    fn test_eval_complex_obfuscation() {
        let mut eval = JsEvaluator::new();
        // Simulating a common obfuscation pattern
        let result = eval.eval_to_string(
            r#"atob("SGVsbG8=").split("").map(function(c) { return c; }).join("")"#,
        );
        assert_eq!(result, Some("Hello".to_string()));
    }

    #[test]
    fn test_execute_defines_global() {
        let mut eval = JsEvaluator::new();
        eval.execute(r#"function foo(){ return "bar"; }"#).unwrap();
        assert_eq!(eval.eval_to_string("foo()"), Some("bar".to_string()));
    }

    #[test]
    fn test_execute_returns_ok_for_undefined() {
        let mut eval = JsEvaluator::new();
        // This produces `undefined` as the last value; execute() should still succeed.
        eval.execute("var x = 1;").unwrap();
    }
}
