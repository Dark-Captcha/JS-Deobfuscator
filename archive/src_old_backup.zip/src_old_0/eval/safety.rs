//! Safety checker for JavaScript expressions.
//!
//! Determines if an expression is safe to evaluate (no side effects,
//! deterministic, constant arguments).

use oxc::ast::ast::{
    Argument, ArrayExpressionElement, CallExpression, Expression, StaticMemberExpression,
};

/// Known safe global functions
const SAFE_GLOBALS: &[&str] = &[
    "atob",
    "btoa",
    "parseInt",
    "parseFloat",
    "decodeURIComponent",
    "encodeURIComponent",
    "decodeURI",
    "encodeURI",
    "unescape",
    "escape",
    "isNaN",
    "isFinite",
];

/// Known safe String methods
const SAFE_STRING_METHODS: &[&str] = &[
    "charAt",
    "charCodeAt",
    "codePointAt",
    "concat",
    "endsWith",
    "includes",
    "indexOf",
    "lastIndexOf",
    "localeCompare",
    "match",
    "normalize",
    "padEnd",
    "padStart",
    "repeat",
    "replace",
    "replaceAll",
    "search",
    "slice",
    "split",
    "startsWith",
    "substring",
    "toLowerCase",
    "toUpperCase",
    "trim",
    "trimEnd",
    "trimStart",
];

/// Known safe Array methods
const SAFE_ARRAY_METHODS: &[&str] = &[
    "concat",
    "every",
    "filter",
    "find",
    "findIndex",
    "flat",
    "flatMap",
    "includes",
    "indexOf",
    "join",
    "lastIndexOf",
    "map",
    "reduce",
    "reduceRight",
    "reverse",
    "slice",
    "some",
    "sort",
    "toString",
];

/// Known safe Math methods
const SAFE_MATH_METHODS: &[&str] = &[
    "abs", "acos", "acosh", "asin", "asinh", "atan", "atan2", "atanh", "cbrt", "ceil", "clz32",
    "cos", "cosh", "exp", "expm1", "floor", "fround", "hypot", "imul", "log", "log10", "log1p",
    "log2", "max", "min", "pow", "round", "sign", "sin", "sinh", "sqrt", "tan", "tanh", "trunc",
];

/// Known safe Number methods
const SAFE_NUMBER_METHODS: &[&str] = &["toFixed", "toPrecision", "toString", "toExponential"];

/// Known safe String static methods
const SAFE_STRING_STATIC_METHODS: &[&str] = &["fromCharCode", "fromCodePoint"];

/// Known unsafe patterns (never evaluate)
const UNSAFE_GLOBALS: &[&str] = &[
    "console",
    "document",
    "window",
    "global",
    "globalThis",
    "process",
    "require",
    "import",
    "eval",
    "Function",
    "setTimeout",
    "setInterval",
    "clearTimeout",
    "clearInterval",
    "fetch",
    "XMLHttpRequest",
    "localStorage",
    "sessionStorage",
    "indexedDB",
    "crypto",
    "Deno",
    "Bun",
];

/// Known non-deterministic methods (never evaluate)
const NON_DETERMINISTIC: &[&str] = &["now", "random"];

/// Check if an expression is safe to evaluate.
/// Safe means: no side effects, deterministic, constant arguments.
pub fn is_safe_expr(expr: &Expression) -> bool {
    match expr {
        // Literals are always safe
        Expression::StringLiteral(_)
        | Expression::NumericLiteral(_)
        | Expression::BooleanLiteral(_)
        | Expression::NullLiteral(_)
        | Expression::BigIntLiteral(_) => true,

        // Template literals with no expressions are safe
        Expression::TemplateLiteral(tpl) => tpl.expressions.is_empty(),

        // Array literals are safe if all elements are safe
        Expression::ArrayExpression(arr) => arr.elements.iter().all(|el| match el {
            ArrayExpressionElement::SpreadElement(_) => false,
            ArrayExpressionElement::Elision(_) => true,
            _ => is_safe_expr(el.to_expression()),
        }),

        // Unary expressions are safe if operand is safe (except delete, void)
        Expression::UnaryExpression(unary) => {
            use oxc::ast::ast::UnaryOperator;
            match unary.operator {
                UnaryOperator::Delete | UnaryOperator::Void => false,
                _ => is_safe_expr(&unary.argument),
            }
        }

        // Binary expressions are safe if both operands are safe
        Expression::BinaryExpression(bin) => is_safe_expr(&bin.left) && is_safe_expr(&bin.right),

        // Logical expressions are safe if both operands are safe
        Expression::LogicalExpression(log) => is_safe_expr(&log.left) && is_safe_expr(&log.right),

        // Conditional expressions are safe if all parts are safe
        Expression::ConditionalExpression(cond) => {
            is_safe_expr(&cond.test)
                && is_safe_expr(&cond.consequent)
                && is_safe_expr(&cond.alternate)
        }

        // Parenthesized expressions
        Expression::ParenthesizedExpression(paren) => is_safe_expr(&paren.expression),

        // Sequence expressions - safe if all are safe
        Expression::SequenceExpression(seq) => seq.expressions.iter().all(is_safe_expr),

        // Member expressions (property access) - check for .length on literals
        Expression::StaticMemberExpression(member) => is_safe_member_expr(member),

        // Call expressions - the main check
        Expression::CallExpression(call) => is_safe_call_expr(call),

        // Everything else is unsafe
        _ => false,
    }
}

/// Check if a member expression is safe (e.g., "hello".length, [1,2,3].length)
fn is_safe_member_expr(member: &StaticMemberExpression) -> bool {
    let prop_name = member.property.name.as_str();

    // .length on literals is safe
    if prop_name == "length" {
        return is_safe_expr(&member.object);
    }

    // Math.PI, Math.E, etc. are safe constants
    if let Expression::Identifier(id) = &member.object
        && id.name == "Math"
    {
        return matches!(
            prop_name,
            "PI" | "E" | "LN2" | "LN10" | "LOG2E" | "LOG10E" | "SQRT1_2" | "SQRT2"
        );
    }

    false
}

/// Check if a call expression is safe
fn is_safe_call_expr(call: &CallExpression) -> bool {
    // First check if all arguments are safe (constant)
    if !all_args_safe(&call.arguments) {
        return false;
    }

    match &call.callee {
        // Direct function call: atob("..."), parseInt("...")
        Expression::Identifier(id) => {
            let name = id.name.as_str();
            // Check against unsafe globals first
            if UNSAFE_GLOBALS.contains(&name) {
                return false;
            }
            // Check if it's a known safe global
            SAFE_GLOBALS.contains(&name)
        }

        // Method call: "hello".toUpperCase(), [1,2,3].reverse()
        Expression::StaticMemberExpression(member) => is_safe_method_call(member, call),

        // Computed member: obj["method"]() - generally unsafe
        Expression::ComputedMemberExpression(_) => false,

        // Chained calls: "abc".split("").reverse().join("")
        Expression::CallExpression(inner_call) => {
            // The inner call must also be safe
            is_safe_call_expr(inner_call)
        }

        _ => false,
    }
}

/// Check if a method call is safe
fn is_safe_method_call(member: &StaticMemberExpression, _call: &CallExpression) -> bool {
    let method_name = member.property.name.as_str();

    // Check for non-deterministic methods
    if NON_DETERMINISTIC.contains(&method_name) {
        return false;
    }

    match &member.object {
        // String literal method: "hello".toUpperCase()
        Expression::StringLiteral(_) => SAFE_STRING_METHODS.contains(&method_name),

        // Number literal method: (255).toString(16)
        Expression::NumericLiteral(_) => SAFE_NUMBER_METHODS.contains(&method_name),

        // Parenthesized number: (255).toString()
        Expression::ParenthesizedExpression(paren) => {
            if matches!(&paren.expression, Expression::NumericLiteral(_)) {
                SAFE_NUMBER_METHODS.contains(&method_name)
            } else {
                // Recursively check
                is_safe_expr(&paren.expression)
                    && (SAFE_STRING_METHODS.contains(&method_name)
                        || SAFE_ARRAY_METHODS.contains(&method_name))
            }
        }

        // Array literal method: [1,2,3].reverse()
        Expression::ArrayExpression(arr) => {
            // Check if array elements are safe
            arr.elements.iter().all(|el| match el {
                ArrayExpressionElement::SpreadElement(_) => false,
                ArrayExpressionElement::Elision(_) => true,
                _ => is_safe_expr(el.to_expression()),
            }) && SAFE_ARRAY_METHODS.contains(&method_name)
        }

        // String.fromCharCode(...), Math.floor(...)
        Expression::Identifier(id) => {
            let obj_name = id.name.as_str();
            match obj_name {
                "String" => SAFE_STRING_STATIC_METHODS.contains(&method_name),
                "Math" => SAFE_MATH_METHODS.contains(&method_name),
                "Number" => matches!(
                    method_name,
                    "isNaN" | "isFinite" | "parseInt" | "parseFloat"
                ),
                "JSON" => matches!(method_name, "parse" | "stringify"),
                // window.atob("..."), globalThis.atob("..."), self.atob("...")
                // Treat these as safe "global" functions when args are constant.
                "window" | "globalThis" | "self" => SAFE_GLOBALS.contains(&method_name),
                _ => false,
            }
        }

        // Chained method call: "abc".split("").reverse()
        Expression::CallExpression(inner_call) => {
            // Inner call must be safe, and method must be safe for the result type
            is_safe_call_expr(inner_call)
                && (SAFE_STRING_METHODS.contains(&method_name)
                    || SAFE_ARRAY_METHODS.contains(&method_name))
        }

        _ => false,
    }
}

/// Check if all arguments are safe (constant/literal values)
fn all_args_safe(args: &oxc::allocator::Vec<Argument>) -> bool {
    args.iter().all(|arg| match arg {
        Argument::SpreadElement(_) => false,
        _ => is_safe_expr(arg.to_expression()),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::allocator::Allocator;
    use oxc::parser::Parser;
    use oxc::span::SourceType;

    fn parse_expr(code: &str) -> bool {
        let allocator = Allocator::default();
        let source_type = SourceType::cjs();
        let ret = Parser::new(&allocator, code, source_type).parse();
        if !ret.errors.is_empty() {
            return false;
        }
        let program = ret.program;
        // Check directives first (string literals at start of program are directives)
        if !program.directives.is_empty() {
            // A directive is a string literal - always safe
            return true;
        }
        if let Some(stmt) = program.body.first() {
            if let oxc::ast::ast::Statement::ExpressionStatement(expr_stmt) = stmt {
                return is_safe_expr(&expr_stmt.expression);
            }
        }
        false
    }

    #[test]
    fn test_safe_literals() {
        assert!(parse_expr(r#""hello""#));
        assert!(parse_expr("42"));
        assert!(parse_expr("true"));
        assert!(parse_expr("null"));
    }

    #[test]
    fn test_safe_global_functions() {
        assert!(parse_expr(r#"atob("SGVsbG8=")"#));
        assert!(parse_expr(r#"btoa("Hello")"#));
        assert!(parse_expr(r#"parseInt("42")"#));
        assert!(parse_expr(r#"parseInt("ff", 16)"#));
        assert!(parse_expr(r#"parseFloat("3.14")"#));
    }

    #[test]
    fn test_safe_string_methods() {
        assert!(parse_expr(r#""hello".toUpperCase()"#));
        assert!(parse_expr(r#""hello".charAt(0)"#));
        assert!(parse_expr(r#""hello".slice(1, 3)"#));
        assert!(parse_expr(r#""hello".length"#));
    }

    #[test]
    fn test_safe_array_methods() {
        assert!(parse_expr(r#"[1, 2, 3].reverse()"#));
        assert!(parse_expr(r#"[1, 2, 3].join("-")"#));
        assert!(parse_expr(r#"[1, 2, 3].length"#));
    }

    #[test]
    fn test_safe_math_methods() {
        assert!(parse_expr("Math.floor(3.7)"));
        assert!(parse_expr("Math.abs(-5)"));
        assert!(parse_expr("Math.PI"));
    }

    #[test]
    fn test_safe_chained_calls() {
        assert!(parse_expr(r#""abc".split("").reverse().join("")"#));
    }

    #[test]
    fn test_safe_string_from_char_code() {
        assert!(parse_expr("String.fromCharCode(72, 101, 108, 108, 111)"));
    }

    #[test]
    fn test_unsafe_console() {
        assert!(!parse_expr(r#"console.log("hello")"#));
    }

    #[test]
    fn test_unsafe_date_now() {
        assert!(!parse_expr("Date.now()"));
    }

    #[test]
    fn test_unsafe_math_random() {
        assert!(!parse_expr("Math.random()"));
    }

    #[test]
    fn test_unsafe_variable_argument() {
        // Variable as argument - not safe because we don't know the value
        assert!(!parse_expr("atob(x)"));
    }

    #[test]
    fn test_unsafe_fetch() {
        assert!(!parse_expr(r#"fetch("url")"#));
    }

    #[test]
    fn test_unsafe_eval() {
        assert!(!parse_expr(r#"eval("code")"#));
    }
}
