//! Universal JavaScript Deobfuscator
//!
//! A modular, multi-pass deobfuscator built on OXC that runs transformations
//! iteratively until convergence (zero modifications).

pub mod core;
pub mod eval;
pub mod keyfetcher;
pub mod modules;
pub mod utils;

pub use core::engine::{DeobfuscateResult, Deobfuscator, run_single_module};
pub use core::error::DeobfuscateError;
pub use core::module::{Module, TransformResult};
pub use core::registry::ModuleRegistry;
