//! Brace wrapper module.
//!
//! Wraps control flow statement bodies in braces for consistent AST structure.
//! Handles ALL JavaScript statements with bodies:
//!   if (x) doSomething();        → if (x) { doSomething(); }
//!   for (...) doSomething();     → for (...) { doSomething(); }
//!   for (x in y) doSomething();  → for (x in y) { doSomething(); }
//!   for (x of y) doSomething();  → for (x of y) { doSomething(); }
//!   while (x) doSomething();     → while (x) { doSomething(); }
//!   do doSomething(); while (x); → do { doSomething(); } while (x);
//!   with (obj) doSomething();    → with (obj) { doSomething(); }
//!   label: doSomething();        → label: { doSomething(); }
//!   case 1: a(); b();            → case 1: { a(); b(); }

use oxc::allocator::{Allocator, TakeIn};
use oxc::ast::ast::{
    DoWhileStatement, ForInStatement, ForOfStatement, ForStatement, IfStatement, LabeledStatement,
    Program, Statement, SwitchCase, WhileStatement, WithStatement,
};
use oxc::semantic::Scoping;
use oxc::span::GetSpan;
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};

/// Wraps control flow statement bodies in braces.
pub struct BraceWrapper;

impl Module for BraceWrapper {
    fn name(&self) -> &'static str {
        "BraceWrapper"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        let mut visitor = BraceWrapperVisitor::default();
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(TransformResult {
            modifications: visitor.modifications,
            scoping,
        })
    }
}

#[derive(Default)]
struct BraceWrapperVisitor {
    modifications: usize,
}

impl BraceWrapperVisitor {
    /// Wraps a statement body in braces if not already a block.
    fn wrap_body<'a>(&mut self, body: &mut Statement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        if !matches!(body, Statement::BlockStatement(_)) {
            let stmt = body.take_in(ctx.ast.allocator);
            *body = ctx.ast.statement_block(stmt.span(), ctx.ast.vec1(stmt));
            self.modifications += 1;
        }
    }
}

impl<'a> Traverse<'a, ()> for BraceWrapperVisitor {
    fn exit_if_statement(&mut self, node: &mut IfStatement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        self.wrap_body(&mut node.consequent, ctx);

        // Wrap alternate (else) if exists and not already a block or if-else chain
        if let Some(alternate) = &mut node.alternate {
            let alt_ref: &Statement = alternate;
            if !matches!(
                alt_ref,
                Statement::BlockStatement(_) | Statement::IfStatement(_)
            ) {
                self.wrap_body(alternate, ctx);
            }
        }
    }

    fn exit_for_statement(&mut self, node: &mut ForStatement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        self.wrap_body(&mut node.body, ctx);
    }

    fn exit_for_in_statement(
        &mut self,
        node: &mut ForInStatement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        self.wrap_body(&mut node.body, ctx);
    }

    fn exit_for_of_statement(
        &mut self,
        node: &mut ForOfStatement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        self.wrap_body(&mut node.body, ctx);
    }

    fn exit_while_statement(
        &mut self,
        node: &mut WhileStatement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        self.wrap_body(&mut node.body, ctx);
    }

    fn exit_do_while_statement(
        &mut self,
        node: &mut DoWhileStatement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        self.wrap_body(&mut node.body, ctx);
    }

    fn exit_with_statement(&mut self, node: &mut WithStatement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        self.wrap_body(&mut node.body, ctx);
    }

    fn exit_labeled_statement(
        &mut self,
        node: &mut LabeledStatement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Don't wrap if body is a loop/switch (common pattern: label: for (...) {})
        if !matches!(
            node.body,
            Statement::BlockStatement(_)
                | Statement::ForStatement(_)
                | Statement::ForInStatement(_)
                | Statement::ForOfStatement(_)
                | Statement::WhileStatement(_)
                | Statement::DoWhileStatement(_)
                | Statement::SwitchStatement(_)
        ) {
            self.wrap_body(&mut node.body, ctx);
        }
    }

    fn exit_switch_case(&mut self, node: &mut SwitchCase<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        if node.consequent.is_empty() {
            return;
        }

        // Skip if already a single block
        if node.consequent.len() == 1 && matches!(&node.consequent[0], Statement::BlockStatement(_))
        {
            return;
        }

        // Wrap statements in block
        let stmts = node.consequent.take_in(ctx.ast.allocator);
        node.consequent = ctx.ast.vec1(ctx.ast.statement_block(node.span, stmts));
        self.modifications += 1;
    }
}
