//! Statement splitter module.
//!
//! Splits compound statements into individual ones for easier analysis:
//!
//! Variable declarations:
//!   var a, b, c;           → var a; var b; var c;
//!   let x = 1, y = 2;      → let x = 1; let y = 2;
//!   const A = 1, B = 2;    → const A = 1; const B = 2;
//!
//! Sequence expressions (comma operator):
//!   a(), b(), c();         → a(); b(); c();
//!   x = 1, y = 2, z = 3;   → x = 1; y = 2; z = 3;
//!
//! This normalization makes it easier for other modules to:
//! - Track individual variable assignments
//! - Analyze individual expressions
//! - Perform dead code elimination per-statement

use oxc::allocator::{Allocator, TakeIn, Vec as ArenaVec};
use oxc::ast::ast::{Expression, Program, Statement};
use oxc::semantic::Scoping;
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};

/// Splits compound statements (multi-var declarations, sequence expressions).
pub struct StatementSplitter;

impl Module for StatementSplitter {
    fn name(&self) -> &'static str {
        "StatementSplitter"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        let mut visitor = StatementSplitterVisitor::default();
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(TransformResult {
            modifications: visitor.modifications,
            scoping,
        })
    }
}

#[derive(Default)]
struct StatementSplitterVisitor {
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for StatementSplitterVisitor {
    fn exit_statements(
        &mut self,
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut new_statements: ArenaVec<'a, Statement<'a>> = ctx.ast.vec();

        for mut statement in statements.take_in(allocator) {
            match &mut statement {
                // Split multi-variable declarations
                Statement::VariableDeclaration(var_decl) if var_decl.declarations.len() > 1 => {
                    let declarations = var_decl.declarations.take_in(allocator);
                    for decl in declarations {
                        let single = ctx.ast.vec1(decl);
                        let new_var_decl = ctx.ast.alloc_variable_declaration(
                            var_decl.span,
                            var_decl.kind,
                            single,
                            var_decl.declare,
                        );
                        new_statements.push(Statement::VariableDeclaration(new_var_decl));
                    }
                    self.modifications += 1;
                }

                // Split sequence expressions (a(), b(), c(); → a(); b(); c();)
                Statement::ExpressionStatement(expr_stmt) if matches!(&expr_stmt.expression, Expression::SequenceExpression(s) if s.expressions.len() > 1) => {
                    if let Expression::SequenceExpression(seq) = &mut expr_stmt.expression {
                        for expr in seq.expressions.take_in(allocator) {
                            new_statements.push(Statement::ExpressionStatement(
                                ctx.ast.alloc_expression_statement(expr_stmt.span, expr),
                            ));
                        }
                        self.modifications += 1;
                    }
                }

                // Keep expression statements that aren't sequences
                Statement::ExpressionStatement(_) => {
                    new_statements.push(statement);
                }

                // Keep everything else as-is
                _ => new_statements.push(statement),
            }
        }

        *statements = new_statements;
    }
}
