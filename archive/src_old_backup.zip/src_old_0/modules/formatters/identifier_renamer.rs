//! Identifier renamer module.
//!
//! Renames obfuscated identifiers to more readable names.
//! Handles ALL JavaScript scope scenarios:
//! - Function declarations and expressions
//! - Arrow functions
//! - Classes (declarations and expressions)
//! - Block scopes (let/const)
//! - Loop variables (for, for-in, for-of)
//! - Catch clause parameters
//! - Destructuring patterns
//! - Shadowing across all scope types

use oxc::allocator::Allocator;
use oxc::ast::ast::{
    ArrowFunctionExpression, AssignmentExpression, AssignmentTarget, BindingIdentifier,
    BindingPattern, BindingPatternKind, CatchClause, Class, ForInStatement, ForOfStatement,
    ForStatement, ForStatementInit, ForStatementLeft, Function, IdentifierReference, Program,
    VariableDeclarator,
};
use oxc::semantic::{Scoping, SymbolId};
use oxc::span::Atom;
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};

/// Renames obfuscated identifiers to readable names.
pub struct IdentifierRenamer;

impl Module for IdentifierRenamer {
    fn name(&self) -> &'static str {
        "IdentifierRenamer"
    }

    fn changes_symbols(&self) -> bool {
        true
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        let mut visitor = RenamerVisitor::default();
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(TransformResult {
            modifications: visitor.modifications,
            scoping,
        })
    }
}

#[derive(Default)]
struct RenamerVisitor<'a> {
    /// Maps symbol IDs to their new unique names
    symbol_mappings: FxHashMap<SymbolId, Atom<'a>>,
    /// Count of modifications made
    modifications: usize,
}

impl<'a> RenamerVisitor<'a> {
    /// Ensures a symbol has a unique name, generating one if needed.
    /// Returns the unique name for the symbol.
    fn ensure_unique_name(
        &mut self,
        ctx: &mut TraverseCtx<'a, ()>,
        symbol_id: SymbolId,
        suggested_name: &Atom<'a>,
    ) -> Atom<'a> {
        // Return cached name if already processed
        if let Some(unique_name) = self.symbol_mappings.get(&symbol_id) {
            return *unique_name;
        }

        // Generate unique name and cache it
        let unique_name = ctx.generate_uid_name(suggested_name);
        self.symbol_mappings.insert(symbol_id, unique_name);
        ctx.scoping_mut().set_symbol_name(symbol_id, &unique_name);
        self.modifications += 1;
        unique_name
    }

    /// Renames an identifier reference if it has a resolved symbol.
    fn rename_reference(
        &mut self,
        ident: &mut IdentifierReference<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Get reference ID
        let Some(reference_id) = ident.reference_id.get() else {
            return;
        };

        // Get symbol ID from reference (None means global/unresolved)
        let Some(symbol_id) = ctx.scoping().get_reference(reference_id).symbol_id() else {
            return; // Global reference, don't rename
        };

        // Get or generate unique name
        ident.name = self.ensure_unique_name(ctx, symbol_id, &ident.name);
    }

    /// Renames a binding identifier if it has a symbol.
    fn rename_binding(&mut self, ident: &mut BindingIdentifier<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        if let Some(symbol_id) = ident.symbol_id.get() {
            ident.name = self.ensure_unique_name(ctx, symbol_id, &ident.name);
        }
    }

    /// Recursively processes binding patterns (destructuring).
    fn process_binding_pattern(
        &mut self,
        pattern: &mut BindingPattern<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        match &mut pattern.kind {
            BindingPatternKind::BindingIdentifier(ident) => {
                self.rename_binding(ident, ctx);
            }
            BindingPatternKind::ObjectPattern(obj) => {
                for prop in obj.properties.iter_mut() {
                    self.process_binding_pattern(&mut prop.value, ctx);
                }
                if let Some(rest) = &mut obj.rest {
                    self.process_binding_pattern(&mut rest.argument, ctx);
                }
            }
            BindingPatternKind::ArrayPattern(arr) => {
                for elem in arr.elements.iter_mut().flatten() {
                    self.process_binding_pattern(elem, ctx);
                }
                if let Some(rest) = &mut arr.rest {
                    self.process_binding_pattern(&mut rest.argument, ctx);
                }
            }
            BindingPatternKind::AssignmentPattern(assign) => {
                self.process_binding_pattern(&mut assign.left, ctx);
            }
        }
    }
}

impl<'a> Traverse<'a, ()> for RenamerVisitor<'a> {
    // ========================================================================
    // IDENTIFIER REFERENCES (reads/uses of variables)
    // ========================================================================

    fn enter_identifier_reference(
        &mut self,
        node: &mut IdentifierReference<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        self.rename_reference(node, ctx);
    }

    // ========================================================================
    // BINDING IDENTIFIERS (variable declarations)
    // ========================================================================

    fn enter_binding_identifier(
        &mut self,
        node: &mut BindingIdentifier<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        self.rename_binding(node, ctx);
    }

    // ========================================================================
    // VARIABLE DECLARATIONS (var, let, const)
    // ========================================================================

    fn enter_variable_declarator(
        &mut self,
        node: &mut VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Handle destructuring patterns in variable declarations
        self.process_binding_pattern(&mut node.id, ctx);
    }

    // ========================================================================
    // FUNCTION DECLARATIONS AND EXPRESSIONS
    // ========================================================================

    fn enter_function(&mut self, node: &mut Function<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Rename function name if present
        if let Some(func_name) = &mut node.id {
            self.rename_binding(func_name, ctx);
        }

        // Rename all parameters (including destructuring)
        for param in node.params.items.iter_mut() {
            self.process_binding_pattern(&mut param.pattern, ctx);
        }

        // Handle rest parameter
        if let Some(rest) = &mut node.params.rest {
            self.process_binding_pattern(&mut rest.argument, ctx);
        }
    }

    // ========================================================================
    // ARROW FUNCTIONS
    // ========================================================================

    fn enter_arrow_function_expression(
        &mut self,
        node: &mut ArrowFunctionExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Rename all parameters (including destructuring)
        for param in node.params.items.iter_mut() {
            self.process_binding_pattern(&mut param.pattern, ctx);
        }

        // Handle rest parameter
        if let Some(rest) = &mut node.params.rest {
            self.process_binding_pattern(&mut rest.argument, ctx);
        }
    }

    // ========================================================================
    // CLASSES
    // ========================================================================

    fn enter_class(&mut self, node: &mut Class<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Rename class name if present (class declarations and named class expressions)
        if let Some(class_name) = &mut node.id {
            self.rename_binding(class_name, ctx);
        }
    }

    // ========================================================================
    // CATCH CLAUSE
    // ========================================================================

    fn enter_catch_clause(&mut self, node: &mut CatchClause<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Rename catch parameter (e.g., catch (error) { ... })
        if let Some(param) = &mut node.param {
            self.process_binding_pattern(&mut param.pattern, ctx);
        }
    }

    // ========================================================================
    // FOR LOOPS
    // ========================================================================

    fn enter_for_statement(&mut self, node: &mut ForStatement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Handle for loop init: for (let i = 0; ...)
        // Note: VariableDeclaration is handled by enter_variable_declarator
        // This is here for completeness if we need special handling
        if let Some(ForStatementInit::VariableDeclaration(decl)) = &mut node.init {
            for declarator in decl.declarations.iter_mut() {
                self.process_binding_pattern(&mut declarator.id, ctx);
            }
        }
    }

    fn enter_for_in_statement(
        &mut self,
        node: &mut ForInStatement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Handle for-in loop variable: for (let key in obj)
        if let ForStatementLeft::VariableDeclaration(decl) = &mut node.left {
            for declarator in decl.declarations.iter_mut() {
                self.process_binding_pattern(&mut declarator.id, ctx);
            }
        }
    }

    fn enter_for_of_statement(
        &mut self,
        node: &mut ForOfStatement<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Handle for-of loop variable: for (let value of arr)
        // Also handles destructuring: for (let [a, b] of pairs)
        if let ForStatementLeft::VariableDeclaration(decl) = &mut node.left {
            for declarator in decl.declarations.iter_mut() {
                self.process_binding_pattern(&mut declarator.id, ctx);
            }
        }
    }

    // ========================================================================
    // ASSIGNMENT EXPRESSIONS
    // ========================================================================

    fn enter_assignment_expression(
        &mut self,
        node: &mut AssignmentExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Handle simple identifier assignment: x = 1
        if let AssignmentTarget::AssignmentTargetIdentifier(ident) = &mut node.left {
            self.rename_reference(ident, ctx);
        }
        // Note: Destructuring assignment targets are handled differently
        // The identifiers inside are IdentifierReferences, not BindingIdentifiers
    }
}
