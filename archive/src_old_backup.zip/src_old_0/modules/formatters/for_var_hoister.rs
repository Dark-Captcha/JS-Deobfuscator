//! For-loop var hoister module.
//!
//! Hoists `var` declarations from for-loop initializers to before the loop.
//! This is safe because `var` has function scope, not block scope.
//!
//! ONLY hoists if the variable is read-only (write_count == 0):
//!   for (var i = 0; i < 10; i++) {}  → unchanged (i is written in i++)
//!   for (var x = arr[0]; x; x = x.next) {} → unchanged (x is written)
//!   for (var len = arr.length; i < len; i++) {} → var len = arr.length; for (; i < len; i++) {}
//!
//! Does NOT hoist `let` or `const` because they have block scope:
//!   for (let i = 0; ...) {}     → unchanged (let is block-scoped)
//!   for (const x of arr) {}     → unchanged (const is block-scoped)
//!
//! This normalization makes it easier for other modules to:
//! - Track variable declarations at the top of scopes
//! - Analyze loop-independent variable initialization
//! - Perform variable inlining

use oxc::allocator::{Allocator, TakeIn, Vec as ArenaVec};
use oxc::ast::ast::{BindingPatternKind, ForStatementInit, Program, Statement};
use oxc::semantic::Scoping;
use oxc::syntax::reference::Reference;
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};

/// Hoists var declarations from for-loop initializers.
pub struct ForVarHoister;

impl Module for ForVarHoister {
    fn name(&self) -> &'static str {
        "ForVarHoister"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        let mut visitor = ForVarHoisterVisitor::default();
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(TransformResult {
            modifications: visitor.modifications,
            scoping,
        })
    }
}

#[derive(Default)]
struct ForVarHoisterVisitor {
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for ForVarHoisterVisitor {
    fn exit_statements(
        &mut self,
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        self.hoist_for_var_inits(statements, ctx);
    }
}

impl ForVarHoisterVisitor {
    /// Hoists var declarations from for-loop initializers.
    ///
    /// ONLY hoists if ALL declared variables are read-only (no writes).
    ///
    /// Example (hoisted - len is only read):
    /// ```js
    /// for (var len = arr.length; i < len; i++) { ... }
    /// ```
    /// Becomes:
    /// ```js
    /// var len = arr.length;
    /// for (; i < len; i++) { ... }
    /// ```
    ///
    /// Example (NOT hoisted - i is written in i++):
    /// ```js
    /// for (var i = 0; i < 10; i++) { ... }
    /// ```
    /// Stays unchanged.
    fn hoist_for_var_inits<'a>(
        &mut self,
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut hoisted_declarations: oxc::allocator::Vec<'_, (usize, Statement<'a>)> =
            ctx.ast.vec();

        for (statement_index, statement) in statements.iter_mut().enumerate() {
            if let Statement::ForStatement(for_statement) = statement {
                // Only hoist `var` declarations, not `let` or `const`
                if let Some(ForStatementInit::VariableDeclaration(var_decl)) =
                    &mut for_statement.init
                {
                    // Check if it's a `var` declaration (not let/const)
                    if var_decl.kind.is_var() && !var_decl.declarations.is_empty() {
                        // Check if ALL declared variables are read-only (no writes)
                        let all_read_only = var_decl.declarations.iter().all(|declarator| {
                            // Get the symbol_id from the binding identifier
                            if let BindingPatternKind::BindingIdentifier(binding_id) =
                                &declarator.id.kind
                            {
                                if let Some(symbol_id) = binding_id.symbol_id.get() {
                                    // Check if any reference is a write
                                    let has_write = ctx
                                        .scoping()
                                        .get_resolved_references(symbol_id)
                                        .any(Reference::is_write);
                                    !has_write
                                } else {
                                    // No symbol_id means it's a global or unresolved - don't hoist
                                    false
                                }
                            } else {
                                // Destructuring pattern - don't hoist (too complex to analyze)
                                false
                            }
                        });

                        if !all_read_only {
                            // Skip hoisting if any variable is written to
                            continue;
                        }

                        // Take the declarations from the for-loop init
                        let declarations = var_decl.declarations.take_in(allocator);

                        // Create a new variable declaration statement
                        let hoisted_var_decl = ctx.ast.alloc_variable_declaration(
                            var_decl.span,
                            var_decl.kind,
                            declarations,
                            var_decl.declare,
                        );

                        // Queue the hoisted declaration to be inserted before the for-loop
                        hoisted_declarations.push((
                            statement_index,
                            Statement::VariableDeclaration(hoisted_var_decl),
                        ));

                        // Remove the init from the for-loop
                        for_statement.init = None;
                        self.modifications += 1;
                    }
                }
            }
        }

        // Insert hoisted declarations in reverse order to maintain correct indices
        // Each declaration is inserted BEFORE its corresponding for-loop
        for (original_index, hoisted_declaration) in hoisted_declarations.into_iter().rev() {
            statements.insert(original_index, hoisted_declaration);
        }
    }
}
