//! AST formatters - modules that run once before and after the deobfuscation loop.
//!
//! These modules normalize code structure to make deobfuscation easier.
//!
//! ## Formatters (ORDER MATTERS)
//! 1. `IdentifierRenamer` - Rename obfuscated identifiers for readability
//! 2. `BraceWrapper` - Wrap control flow bodies in braces
//! 3. `ForVarHoister` - Hoist `for(var i=0;...)` to `var i=0; for(;...)`
//! 4. `StatementSplitter` - Split multi-var declarations and sequence expressions

pub mod brace_wrapper;
pub mod for_var_hoister;
pub mod identifier_renamer;
pub mod statement_splitter;

pub use brace_wrapper::BraceWrapper;
pub use for_var_hoister::ForVarHoister;
pub use identifier_renamer::IdentifierRenamer;
pub use statement_splitter::StatementSplitter;
