//! Proxy function inlining module.
//!
//! Inlines simple proxy functions at their call sites.
//!
//! Handles:
//!   function f() { return expr; }           → inline expr
//!   function f(a, b) { return a + b; }      → inline with arg substitution
//!   function f(x) { return arr[x]; }        → inline arr[arg]
//!   function f(a, b) { return g(b, a); }    → inline g(arg2, arg1)
//!
//! Requirements:
//!   - Function must have single return statement
//!   - Function must not be reassigned
//!   - Arguments must be simple (no spread)

use oxc::allocator::{Allocator, CloneIn};
use oxc::ast::ast::{Argument, BindingPatternKind, Expression, Function, Program, Statement};
use oxc::semantic::{Scoping, SymbolId};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::utils::symbols::{count_write_references, get_reference_symbol};

pub struct ProxyInliner;

impl Module for ProxyInliner {
    fn name(&self) -> &'static str {
        "ProxyInliner"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Pass 1: Collect proxy functions
        let mut collector = Collector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        if collector.proxies.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        // Pass 2: Inline proxy calls
        let mut inliner = Inliner {
            proxies: collector.proxies,
            modifications: 0,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        Ok(TransformResult {
            modifications: inliner.modifications,
            scoping,
        })
    }
}

// ============================================================================
// Proxy representation
// ============================================================================

struct Proxy<'a> {
    /// Parameter names in order (for substitution matching)
    param_names: Vec<String>,
    /// The return expression (template for substitution)
    body: Expression<'a>,
}

// ============================================================================
// Pass 1: Collect proxy functions
// ============================================================================

#[derive(Default)]
struct Collector<'a> {
    proxies: FxHashMap<SymbolId, Proxy<'a>>,
}

impl<'a> Traverse<'a, ()> for Collector<'a> {
    fn enter_function(&mut self, func: &mut Function<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Must be named function
        let Some(id) = &func.id else { return };
        let Some(func_symbol) = id.symbol_id.get() else { return };

        // Must have a body with exactly one statement
        let Some(body) = &func.body else { return };
        if body.statements.len() != 1 {
            return;
        }

        // Must be a return statement with an argument
        let Statement::ReturnStatement(ret) = &body.statements[0] else { return };
        let Some(return_expr) = &ret.argument else { return };

        // Collect parameter names
        let mut param_names = Vec::new();
        for param in &func.params.items {
            let BindingPatternKind::BindingIdentifier(binding) = &param.pattern.kind else {
                return; // Destructuring - bail
            };
            param_names.push(binding.name.to_string());
        }

        // Check function is not reassigned (only declaration, no writes)
        if count_write_references(ctx.scoping(), func_symbol) > 0 {
            return;
        }

        self.proxies.insert(
            func_symbol,
            Proxy {
                param_names,
                body: return_expr.clone_in(ctx.ast.allocator),
            },
        );
    }
}

// ============================================================================
// Pass 2: Inline proxy calls
// ============================================================================

struct Inliner<'a> {
    proxies: FxHashMap<SymbolId, Proxy<'a>>,
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for Inliner<'a> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let Expression::CallExpression(call) = expr else { return };

        // Get callee symbol
        let Expression::Identifier(callee_id) = &call.callee else { return };
        let Some(func_symbol) = get_reference_symbol(ctx.scoping(), callee_id) else { return };

        // Check if it's a proxy
        let Some(proxy) = self.proxies.get(&func_symbol) else { return };

        // Must have matching argument count
        if call.arguments.len() != proxy.param_names.len() {
            return;
        }

        // All arguments must be non-spread
        if call.arguments.iter().any(|a| matches!(a, Argument::SpreadElement(_))) {
            return;
        }

        // Clone the body and substitute parameters
        let mut result = proxy.body.clone_in(ctx.ast.allocator);

        // Build param name -> arg mapping (avoid cloning args up-front; clone only when substituting).
        let substitutions: FxHashMap<&str, &Expression<'a>> = proxy
            .param_names
            .iter()
            .zip(call.arguments.iter())
            .filter_map(|(param_name, arg)| arg.as_expression().map(|e| (param_name.as_str(), e)))
            .collect();

        // Substitute all parameter references by name
        substitute_params(&mut result, &substitutions, ctx.ast.allocator);

        *expr = result;
        self.modifications += 1;
    }
}

// ============================================================================
// Parameter substitution (recursive)
// ============================================================================

fn substitute_params<'a>(
    expr: &mut Expression<'a>,
    subs: &FxHashMap<&str, &Expression<'a>>,
    alloc: &'a Allocator,
) {
    match expr {
        Expression::Identifier(id) => {
            // Match by identifier name
            let name = id.name.as_str();
            if let Some(replacement) = subs.get(name) {
                *expr = (*replacement).clone_in(alloc);
                return;
            }
        }

        Expression::BinaryExpression(e) => {
            substitute_params(&mut e.left, subs, alloc);
            substitute_params(&mut e.right, subs, alloc);
        }

        Expression::UnaryExpression(e) => {
            substitute_params(&mut e.argument, subs, alloc);
        }

        Expression::LogicalExpression(e) => {
            substitute_params(&mut e.left, subs, alloc);
            substitute_params(&mut e.right, subs, alloc);
        }

        Expression::ConditionalExpression(e) => {
            substitute_params(&mut e.test, subs, alloc);
            substitute_params(&mut e.consequent, subs, alloc);
            substitute_params(&mut e.alternate, subs, alloc);
        }

        Expression::CallExpression(e) => {
            substitute_params(&mut e.callee, subs, alloc);
            for arg in e.arguments.iter_mut() {
                if let Some(arg_expr) = arg.as_expression_mut() {
                    substitute_params(arg_expr, subs, alloc);
                }
            }
        }

        Expression::ComputedMemberExpression(e) => {
            substitute_params(&mut e.object, subs, alloc);
            substitute_params(&mut e.expression, subs, alloc);
        }

        Expression::StaticMemberExpression(e) => {
            substitute_params(&mut e.object, subs, alloc);
        }

        Expression::PrivateFieldExpression(e) => {
            substitute_params(&mut e.object, subs, alloc);
        }

        Expression::ArrayExpression(e) => {
            for el in e.elements.iter_mut() {
                if let Some(el_expr) = el.as_expression_mut() {
                    substitute_params(el_expr, subs, alloc);
                }
            }
        }

        Expression::ObjectExpression(e) => {
            for prop in e.properties.iter_mut() {
                if let oxc::ast::ast::ObjectPropertyKind::ObjectProperty(p) = prop {
                    substitute_params(&mut p.value, subs, alloc);
                }
            }
        }

        Expression::ParenthesizedExpression(e) => {
            substitute_params(&mut e.expression, subs, alloc);
        }

        Expression::SequenceExpression(e) => {
            for inner in e.expressions.iter_mut() {
                substitute_params(inner, subs, alloc);
            }
        }

        Expression::AssignmentExpression(e) => {
            substitute_params(&mut e.right, subs, alloc);
        }

        Expression::NewExpression(e) => {
            substitute_params(&mut e.callee, subs, alloc);
            for arg in e.arguments.iter_mut() {
                if let Some(arg_expr) = arg.as_expression_mut() {
                    substitute_params(arg_expr, subs, alloc);
                }
            }
        }

        Expression::TemplateLiteral(e) => {
            for expr in e.expressions.iter_mut() {
                substitute_params(expr, subs, alloc);
            }
        }

        Expression::TaggedTemplateExpression(e) => {
            substitute_params(&mut e.tag, subs, alloc);
        }

        Expression::AwaitExpression(e) => {
            substitute_params(&mut e.argument, subs, alloc);
        }

        Expression::YieldExpression(e) => {
            if let Some(arg) = &mut e.argument {
                substitute_params(arg, subs, alloc);
            }
        }

        // Literals and other expressions don't need substitution
        _ => {}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    fn transform(source: &str) -> (String, usize) {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;
        let semantic = SemanticBuilder::new().build(&program).semantic;
        let scoping = semantic.into_scoping();

        let mut module = ProxyInliner;
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        let code = Codegen::new().build(&program).code;
        (code, result.modifications)
    }

    #[test]
    fn test_zero_arg_proxy() {
        let (code, mods) = transform(r#"function f() { return 42; } console.log(f());"#);
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(42)"), "got: {}", code);
    }

    #[test]
    fn test_single_arg_proxy() {
        let (code, mods) = transform(r#"function f(x) { return x + 1; } console.log(f(5));"#);
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(5 + 1)"), "got: {}", code);
    }

    #[test]
    fn test_two_arg_proxy() {
        let (code, mods) = transform(r#"function f(a, b) { return a - b; } console.log(f(10, 3));"#);
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(10 - 3)"), "got: {}", code);
    }

    #[test]
    fn test_array_lookup_proxy() {
        let (code, mods) = transform(r#"function f(x) { return arr[x]; } console.log(f(5));"#);
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(arr[5])"), "got: {}", code);
    }

    #[test]
    fn test_nested_call_proxy() {
        let (code, mods) = transform(r#"function f(a, b) { return g(b, a - 100); } f(1, 2);"#);
        assert_eq!(mods, 1);
        assert!(code.contains("g(2, 1 - 100)"), "got: {}", code);
    }

    #[test]
    fn test_no_inline_multi_statement() {
        let (code, mods) = transform(r#"function f() { var x = 1; return x; } f();"#);
        assert_eq!(mods, 0);
        assert!(code.contains("f()"), "got: {}", code);
    }

    #[test]
    fn test_no_inline_wrong_arg_count() {
        let (code, mods) = transform(r#"function f(a, b) { return a + b; } f(1);"#);
        assert_eq!(mods, 0);
        assert!(code.contains("f(1)"), "got: {}", code);
    }

    #[test]
    fn test_multiple_calls() {
        let (code, mods) = transform(r#"function f(x) { return x * 2; } f(1); f(2); f(3);"#);
        assert_eq!(mods, 3);
        assert!(code.contains("1 * 2"), "got: {}", code);
        assert!(code.contains("2 * 2"), "got: {}", code);
        assert!(code.contains("3 * 2"), "got: {}", code);
    }
}
