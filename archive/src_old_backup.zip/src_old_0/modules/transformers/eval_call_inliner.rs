//! Eval-based local call inliner.
//!
//! Replaces calls to *local* functions with deterministic arguments by executing the call
//! in `JsEvaluator` (V8) and inlining the returned primitive (primarily strings).
//!
//! This is meant to handle non-array decoders (XOR/Base64/ROT/custom) without pattern matching.
//! It is intentionally conservative: it only attempts calls with "safe" arguments, and it
//! avoids functions that (directly or indirectly) depend on string-array rotators.

use oxc::allocator::{Allocator, CloneIn};
use oxc::ast::ast::{
    Argument, AssignmentOperator, AssignmentTarget, Expression, FormalParameterKind,
    Program, Statement, VariableDeclarationKind, VariableDeclarator,
};
use oxc::semantic::{Scoping, SymbolId};
use oxc::span::{GetSpan, Span, SPAN};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::{FxHashMap, FxHashSet};
use tracing::debug;

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::eval::{JsEvaluator, expr_to_code, is_safe_expr, value_to_expr};
use crate::utils::ast::function_to_code;
use crate::utils::symbols::{count_read_references, get_reference_symbol};
use crate::utils::span::span_in;
use crate::modules::transformers::string_array_decoder::{
    AccessorCollector, ArrayFunctionCollector, ShufflerCollector,
};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum DefKind {
    Function,
    VarInit,
}

#[derive(Debug)]
struct DefInfo {
    kind: DefKind,
    code: String,
    deps: FxHashSet<SymbolId>,
}

/// Collect local function/variable definitions with codegen + dependency info.
struct DefinitionCollector {
    defs: FxHashMap<SymbolId, DefInfo>,
    /// Active definition symbols while traversing (used to attribute identifier refs as deps).
    active: Vec<SymbolId>,
    /// Stack to track whether we pushed a var symbol for the current VariableDeclarator.
    var_stack: Vec<Option<SymbolId>>,
}

impl DefinitionCollector {
    fn new() -> Self {
        Self {
            defs: FxHashMap::default(),
            active: Vec::new(),
            var_stack: Vec::new(),
        }
    }

    fn into_defs(self) -> FxHashMap<SymbolId, DefInfo> {
        self.defs
    }

    fn code_for_var_init<'a>(&self, name: &str, init: &Expression<'a>) -> String {
        format!("var {} = {};", name, expr_to_code(init))
    }
}

impl<'a> Traverse<'a, ()> for DefinitionCollector {
    fn enter_function(&mut self, func: &mut oxc::ast::ast::Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        // Only collect named functions that have a symbol id (function declarations).
        let Some(symbol_id) = func.id.as_ref().and_then(|id| id.symbol_id.get()) else {
            return;
        };
        // Generate code for the function declaration.
        let code = function_to_code(func);

        self.defs.entry(symbol_id).or_insert_with(|| DefInfo {
            kind: DefKind::Function,
            code,
            deps: FxHashSet::default(),
        });

        self.active.push(symbol_id);
    }

    fn exit_function(&mut self, func: &mut oxc::ast::ast::Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        if func.id.as_ref().and_then(|id| id.symbol_id.get()).is_some() {
            let _ = self.active.pop();
        }
    }

    fn enter_variable_declarator(
        &mut self,
        node: &mut VariableDeclarator<'a>,
        _ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let Some(init) = &node.init else {
            self.var_stack.push(None);
            return;
        };
        let Some(binding) = node.id.get_binding_identifier() else {
            self.var_stack.push(None);
            return;
        };
        let Some(symbol_id) = binding.symbol_id.get() else {
            self.var_stack.push(None);
            return;
        };
        let name = binding.name.to_string();

        let code = self.code_for_var_init(&name, init);

        self.defs.entry(symbol_id).or_insert_with(|| DefInfo {
            kind: DefKind::VarInit,
            code,
            deps: FxHashSet::default(),
        });

        self.active.push(symbol_id);
        self.var_stack.push(Some(symbol_id));
    }

    fn exit_variable_declarator(
        &mut self,
        _node: &mut VariableDeclarator<'a>,
        _ctx: &mut TraverseCtx<'a, ()>,
    ) {
        if let Some(pushed) = self.var_stack.pop() {
            if pushed.is_some() {
                let _ = self.active.pop();
            }
        }
    }

    fn enter_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Attribute identifier references as dependencies for all active definitions.
        if self.active.is_empty() {
            return;
        }
        let Expression::Identifier(ident) = expr else { return };
        let Some(sym) = get_reference_symbol(ctx.scoping(), ident) else { return };
        for def_sym in self.active.iter().copied() {
            if let Some(def) = self.defs.get_mut(&def_sym) {
                if sym != def_sym {
                    def.deps.insert(sym);
                }
            }
        }
    }
}

/// Collect which local functions are called with safe args, and track aliases from assignments.
struct CallCalleeCollector {
    callees: FxHashSet<SymbolId>,
    /// Maps variable symbols to function symbols they alias (from assignments like `var a = func` or `a = func`).
    aliases: FxHashMap<SymbolId, SymbolId>,
}

impl CallCalleeCollector {
    fn new() -> Self {
        Self {
            callees: FxHashSet::default(),
            aliases: FxHashMap::default(),
        }
    }

    fn into_set(self) -> FxHashSet<SymbolId> {
        self.callees
    }

    fn into_aliases(self) -> FxHashMap<SymbolId, SymbolId> {
        self.aliases
    }

    fn into_parts(self) -> (FxHashSet<SymbolId>, FxHashMap<SymbolId, SymbolId>) {
        (self.callees, self.aliases)
    }

    fn is_dead_simple_assignment(expr: &Expression, scoping: &Scoping) -> bool {
        let Expression::AssignmentExpression(assign) = expr else {
            return false;
        };
        if assign.operator != oxc::ast::ast::AssignmentOperator::Assign {
            return false;
        }
        let oxc::ast::ast::AssignmentTarget::AssignmentTargetIdentifier(id) = &assign.left else {
            return false;
        };
        let Some(sym) = get_reference_symbol(scoping, id) else { return false };
        // Only if RHS is safe AND the variable is never read.
        is_safe_expr(&assign.right) && count_read_references(scoping, sym) == 0
    }

    fn unwrap_paren<'a>(mut expr: &'a Expression<'a>) -> &'a Expression<'a> {
        while let Expression::ParenthesizedExpression(p) = expr {
            expr = &p.expression;
        }
        expr
    }

    fn expr_is_safeish(expr: &Expression, scoping: &Scoping) -> bool {
        let expr = Self::unwrap_paren(expr);

        // Normal safe expressions (no side effects).
        if is_safe_expr(expr) {
            return true;
        }

        // Allow "dead" assignments used as obfuscator noise, e.g. (_a = 1, "KEY")
        if Self::is_dead_simple_assignment(expr, scoping) {
            return true;
        }

        // Allow sequences if all leading expressions are safe or dead-assignments,
        // and the last expression is safeish.
        let Expression::SequenceExpression(seq) = expr else {
            return false;
        };
        if seq.expressions.is_empty() {
            return false;
        }
        if seq.expressions.len() == 1 {
            return Self::expr_is_safeish(&seq.expressions[0], scoping);
        }

        let (head, last) = seq.expressions.split_at(seq.expressions.len() - 1);
        if !Self::expr_is_safeish(&last[0], scoping) {
            return false;
        }
        for e in head {
            let e = Self::unwrap_paren(e);
            if is_safe_expr(e) || Self::is_dead_simple_assignment(e, scoping) {
                continue;
            }
            return false;
        }
        true
    }

    fn args_are_safe(args: &[Argument], scoping: &Scoping) -> bool {
        args.iter().all(|arg| match arg {
            Argument::SpreadElement(_) => false,
            _ => Self::expr_is_safeish(arg.to_expression(), scoping),
        })
    }

    /// Recursively collect aliases from expressions, including assignments within sequences.
    fn collect_aliases_from_expr(&mut self, expr: &Expression, scoping: &Scoping) {
        match expr {
            Expression::AssignmentExpression(assign) => {
                if assign.operator == AssignmentOperator::Assign {
                    if let AssignmentTarget::AssignmentTargetIdentifier(lhs_id) = &assign.left {
                        if let Expression::Identifier(rhs_id) = &assign.right {
                            if let (Some(lhs_sym), Some(rhs_sym)) = (
                                get_reference_symbol(scoping, lhs_id),
                                get_reference_symbol(scoping, rhs_id),
                            ) {
                                // Record alias: lhs_sym aliases rhs_sym
                                self.aliases.insert(lhs_sym, rhs_sym);
                            }
                        }
                    }
                }
            }
            Expression::SequenceExpression(seq) => {
                // Check each expression in the sequence for aliases
                for e in &seq.expressions {
                    self.collect_aliases_from_expr(e, scoping);
                }
            }
            Expression::ParenthesizedExpression(p) => {
                self.collect_aliases_from_expr(&p.expression, scoping);
            }
            _ => {}
        }
    }
}

impl<'a> Traverse<'a, ()> for CallCalleeCollector {
    fn enter_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Track assignment expressions that create aliases: `var a = func` or `a = func` or `(a = func, ...)`
        self.collect_aliases_from_expr(expr, ctx.scoping());

        // Track function calls
        let Expression::CallExpression(call) = expr else { return };
        let Expression::Identifier(ident) = &call.callee else { return };
        // Heuristic: focus on decoder-like calls (most take at least one argument).
        // This avoids wasting time trying to evaluate many environment probe helpers (0-arg).
        if call.arguments.is_empty() {
            return;
        }
        if !Self::args_are_safe(&call.arguments, ctx.scoping()) {
            return;
        }
        let Some(sym) = get_reference_symbol(ctx.scoping(), ident) else { return };
        self.callees.insert(sym);
    }
}

/// Inlines call expressions for a fixed set of callee symbols using a prepared runtime.
struct CallInliner<'e> {
    evaluator: &'e mut JsEvaluator,
    /// Only inline these callee symbols.
    allowed_callees: FxHashSet<SymbolId>,
    /// Map from variable symbols to the function symbols they alias (from assignments like `var a = func` or `a = func`).
    alias_map: FxHashMap<SymbolId, SymbolId>,
    /// Spans we must not mutate (decoder machinery we load into runtime).
    protected_spans: Vec<Span>,
    cache: FxHashMap<String, serde_json::Value>,
    modifications: usize,
}

impl<'e> CallInliner<'e> {
    fn new(
        evaluator: &'e mut JsEvaluator,
        allowed_callees: FxHashSet<SymbolId>,
        alias_map: FxHashMap<SymbolId, SymbolId>,
        protected_spans: Vec<Span>,
    ) -> Self {
        Self {
            evaluator,
            allowed_callees,
            alias_map,
            protected_spans,
            cache: FxHashMap::default(),
            modifications: 0,
        }
    }

    /// Resolve a symbol to its actual function symbol, following aliases.
    fn resolve_callee(&self, sym: SymbolId) -> SymbolId {
        let mut current = sym;
        let mut visited = FxHashSet::default();
        // Follow alias chain (with cycle detection)
        while let Some(&aliased) = self.alias_map.get(&current) {
            if !visited.insert(current) {
                break; // Cycle detected
            }
            current = aliased;
        }
        current
    }

    fn is_in_protected_span(&self, span: Span) -> bool {
        self.protected_spans
            .iter()
            .any(|p| span_in(span, *p))
    }

    fn args_are_safe(args: &[Argument], scoping: &Scoping) -> bool {
        CallCalleeCollector::args_are_safe(args, scoping)
    }

    fn try_inline_computed_member_decoder_call<'a>(
        &mut self,
        call: &oxc::ast::ast::CallExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> Option<Expression<'a>> {
        // Match: obj[decoder((a=1, b=2, "ENC"))](...args)
        let Expression::ComputedMemberExpression(member) = &call.callee else {
            return None;
        };
        if member.optional || call.optional {
            return None;
        }

        // Key must be a direct call to an allowed decoder.
        let Expression::CallExpression(key_call) = &member.expression else {
            return None;
        };
        let Expression::Identifier(key_ident) = &key_call.callee else {
            return None;
        };
        let key_ref = key_ident.reference_id.get()?;
        let key_sym = ctx.scoping().get_reference(key_ref).symbol_id()?;
        if !self.allowed_callees.contains(&key_sym) {
            return None;
        }

        // Extract obfuscator-noise assignments from the first arg if it's a sequence.
        let first_arg_expr = key_call.arguments.first()?.as_expression()?;
        let arg_core = match first_arg_expr {
            Expression::ParenthesizedExpression(p) => &p.expression,
            other => other,
        };
        let Expression::SequenceExpression(seq) = arg_core else {
            return None;
        };
        if seq.expressions.len() < 2 {
            return None;
        }

        let mut side_effects: Vec<Expression<'a>> = Vec::new();
        for e in seq.expressions.iter().take(seq.expressions.len() - 1) {
            let e = match e {
                Expression::ParenthesizedExpression(p) => &p.expression,
                other => other,
            };

            // Preserve simple `x = <safe>` assignments (these are common in PX noise sequences).
            if let Expression::AssignmentExpression(a) = e
                && a.operator == AssignmentOperator::Assign
                && matches!(&a.left, AssignmentTarget::AssignmentTargetIdentifier(_))
                && is_safe_expr(&a.right)
            {
                side_effects.push(e.clone_in(ctx.ast.allocator));
                continue;
            }

            // Drop side-effect-free expressions (numbers/strings/etc).
            if is_safe_expr(e) {
                continue;
            }

            // Anything else is too risky to restructure.
            return None;
        }

        // Evaluate the key expression (decoder call) in V8 and require a string result.
        let key_code = expr_to_code(&member.expression);
        let key_wrapped = format!(
            "(()=>{{const __v = ({}); if (__v === null) return [0,null]; const __t = typeof __v; if (__t === 'string') return [1,__v]; return [4,__t];}})()",
            key_code
        );
        let key_value = match self.evaluator.eval(&key_wrapped) {
            Ok(v) => v,
            Err(_) => return None,
        };
        let serde_json::Value::Array(arr) = key_value else { return None };
        if arr.len() < 2 || arr[0].as_i64().unwrap_or(4) != 1 {
            return None;
        }
        let decoded_key = arr[1].as_str()?.to_string();

        // Build: (() => { var tmp = <obj>; <side_effects>; return tmp["decoded_key"](...args); })()
        let suggested = ctx.ast.atom("__dc_obj");
        let tmp_name = ctx.generate_uid_name(&suggested);

        let tmp_kind = ctx
            .ast
            .binding_pattern_kind_binding_identifier(SPAN, tmp_name);
        let tmp_binding = ctx.ast.binding_pattern(
            tmp_kind,
            None::<oxc::allocator::Box<'a, oxc::ast::ast::TSTypeAnnotation<'a>>>,
            false,
        );
        let tmp_decl = ctx.ast.variable_declarator(
            SPAN,
            VariableDeclarationKind::Var,
            tmp_binding,
            Some(member.object.clone_in(ctx.ast.allocator)),
            false,
        );
        let tmp_stmt = Statement::VariableDeclaration(ctx.ast.alloc_variable_declaration(
            SPAN,
            VariableDeclarationKind::Var,
            ctx.ast.vec1(tmp_decl),
            false,
        ));

        let mut stmts = ctx.ast.vec();
        stmts.push(tmp_stmt);
        for se in side_effects {
            stmts.push(ctx.ast.statement_expression(SPAN, se));
        }

        let tmp_read = ctx.ast.expression_identifier(SPAN, tmp_name);
        let key_lit =
            ctx.ast
                .expression_string_literal(SPAN, ctx.ast.atom(&decoded_key), None);
        let member_callee =
            Expression::ComputedMemberExpression(ctx.ast.alloc_computed_member_expression(
                call.span,
                tmp_read,
                key_lit,
                false,
            ));
        let invoked = ctx.ast.expression_call(
            call.span,
            member_callee,
            call.type_arguments.clone_in(ctx.ast.allocator),
            call.arguments.clone_in(ctx.ast.allocator),
            false,
        );
        stmts.push(ctx.ast.statement_return(SPAN, Some(invoked)));

        let params = ctx.ast.alloc_formal_parameters(
            SPAN,
            FormalParameterKind::ArrowFormalParameters,
            ctx.ast.vec(),
            None::<oxc::allocator::Box<'a, oxc::ast::ast::BindingRestElement<'a>>>,
        );
        let body = ctx.ast.alloc_function_body(SPAN, ctx.ast.vec(), stmts);
        let arrow = ctx.ast.expression_arrow_function(
            call.span,
            false,
            false,
            None::<oxc::allocator::Box<'a, oxc::ast::ast::TSTypeParameterDeclaration<'a>>>,
            params,
            None::<oxc::allocator::Box<'a, oxc::ast::ast::TSTypeAnnotation<'a>>>,
            body,
        );
        let arrow_paren = ctx.ast.expression_parenthesized(call.span, arrow);

        Some(ctx.ast.expression_call(
            call.span,
            arrow_paren,
            None::<oxc::allocator::Box<'a, oxc::ast::ast::TSTypeParameterInstantiation<'a>>>,
            ctx.ast.vec(),
            false,
        ))
    }

    // JSON → AST conversion uses the shared helper in `crate::eval::value_to_expr`.
}

impl<'a, 'e> Traverse<'a, ()> for CallInliner<'e> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        if self.is_in_protected_span(expr.span()) {
            return;
        }

        let Expression::CallExpression(call) = expr else { return };

        // Special-case: obj[decoder((a=1,b=2,"ENC"))](...) where the sequence arg is just noise.
        // We inline the decoder result while preserving the assignments by moving them into an IIFE,
        // which also enables later DCE to delete truly-dead assignments.
        if let Some(repl) = self.try_inline_computed_member_decoder_call(&*call, ctx) {
            *expr = repl;
            self.modifications += 1;
            return;
        }

        // UNIVERSAL PATTERN: Normalize callee expressions before processing.
        // Handle patterns like `(var = func)(args)` -> `func(args)`
        // This must happen FIRST, before any other processing.
        let scoping = ctx.scoping();
        let callee_unwrapped = CallCalleeCollector::unwrap_paren(&call.callee);
        
        // Pattern: (var = func)(args) -> func(args)
        if let Expression::AssignmentExpression(assign) = callee_unwrapped {
            if assign.operator == AssignmentOperator::Assign {
                // Extract the function from the assignment's RHS
                if let Expression::Identifier(func_ident) = &assign.right {
                    // Track the alias for later resolution
                    if let AssignmentTarget::AssignmentTargetIdentifier(var_ident) = &assign.left {
                        if let (Some(var_sym), Some(func_sym)) = (
                            get_reference_symbol(scoping, var_ident),
                            get_reference_symbol(scoping, func_ident),
                        ) {
                            // Record alias - this helps with other patterns that might reference the variable
                            self.alias_map.insert(var_sym, func_sym);
                        }
                    }
                    // Replace callee with the function identifier
                    call.callee = Expression::Identifier(func_ident.clone_in(ctx.ast.allocator));
                    self.modifications += 1;
                }
            }
        }

        // Always clean sequence arguments with dead assignments, regardless of whether
        // the call will be inlined. This makes dead assignments available for DCE.
        let scoping = ctx.scoping();
        let mut cleaned_args: Vec<Option<Argument<'a>>> = call.arguments
            .iter()
            .map(|arg| {
                let arg_expr = arg.to_expression();
                let unwrapped = CallCalleeCollector::unwrap_paren(arg_expr);
                
                // If argument is a sequence with dead assignments, extract just the last expression.
                if let Expression::SequenceExpression(seq) = unwrapped {
                    if seq.expressions.len() > 1 {
                        let (head, last) = seq.expressions.split_at(seq.expressions.len() - 1);
                        
                        // Check if all leading expressions are dead assignments or safe.
                        let all_dead_or_safe = head.iter().all(|e| {
                            let e = CallCalleeCollector::unwrap_paren(e);
                            is_safe_expr(e) || CallCalleeCollector::is_dead_simple_assignment(e, scoping)
                        });
                        
                        if all_dead_or_safe {
                            // Extract the last expression and convert it to an Argument.
                            let last_expr = last[0].clone_in(ctx.ast.allocator);
                            return Some(Argument::from(last_expr));
                        }
                    }
                }
                
                None
            })
            .collect();

        // Apply cleaned arguments to the call AST if any were cleaned.
        let mut args_changed = false;
        for (i, cleaned_arg) in cleaned_args.iter_mut().enumerate() {
            if let Some(new_arg) = cleaned_arg.take() {
                call.arguments[i] = new_arg;
                args_changed = true;
            }
        }

        // If we cleaned arguments, count it as a modification and continue
        // (the call might still be inlined below if it's in allowed_callees).
        if args_changed {
            self.modifications += 1;
        }

        // Now check if this call should be inlined.
        // After normalization, callee should be an identifier (or we return early).
        let Expression::Identifier(ident) = &call.callee else { return };
        let Some(sym) = get_reference_symbol(ctx.scoping(), ident) else { return };
        let resolved_sym = self.resolve_callee(sym);
        if !self.allowed_callees.contains(&resolved_sym) {
            return;
        }
        if !Self::args_are_safe(&call.arguments, ctx.scoping()) {
            return;
        }

        // If callee was resolved through an alias, replace it with the actual function identifier
        // so the runtime can find it (e.g., `_q19(...)` -> `_u275(...)`).
        let scoping = ctx.scoping();
        if resolved_sym != sym {
            let resolved_name = scoping.symbol_name(resolved_sym);
            // Replace the callee identifier with the resolved function name
            let resolved_ident = ctx.ast.expression_identifier(call.callee.span(), ctx.ast.atom(resolved_name));
            call.callee = resolved_ident;
            self.modifications += 1; // Count alias resolution as a modification
        }

        // Build code for evaluation (arguments may have been cleaned above, callee may have been resolved).
        let code = expr_to_code(expr);
        if let Some(v) = self.cache.get(&code).cloned() {
            if let Some(repl) = value_to_expr(v, ctx.ast.allocator) {
                *expr = repl;
                self.modifications += 1;
            }
            return;
        }

        // Only try to serialize primitives; never attempt to serialize arbitrary objects/functions.
        let wrapped = format!(
            "(()=>{{const __v = ({}); if (__v === null) return [0,null]; const __t = typeof __v; if (__t === 'string') return [1,__v]; if (__t === 'number') return [2,__v]; if (__t === 'boolean') return [3,__v]; return [4,__t];}})()",
            code
        );

        let value = match self.evaluator.eval(&wrapped) {
            Ok(v) => v,
            Err(e) => {
                debug!(code = %code, error = %e, "EvalCallInliner: eval failed");
                return;
            }
        };

        let serde_json::Value::Array(arr) = value else { return };
        if arr.len() < 2 {
            return;
        }
        let tag = arr[0].as_i64().unwrap_or(4);
        if tag == 4 {
            // non-primitive / unsupported
            return;
        }
        let prim = arr[1].clone();

        let Some(repl) = value_to_expr(prim.clone(), ctx.ast.allocator) else { return };
        self.cache.insert(code, prim);
        *expr = repl;
        self.modifications += 1;
    }
}

/// Compute transitive dependency closure for a symbol.
fn collect_closure(
    root: SymbolId,
    defs: &FxHashMap<SymbolId, DefInfo>,
    out: &mut FxHashSet<SymbolId>,
    budget: usize,
) {
    if out.len() >= budget {
        return;
    }
    if !out.insert(root) {
        return;
    }
    let Some(info) = defs.get(&root) else { return };
    for dep in info.deps.iter().copied() {
        if out.len() >= budget {
            return;
        }
        if defs.contains_key(&dep) {
            collect_closure(dep, defs, out, budget);
        }
    }
}

/// Prepare a runtime by defining the provided symbol closure.
fn define_runtime(
    evaluator: &mut JsEvaluator,
    defs: &FxHashMap<SymbolId, DefInfo>,
    symbols: &FxHashSet<SymbolId>,
) {
    // Define all function declarations first.
    for sym in symbols.iter().copied() {
        let Some(info) = defs.get(&sym) else { continue };
        if info.kind == DefKind::Function {
            let _ = evaluator.execute(&info.code);
        }
    }

    // Define vars iteratively (order can matter).
    let mut remaining: Vec<SymbolId> = symbols
        .iter()
        .copied()
        .filter(|s| defs.get(s).is_some_and(|d| d.kind == DefKind::VarInit))
        .collect();

    // Best-effort: retry a few times for ordering.
    for _ in 0..8 {
        if remaining.is_empty() {
            break;
        }
        let mut next = Vec::new();
        let mut progressed = false;
        for sym in remaining {
            let Some(info) = defs.get(&sym) else { continue };
            match evaluator.execute(&info.code) {
                Ok(_) => progressed = true,
                Err(_) => next.push(sym),
            }
        }
        remaining = next;
        if !progressed {
            break;
        }
    }
}

/// EvalCallInliner module.
pub struct EvalCallInliner {
    timeout_ms: u64,
}

impl EvalCallInliner {
    pub fn new() -> Self {
        Self { timeout_ms: 2000 }
    }

    pub fn with_timeout(timeout_ms: u64) -> Self {
        Self { timeout_ms }
    }
}

impl Default for EvalCallInliner {
    fn default() -> Self {
        Self::new()
    }
}

impl Module for EvalCallInliner {
    fn name(&self) -> &'static str {
        "EvalCallInliner"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Collect string-array symbols so we can avoid decoding functions dependent on rotated arrays.
        let mut array_collector = ArrayFunctionCollector::new();
        let scoping = traverse_mut(&mut array_collector, allocator, program, scoping, ());
        let array_map = array_collector.into_map();
        let array_symbols: FxHashSet<SymbolId> = array_map.keys().copied().collect();

        // Protect string-array machinery spans from any eval-based inlining.
        // This prevents corrupting shufflers/arrays/accessors, which can lead to wrong strings in
        // later passes when StringArrayDecoder executes them again.
        let mut protected_spans: Vec<Span> = Vec::new();
        protected_spans.extend(array_map.values().map(|a| a.span));

        let mut shuffler_collector = ShufflerCollector::new(&array_map);
        let scoping = traverse_mut(&mut shuffler_collector, allocator, program, scoping, ());
        let shuffler_map = shuffler_collector.into_map();
        protected_spans.extend(shuffler_map.values().map(|s| s.statement_span));
        protected_spans.extend(shuffler_map.values().map(|s| s.iife_span));

        let mut accessor_collector = AccessorCollector::new(&array_map);
        let scoping = traverse_mut(&mut accessor_collector, allocator, program, scoping, ());
        let accessor_map = accessor_collector.into_map();
        protected_spans.extend(accessor_map.values().map(|a| a.span));

        // Collect definitions and dependency info.
        let mut def_collector = DefinitionCollector::new();
        let scoping = traverse_mut(&mut def_collector, allocator, program, scoping, ());
        let defs = def_collector.into_defs();

        // Find local callees with safe args, and collect aliases.
        let mut call_collector = CallCalleeCollector::new();
        let scoping = traverse_mut(&mut call_collector, allocator, program, scoping, ());
        let (called, alias_map) = call_collector.into_parts();

        // Choose which callees are safe-ish to inline: must have a definition, and must NOT depend
        // (transitively) on string-array functions.
        let mut allowed_callees: FxHashSet<SymbolId> = FxHashSet::default();
        let mut symbols_to_define: FxHashSet<SymbolId> = FxHashSet::default();

        for callee in called.iter().copied() {
            if !defs.contains_key(&callee) {
                continue;
            }
            // Build dependency closure for this callee.
            let mut closure: FxHashSet<SymbolId> = FxHashSet::default();
            collect_closure(callee, &defs, &mut closure, 256);

            // Exclude string-array dependent callees (these should be handled by StringArrayDecoder).
            if closure.iter().any(|s| array_symbols.contains(s)) {
                continue;
            }

            allowed_callees.insert(callee);
            symbols_to_define.extend(closure.iter().copied());
        }

        // Nothing to do.
        if allowed_callees.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        // Prepare runtime.
        let mut evaluator = JsEvaluator::with_timeout(self.timeout_ms);
        define_runtime(&mut evaluator, &defs, &symbols_to_define);

        // Inline call sites.
        let mut inliner = CallInliner::new(&mut evaluator, allowed_callees, alias_map, protected_spans);
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        Ok(TransformResult {
            modifications: inliner.modifications,
            scoping,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    fn run_module(source: &str) -> (String, usize) {
        let allocator = Allocator::default();
        let source_type = SourceType::cjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        assert!(ret.errors.is_empty(), "Parse errors: {:?}", ret.errors);
        let mut program = ret.program;
        let scoping = SemanticBuilder::new().build(&program).semantic.into_scoping();

        let mut module = EvalCallInliner::with_timeout(2000);
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        let code = Codegen::new().build(&program).code;
        (code, result.modifications)
    }

    #[test]
    fn inlines_xor_base64_decoder_calls() {
        let source = r#"
var r = (function () {
  try { if (atob && "test" === atob("dGVzdA==")) return atob; } catch (r) {}
  function r(r) { this.message = r; }
  (r.prototype = new Error()), (r.prototype.name = "InvalidCharacterError");
  return function (v) {
    var u = String(v).replace(/[=]+$/, "");
    if (u.length % 4 == 1) throw new r("'atob' failed");
    for (var n, t, f = 0, e = 0, c = ""; (t = u.charAt(e++)); ~t && ((n = f % 4 ? 64 * n + t : t), f++ % 4) ? (c += String.fromCharCode(255 & (n >> ((-2 * f) & 6)))) : 0)
      t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".indexOf(t);
    return c;
  };
})();
var v = Object.create(null);
function u(u) {
  var n = v[u];
  if (n) f = n;
  else {
    for (var t = r(u), f = "", e = 0; e < t.length; ++e) {
      var c = "Yztf4Fd".charCodeAt(e % 7);
      f += String.fromCharCode(c ^ t.charCodeAt(e));
    }
    v[u] = f;
  }
  return f;
}
var x = u("BgoMJ0Q2LT0");
"#;
        let (code, mods) = run_module(source);
        assert!(mods > 0, "Expected modifications > 0");
        assert!(
            code.contains(r#"var x = "_pxAppId";"#) || code.contains(r#"var x = '_pxAppId';"#),
            "Expected inlined string literal, got: {}",
            code
        );
    }
}


