//! Alias inliner module.
//!
//! Inlines identifier aliases at their use sites.
//!
//! Handles:
//!   var a = b; use(a)           → use(b)
//!   var x = window; x.foo       → window.foo
//!   var f = console.log; f()    → console.log()
//!
//! Chains with ConstantPropagator:
//!   var x = 5; var y = x; use(y) → use(5)
//!   (ConstantProp inlines x=5, then AliasInliner sees y=5)
//!
//! Does NOT handle:
//!   - Literals (handled by ConstantPropagator)
//!   - Variables with writes

use oxc::allocator::{Allocator, CloneIn};
use oxc::ast::ast::{Expression, Program};
use oxc::semantic::{Scoping, SymbolId};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::utils::symbols::get_reference_symbol;

pub struct AliasInliner;

impl Module for AliasInliner {
    fn name(&self) -> &'static str {
        "AliasInliner"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Pass 1: Collect aliases
        let mut collector = Collector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        if collector.aliases.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        // Pass 2: Inline aliases
        let mut inliner = Inliner {
            aliases: collector.aliases,
            modifications: 0,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        Ok(TransformResult {
            modifications: inliner.modifications,
            scoping,
        })
    }
}

// ============================================================================
// Pass 1: Collect aliases
// ============================================================================

#[derive(Default)]
struct Collector<'a> {
    aliases: FxHashMap<SymbolId, Expression<'a>>,
}

impl<'a> Traverse<'a, ()> for Collector<'a> {
    fn enter_variable_declarator(
        &mut self,
        node: &mut oxc::ast::ast::VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Need an initializer
        let Some(init) = &node.init else { return };

        // Need a simple binding (not destructuring)
        let Some(binding) = node.id.get_binding_identifier() else { return };
        let Some(symbol_id) = binding.symbol_id.get() else { return };

        // Check if init is an alias-able expression
        if !is_aliasable(init) {
            return;
        }

        // Check: no writes to this variable
        let scoping = ctx.scoping();
        let has_writes = scoping
            .get_resolved_references(symbol_id)
            .any(|r| r.flags().is_write());

        if has_writes {
            return;
        }

        // Collect it
        self.aliases
            .insert(symbol_id, init.clone_in(ctx.ast.allocator));
    }
}

// ============================================================================
// Pass 2: Inline aliases
// ============================================================================

struct Inliner<'a> {
    aliases: FxHashMap<SymbolId, Expression<'a>>,
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for Inliner<'a> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {

        // Standard alias inlining: replace identifier with its alias
        let Expression::Identifier(ident) = expr else { return };

        // Get symbol for this reference
        let Some(symbol_id) = get_reference_symbol(ctx.scoping(), ident) else { return };

        // Check if we have an alias for this symbol
        let Some(alias) = self.aliases.get(&symbol_id) else { return };

        // Replace with the alias value
        *expr = alias.clone_in(ctx.ast.allocator);
        self.modifications += 1;
    }
}

// ============================================================================
// Helpers
// ============================================================================

/// Check if an expression can be safely aliased (inlined at use sites).
fn is_aliasable(expr: &Expression) -> bool {
    match expr {
        // Identifiers: var a = b
        Expression::Identifier(_) => true,

        // Member expressions: var a = window.foo, var a = obj["prop"]
        Expression::StaticMemberExpression(_) | Expression::ComputedMemberExpression(_) => true,

        // This expression: var self = this
        Expression::ThisExpression(_) => true,

        // Parenthesized: var a = (b)
        Expression::ParenthesizedExpression(p) => is_aliasable(&p.expression),

        // Don't alias literals (ConstantPropagator handles those)
        // Don't alias calls, objects, arrays (side effects or too complex)
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    fn transform(source: &str) -> (String, usize) {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;
        let semantic = SemanticBuilder::new().build(&program).semantic;
        let scoping = semantic.into_scoping();

        let mut module = AliasInliner;
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        let code = Codegen::new().build(&program).code;
        (code, result.modifications)
    }

    #[test]
    fn test_simple_identifier() {
        let (code, mods) = transform("var a = b; console.log(a);");
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(b)"), "got: {}", code);
    }

    #[test]
    fn test_member_expression() {
        let (code, mods) = transform("var log = console.log; log('hello');");
        assert_eq!(mods, 1);
        assert!(code.contains("console.log("), "got: {}", code);
    }

    #[test]
    fn test_computed_member() {
        let (code, mods) = transform(r#"var x = obj["prop"]; use(x);"#);
        assert_eq!(mods, 1);
        assert!(code.contains(r#"use(obj["prop"])"#), "got: {}", code);
    }

    #[test]
    fn test_this_expression() {
        let (code, mods) = transform("var self = this; self.foo();");
        assert_eq!(mods, 1);
        assert!(code.contains("this.foo()"), "got: {}", code);
    }

    #[test]
    fn test_no_inline_with_write() {
        let (code, mods) = transform("var a = b; a = c; console.log(a);");
        assert_eq!(mods, 0);
        assert!(code.contains("console.log(a)"), "got: {}", code);
    }

    #[test]
    fn test_no_inline_literal() {
        // Literals should be handled by ConstantPropagator, not AliasInliner
        let (code, mods) = transform("var x = 5; console.log(x);");
        assert_eq!(mods, 0);
        assert!(code.contains("console.log(x)"), "got: {}", code);
    }

    #[test]
    fn test_multiple_uses() {
        let (code, mods) = transform("var a = b; use(a, a, a);");
        assert_eq!(mods, 3);
        assert!(code.contains("use(b, b, b)"), "got: {}", code);
    }

    #[test]
    fn test_chain_alias() {
        // var a = b; var c = a; use(c)
        // Pass 1: a is aliased to b, c is aliased to a
        // - "var c = a" → "var c = b" (a replaced with b)
        // - "use(c)" → "use(a)" (c replaced with a, not b - chains need multiple passes)
        // The convergence loop will handle full chain resolution
        let (code, mods) = transform("var a = b; var c = a; use(c);");
        assert_eq!(mods, 2);
        assert!(code.contains("var c = b"), "got: {}", code);
        // use(c) becomes use(a), next pass would make it use(b)
        assert!(code.contains("use(a)"), "got: {}", code);
    }

}
