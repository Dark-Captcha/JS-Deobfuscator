//! Constant propagation module.
//!
//! Inlines constant literal values at their use sites.
//!
//! Handles:
//!   var x = 5; use(x)           → use(5)
//!   var x = "str"; use(x)       → use("str")
//!   var x = -42; use(x)         → use(-42)
//!   var x = (1, 2, 3); use(x)   → use(3)  (sequence expr last value)
//!
//! Does NOT handle (leave to other modules):
//!   - Identifier aliases (var a = b) → AliasInliner
//!   - Object properties (var o = {a:1}) → ObjectFlattener
//!   - Function calls → StaticEvaluator

use oxc::allocator::Allocator;
use oxc::ast::ast::{Expression, Program};
use oxc::semantic::{Scoping, SymbolId};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::utils::symbols::get_reference_symbol;
use crate::utils::literal::{LiteralValue, extract_literal_value, literal_value_to_expression};

pub struct ConstantPropagator;

impl Module for ConstantPropagator {
    fn name(&self) -> &'static str {
        "ConstantPropagator"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Pass 1: Collect constant values
        let mut collector = Collector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        if collector.constants.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        // Pass 2: Inline collected values
        let mut inliner = Inliner {
            constants: collector.constants,
            modifications: 0,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        Ok(TransformResult {
            modifications: inliner.modifications,
            scoping,
        })
    }
}

// ============================================================================
// Pass 1: Collect constants
// ============================================================================

#[derive(Default)]
struct Collector {
    constants: FxHashMap<SymbolId, LiteralValue>,
}

impl<'a> Traverse<'a, ()> for Collector {
    fn enter_variable_declarator(
        &mut self,
        node: &mut oxc::ast::ast::VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Need an initializer
        let Some(init) = &node.init else { return };

        // Need a simple binding (not destructuring)
        let Some(binding) = node.id.get_binding_identifier() else { return };
        let Some(symbol_id) = binding.symbol_id.get() else { return };

        // Extract literal value (handles sequence expressions)
        let Some(literal) = extract_literal_value(init) else { return };

        // Check: no writes to this variable (declaration doesn't count as write in OXC)
        let scoping = ctx.scoping();
        let has_writes = scoping
            .get_resolved_references(symbol_id)
            .any(|r| r.flags().is_write());

        if has_writes {
            return;
        }

        // Collect it
        self.constants
            .insert(symbol_id, literal);
    }
}

// ============================================================================
// Pass 2: Inline constants
// ============================================================================

struct Inliner {
    constants: FxHashMap<SymbolId, LiteralValue>,
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for Inliner {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Only process identifiers
        let Expression::Identifier(ident) = expr else { return };

        // Get symbol for this reference
        let Some(symbol_id) = get_reference_symbol(ctx.scoping(), ident) else { return };

        // Check if we have a constant for this symbol
        let Some(constant) = self.constants.get(&symbol_id) else { return };

        // Replace with the constant value
        *expr = literal_value_to_expression(constant, ctx.ast);
        self.modifications += 1;
    }
}

// ============================================================================
// Helpers
// ============================================================================

// (literal extraction lives in `crate::utils::literal`.)

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    fn transform(source: &str) -> (String, usize) {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;
        let semantic = SemanticBuilder::new().build(&program).semantic;
        let scoping = semantic.into_scoping();

        let mut module = ConstantPropagator;
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        let code = Codegen::new().build(&program).code;
        (code, result.modifications)
    }

    #[test]
    fn test_simple_number() {
        let (code, mods) = transform("var x = 5; console.log(x);");
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(5)"), "got: {}", code);
    }

    #[test]
    fn test_simple_string() {
        let (code, mods) = transform(r#"var x = "hello"; console.log(x);"#);
        assert_eq!(mods, 1);
        assert!(code.contains(r#"console.log("hello")"#), "got: {}", code);
    }

    #[test]
    fn test_negative_number() {
        let (code, mods) = transform("var x = -42; console.log(x);");
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(-42)"), "got: {}", code);
    }

    #[test]
    fn test_sequence_expression() {
        let (code, mods) = transform("var x = (1, 2, 3); console.log(x);");
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(3)"), "got: {}", code);
    }

    #[test]
    fn test_no_inline_with_write() {
        let (code, mods) = transform("var x = 5; x = 10; console.log(x);");
        assert_eq!(mods, 0);
        assert!(code.contains("console.log(x)"), "got: {}", code);
    }

    #[test]
    fn test_multiple_uses() {
        let (code, mods) = transform("var x = 5; console.log(x, x, x);");
        assert_eq!(mods, 3);
        assert!(code.contains("console.log(5, 5, 5)"), "got: {}", code);
    }

    #[test]
    fn test_no_inline_identifier() {
        // Identifier aliases should be handled by AliasInliner, not here
        let (code, mods) = transform("var a = b; console.log(a);");
        assert_eq!(mods, 0);
        assert!(code.contains("console.log(a)"), "got: {}", code);
    }
}
