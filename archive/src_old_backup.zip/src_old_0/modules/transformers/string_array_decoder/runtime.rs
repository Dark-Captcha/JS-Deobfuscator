//! V8 runtime preparation for StringArrayDecoder.
//!
//! Responsibilities:
//! - Create the `JsEvaluator` with the module's timeout
//! - Install a best-effort `push/shift` loop guard while executing shufflers
//! - Define array functions and accessors in the runtime
//! - Execute shuffler IIFEs to rotate arrays
//! - Restore native Array methods before subsequent evaluation/inlining

use crate::eval::JsEvaluator;

use super::types::{AccessorMap, ArrayMap, ShufflerMap};

const DEFAULT_TIMEOUT_MS: u64 = 5_000;

const ITER_GUARD_INSTALL: &str = r#"
var __dc_iter = 0;
var __dc_maxIter = 200000;
var __dc_orig_push = Array.prototype.push;
var __dc_orig_shift = Array.prototype.shift;
Array.prototype.push = function() {
  if (++__dc_iter > __dc_maxIter) throw new Error("StringArrayDecoder: max iterations exceeded");
  return __dc_orig_push.apply(this, arguments);
};
Array.prototype.shift = function() {
  if (++__dc_iter > __dc_maxIter) throw new Error("StringArrayDecoder: max iterations exceeded");
  return __dc_orig_shift.apply(this, arguments);
};
"#;

const ITER_GUARD_RESTORE: &str = r#"
if (typeof __dc_orig_push !== "undefined") Array.prototype.push = __dc_orig_push;
if (typeof __dc_orig_shift !== "undefined") Array.prototype.shift = __dc_orig_shift;
"#;

/// RAII helper that restores native Array methods even if we early-return.
///
/// Note: This guard **owns** the evaluator so we can safely restore before returning the runtime
/// to the inliner stage (otherwise we'd keep instrumented `push/shift` during inlining).
struct ArrayProtoIterGuard {
    evaluator: Option<JsEvaluator>,
    armed: bool,
}

impl ArrayProtoIterGuard {
    fn new(mut evaluator: JsEvaluator) -> Self {
        // Best-effort instrumentation: cap `push/shift`-driven shuffle loops.
        // We still rely on the evaluator timeout as the ultimate safety net.
        let _ = evaluator.execute(ITER_GUARD_INSTALL);
        Self {
            evaluator: Some(evaluator),
            armed: true,
        }
    }

    #[inline]
    fn evaluator_mut(&mut self) -> &mut JsEvaluator {
        self.evaluator
            .as_mut()
            .expect("ArrayProtoIterGuard: evaluator missing")
    }

    fn restore_now(&mut self) {
        if !self.armed {
            return;
        }
        if let Some(eval) = self.evaluator.as_mut() {
            let _ = eval.execute(ITER_GUARD_RESTORE);
        }
        self.armed = false;
    }

    fn into_evaluator(mut self) -> JsEvaluator {
        self.restore_now();
        self.evaluator
            .take()
            .expect("ArrayProtoIterGuard: evaluator missing")
    }
}

impl Drop for ArrayProtoIterGuard {
    fn drop(&mut self) {
        self.restore_now();
    }
}

/// Prepare a `JsEvaluator` for string-array decoding:
/// - Define all array functions and accessor functions
/// - Execute all shuffler IIFEs (with `push/shift` loop guard)
/// - Restore native Array methods before returning
pub(crate) fn prepare_string_array_runtime(
    array_map: &ArrayMap,
    accessor_map: &AccessorMap,
    shuffler_map: &ShufflerMap,
) -> JsEvaluator {
    let evaluator = JsEvaluator::with_timeout(DEFAULT_TIMEOUT_MS);
    let mut guard = ArrayProtoIterGuard::new(evaluator);

    // Define array functions.
    let mut _array_defs_ok = 0usize;
    let mut _array_defs_err = 0usize;
    for array_info in array_map.values() {
        if let Err(e) = guard.evaluator_mut().execute(&array_info.code) {
            _array_defs_err += 1;
            tracing::warn!(
                "Failed to define array function {} in JsEvaluator: {}",
                array_info.name,
                e
            );
        } else {
            _array_defs_ok += 1;
        }
    }

    // Define accessors (needed by many shufflers for checksum conditions).
    let mut _accessor_defs_ok = 0usize;
    let mut _accessor_defs_err = 0usize;
    for accessor_info in accessor_map.values() {
        if let Err(e) = guard.evaluator_mut().execute(&accessor_info.code) {
            _accessor_defs_err += 1;
            tracing::warn!(
                "Failed to define accessor {} in JsEvaluator: {}",
                accessor_info.name,
                e
            );
        } else {
            _accessor_defs_ok += 1;
        }
    }

    // Execute shufflers to rotate arrays.
    let mut _shufflers_ok = 0usize;
    let mut _shufflers_err = 0usize;
    for shuffler_info in shuffler_map.values() {
        // Reset iteration counter per shuffler (multiple arrays may exist).
        let _ = guard.evaluator_mut().execute("__dc_iter = 0;");
        if let Err(e) = guard.evaluator_mut().execute(&shuffler_info.code) {
            _shufflers_err += 1;
            tracing::warn!(
                "Failed to execute shuffler for array symbol {:?}: {}",
                shuffler_info.array_symbol,
                e
            );
        } else {
            _shufflers_ok += 1;
        }
    }

    // Restore native Array methods before non-shuffler evaluation (inlining).
    guard.into_evaluator()
}





