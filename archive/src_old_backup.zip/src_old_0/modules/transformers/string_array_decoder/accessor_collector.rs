//! Accessor function collector for the String Array Decoder.
//!
//! Detects functions that retrieve strings from collected array functions.
//!
//! **Design note:** We intentionally do *not* re-implement decoding logic (base64/xor/rot/etc.)
//! here. We only identify likely accessor functions and collect their JS definition source so
//! the inliner can execute the real code in V8 via `JsEvaluator`.

use oxc::ast::ast::{Expression, Function, FunctionBody, Statement, VariableDeclarator};
use oxc::semantic::SymbolId;
use oxc::span::GetSpan;
use oxc_traverse::{Traverse, TraverseCtx};

use crate::eval::expr_to_code;
use crate::utils::ast::function_to_code;
use crate::utils::symbols::get_reference_symbol;

use super::types::{AccessorInfo, AccessorMap, ArrayMap};

/// Collector for accessor functions.
pub struct AccessorCollector<'m> {
    /// Reference to known array functions.
    array_map: &'m ArrayMap,
    /// Collected accessors: accessor_symbol → info.
    accessors: AccessorMap,
    /// Track nesting (informational only; we intentionally do not restrict collection by depth).
    function_depth: usize,
}

impl<'m> AccessorCollector<'m> {
    pub fn new(array_map: &'m ArrayMap) -> Self {
        Self {
            array_map,
            accessors: AccessorMap::default(),
            function_depth: 0,
        }
    }

    pub fn into_map(self) -> AccessorMap {
        self.accessors
    }

    fn analyze_function_body<'a>(
        &self,
        body: &FunctionBody<'a>,
        ctx: &TraverseCtx<'a, ()>,
    ) -> Option<SymbolId> {
        self.analyze_function_body_with_context(body, ctx, None, None)
    }

    fn analyze_function_body_with_context<'a>(
        &self,
        body: &FunctionBody<'a>,
        ctx: &TraverseCtx<'a, ()>,
        outer_array_symbol: Option<SymbolId>,
        outer_array_var: Option<SymbolId>,
    ) -> Option<SymbolId> {
        // Track: variable holding `arr()` result + its array function symbol.
        let mut array_var: Option<SymbolId> = outer_array_var;
        let mut array_symbol: Option<SymbolId> = outer_array_symbol;

        // Pass 1: find `var x = arr()` (or `let/const`), so we can recognize `x[...]`.
        for stmt in &body.statements {
            let Statement::VariableDeclaration(decl) = stmt else { continue };
            for declarator in &decl.declarations {
                let Some(init) = &declarator.init else { continue };
                let Some(arr_sym) = self.get_array_call_symbol(init, ctx) else { continue };

                array_symbol = Some(arr_sym);
                if let Some(binding) = declarator.id.get_binding_identifier()
                    && let Some(var_sym) = binding.symbol_id.get()
                {
                    array_var = Some(var_sym);
                }
            }
        }

        // Pass 2: look for computed member access into the array, or self-reassignment accessors.
        for stmt in &body.statements {
            match stmt {
                Statement::ReturnStatement(ret) => {
                    if let Some(arg) = &ret.argument {
                        if let Some(sym) =
                            self.detect_accessor_from_expr(arg, array_var, array_symbol, ctx)
                        {
                            return Some(sym);
                        }
                        if let Some(sym) = self.check_self_reassignment_accessor_with_context(
                            arg,
                            ctx,
                            array_symbol,
                            array_var,
                        ) {
                            return Some(sym);
                        }
                    }
                }
                Statement::VariableDeclaration(decl) => {
                    for declarator in &decl.declarations {
                        let Some(init) = &declarator.init else { continue };
                        if let Some(sym) =
                            self.detect_accessor_from_expr(init, array_var, array_symbol, ctx)
                        {
                            return Some(sym);
                        }
                    }
                }
                _ => {}
            }
        }

        None
    }

    fn detect_accessor_from_expr<'a>(
        &self,
        expr: &Expression<'a>,
        array_var: Option<SymbolId>,
        array_symbol: Option<SymbolId>,
        ctx: &TraverseCtx<'a, ()>,
    ) -> Option<SymbolId> {
        match expr {
            Expression::ParenthesizedExpression(p) => {
                self.detect_accessor_from_expr(&p.expression, array_var, array_symbol, ctx)
            }

            Expression::ComputedMemberExpression(member) => {
                let arr_sym = array_symbol?;

                // Case 1: `var a = arr(); return a[...];`
                if let (Some(array_var_sym), Expression::Identifier(obj_ident)) =
                    (array_var, &member.object)
                {
                    let obj_sym = get_reference_symbol(ctx.scoping(), obj_ident)?;
                    if obj_sym == array_var_sym {
                        return Some(arr_sym);
                    }
                }

                // Case 2: `return arr()[...];`
                if let Expression::CallExpression(call) = &member.object
                    && let Expression::Identifier(callee_ident) = &call.callee
                    && let Some(sym) = get_reference_symbol(ctx.scoping(), callee_ident)
                    && sym == arr_sym
                {
                    return Some(arr_sym);
                }

                None
            }

            _ => None,
        }
    }

    /// Check if expression is a call to a known array function.
    fn get_array_call_symbol<'a>(
        &self,
        expr: &Expression<'a>,
        ctx: &TraverseCtx<'a, ()>,
    ) -> Option<SymbolId> {
        let Expression::CallExpression(call) = expr else { return None };
        let Expression::Identifier(ident) = &call.callee else { return None };

        let symbol_id = get_reference_symbol(ctx.scoping(), ident)?;
        self.array_map.contains_key(&symbol_id).then_some(symbol_id)
    }

    /// Check for self-reassignment accessor patterns where a function returns an IIFE/sequence
    /// that assigns a new function and immediately calls it.
    fn check_self_reassignment_accessor_with_context<'a>(
        &self,
        expr: &Expression<'a>,
        ctx: &TraverseCtx<'a, ()>,
        outer_array_symbol: Option<SymbolId>,
        outer_array_var: Option<SymbolId>,
    ) -> Option<SymbolId> {
        match expr {
            // Pattern: (fn = function(...) { ... })(...)
            Expression::CallExpression(call) => {
                let callee = match &call.callee {
                    Expression::ParenthesizedExpression(p) => &p.expression,
                    other => other,
                };

                let Expression::AssignmentExpression(assign) = callee else { return None };
                let Expression::FunctionExpression(func) = &assign.right else { return None };
                let body = func.body.as_ref()?;
                self.analyze_function_body_with_context(body, ctx, outer_array_symbol, outer_array_var)
            }

            // Pattern: ((fn = function(...) { ... }), fn(...))
            Expression::SequenceExpression(seq) => {
                for sub_expr in &seq.expressions {
                    let assign = match sub_expr {
                        Expression::AssignmentExpression(a) => Some(a),
                        Expression::ParenthesizedExpression(p) => {
                            if let Expression::AssignmentExpression(a) = &p.expression {
                                Some(a)
                            } else {
                                None
                            }
                        }
                        _ => None,
                    };

                    let Some(assign) = assign else { continue };
                    let Expression::FunctionExpression(func) = &assign.right else { continue };
                    let body = func.body.as_ref()?;
                    if let Some(sym) =
                        self.analyze_function_body_with_context(body, ctx, outer_array_symbol, outer_array_var)
                    {
                        return Some(sym);
                    }
                }
                None
            }

            // Unwrap parentheses
            Expression::ParenthesizedExpression(p) => self.check_self_reassignment_accessor_with_context(
                &p.expression,
                ctx,
                outer_array_symbol,
                outer_array_var,
            ),

            _ => None,
        }
    }

    fn code_for_function<'a>(&self, func: &Function<'a>) -> String {
        function_to_code(func)
    }

    fn code_for_var_init<'a>(&self, name: &str, init: &Expression<'a>) -> String {
        format!("var {} = {};", name, expr_to_code(init))
    }
}

impl<'a, 'm> Traverse<'a, ()> for AccessorCollector<'m> {
    fn enter_function(&mut self, func: &mut Function<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Track nesting depth for debugging, but DO NOT restrict collection to top-level.
        // Obfuscated code commonly defines accessors inside an IIFE wrapper.
        let _depth = self.function_depth;
        self.function_depth += 1;

        let Some(symbol_id) = func.id.as_ref().and_then(|id| id.symbol_id.get()) else { return };
        let Some(name) = func.id.as_ref().map(|id| id.name.to_string()) else { return };
        let Some(body) = &func.body else { return };

        let Some(array_symbol) = self.analyze_function_body(body, ctx) else { return };

        let code = self.code_for_function(func);
        self.accessors.insert(
            symbol_id,
            AccessorInfo {
                symbol_id,
                span: func.span,
                name,
                array_symbol,
                code,
            },
        );
    }

    fn exit_function(&mut self, _func: &mut Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        self.function_depth = self.function_depth.saturating_sub(1);
    }

    fn enter_variable_declarator(
        &mut self,
        node: &mut VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let Some(init) = &node.init else { return };
        let Some(binding) = node.id.get_binding_identifier() else { return };
        let Some(symbol_id) = binding.symbol_id.get() else { return };
        let name = binding.name.to_string();

        let array_symbol = match init {
            Expression::FunctionExpression(func) => func
                .body
                .as_ref()
                .and_then(|body| self.analyze_function_body(body, ctx)),
            Expression::ArrowFunctionExpression(arrow) => self.analyze_function_body(&arrow.body, ctx),
            _ => None,
        };
        let Some(array_symbol) = array_symbol else { return };

        let code = self.code_for_var_init(&name, init);
        self.accessors.insert(
            symbol_id,
            AccessorInfo {
                symbol_id,
                span: init.span(),
                name,
                array_symbol,
                code,
            },
        );
    }
}


