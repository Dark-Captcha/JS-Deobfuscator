//! Post-deob cleanup for string-array obfuscation artifacts.
//!
//! Why this exists:
//! - The main `StringArrayDecoder` intentionally **does not** remove array/accessor/shuffler code
//!   during the convergence loop, because later modules can expose new call-sites in later passes.
//! - The global `DeadCodeEliminator` also won't remove shuffler IIFEs because they look side-effectful
//!   (e.g. `a().push(a().shift())`), even when the strings are fully inlined.
//!
//! This module runs **after** convergence (post-deob stage) and removes:
//! - Unused accessor functions
//! - Unused array functions
//! - Shuffler IIFE statements for unused arrays

use oxc::allocator::{Allocator, TakeIn};
use oxc::ast::ast::{Expression, Program, Statement};
use oxc::semantic::{Scoping, SymbolId};
use oxc::span::{GetSpan, Span};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::{FxHashMap, FxHashSet};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};

use super::accessor_collector::AccessorCollector;
use super::array_collector::ArrayFunctionCollector;
use super::shuffler_collector::ShufflerCollector;
use crate::utils::span::span_in;

/// Post-deob cleaner for string-array artifacts.
pub struct StringArrayPostCleaner;

impl Module for StringArrayPostCleaner {
    fn name(&self) -> &'static str {
        "StringArrayPostCleaner"
    }

    fn changes_symbols(&self) -> bool {
        true
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Collect array functions.
        let mut array_collector = ArrayFunctionCollector::new();
        let scoping = traverse_mut(&mut array_collector, allocator, program, scoping, ());
        let array_map = array_collector.into_map();
        if array_map.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        // Collect shuffler statements for those arrays.
        let mut shuffler_collector = ShufflerCollector::new(&array_map);
        let scoping = traverse_mut(&mut shuffler_collector, allocator, program, scoping, ());
        let shuffler_map = shuffler_collector.into_map();

        // Collect accessors for those arrays.
        let mut accessor_collector = AccessorCollector::new(&array_map);
        let scoping = traverse_mut(&mut accessor_collector, allocator, program, scoping, ());
        let accessor_map = accessor_collector.into_map();

        // -----------------------------------------------------------------
        // Compute liveness by scanning identifier references and ignoring:
        // - References inside shuffler statements (they're artifacts)
        // - Self references inside the definition span of the symbol itself
        // - References inside accessor definitions that we will remove (for array liveness)
        // -----------------------------------------------------------------

        let shuffler_statement_spans: Vec<Span> =
            shuffler_map.values().map(|s| s.statement_span).collect();

        let accessor_symbols: FxHashSet<SymbolId> = accessor_map.keys().copied().collect();
        let accessor_spans: FxHashMap<SymbolId, Span> = accessor_map
            .iter()
            .map(|(sym, info)| (*sym, info.span))
            .collect();

        let array_symbols: FxHashSet<SymbolId> = array_map.keys().copied().collect();
        let array_spans: FxHashMap<SymbolId, Span> =
            array_map.iter().map(|(sym, info)| (*sym, info.span)).collect();

        // Pass A: Find accessors that are used outside shuffler statements.
        let mut accessor_use = SymbolUseCollector::new(
            accessor_symbols.clone(),
            accessor_spans.clone(),
            shuffler_statement_spans.clone(),
        );
        let scoping = traverse_mut(&mut accessor_use, allocator, program, scoping, ());
        let live_accessors = accessor_use.live;
        let dead_accessors: FxHashSet<SymbolId> = accessor_symbols
            .difference(&live_accessors)
            .copied()
            .collect();

        // Build ignore spans for array liveness: shufflers + dead accessor spans.
        let mut ignore_for_arrays = shuffler_statement_spans;
        ignore_for_arrays.extend(dead_accessors.iter().filter_map(|sym| accessor_spans.get(sym).copied()));

        // Pass B: Find arrays that are used outside shufflers / dead accessors.
        let mut array_use =
            SymbolUseCollector::new(array_symbols.clone(), array_spans.clone(), ignore_for_arrays);
        let scoping = traverse_mut(&mut array_use, allocator, program, scoping, ());
        let live_arrays = array_use.live;
        let dead_arrays: FxHashSet<SymbolId> =
            array_symbols.difference(&live_arrays).copied().collect();

        // Shufflers are removable when their array is removable.
        let mut spans_to_remove: FxHashSet<Span> = FxHashSet::default();
        for shuffler in shuffler_map.values() {
            if dead_arrays.contains(&shuffler.array_symbol) {
                spans_to_remove.insert(shuffler.statement_span);
            }
        }

        let mut symbols_to_remove: FxHashSet<SymbolId> = FxHashSet::default();
        symbols_to_remove.extend(dead_accessors);
        symbols_to_remove.extend(dead_arrays);

        if symbols_to_remove.is_empty() && spans_to_remove.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        let mut cleaner = Cleaner {
            symbols_to_remove,
            spans_to_remove,
            modifications: 0,
        };
        let scoping = traverse_mut(&mut cleaner, allocator, program, scoping, ());

        Ok(TransformResult {
            modifications: cleaner.modifications,
            scoping,
        })
    }
}

// ============================================================================
// Liveness scanning
// ============================================================================

struct SymbolUseCollector {
    targets: FxHashSet<SymbolId>,
    own_spans: FxHashMap<SymbolId, Span>,
    ignore_spans: Vec<Span>,
    live: FxHashSet<SymbolId>,
}

impl SymbolUseCollector {
    fn new(
        targets: FxHashSet<SymbolId>,
        own_spans: FxHashMap<SymbolId, Span>,
        ignore_spans: Vec<Span>,
    ) -> Self {
        Self {
            targets,
            own_spans,
            ignore_spans,
            live: FxHashSet::default(),
        }
    }

    fn is_ignored(&self, symbol: SymbolId, span: Span) -> bool {
        if let Some(own) = self.own_spans.get(&symbol) {
            if span_in(span, *own) {
                return true;
            }
        }
        self.ignore_spans.iter().any(|s| span_in(span, *s))
    }
}

impl<'a> Traverse<'a, ()> for SymbolUseCollector {
    fn enter_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let Expression::Identifier(ident) = expr else { return };
        let Some(symbol_id) = crate::utils::symbols::get_reference_symbol(ctx.scoping(), ident) else {
            return;
        };
        if !self.targets.contains(&symbol_id) {
            return;
        }

        let span = ident.span;
        if self.is_ignored(symbol_id, span) {
            return;
        }

        self.live.insert(symbol_id);
    }
}

// ============================================================================
// Statement cleanup
// ============================================================================

struct Cleaner {
    symbols_to_remove: FxHashSet<SymbolId>,
    spans_to_remove: FxHashSet<Span>,
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for Cleaner {
    fn exit_statements(
        &mut self,
        statements: &mut oxc::allocator::Vec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let allocator = ctx.ast.allocator;
        let mut out = ctx.ast.vec();

        for mut stmt in statements.take_in(allocator) {
            // Remove entire shuffler statement by span.
            if self.spans_to_remove.contains(&stmt.span()) {
                self.modifications += 1;
                continue;
            }

            match &mut stmt {
                // Function declarations.
                Statement::FunctionDeclaration(func) => {
                    let sym = func.id.as_ref().and_then(|id| id.symbol_id.get());
                    if sym.is_some_and(|s| self.symbols_to_remove.contains(&s)) {
                        self.modifications += 1;
                        continue;
                    }
                    out.push(stmt);
                }

                // Variable declarations. Remove only the declarators we know are dead.
                Statement::VariableDeclaration(var_decl) => {
                    let before = var_decl.declarations.len();
                    let mut kept = ctx.ast.vec();
                    for decl in var_decl.declarations.take_in(allocator) {
                        let remove = decl
                            .id
                            .get_binding_identifier()
                            .and_then(|b| b.symbol_id.get())
                            .is_some_and(|s| self.symbols_to_remove.contains(&s));

                        if remove {
                            self.modifications += 1;
                        } else {
                            kept.push(decl);
                        }
                    }

                    if kept.is_empty() {
                        // Entire statement removed.
                        if before > 0 {
                            self.modifications += 1;
                        }
                        continue;
                    }

                    var_decl.declarations = kept;
                    out.push(stmt);
                }

                // Keep everything else.
                _ => out.push(stmt),
            }
        }

        *statements = out;
    }
}


