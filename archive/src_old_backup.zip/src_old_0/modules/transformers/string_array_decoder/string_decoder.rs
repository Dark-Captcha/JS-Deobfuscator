//! String decoding utilities for the String Array Decoder.
//!
//! Provides functions to decode various encoding schemes used by obfuscators:
//! - Standard base64 (A-Za-z0-9+/=)
//! - Custom base64 (a-zA-Z0-9+/=, lowercase first)
//! - URL encoding (%XX)
//! - JavaScript parseInt semantics

use std::collections::HashMap;

/// Standard base64 alphabet (uppercase first).
const BASE64_STANDARD: &str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/// Custom base64 alphabet (lowercase first) - used by some obfuscators.
const BASE64_CUSTOM: &str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/";

/// String decoder utilities.
pub struct StringDecoder;

impl StringDecoder {
    /// Decode standard base64 (A-Za-z0-9+/=).
    pub fn decode_base64_standard(encoded: &str) -> Result<String, &'static str> {
        Self::decode_base64_with_alphabet(encoded, BASE64_STANDARD)
    }

    /// Decode custom base64 (a-zA-Z0-9+/=, lowercase first).
    pub fn decode_base64_custom(encoded: &str) -> Result<String, &'static str> {
        Self::decode_base64_with_alphabet(encoded, BASE64_CUSTOM)
    }

    /// Decode base64 with a custom alphabet.
    fn decode_base64_with_alphabet(encoded: &str, alphabet: &str) -> Result<String, &'static str> {
        // Build reverse lookup table
        let mut lookup: HashMap<char, u8> = HashMap::new();
        for (i, c) in alphabet.chars().enumerate() {
            lookup.insert(c, i as u8);
        }

        // Remove padding and whitespace
        let encoded: String = encoded.chars().filter(|c| !c.is_whitespace()).collect();
        let encoded = encoded.trim_end_matches('=');

        if encoded.is_empty() {
            return Ok(String::new());
        }

        // Decode
        let mut bytes = Vec::new();
        let chars: Vec<char> = encoded.chars().collect();
        let mut i = 0;

        while i < chars.len() {
            let mut value: u32 = 0;
            let mut bits = 0;

            // Collect up to 4 characters (24 bits)
            for _ in 0..4 {
                if i >= chars.len() {
                    break;
                }

                let c = chars[i];
                if let Some(&v) = lookup.get(&c) {
                    value = (value << 6) | (v as u32);
                    bits += 6;
                    i += 1;
                } else {
                    return Err("Invalid base64 character");
                }
            }

            // Extract bytes
            while bits >= 8 {
                bits -= 8;
                bytes.push(((value >> bits) & 0xFF) as u8);
            }
        }

        String::from_utf8(bytes).map_err(|_| "Invalid UTF-8 in decoded string")
    }

    /// Decode URL encoding (%XX patterns).
    pub fn url_decode(s: &str) -> String {
        let mut result = String::with_capacity(s.len());
        let mut chars = s.chars().peekable();

        while let Some(c) = chars.next() {
            if c == '%' {
                // Try to read two hex digits
                let hex: String = chars.by_ref().take(2).collect();
                if hex.len() == 2 {
                    if let Ok(byte) = u8::from_str_radix(&hex, 16) {
                        result.push(byte as char);
                        continue;
                    }
                }
                // Invalid escape, keep original
                result.push('%');
                result.push_str(&hex);
            } else if c == '+' {
                // + is space in URL encoding
                result.push(' ');
            } else {
                result.push(c);
            }
        }

        result
    }

    /// Parse integer using JavaScript parseInt semantics.
    ///
    /// JavaScript's parseInt(s, 10):
    /// - Skips leading whitespace
    /// - Handles optional sign (+ or -)
    /// - Extracts only leading digits
    /// - Returns NaN (we return 0) if no digits found
    pub fn parse_int_js(s: &str) -> i64 {
        let s = s.trim_start();

        if s.is_empty() {
            return 0;
        }

        let mut chars = s.chars().peekable();
        let mut negative = false;

        // Handle sign
        if let Some(&c) = chars.peek() {
            if c == '-' {
                negative = true;
                chars.next();
            } else if c == '+' {
                chars.next();
            }
        }

        // Extract digits
        let mut result: i64 = 0;
        let mut found_digit = false;

        while let Some(&c) = chars.peek() {
            if let Some(digit) = c.to_digit(10) {
                found_digit = true;
                result = result.saturating_mul(10).saturating_add(digit as i64);
                chars.next();
            } else {
                break;
            }
        }

        if !found_digit {
            return 0; // NaN in JS
        }

        if negative {
            -result
        } else {
            result
        }
    }

    /// Try to decode a string using various methods.
    /// Returns the decoded string or the original if decoding fails.
    pub fn try_decode(s: &str, use_custom_base64: bool) -> String {
        // First try base64
        let base64_result = if use_custom_base64 {
            Self::decode_base64_custom(s)
        } else {
            Self::decode_base64_standard(s)
        };

        if let Ok(decoded) = base64_result {
            // Then apply URL decoding
            return Self::url_decode(&decoded);
        }

        // Return original if decoding fails
        s.to_string()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_base64_standard_decode() {
        assert_eq!(
            StringDecoder::decode_base64_standard("SGVsbG8gV29ybGQ=").unwrap(),
            "Hello World"
        );
        assert_eq!(
            StringDecoder::decode_base64_standard("dGVzdA==").unwrap(),
            "test"
        );
    }

    #[test]
    fn test_base64_custom_decode() {
        // Custom alphabet: lowercase first
        // "Hello" in custom base64
        let _encoded = "sGVsbG8="; // This would be different with custom alphabet
        // Note: actual encoding depends on the alphabet mapping
    }

    #[test]
    fn test_url_decode() {
        assert_eq!(StringDecoder::url_decode("hello%20world"), "hello world");
        assert_eq!(StringDecoder::url_decode("test%2Fpath"), "test/path");
        assert_eq!(StringDecoder::url_decode("a+b"), "a b");
        assert_eq!(StringDecoder::url_decode("no%encoding"), "no%encoding"); // Invalid escape
    }

    #[test]
    fn test_parse_int_js() {
        assert_eq!(StringDecoder::parse_int_js("123"), 123);
        assert_eq!(StringDecoder::parse_int_js("-456"), -456);
        assert_eq!(StringDecoder::parse_int_js("+789"), 789);
        assert_eq!(StringDecoder::parse_int_js("  42"), 42);
        assert_eq!(StringDecoder::parse_int_js("123abc"), 123);
        assert_eq!(StringDecoder::parse_int_js("abc"), 0); // NaN → 0
        assert_eq!(StringDecoder::parse_int_js(""), 0);
        assert_eq!(StringDecoder::parse_int_js("12.34"), 12);
    }
}
