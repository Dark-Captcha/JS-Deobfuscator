//! Array function collector for the String Array Decoder.
//!
//! Detects functions that return arrays of string literals.
//! Handles multiple patterns:
//! - Direct return: `function f() { return ["a", "b"]; }`
//! - Variable + return: `function f() { var r = ["a", "b"]; return r; }`
//! - Self-reassignment: `function f() { var r = [...]; return (f = function() { return r; })(); }`

use oxc::ast::ast::{
    ArrayExpressionElement, BindingPatternKind, Expression, Function, FunctionBody, Statement,
    VariableDeclarator,
};
use oxc::semantic::SymbolId;
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::FxHashMap;

use crate::eval::expr_to_code;
use crate::utils::symbols::get_reference_symbol;
use crate::utils::ast::function_to_code;

use super::types::{ArrayFunctionInfo, ArrayMap};

/// Collector for array functions.
pub struct ArrayFunctionCollector {
    /// Collected array functions: symbol_id → info
    arrays: ArrayMap,
    /// Current function being analyzed (for nested function handling)
    current_function: Option<SymbolId>,
    /// Track nesting (informational only; we intentionally do not restrict collection by depth).
    function_depth: usize,
}

impl ArrayFunctionCollector {
    pub fn new() -> Self {
        Self {
            arrays: FxHashMap::default(),
            current_function: None,
            function_depth: 0,
        }
    }

    pub fn into_map(self) -> ArrayMap {
        self.arrays
    }

    /// Extract strings from an array expression.
    fn extract_strings(elements: &[ArrayExpressionElement]) -> Option<Vec<String>> {
        let mut strings = Vec::with_capacity(elements.len());

        for elem in elements {
            match elem {
                ArrayExpressionElement::StringLiteral(lit) => {
                    strings.push(lit.value.to_string());
                }
                // Skip non-string elements but track position
                ArrayExpressionElement::SpreadElement(_) => return None,
                ArrayExpressionElement::Elision(_) => {
                    strings.push(String::new()); // Placeholder for elision
                }
                _ => {
                    // Non-string element - still collect but mark as empty
                    strings.push(String::new());
                }
            }
        }

        // Only return if we have at least some strings
        if strings.iter().any(|s| !s.is_empty()) {
            Some(strings)
        } else {
            None
        }
    }

    /// Check if an expression is an array of strings.
    fn get_array_strings(expr: &Expression) -> Option<Vec<String>> {
        match expr {
            Expression::ArrayExpression(arr) => Self::extract_strings(&arr.elements),
            Expression::ParenthesizedExpression(p) => Self::get_array_strings(&p.expression),
            _ => None,
        }
    }

    /// Analyze a function body to find array returns.
    fn analyze_function_body<'a>(
        &self,
        body: &FunctionBody<'a>,
        ctx: &TraverseCtx<'a, ()>,
    ) -> Option<Vec<String>> {
        // Look for variable declarations with array initializers
        let mut array_var: Option<(SymbolId, Vec<String>)> = None;

        for stmt in &body.statements {
            match stmt {
                // Pattern 1: Direct return of array
                Statement::ReturnStatement(ret) => {
                    if let Some(arg) = &ret.argument {
                        // Check for direct array return
                        if let Some(strings) = Self::get_array_strings(arg) {
                            return Some(strings);
                        }

                        // Check for return of variable that holds array
                        if let Expression::Identifier(ident) = arg {
                            if let Some(symbol_id) = get_reference_symbol(ctx.scoping(), ident) {
                                if let Some((var_symbol, strings)) = &array_var {
                                    if symbol_id == *var_symbol {
                                        return Some(strings.clone());
                                    }
                                }
                            }
                        }

                        // Check for self-reassignment pattern: (fn = function() { return r; })()
                        // or comma pattern: (fn = function() { return r; }, fn())
                        if let Some(strings) = self.check_comma_or_call_pattern(arg, &array_var) {
                            return Some(strings);
                        }
                    }
                }

                // Pattern 2: Variable declaration with array
                Statement::VariableDeclaration(decl) => {
                    for declarator in &decl.declarations {
                        if let Some(init) = &declarator.init {
                            if let Some(strings) = Self::get_array_strings(init) {
                                if let BindingPatternKind::BindingIdentifier(binding) = &declarator.id.kind {
                                    if let Some(symbol_id) = binding.symbol_id.get() {
                                        array_var = Some((symbol_id, strings));
                                    }
                                }
                            }
                        }
                    }
                }

                _ => {}
            }
        }

        None
    }

    /// Check for self-reassignment pattern: `return (fn = function() { return r; })()`
    fn check_self_reassignment(
        &self,
        expr: &Expression,
        array_var: &Option<(SymbolId, Vec<String>)>,
    ) -> Option<Vec<String>> {
        // Look for CallExpression with AssignmentExpression callee
        let Expression::CallExpression(call) = expr else { return None };

        // Unwrap parentheses
        let callee = match &call.callee {
            Expression::ParenthesizedExpression(p) => &p.expression,
            other => other,
        };

        // Check for assignment expression
        let Expression::AssignmentExpression(assign) = callee else { return None };

        // The right side should be a function expression
        let Expression::FunctionExpression(func) = &assign.right else { return None };

        // Check if the function returns the array variable
        if let Some(body) = &func.body {
            for stmt in &body.statements {
                if let Statement::ReturnStatement(ret) = stmt {
                    if let Some(arg) = &ret.argument {
                        if let Expression::Identifier(_) = arg {
                            // This returns a variable - if we have an array var, return its strings
                            // The inner function captures the outer variable
                            if let Some((_, strings)) = array_var {
                                return Some(strings.clone());
                            }
                        }
                    }
                }
            }
        }

        None
    }

    /// Check for comma expression pattern: `return (fn = function() { return r; }, fn())`
    /// or just `return (fn = function() { return r; })()`
    fn check_comma_or_call_pattern(
        &self,
        expr: &Expression,
        array_var: &Option<(SymbolId, Vec<String>)>,
    ) -> Option<Vec<String>> {
        match expr {
            // Direct call pattern: (fn = function() { return r; })()
            Expression::CallExpression(_) => self.check_self_reassignment(expr, array_var),
            
            // Comma pattern: (fn = function() { return r; }, fn())
            Expression::SequenceExpression(seq) => {
                // Check if any part of the sequence is a self-reassignment
                for sub_expr in &seq.expressions {
                    if let Some(strings) = self.check_self_reassignment(sub_expr, array_var) {
                        return Some(strings);
                    }
                }
                None
            }
            
            _ => None,
        }
    }

    fn code_for_var_init<'a>(&self, name: &str, init: &Expression<'a>) -> String {
        format!("var {} = {};", name, expr_to_code(init))
    }
}

impl<'a> Traverse<'a, ()> for ArrayFunctionCollector {
    fn enter_function(&mut self, func: &mut Function<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Track nesting depth for debugging, but DO NOT restrict collection to top-level.
        // Real-world obfuscated code (e.g. captcha.js) typically wraps everything in an IIFE.
        let _depth = self.function_depth;
        self.function_depth += 1;

        // Get function symbol
        let symbol_id = func.id.as_ref().and_then(|id| id.symbol_id.get());
        if let Some(symbol_id) = symbol_id {
            self.current_function = Some(symbol_id);

            // Analyze function body
            if let Some(body) = &func.body {
                if let Some(strings) = self.analyze_function_body(body, ctx) {
                    // Only collect if we have a reasonable number of strings (likely obfuscated)
                    if strings.len() >= 5 {
                        let name = func.id.as_ref().map(|id| id.name.to_string()).unwrap_or_default();
                        
                        // Generate code for this function using Codegen
                        let code = function_to_code(func);
                        
                        self.arrays.insert(
                            symbol_id,
                            ArrayFunctionInfo {
                                symbol_id,
                                name,
                                strings,
                                span: func.span,
                                code,
                            },
                        );
                    }
                }
            }
        }
    }

    fn exit_function(&mut self, _func: &mut Function<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        self.current_function = None;
        self.function_depth = self.function_depth.saturating_sub(1);
    }

    fn enter_variable_declarator(
        &mut self,
        node: &mut VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let Some(init) = &node.init else { return };
        let Some(binding) = node.id.get_binding_identifier() else { return };
        let Some(symbol_id) = binding.symbol_id.get() else { return };
        let name = binding.name.to_string();

        // Only consider function-valued variables.
        let strings = match init {
            Expression::FunctionExpression(func) => func
                .body
                .as_ref()
                .and_then(|body| self.analyze_function_body(body, ctx)),
            Expression::ArrowFunctionExpression(arrow) => self.analyze_function_body(&arrow.body, ctx),
            _ => None,
        };

        let Some(strings) = strings else { return };
        if strings.len() < 5 {
            return;
        }

        let code = self.code_for_var_init(&name, init);

        self.arrays.insert(
            symbol_id,
            ArrayFunctionInfo {
                symbol_id,
                name,
                strings,
                span: node.span,
                code,
            },
        );
    }
}
