//! Shuffler IIFE collector for the String Array Decoder.
//!
//! Detects IIFEs that rotate string arrays using push(shift()) pattern.
//! Handles multiple patterns:
//! - Parenthesized: `(function(r, v) { ... })(arrayFunc)`
//! - Unary prefix: `!(function(r, v) { ... })(arrayFunc)`
//! - Various loop constructs: for(;;), while(true), while(1)

use oxc::ast::ast::{
    CallExpression, Expression, FunctionBody, Statement, UnaryOperator,
};
use oxc::semantic::SymbolId;
use oxc::span::{GetSpan, Span};
use oxc_traverse::{Traverse, TraverseCtx};

use crate::eval::expr_to_code;
use crate::utils::symbols::get_reference_symbol;

use super::types::{ArrayMap, ShufflerInfo, ShufflerMap};

/// Collector for shuffler IIFEs.
pub struct ShufflerCollector<'m> {
    /// Reference to known array functions
    array_map: &'m ArrayMap,
    /// Collected shufflers: array_symbol → info
    shufflers: ShufflerMap,
    /// Current statement span (for removal tracking)
    current_statement_span: Option<Span>,
}

impl<'m> ShufflerCollector<'m> {
    pub fn new(array_map: &'m ArrayMap) -> Self {
        Self {
            array_map,
            shufflers: ShufflerMap::default(),
            current_statement_span: None,
        }
    }

    pub fn into_map(self) -> ShufflerMap {
        self.shufflers
    }

    /// Check if a function body contains push(shift()) pattern.
    fn has_push_shift_pattern(body: &FunctionBody) -> bool {
        Self::search_push_shift_in_statements(&body.statements)
    }

    /// Recursively search for push(shift()) in statements.
    fn search_push_shift_in_statements(statements: &[Statement]) -> bool {
        for stmt in statements {
            if Self::search_push_shift_in_statement(stmt) {
                return true;
            }
        }
        false
    }

    /// Search for push(shift()) in a single statement.
    fn search_push_shift_in_statement(stmt: &Statement) -> bool {
        match stmt {
            Statement::ExpressionStatement(expr_stmt) => {
                Self::is_push_shift_call(&expr_stmt.expression)
            }

            Statement::ForStatement(for_stmt) => {
                if let Statement::BlockStatement(body) = &for_stmt.body {
                    Self::search_push_shift_in_statements(&body.body)
                } else {
                    Self::search_push_shift_in_statement(&for_stmt.body)
                }
            }

            Statement::WhileStatement(while_stmt) => {
                if let Statement::BlockStatement(body) = &while_stmt.body {
                    Self::search_push_shift_in_statements(&body.body)
                } else {
                    Self::search_push_shift_in_statement(&while_stmt.body)
                }
            }

            Statement::DoWhileStatement(do_while) => {
                if let Statement::BlockStatement(body) = &do_while.body {
                    Self::search_push_shift_in_statements(&body.body)
                } else {
                    Self::search_push_shift_in_statement(&do_while.body)
                }
            }

            Statement::TryStatement(try_stmt) => {
                Self::search_push_shift_in_statements(&try_stmt.block.body)
                    || try_stmt
                        .handler
                        .as_ref()
                        .map(|h| Self::search_push_shift_in_statements(&h.body.body))
                        .unwrap_or(false)
            }

            Statement::BlockStatement(block) => {
                Self::search_push_shift_in_statements(&block.body)
            }

            Statement::IfStatement(if_stmt) => {
                let in_consequent = if let Statement::BlockStatement(block) = &if_stmt.consequent {
                    Self::search_push_shift_in_statements(&block.body)
                } else {
                    Self::search_push_shift_in_statement(&if_stmt.consequent)
                };

                let in_alternate = if_stmt
                    .alternate
                    .as_ref()
                    .map(|alt| {
                        if let Statement::BlockStatement(block) = alt {
                            Self::search_push_shift_in_statements(&block.body)
                        } else {
                            Self::search_push_shift_in_statement(alt)
                        }
                    })
                    .unwrap_or(false);

                in_consequent || in_alternate
            }

            _ => false,
        }
    }

    /// Check if an expression is a push(shift()) call.
    /// Pattern: arr.push(arr.shift())
    fn is_push_shift_call(expr: &Expression) -> bool {
        let Expression::CallExpression(call) = expr else { return false };

        // Check for .push() call
        let Expression::StaticMemberExpression(member) = &call.callee else { return false };
        if member.property.name != "push" {
            return false;
        }

        // Check argument is .shift() call
        if call.arguments.len() != 1 {
            return false;
        }

        let Some(arg) = call.arguments.first() else { return false };
        let arg_expr = match arg {
            oxc::ast::ast::Argument::SpreadElement(_) => return false,
            _ => arg.to_expression(),
        };

        let Expression::CallExpression(shift_call) = arg_expr else { return false };
        let Expression::StaticMemberExpression(shift_member) = &shift_call.callee else { return false };

        shift_member.property.name == "shift"
    }

    /// Extract array function symbol from IIFE arguments.
    fn get_array_symbol_from_args<'a>(
        &self,
        call: &CallExpression<'a>,
        ctx: &TraverseCtx<'a, ()>,
    ) -> Option<SymbolId> {
        // First argument should be a reference to an array function
        let first_arg = call.arguments.first()?;
        let arg_expr = match first_arg {
            oxc::ast::ast::Argument::SpreadElement(_) => return None,
            _ => first_arg.to_expression(),
        };

        let Expression::Identifier(ident) = arg_expr else { return None };
        let symbol_id = get_reference_symbol(ctx.scoping(), ident)?;

        // Check if this symbol is a known array function
        if self.array_map.contains_key(&symbol_id) {
            Some(symbol_id)
        } else {
            None
        }
    }

    /// Process a potential shuffler IIFE.
    fn process_iife<'a>(
        &mut self,
        call: &CallExpression<'a>,
        iife_span: Span,
        code: String,
        ctx: &TraverseCtx<'a, ()>,
    ) {
        // Get the function expression (callee)
        let func_expr = match &call.callee {
            Expression::FunctionExpression(f) => Some(f),
            Expression::ParenthesizedExpression(p) => {
                if let Expression::FunctionExpression(f) = &p.expression {
                    Some(f)
                } else {
                    None
                }
            }
            _ => None,
        };

        let Some(func) = func_expr else { return };
        let Some(body) = &func.body else { return };

        // Check for push(shift()) pattern
        if !Self::has_push_shift_pattern(body) {
            return;
        }

        // Get the array function from arguments
        let Some(array_symbol) = self.get_array_symbol_from_args(call, ctx) else { return };

        // Record the shuffler
        let statement_span = self.current_statement_span.unwrap_or(iife_span);
        self.shufflers.insert(
            array_symbol,
            ShufflerInfo {
                array_symbol,
                statement_span,
                iife_span,
                code,
            },
        );
    }
}

impl<'a, 'm> Traverse<'a, ()> for ShufflerCollector<'m> {
    fn enter_statement(&mut self, stmt: &mut Statement<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        // Track statement span for removal
        self.current_statement_span = Some(stmt.span());
    }

    fn exit_statement(&mut self, _stmt: &mut Statement<'a>, _ctx: &mut TraverseCtx<'a, ()>) {
        self.current_statement_span = None;
    }

    fn enter_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Generate code first (immutable borrow)
        let code = expr_to_code(expr);

        match expr {
            // Pattern 1: Direct IIFE - (function(...) { ... })(args)
            Expression::CallExpression(call) => {
                let is_iife = matches!(
                    &call.callee,
                    Expression::FunctionExpression(_)
                        | Expression::ParenthesizedExpression(_)
                );

                if is_iife {
                    self.process_iife(call, call.span, code, ctx);
                }
            }

            // Pattern 2: Unary prefix - !(function(...) { ... })(args)
            Expression::UnaryExpression(unary) => {
                let is_iife_prefix = matches!(
                    unary.operator,
                    UnaryOperator::LogicalNot
                        | UnaryOperator::UnaryPlus
                        | UnaryOperator::UnaryNegation
                        | UnaryOperator::BitwiseNot
                        | UnaryOperator::Void
                );

                if is_iife_prefix {
                    if let Expression::CallExpression(call) = &unary.argument {
                        let is_iife = matches!(
                            &call.callee,
                            Expression::FunctionExpression(_)
                                | Expression::ParenthesizedExpression(_)
                        );

                        if is_iife {
                            self.process_iife(call, unary.span, code, ctx);
                        }
                    }
                }
            }

            _ => {}
        }
    }
}
