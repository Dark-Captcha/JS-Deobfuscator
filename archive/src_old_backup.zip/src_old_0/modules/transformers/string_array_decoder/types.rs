//! Data structures for the String Array Decoder module.

use oxc::semantic::SymbolId;
use oxc::span::Span;
use rustc_hash::FxHashMap;

/// Information about a detected array function.
///
/// Array functions are functions that return an array of encoded strings,
/// typically used by obfuscators to store string literals.
#[derive(Debug, Clone)]
pub struct ArrayFunctionInfo {
    /// The symbol ID of the array function.
    #[allow(dead_code)]
    pub symbol_id: SymbolId,
    /// The function name (for code generation).
    pub name: String,
    /// The original (unrotated) string array.
    #[allow(dead_code)]
    pub strings: Vec<String>,
    /// The AST node span for code generation.
    #[allow(dead_code)]
    pub span: Span,
    /// Generated JavaScript code for this function (for execution).
    pub code: String,
}

/// Information about a detected shuffler IIFE.
///
/// Shuffler IIFEs rotate the string array until a checksum condition is satisfied.
/// They contain a `push(shift())` pattern in a loop.
#[derive(Debug, Clone)]
pub struct ShufflerInfo {
    /// The array function this shuffler operates on.
    pub array_symbol: SymbolId,
    /// The span of the entire shuffler statement (for removal).
    #[allow(dead_code)]
    pub statement_span: Span,
    /// The span of the shuffler IIFE (for code generation).
    #[allow(dead_code)]
    pub iife_span: Span,
    /// Generated JavaScript code for this shuffler (for execution).
    pub code: String,
}

/// Information about an accessor function.
///
/// Accessor functions retrieve strings from the array by index,
/// applying an offset and optional base64 decoding.
#[derive(Debug, Clone)]
pub struct AccessorInfo {
    /// The symbol ID of the accessor function.
    #[allow(dead_code)]
    pub symbol_id: SymbolId,
    /// Span covering the accessor definition expression / function.
    ///
    /// Used by post-cleanup to ignore self-references when determining liveness.
    pub span: Span,
    /// The accessor binding name (for JS code generation / runtime execution).
    pub name: String,
    /// The array function this accessor uses.
    #[allow(dead_code)]
    pub array_symbol: SymbolId,
    /// Generated JavaScript code for this accessor definition.
    pub code: String,
}

// ============================================================================
// Type Aliases for Collection Maps
// ============================================================================

/// Array functions: symbol → info
pub type ArrayMap = FxHashMap<SymbolId, ArrayFunctionInfo>;

/// Shufflers: array_symbol → shuffler_info
pub type ShufflerMap = FxHashMap<SymbolId, ShufflerInfo>;

/// Accessors: accessor_symbol → accessor_info
pub type AccessorMap = FxHashMap<SymbolId, AccessorInfo>;
