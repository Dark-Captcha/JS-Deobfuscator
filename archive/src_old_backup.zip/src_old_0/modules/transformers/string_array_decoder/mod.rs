//! String Array Decoder module.
//!
//! Resolves rotated string arrays used by JavaScript obfuscators.
//! Uses an execution-based approach rather than pattern matching,
//! making it universal for any checksum algorithm.
//!
//! The module operates in multiple passes:
//! 1. Collection Phase: Detect array functions, shuffler IIFEs, and accessor functions
//! 2. Execution Phase: Generate and execute JavaScript to resolve rotated arrays
//! 3. Inlining Phase: Replace accessor calls with decoded string literals
//! 4. Cleanup Phase: Remove dead code (array functions, shufflers, accessors)

mod accessor_collector;
mod accessor_inliner;
mod array_collector;
mod protect;
mod post_cleaner;
mod runtime;
mod shuffler_collector;
mod string_decoder;
mod types;

use oxc::allocator::Allocator;
use oxc::ast::ast::Program;
use oxc::semantic::Scoping;
use oxc_traverse::traverse_mut;

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};

pub(crate) use self::accessor_collector::AccessorCollector;
use self::accessor_inliner::AccessorInliner;
pub(crate) use self::array_collector::ArrayFunctionCollector;
pub(crate) use self::shuffler_collector::ShufflerCollector;
use self::protect::collect_protected_spans;
use self::runtime::prepare_string_array_runtime;
use self::types::{AccessorMap, ArrayMap, ShufflerMap};

pub use self::string_decoder::StringDecoder as StringDecoderUtils;
pub use self::post_cleaner::StringArrayPostCleaner;

/// String Array Decoder - resolves rotated string arrays and inlines decoded strings.
pub struct StringArrayDecoder;

impl Module for StringArrayDecoder {
    fn name(&self) -> &'static str {
        "StringArrayDecoder"
    }

    fn changes_symbols(&self) -> bool {
        // We do not remove declarations in this module anymore (cleanup is handled by the global
        // DeadCodeEliminator once convergence is reached).
        false
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Pass 1: Collect array functions
        let mut array_collector = ArrayFunctionCollector::new();
        let scoping = traverse_mut(&mut array_collector, allocator, program, scoping, ());

        let array_map: ArrayMap = array_collector.into_map();
        if array_map.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        // Pass 2: Collect shuffler IIFEs
        let mut shuffler_collector = ShufflerCollector::new(&array_map);
        let scoping = traverse_mut(&mut shuffler_collector, allocator, program, scoping, ());
        let shuffler_map: ShufflerMap = shuffler_collector.into_map();

        // Pass 3: Collect accessor functions
        let mut accessor_collector = AccessorCollector::new(&array_map);
        let scoping = traverse_mut(&mut accessor_collector, allocator, program, scoping, ());
        let accessor_map: AccessorMap = accessor_collector.into_map();

        if accessor_map.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        // Execution Phase: Prepare runtime (array funcs + accessors + shufflers) in V8.
        // This includes a best-effort `push/shift` loop guard during shuffler execution and
        // restores native Array methods before inlining.
        let mut evaluator = prepare_string_array_runtime(&array_map, &accessor_map, &shuffler_map);

        // Pass 4: Inline accessor calls by executing the real call expression in V8.
        //
        // Protect decoder machinery (array defs + shuffler IIFEs) from mutation; otherwise
        // later passes may execute a simplified/no-op shuffler and produce wrong strings.
        let protected_spans = collect_protected_spans(&array_map, &shuffler_map);
        let mut inliner = AccessorInliner::new(&accessor_map, &mut evaluator, protected_spans);
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());
        let modifications = inliner.modifications();

        // Pass 5: Dead-code cleanup
        //
        // IMPORTANT (debug): Do NOT remove array/accessor/shuffler code here.
        // In `main.min.js`, later modules (AliasInliner/ProxyInliner/etc.) can expose
        // new accessor call sites *after* this module runs in a pass. If we remove
        // accessors/arrays eagerly, subsequent passes cannot inline newly-exposed
        // calls (e.g. `_Qp(417)`), and the output becomes broken (call sites remain,
        // but definitions are gone).
        //
        // We rely on the global `DeadCodeEliminator` module to remove unused code
        // once no references remain across the whole convergence loop.

        Ok(TransformResult {
            modifications,
            scoping,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::allocator::Allocator;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    #[test]
    fn shuffler_can_depend_on_accessor() {
        let source = r#"
function arr() {
  var a = ["1","2","3","4","5"];
  return (arr = function(){ return a; })();
}

function get(i) {
  var a = arr();
  return a[i];
}

(function(a){
  for(;;){
    try{
      if (parseInt(get(0)) === 2) break;
      a().push(a().shift());
    } catch(e) {
      a().push(a().shift());
    }
  }
})(arr);

console.log(get(0));
"#;

        let allocator = Allocator::default();
        let source_type = SourceType::cjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        assert!(ret.errors.is_empty(), "Parse errors: {:?}", ret.errors);

        let mut program = ret.program;
        let semantic = SemanticBuilder::new().build(&program).semantic;
        let scoping = semantic.into_scoping();

        let mut module = StringArrayDecoder;
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        assert!(result.modifications > 0, "Expected at least 1 modification");

        let code = Codegen::new().build(&program).code;

        // We should have inlined `get(0)` after executing the shuffler.
        assert!(
            code.contains(r#""2""#) || code.contains(r#"'2'"#),
            "Expected decoded string literal in output, got: {}",
            code
        );
    }
}
