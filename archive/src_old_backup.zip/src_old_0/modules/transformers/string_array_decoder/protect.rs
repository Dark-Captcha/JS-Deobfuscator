//! Protected-span computation for StringArrayDecoder.
//!
//! We must avoid mutating decoder machinery (array defs + shuffler IIFEs) while inlining,
//! otherwise later passes may execute a modified shuffler and produce wrong strings.

use oxc::span::Span;

use super::types::{ArrayMap, ShufflerMap};

/// Collect spans that the inliner should not mutate.
///
/// Kept behavior-identical to the previous inline logic:
/// - array function definition spans
/// - shuffler IIFE spans
pub(crate) fn collect_protected_spans(array_map: &ArrayMap, shuffler_map: &ShufflerMap) -> Vec<Span> {
    let mut spans = Vec::with_capacity(array_map.len() + shuffler_map.len());
    spans.extend(array_map.values().map(|a| a.span));
    spans.extend(shuffler_map.values().map(|s| s.iife_span));
    spans
}





