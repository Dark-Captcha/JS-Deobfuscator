//! Accessor inliner for the String Array Decoder.
//!
//! Replaces accessor function calls with decoded string literals by **executing**
//! the real accessor call in V8 (`JsEvaluator`).
//!
//! This avoids hardcoding specific decoding schemes (offset/base64/xor/rot/etc).

use oxc::ast::ast::{Argument, Expression};
use oxc::semantic::SymbolId;
use oxc::span::{GetSpan, Span, SPAN};
use oxc_traverse::{Traverse, TraverseCtx};
use rustc_hash::FxHashMap;
use rustc_hash::FxHashSet;

use crate::eval::{expr_to_code, is_safe_expr, JsEvaluator};
use crate::utils::symbols::get_reference_symbol;
use crate::utils::span::span_in;

use super::types::AccessorMap;

/// Inliner for accessor function calls.
pub struct AccessorInliner<'m, 'e> {
    /// Reference to accessor function info.
    accessor_map: &'m AccessorMap,
    /// Shared evaluator instance with the string-array runtime prepared.
    evaluator: &'e mut JsEvaluator,
    /// Cache: call_code → decoded string.
    cache: FxHashMap<String, String>,
    /// Number of modifications made.
    modifications: usize,
    // ---------------------------------------------------------------------
    // Protect decoder/shuffler spans from mutation
    // ---------------------------------------------------------------------
    protected_spans: Vec<Span>,
}

impl<'m, 'e> AccessorInliner<'m, 'e> {
    pub fn new(
        accessor_map: &'m AccessorMap,
        evaluator: &'e mut JsEvaluator,
        protected_spans: Vec<Span>,
    ) -> Self {
        Self {
            accessor_map,
            evaluator,
            cache: FxHashMap::default(),
            modifications: 0,
            protected_spans,
        }
    }

    pub fn modifications(&self) -> usize {
        self.modifications
    }

    fn is_in_protected_span(&self, span: Span) -> bool {
        self.protected_spans
            .iter()
            .any(|p| span_in(span, *p))
    }

    fn get_accessor_symbol<'a>(
        &self,
        callee: &Expression<'a>,
        ctx: &TraverseCtx<'a, ()>,
    ) -> Option<SymbolId> {
        let Expression::Identifier(ident) = callee else { return None };
        let symbol_id = get_reference_symbol(ctx.scoping(), ident)?;
        self.accessor_map.contains_key(&symbol_id).then_some(symbol_id)
    }

    fn args_are_safe(args: &[Argument]) -> bool {
        args.iter().all(|arg| match arg {
            Argument::SpreadElement(_) => false,
            _ => is_safe_expr(arg.to_expression()),
        })
    }
}

impl<'a, 'm, 'e> Traverse<'a, ()> for AccessorInliner<'m, 'e> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Never inline inside decoder machinery (shuffler IIFEs, array/accessor defs).
        // Mutating those can cause later passes to execute the wrong shuffler and produce
        // incorrect strings (e.g. wrong `_u275(...)` arguments).
        if self.is_in_protected_span(expr.span()) {
            return;
        }

        // Handle sequence expressions that hide constant arguments via comma operator:
        // e.g. `(_a = 1, _b = 2, accessor(_b + 3, _a))`
        if let Expression::SequenceExpression(seq_ro) = &*expr {
            let Some(last_ro) = seq_ro.expressions.last() else { return };
            let Expression::CallExpression(call_ro) = last_ro else { return };
            let Some(_accessor_symbol) = self.get_accessor_symbol(&call_ro.callee, ctx) else { return };

            // Evaluate the full sequence expression in a wrapper that declares any assigned identifiers,
            // then replace only the *last* expression with the decoded string literal.
            // This preserves assignment side effects in the original code.
            let seq_code = expr_to_code(&*expr);
            let cache_key = format!("seq:{}", seq_code);
            let mut decoded: Option<String> = self.cache.get(&cache_key).cloned();

            // Collect identifier assignment targets so we can `var`-declare them in the wrapper.
            let mut decls: FxHashSet<&str> = FxHashSet::default();
            for e in seq_ro.expressions.iter() {
                if let Expression::AssignmentExpression(assign) = e {
                    if let oxc::ast::ast::AssignmentTarget::AssignmentTargetIdentifier(id) =
                        &assign.left
                    {
                        decls.insert(id.name.as_str());
                    }
                }
            }

            let decl_code = if decls.is_empty() {
                String::new()
            } else {
                // `var a,b,c;`
                let mut out = String::from("var ");
                for (i, name) in decls.iter().enumerate() {
                    if i != 0 {
                        out.push(',');
                    }
                    out.push_str(name);
                }
                out.push(';');
                out
            };

            if decoded.is_none() {
                let wrapped = format!("(()=>{{{} return ({});}})()", decl_code, seq_code);
                match self.evaluator.eval(&wrapped) {
                    Ok(serde_json::Value::String(s)) => {
                        self.cache.insert(cache_key, s.clone());
                        decoded = Some(s);
                    }
                    Ok(_) => {
                        // Not a string; keep original and keep the accessor around.
                        return;
                    }
                    Err(e) => {
                        let _ = e;
                        return;
                    }
                }
            }

            if let Some(decoded) = decoded {
                // Mutate the last expression only after all immutable borrows are dropped.
                if let Expression::SequenceExpression(seq_mut) = expr {
                    if let Some(last_mut) = seq_mut.expressions.last_mut() {
                        let atom = ctx.ast.atom(&decoded);
                        *last_mut = ctx.ast.expression_string_literal(SPAN, atom, None);
                        self.modifications += 1;
                    }
                }
                return;
            }
        }

        let Expression::CallExpression(call) = expr else { return };

        // Only inline calls to collected accessors.
        let Some(accessor_symbol) = self.get_accessor_symbol(&call.callee, ctx) else {
            return;
        };

        // Only inline when all args are constant/safe.
        if !Self::args_are_safe(&call.arguments) {
            return;
        }

        let code = expr_to_code(expr);

        if let Some(decoded) = self.cache.get(&code).cloned() {
            let atom = ctx.ast.atom(&decoded);
            *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
            self.modifications += 1;
            return;
        }

        let value = match self.evaluator.eval(&code) {
            Ok(v) => v,
            Err(e) => {
                let _ = (e, accessor_symbol);
                return;
            }
        };

        let serde_json::Value::String(decoded) = value else {
            return;
        };

        self.cache.insert(code, decoded.clone());

        let atom = ctx.ast.atom(&decoded);
        *expr = ctx.ast.expression_string_literal(SPAN, atom, None);
        self.modifications += 1;
    }
}


