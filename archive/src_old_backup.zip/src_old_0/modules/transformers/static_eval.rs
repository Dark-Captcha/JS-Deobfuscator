//! Static evaluation module.
//!
//! Evaluates safe JavaScript expressions at compile-time using deno_core (V8).
//! This enables universal deobfuscation by executing decoder functions rather
//! than pattern-matching specific obfuscation schemes.

use oxc::allocator::Allocator;
use oxc::ast::ast::{Expression, Program};
use oxc::semantic::Scoping;
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;
use tracing::{debug, trace};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::eval::{JsEvaluator, expr_to_code, is_safe_expr, value_to_expr};

/// Static evaluator that executes safe JavaScript expressions at compile-time.
///
/// This module identifies expressions that:
/// 1. Are safe to evaluate (no side effects, deterministic)
/// 2. Have only literal/constant arguments
/// 3. Use known safe functions (atob, btoa, String methods, etc.)
///
/// It then evaluates them using V8 and replaces them with the result.
///
/// Note: The JsEvaluator is created fresh for each transform call because
/// deno_core's JsRuntime is not Send+Sync.
pub struct StaticEvaluator {
    timeout_ms: u64,
}

impl StaticEvaluator {
    /// Create a new StaticEvaluator with default timeout (1000ms).
    pub fn new() -> Self {
        Self { timeout_ms: 1000 }
    }

    /// Create with custom timeout in milliseconds.
    pub fn with_timeout(timeout_ms: u64) -> Self {
        Self { timeout_ms }
    }
}

impl Default for StaticEvaluator {
    fn default() -> Self {
        Self::new()
    }
}

impl Module for StaticEvaluator {
    fn name(&self) -> &'static str {
        "StaticEvaluator"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Create a fresh evaluator for each transform (JsRuntime is not Send+Sync)
        let mut evaluator = JsEvaluator::with_timeout(self.timeout_ms);
        let mut visitor = StaticEvalVisitor::new(&mut evaluator);
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(TransformResult {
            modifications: visitor.modifications,
            scoping,
        })
    }
}

/// Check if an expression already represents the same value as the eval result.
/// This avoids counting no-op evaluations (e.g., `5` -> `5`) as modifications.
fn is_same_value(expr: &Expression<'_>, value: &serde_json::Value) -> bool {
    match (expr, value) {
        // String literal matches string value
        (Expression::StringLiteral(lit), serde_json::Value::String(s)) => lit.value.as_str() == s,

        // Numeric literal matches number value
        (Expression::NumericLiteral(lit), serde_json::Value::Number(n)) => {
            if let Some(f) = n.as_f64() {
                (lit.value - f).abs() < f64::EPSILON
            } else {
                false
            }
        }

        // Unary expression with numeric literal (handles -1, -5, etc.)
        (Expression::UnaryExpression(unary), serde_json::Value::Number(n)) => {
            if unary.operator == oxc::ast::ast::UnaryOperator::UnaryNegation {
                if let Expression::NumericLiteral(lit) = &unary.argument {
                    if let Some(f) = n.as_f64() {
                        return ((-lit.value) - f).abs() < f64::EPSILON;
                    }
                }
            }
            false
        }

        // Boolean literal matches bool value
        (Expression::BooleanLiteral(lit), serde_json::Value::Bool(b)) => lit.value == *b,

        // Null literal matches null value
        (Expression::NullLiteral(_), serde_json::Value::Null) => true,

        // Array expressions - check element-wise
        (Expression::ArrayExpression(arr), serde_json::Value::Array(vals)) => {
            if arr.elements.len() != vals.len() {
                return false;
            }
            arr.elements.iter().zip(vals.iter()).all(|(elem, val)| {
                match elem {
                    oxc::ast::ast::ArrayExpressionElement::SpreadElement(_) => false,
                    oxc::ast::ast::ArrayExpressionElement::Elision(_) => {
                        matches!(val, serde_json::Value::Null)
                    }
                    _ => {
                        if let Some(e) = elem.as_expression() {
                            is_same_value(e, val)
                        } else {
                            false
                        }
                    }
                }
            })
        }

        // Different types or complex expressions - not the same
        _ => false,
    }
}

/// Visitor that traverses the AST and evaluates safe expressions.
struct StaticEvalVisitor<'e> {
    evaluator: &'e mut JsEvaluator,
    cache: FxHashMap<String, serde_json::Value>,
    modifications: usize,
}

impl<'e> StaticEvalVisitor<'e> {
    fn new(evaluator: &'e mut JsEvaluator) -> Self {
        Self {
            evaluator,
            cache: FxHashMap::default(),
            modifications: 0,
        }
    }
}

impl<'a, 'e> Traverse<'a, ()> for StaticEvalVisitor<'e> {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Skip if already a literal (nothing to simplify)
        if matches!(
            expr,
            Expression::StringLiteral(_)
                | Expression::NumericLiteral(_)
                | Expression::BooleanLiteral(_)
                | Expression::NullLiteral(_)
        ) {
            return;
        }

        // Try to evaluate expressions that can be statically computed
        let should_try = matches!(
            expr,
            Expression::CallExpression(_)
                | Expression::StaticMemberExpression(_)
                | Expression::BinaryExpression(_)
                | Expression::UnaryExpression(_)
        );

        if !should_try {
            return;
        }

        // Skip if not safe to evaluate
        if !is_safe_expr(expr) {
            return;
        }

        // Convert AST to code string
        let code = expr_to_code(expr);
        trace!(code = %code, "Attempting to evaluate expression");

        // Evaluate using V8 (with per-pass cache to avoid repeating identical evals).
        let value = if let Some(v) = self.cache.get(&code).cloned() {
            v
        } else {
            let v = match self.evaluator.eval(&code) {
                Ok(v) => v,
                Err(e) => {
                    debug!(code = %code, error = %e, "Static evaluation failed");
                    return;
                }
            };
            self.cache.insert(code.clone(), v.clone());
            v
        };

        // Check if the result is semantically the same as the input
        if is_same_value(expr, &value) {
            return;
        }

        // Convert result back to AST using ctx.ast (no unsafe transmute needed)
        if let Some(result) = value_to_expr(value.clone(), ctx.ast.allocator) {
            trace!(code = %code, result = ?value, "Successfully evaluated expression");
            *expr = result;
            self.modifications += 1;
        } else {
            debug!(code = %code, result = ?value, "Could not convert result to AST");
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    fn transform(source: &str) -> (String, usize) {
        let allocator = Allocator::default();
        let source_type = SourceType::cjs();

        let ret = Parser::new(&allocator, source, source_type).parse();
        assert!(ret.errors.is_empty(), "Parse errors: {:?}", ret.errors);

        let mut program = ret.program;

        let semantic = SemanticBuilder::new().build(&program).semantic;
        let scoping = semantic.into_scoping();

        let mut evaluator = StaticEvaluator::new();
        let result = evaluator
            .transform(&allocator, &mut program, scoping)
            .unwrap();

        let code = Codegen::new().build(&program).code;
        (code, result.modifications)
    }

    #[test]
    fn test_atob() {
        let (code, mods) = transform(r#"var x = atob("SGVsbG8=");"#);
        assert_eq!(mods, 1);
        assert!(
            code.contains(r#""Hello""#),
            "Expected 'Hello', got: {}",
            code
        );
    }

    #[test]
    fn test_btoa() {
        let (code, mods) = transform(r#"var x = btoa("Hello");"#);
        assert_eq!(mods, 1);
        assert!(
            code.contains(r#""SGVsbG8=""#),
            "Expected 'SGVsbG8=', got: {}",
            code
        );
    }

    #[test]
    fn test_string_from_char_code() {
        let (code, mods) = transform("var x = String.fromCharCode(72, 101, 108, 108, 111);");
        assert_eq!(mods, 1);
        assert!(
            code.contains(r#""Hello""#),
            "Expected 'Hello', got: {}",
            code
        );
    }

    #[test]
    fn test_string_method_chain() {
        let (code, mods) = transform(r#"var x = "olleh".split("").reverse().join("");"#);
        // Multiple modifications because each intermediate call is also safe
        assert!(mods >= 1, "Expected at least 1 modification, got: {}", mods);
        assert!(
            code.contains(r#""hello""#),
            "Expected 'hello', got: {}",
            code
        );
    }

    #[test]
    fn test_parse_int() {
        let (code, mods) = transform(r#"var x = parseInt("ff", 16);"#);
        assert_eq!(mods, 1);
        assert!(code.contains("255"), "Expected 255, got: {}", code);
    }

    #[test]
    fn test_math_floor() {
        let (code, mods) = transform("var x = Math.floor(3.7);");
        assert_eq!(mods, 1);
        assert!(code.contains("3"), "Expected 3, got: {}", code);
    }

    #[test]
    fn test_string_length() {
        let (code, mods) = transform(r#"var x = "hello".length;"#);
        assert_eq!(mods, 1);
        assert!(code.contains("5"), "Expected 5, got: {}", code);
    }

    #[test]
    fn test_array_join() {
        let (code, mods) = transform(r#"var x = [1, 2, 3].join("-");"#);
        assert_eq!(mods, 1);
        assert!(
            code.contains(r#""1-2-3""#),
            "Expected '1-2-3', got: {}",
            code
        );
    }

    #[test]
    fn test_decode_uri_component() {
        let (code, mods) = transform(r#"var x = decodeURIComponent("%48%65%6C%6C%6F");"#);
        assert_eq!(mods, 1);
        assert!(
            code.contains(r#""Hello""#),
            "Expected 'Hello', got: {}",
            code
        );
    }

    #[test]
    fn test_unsafe_expression_unchanged() {
        let (code, mods) = transform(r#"var x = console.log("test");"#);
        assert_eq!(mods, 0);
        assert!(
            code.contains("console.log"),
            "Unsafe expression should be unchanged"
        );
    }

    #[test]
    fn test_variable_argument_unchanged() {
        let (code, mods) = transform("var y = 'test'; var x = atob(y);");
        assert_eq!(mods, 0);
        assert!(
            code.contains("atob(y)"),
            "Variable argument should be unchanged"
        );
    }

    #[test]
    fn test_math_random_unchanged() {
        let (code, mods) = transform("var x = Math.random();");
        assert_eq!(mods, 0);
        assert!(
            code.contains("Math.random"),
            "Non-deterministic should be unchanged"
        );
    }

    #[test]
    fn test_multiple_evaluations() {
        let (code, mods) = transform(
            r#"var a = atob("SGVsbG8="); var b = btoa("World"); var c = parseInt("42");"#,
        );
        assert_eq!(mods, 3);
        assert!(code.contains(r#""Hello""#));
        assert!(code.contains(r#""V29ybGQ=""#));
        assert!(code.contains("42"));
    }

    #[test]
    fn test_nested_safe_calls() {
        let (code, mods) = transform(r#"var x = atob("SGVsbG8=").toUpperCase();"#);
        // This should evaluate the inner atob first, then the toUpperCase
        // Due to bottom-up traversal, we might get 2 modifications
        assert!(mods >= 1);
        assert!(
            code.contains(r#""HELLO""#) || code.contains(r#""Hello""#),
            "Expected evaluated result, got: {}",
            code
        );
    }
}
