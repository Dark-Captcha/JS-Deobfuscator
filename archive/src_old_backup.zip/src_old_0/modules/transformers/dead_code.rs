//! Dead code elimination module.
//!
//! Removes unused variables, functions, and unreachable code.
//! Handles ALL JavaScript constructs:
//!
//! Constant conditions:
//!   if(true) { a } else { b }  → { a }
//!   if(false) { a } else { b } → { b }
//!   if(false) { a }            → ;
//!   while(false) { ... }       → (removed)
//!   do { ... } while(false)    → { ... } (executes once)
//!   for(;false;) { ... }       → (removed)
//!   true ? a : b               → a
//!   false ? a : b              → b
//!
//! Logical short-circuit:
//!   true || x                  → true
//!   false || x                 → x
//!   true && x                  → x
//!   false && x                 → false
//!
//! Unreachable code:
//!   { return; x; y; }          → { return; }
//!   { throw e; x; }            → { throw e; }
//!   { break; x; }              → { break; }
//!   { continue; x; }           → { continue; }
//!
//! Unused declarations:
//!   var x = 1; (never used)    → (removed)
//!   function f() {} (never called) → (removed)
//!
//! Empty/debug:
//!   ;                          → (removed)
//!   debugger;                  → (removed)

use oxc::allocator::{Allocator, TakeIn, Vec as ArenaVec};
use oxc::ast::ast::{
    Expression, ForStatement, ForStatementInit, LogicalOperator, Program, Statement,
    VariableDeclarator,
};
use oxc::semantic::{Scoping, SymbolId};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::utils::symbols::{count_read_references, get_reference_symbol};

/// Eliminates dead code including unused declarations.
pub struct DeadCodeEliminator;

impl Module for DeadCodeEliminator {
    fn name(&self) -> &'static str {
        "DeadCodeEliminator"
    }

    fn changes_symbols(&self) -> bool {
        true
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        let mut visitor = DeadCodeVisitor::default();
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(TransformResult {
            modifications: visitor.modifications,
            scoping,
        })
    }
}

#[derive(Default)]
struct DeadCodeVisitor {
    modifications: usize,
}

impl DeadCodeVisitor {
    /// Get constant truthiness of an expression.
    fn get_truthiness(expr: &Expression) -> Option<bool> {
        match expr {
            Expression::BooleanLiteral(lit) => Some(lit.value),
            Expression::NumericLiteral(lit) => Some(lit.value != 0.0 && !lit.value.is_nan()),
            Expression::StringLiteral(lit) => Some(!lit.value.is_empty()),
            Expression::NullLiteral(_) => Some(false),
            Expression::Identifier(ident) if ident.name == "undefined" => Some(false),
            Expression::ArrayExpression(_) | Expression::ObjectExpression(_) => Some(true),
            Expression::ParenthesizedExpression(p) => Self::get_truthiness(&p.expression),
            Expression::UnaryExpression(u)
                if u.operator == oxc::ast::ast::UnaryOperator::LogicalNot =>
            {
                Self::get_truthiness(&u.argument).map(|v| !v)
            }
            _ => None,
        }
    }

    /// Check if expression is side-effect free (safe to remove).
    fn is_side_effect_free(expr: &Expression) -> bool {
        match expr {
            Expression::NumericLiteral(_)
            | Expression::StringLiteral(_)
            | Expression::BooleanLiteral(_)
            | Expression::NullLiteral(_)
            | Expression::Identifier(_) => true,

            // Property reads (deobfuscation-oriented):
            // Treat `obj.prop` / `obj["prop"]` as side-effect free if their sub-expressions are.
            // This is intentionally a bit more aggressive to clean up obfuscator "noise" temps like:
            // `var x = arg.prop;` where `x` is never read.
            Expression::StaticMemberExpression(m) => {
                !m.optional && Self::is_side_effect_free(&m.object)
            }
            Expression::ComputedMemberExpression(m) => {
                !m.optional
                    && Self::is_side_effect_free(&m.object)
                    && Self::is_side_effect_free(&m.expression)
            }

            Expression::UnaryExpression(u) => Self::is_side_effect_free(&u.argument),

            Expression::BinaryExpression(b) => {
                Self::is_side_effect_free(&b.left) && Self::is_side_effect_free(&b.right)
            }

            Expression::ParenthesizedExpression(p) => Self::is_side_effect_free(&p.expression),

            // Array literals are side-effect free if all elements are
            Expression::ArrayExpression(arr) => arr.elements.iter().all(|el| {
                match el {
                    oxc::ast::ast::ArrayExpressionElement::SpreadElement(_) => false,
                    oxc::ast::ast::ArrayExpressionElement::Elision(_) => true,
                    _ => {
                        // ArrayExpressionElement can be converted to Expression
                        if let Some(expr) = el.as_expression() {
                            Self::is_side_effect_free(expr)
                        } else {
                            false
                        }
                    }
                }
            }),

            // Object literals are side-effect free if all values are
            Expression::ObjectExpression(obj) => {
                use oxc::ast::ast::{ObjectPropertyKind, PropertyKey};
                obj.properties.iter().all(|prop| match prop {
                    ObjectPropertyKind::ObjectProperty(p) => {
                        // Computed keys might have side effects
                        let key_safe = match &p.key {
                            PropertyKey::StaticIdentifier(_) | PropertyKey::StringLiteral(_) | PropertyKey::NumericLiteral(_) => true,
                            _ => false,
                        };
                        key_safe && Self::is_side_effect_free(&p.value)
                    }
                    ObjectPropertyKind::SpreadProperty(_) => false,
                })
            }

            // Function/arrow expressions are side-effect free (defining, not calling)
            Expression::FunctionExpression(_) | Expression::ArrowFunctionExpression(_) => true,

            _ => false,
        }
    }

    /// Check if variable declarator should be kept.
    fn should_keep_declarator(declarator: &VariableDeclarator, scoping: &Scoping) -> bool {
        let Some(binding) = declarator.id.get_binding_identifier() else {
            return true; // Keep destructuring
        };
        let Some(symbol_id) = binding.symbol_id.get() else {
            return true;
        };

        // Check if init has side effects
        let has_side_effects = declarator
            .init
            .as_ref()
            .is_some_and(|init| !Self::is_side_effect_free(init));

        if has_side_effects {
            return true; // Keep if init has side effects
        }

        // Remove if no reads
        count_read_references(scoping, symbol_id) > 0
    }

    fn count_references(scoping: &Scoping, symbol_id: SymbolId) -> usize {
        scoping.get_resolved_references(symbol_id).count()
    }

    /// Check if statement terminates control flow.
    fn is_terminating(stmt: &Statement) -> bool {
        matches!(
            stmt,
            Statement::ReturnStatement(_)
                | Statement::ThrowStatement(_)
                | Statement::BreakStatement(_)
                | Statement::ContinueStatement(_)
        )
    }

    /// Check if an expression is a dead assignment (assigned but never read).
    fn is_dead_assignment(expr: &Expression, scoping: &Scoping) -> bool {
        // Must be an assignment expression
        let Expression::AssignmentExpression(assign) = expr else {
            return false;
        };

        // Only handle simple assignment (=), not +=, etc.
        if assign.operator != oxc::ast::ast::AssignmentOperator::Assign {
            return false;
        }

        // Left side must be a simple identifier
        let oxc::ast::ast::AssignmentTarget::AssignmentTargetIdentifier(id) = &assign.left else {
            return false;
        };

        // Get symbol for the identifier
        let Some(symbol_id) = get_reference_symbol(scoping, id) else {
            return false; // Global - can't track, keep it
        };

        // Check if RHS has side effects
        if !Self::is_side_effect_free(&assign.right) {
            return false;
        }

        // Check if variable has any reads
        count_read_references(scoping, symbol_id) == 0
    }
}

impl<'a> Traverse<'a, ()> for DeadCodeVisitor {
    // ========================================================================
    // STATEMENTS - Remove unreachable code, simplify constant conditions
    // ========================================================================

    fn exit_statements(
        &mut self,
        statements: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let scoping = ctx.scoping();
        let allocator = ctx.ast.allocator;
        let mut new_statements = ctx.ast.vec();
        let mut terminated = false;

        for mut statement in statements.take_in(allocator) {
            // Skip unreachable code after return/throw/break/continue
            if terminated {
                self.modifications += 1;
                continue;
            }

            match &mut statement {
                // Remove empty statements
                Statement::EmptyStatement(_) => {
                    self.modifications += 1;
                    continue;
                }

                // Remove debugger statements
                Statement::DebuggerStatement(_) => {
                    self.modifications += 1;
                    continue;
                }

                // Flatten standalone blocks (unwrap { stmt; stmt; } into parent)
                // Only flatten if block doesn't contain let/const (which need block scope)
                Statement::BlockStatement(block) => {
                    let has_block_scoped = block.body.iter().any(|s| {
                        matches!(s, Statement::VariableDeclaration(v) if !v.kind.is_var())
                    });

                    if !has_block_scoped {
                        // Flatten: add all inner statements to parent
                        self.modifications += 1;
                        for inner in block.body.take_in(allocator) {
                            if Self::is_terminating(&inner) {
                                terminated = true;
                            }
                            new_statements.push(inner);
                        }
                        continue;
                    }
                }

                // Remove unused variable declarations
                Statement::VariableDeclaration(var_decl) => {
                    let before = var_decl.declarations.len();
                    var_decl
                        .declarations
                        .retain(|d| Self::should_keep_declarator(d, scoping));
                    let after = var_decl.declarations.len();
                    self.modifications += before - after;

                    if var_decl.declarations.is_empty() {
                        continue;
                    }
                }

                // Remove unused function declarations
                Statement::FunctionDeclaration(func_decl) => {
                    let is_unused = func_decl
                        .id
                        .as_ref()
                        .and_then(|b| b.symbol_id.get())
                        .is_some_and(|sym| Self::count_references(scoping, sym) == 0);

                    if is_unused {
                        self.modifications += 1;
                        continue;
                    }
                }

                // Remove unused assignment expressions: x = {...} where x has no reads
                Statement::ExpressionStatement(expr_stmt) => {
                    if Self::is_dead_assignment(&expr_stmt.expression, scoping) {
                        self.modifications += 1;
                        continue;
                    }
                }

                _ => {}
            }

            // Check if this statement terminates control flow
            if Self::is_terminating(&statement) {
                terminated = true;
            }

            new_statements.push(statement);
        }

        *statements = new_statements;
    }

    fn enter_for_statement(&mut self, node: &mut ForStatement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let scoping = ctx.scoping();

        // Remove unused vars from for-loop init
        if let Some(ForStatementInit::VariableDeclaration(var_decl)) = &mut node.init {
            let before = var_decl.declarations.len();
            var_decl
                .declarations
                .retain(|d| Self::should_keep_declarator(d, scoping));
            let after = var_decl.declarations.len();
            self.modifications += before - after;

            if var_decl.declarations.is_empty() {
                node.init = None;
            }
        }
    }

    fn exit_statement(&mut self, stmt: &mut Statement<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let allocator = ctx.ast.allocator;

        match stmt {
            // if(true/false) simplification
            Statement::IfStatement(if_stmt) => {
                if let Some(truthy) = Self::get_truthiness(&if_stmt.test) {
                    *stmt = if truthy {
                        if_stmt.consequent.take_in(allocator)
                    } else if let Some(alt) = &mut if_stmt.alternate {
                        alt.take_in(allocator)
                    } else {
                        ctx.ast.statement_empty(if_stmt.span)
                    };
                    self.modifications += 1;
                }
            }

            // while(false) → remove
            Statement::WhileStatement(while_stmt) => {
                if Self::get_truthiness(&while_stmt.test) == Some(false) {
                    *stmt = ctx.ast.statement_empty(while_stmt.span);
                    self.modifications += 1;
                }
            }

            // do{}while(false) → execute body once
            Statement::DoWhileStatement(do_stmt) => {
                if Self::get_truthiness(&do_stmt.test) == Some(false) {
                    *stmt = do_stmt.body.take_in(allocator);
                    self.modifications += 1;
                }
            }

            // for(;false;) → remove
            Statement::ForStatement(for_stmt) => {
                if for_stmt
                    .test
                    .as_ref()
                    .is_some_and(|t| Self::get_truthiness(t) == Some(false))
                {
                    *stmt = ctx.ast.statement_empty(for_stmt.span);
                    self.modifications += 1;
                }
            }

            _ => {}
        }
    }

    // ========================================================================
    // EXPRESSIONS - Simplify ternary and logical
    // ========================================================================

    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let allocator = ctx.ast.allocator;

        match expr {
            // true ? a : b → a, false ? a : b → b
            Expression::ConditionalExpression(cond) => {
                if let Some(truthy) = Self::get_truthiness(&cond.test) {
                    *expr = if truthy {
                        cond.consequent.take_in(allocator)
                    } else {
                        cond.alternate.take_in(allocator)
                    };
                    self.modifications += 1;
                }
            }

            // Logical short-circuit
            Expression::LogicalExpression(logical) => {
                if let Some(truthy) = Self::get_truthiness(&logical.left) {
                    match logical.operator {
                        // true || x → true, false || x → x
                        LogicalOperator::Or => {
                            *expr = if truthy {
                                logical.left.take_in(allocator)
                            } else {
                                logical.right.take_in(allocator)
                            };
                            self.modifications += 1;
                        }
                        // true && x → x, false && x → false
                        LogicalOperator::And => {
                            *expr = if truthy {
                                logical.right.take_in(allocator)
                            } else {
                                logical.left.take_in(allocator)
                            };
                            self.modifications += 1;
                        }
                        // a ?? b - only simplify if left is null/undefined
                        LogicalOperator::Coalesce => {
                            let is_nullish = matches!(&logical.left, Expression::NullLiteral(_))
                                || matches!(
                                    &logical.left,
                                    Expression::Identifier(i) if i.name == "undefined"
                                );
                            if is_nullish {
                                *expr = logical.right.take_in(allocator);
                                self.modifications += 1;
                            }
                        }
                    }
                }
            }

            _ => {}
        }
    }
}
