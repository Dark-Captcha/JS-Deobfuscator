//! Control Flow Deflattener - Simple implementation.
//!
//! Transforms state machine patterns back to linear code:
//! ```js
//! var state = 1;
//! while (true) {
//!     switch (state) {
//!         case 1: x = 10; state = 2; break;
//!         case 2: x = x + 5; state = 3; break;
//!         case 3: return x;
//!     }
//! }
//! ```
//! Into:
//! ```js
//! var state = 1;
//! x = 10;
//! x = x + 5;
//! return x;
//! ```

use rustc_hash::{FxHashMap, FxHashSet};

use oxc::allocator::{Allocator, CloneIn, TakeIn, Vec as ArenaVec};
use oxc::ast::ast::{Expression, Program, Statement, SwitchCase, SwitchStatement};
use oxc::semantic::Scoping;
use oxc_traverse::{traverse_mut, Traverse, TraverseCtx};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};

pub struct ControlFlowDeflattener;

impl ControlFlowDeflattener {
    pub fn new() -> Self {
        Self
    }
}

impl Default for ControlFlowDeflattener {
    fn default() -> Self {
        Self::new()
    }
}

impl Module for ControlFlowDeflattener {
    fn name(&self) -> &'static str {
        "ControlFlowDeflattener"
    }

    fn changes_symbols(&self) -> bool {
        true
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        let mut visitor = Visitor { modifications: 0 };
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(TransformResult {
            modifications: visitor.modifications,
            scoping,
        })
    }
}

struct Visitor {
    modifications: usize,
}

/// Represents a case value (number or string)
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
enum CaseValue {
    Number(i64),
    String(String),
}

/// Info about a switch case
struct CaseInfo {
    /// Next state value (None if terminal like return/throw)
    next_state: Option<CaseValue>,
    /// Is this a terminal case (return/throw)?
    is_terminal: bool,
}

impl<'a> Traverse<'a, ()> for Visitor {
    fn exit_statements(
        &mut self,
        stmts: &mut ArenaVec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // First pass: analyze which statements can be deflattened
        let mut analyses: Vec<(usize, AnalysisResult)> = Vec::new();
        for (i, stmt) in stmts.iter().enumerate() {
            if let Some(analysis) = analyze_loop(stmt) {
                analyses.push((i, analysis));
            }
        }

        if analyses.is_empty() {
            return;
        }

        // Second pass: rebuild statements
        let allocator = ctx.ast.allocator;
        let mut new_stmts: ArenaVec<'a, Statement<'a>> = ctx.ast.vec();
        let mut analysis_idx = 0;

        for (i, stmt) in stmts.take_in(allocator).into_iter().enumerate() {
            if analysis_idx < analyses.len() && i == analyses[analysis_idx].0 {
                let analysis = &analyses[analysis_idx].1;
                // Linearize directly from the owned statement
                if let Some(linearized) = linearize_stmt(&stmt, analysis, ctx) {
                    for s in linearized {
                        new_stmts.push(s);
                    }
                    analysis_idx += 1;
                    self.modifications += 1;
                    continue;
                }
                analysis_idx += 1;
            }
            new_stmts.push(stmt);
        }

        *stmts = new_stmts;
    }
}

/// Linearize a statement using pre-computed analysis
fn linearize_stmt<'a>(
    stmt: &Statement<'a>,
    analysis: &AnalysisResult,
    ctx: &mut TraverseCtx<'a, ()>,
) -> Option<Vec<Statement<'a>>> {
    // Get the switch from the statement
    let switch = get_switch_from_loop(stmt)?;

    let mut result = Vec::new();

    for case_value in &analysis.execution_order {
        // Find the case with this value
        let case = switch.cases.iter().find(|c| {
            get_case_value(&c.test) == Some(case_value.clone())
        })?;

        // Clone statements (excluding break and state assignments)
        for case_stmt in &case.consequent {
            if matches!(case_stmt, Statement::BreakStatement(_)) {
                continue;
            }
            if is_state_assignment(case_stmt, &analysis.state_var) {
                continue;
            }
            result.push(case_stmt.clone_in(ctx.ast.allocator));
        }
    }

    if result.is_empty() {
        return None;
    }

    Some(result)
}

/// Get switch statement from a loop (owned version)
fn get_switch_from_loop<'a>(stmt: &'a Statement<'a>) -> Option<&'a SwitchStatement<'a>> {
    let body = match stmt {
        Statement::WhileStatement(w) => &w.body,
        Statement::ForStatement(f) => &f.body,
        Statement::DoWhileStatement(d) => &d.body,
        _ => return None,
    };

    get_switch_from_body(body)
}

fn get_switch_from_body<'a>(body: &'a Statement<'a>) -> Option<&'a SwitchStatement<'a>> {
    match body {
        Statement::SwitchStatement(switch) => Some(switch),
        Statement::BlockStatement(block) => {
            for s in &block.body {
                if let Statement::SwitchStatement(switch) = s {
                    return Some(switch);
                }
            }
            None
        }
        Statement::LabeledStatement(labeled) => get_switch_from_body(&labeled.body),
        _ => None,
    }
}

/// Analysis result that doesn't borrow from the statement
struct AnalysisResult {
    state_var: String,
    execution_order: Vec<CaseValue>,
}

/// Analyze a loop to see if it can be deflattened
fn analyze_loop(stmt: &Statement) -> Option<AnalysisResult> {
    let (switch, state_var) = find_switch_in_loop(stmt)?;
    let cases = collect_cases(switch, state_var)?;
    let initial_state = find_initial_state(&cases)?;
    let execution_order = get_execution_order(&cases, initial_state.clone())?;

    Some(AnalysisResult {
        state_var: state_var.to_string(),
        execution_order,
    })
}

/// Get execution order by following transitions
fn get_execution_order(
    cases: &FxHashMap<CaseValue, CaseInfo>,
    initial: CaseValue,
) -> Option<Vec<CaseValue>> {
    let mut order = Vec::new();
    let mut current = initial;
    let mut visited: FxHashSet<CaseValue> = FxHashSet::default();

    loop {
        if visited.contains(&current) {
            return None; // Cycle
        }
        visited.insert(current.clone());
        order.push(current.clone());

        let info = cases.get(&current)?;
        if info.is_terminal {
            break;
        }

        let Some(next) = &info.next_state else {
            break;
        };
        current = next.clone();
    }

    Some(order)
}



/// Check if statement is a state assignment
fn is_state_assignment(stmt: &Statement, state_var: &str) -> bool {
    let Statement::ExpressionStatement(expr_stmt) = stmt else {
        return false;
    };
    let Expression::AssignmentExpression(assign) = &expr_stmt.expression else {
        return false;
    };

    match &assign.left {
        oxc::ast::ast::AssignmentTarget::AssignmentTargetIdentifier(id) => {
            id.name.as_str() == state_var
        }
        oxc::ast::ast::AssignmentTarget::ComputedMemberExpression(m) => {
            if let Expression::Identifier(id) = &m.object {
                id.name.as_str() == state_var
            } else {
                false
            }
        }
        _ => false,
    }
}



/// Find switch statement inside a loop, return (switch, state_var_name)
fn find_switch_in_loop<'a>(stmt: &'a Statement<'a>) -> Option<(&'a SwitchStatement<'a>, &'a str)> {
    let body = match stmt {
        Statement::WhileStatement(w) => &w.body,
        Statement::ForStatement(f) => &f.body,
        Statement::DoWhileStatement(d) => &d.body,
        _ => return None,
    };

    find_switch_in_body(body)
}

fn find_switch_in_body<'a>(body: &'a Statement<'a>) -> Option<(&'a SwitchStatement<'a>, &'a str)> {
    match body {
        Statement::SwitchStatement(switch) => {
            let state_var = get_switch_discriminant_name(&switch.discriminant)?;
            Some((switch, state_var))
        }
        Statement::BlockStatement(block) => {
            for s in &block.body {
                if let Statement::SwitchStatement(switch) = s {
                    let state_var = get_switch_discriminant_name(&switch.discriminant)?;
                    return Some((switch, state_var));
                }
            }
            None
        }
        Statement::LabeledStatement(labeled) => find_switch_in_body(&labeled.body),
        _ => None,
    }
}

/// Get the variable name from switch discriminant
fn get_switch_discriminant_name<'a>(expr: &'a Expression<'a>) -> Option<&'a str> {
    match expr {
        Expression::Identifier(id) => Some(id.name.as_str()),
        Expression::ComputedMemberExpression(m) => {
            // arr[0] - get array name
            if let Expression::Identifier(id) = &m.object {
                Some(id.name.as_str())
            } else {
                None
            }
        }
        _ => None,
    }
}

/// Collect all cases from switch, return None if any case has conditional transitions
fn collect_cases(
    switch: &SwitchStatement,
    state_var: &str,
) -> Option<FxHashMap<CaseValue, CaseInfo>> {
    let mut cases: FxHashMap<CaseValue, CaseInfo> = FxHashMap::default();

    for case in &switch.cases {
        let case_value = get_case_value(&case.test)?;
        let info = analyze_case(case, state_var)?;
        cases.insert(case_value, info);
    }

    Some(cases)
}

/// Get case value from test expression
fn get_case_value(test: &Option<Expression>) -> Option<CaseValue> {
    let expr = test.as_ref()?;
    match expr {
        Expression::NumericLiteral(n) => Some(CaseValue::Number(n.value as i64)),
        Expression::StringLiteral(s) => Some(CaseValue::String(s.value.to_string())),
        Expression::UnaryExpression(u) => {
            // Handle -5
            if let Expression::NumericLiteral(n) = &u.argument {
                if u.operator == oxc::ast::ast::UnaryOperator::UnaryNegation {
                    return Some(CaseValue::Number(-(n.value as i64)));
                }
            }
            None
        }
        // Computed case labels like `5 + 5` - skip for now
        _ => None,
    }
}

/// Analyze a case body, extract next state
fn analyze_case(case: &SwitchCase, state_var: &str) -> Option<CaseInfo> {
    let mut next_state = None;
    let mut is_terminal = false;

    for stmt in &case.consequent {
        // Skip break
        if matches!(stmt, Statement::BreakStatement(_)) {
            continue;
        }

        // Check for return/throw (terminal)
        if matches!(
            stmt,
            Statement::ReturnStatement(_) | Statement::ThrowStatement(_)
        ) {
            is_terminal = true;
            break;
        }

        // Check for state assignment: state = X or arr[0] = X
        if let Some(next) = extract_state_assignment(stmt, state_var) {
            // Check for conditional: state = cond ? a : b
            if next.is_none() {
                // Conditional transition - bail out
                return None;
            }
            next_state = next;
        }
    }

    Some(CaseInfo {
        next_state,
        is_terminal,
    })
}

/// Extract next state from assignment, return None for conditional
fn extract_state_assignment(stmt: &Statement, state_var: &str) -> Option<Option<CaseValue>> {
    let Statement::ExpressionStatement(expr_stmt) = stmt else {
        return None;
    };

    let Expression::AssignmentExpression(assign) = &expr_stmt.expression else {
        return None;
    };

    // Check if assigning to state variable
    let is_state_assign = match &assign.left {
        oxc::ast::ast::AssignmentTarget::AssignmentTargetIdentifier(id) => {
            id.name.as_str() == state_var
        }
        oxc::ast::ast::AssignmentTarget::ComputedMemberExpression(m) => {
            if let Expression::Identifier(id) = &m.object {
                id.name.as_str() == state_var
            } else {
                false
            }
        }
        _ => false,
    };

    if !is_state_assign {
        return None;
    }

    // Check RHS
    match &assign.right {
        Expression::NumericLiteral(n) => Some(Some(CaseValue::Number(n.value as i64))),
        Expression::StringLiteral(s) => Some(Some(CaseValue::String(s.value.to_string()))),
        Expression::ConditionalExpression(_) => Some(None), // Conditional - bail
        Expression::UnaryExpression(u) => {
            if let Expression::NumericLiteral(n) = &u.argument {
                if u.operator == oxc::ast::ast::UnaryOperator::UnaryNegation {
                    return Some(Some(CaseValue::Number(-(n.value as i64))));
                }
            }
            Some(None)
        }
        _ => Some(None), // Unknown - bail
    }
}

/// Find initial state (state with no incoming transitions)
fn find_initial_state(cases: &FxHashMap<CaseValue, CaseInfo>) -> Option<CaseValue> {
    // Find state with no incoming transitions
    let mut has_incoming: FxHashSet<&CaseValue> = FxHashSet::default();
    for info in cases.values() {
        if let Some(ref next) = info.next_state {
            has_incoming.insert(next);
        }
    }

    // Entry states = states with no incoming
    let entry_states: Vec<_> = cases
        .keys()
        .filter(|k| !has_incoming.contains(k))
        .collect();

    if entry_states.len() == 1 {
        return Some(entry_states[0].clone());
    }

    // Fallback: smallest numeric
    let mut nums: Vec<_> = cases
        .keys()
        .filter_map(|k| {
            if let CaseValue::Number(n) = k {
                Some(*n)
            } else {
                None
            }
        })
        .collect();
    nums.sort();
    nums.first().map(|n| CaseValue::Number(*n))
}


