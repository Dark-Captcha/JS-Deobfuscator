//! Member expression simplification module.
//!
//! Transforms:
//!   obj["prop"]     → obj.prop       (when prop is valid identifier)
//!   obj[`prop`]     → obj.prop       (template literal without expressions)
//!   "hello"[0]      → "h"            (string indexing)
//!   "hello"["length"] → 5            (string property access)

use oxc::allocator::{Allocator, Box as ArenaBox, CloneIn};
use oxc::ast::ast::{
    AssignmentTarget, Expression, Program, SimpleAssignmentTarget, StaticMemberExpression,
};
use oxc::semantic::Scoping;
use oxc::span::SPAN;
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};

pub struct MemberSimplifier;

impl Module for MemberSimplifier {
    fn name(&self) -> &'static str {
        "MemberSimplifier"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        let mut visitor = Visitor::default();
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(TransformResult {
            modifications: visitor.modifications,
            scoping,
        })
    }
}

#[derive(Default)]
struct Visitor {
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for Visitor {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Try each simplification in order
        if self.try_string_index(expr, ctx) {
            return;
        }
        if self.try_string_property(expr, ctx) {
            return;
        }
        if self.try_computed_to_static(expr, ctx) {
            return;
        }
    }

    fn exit_assignment_target(
        &mut self,
        node: &mut AssignmentTarget<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let _ = self.try_computed_to_static_assignment_target(node, ctx);
    }

    fn exit_simple_assignment_target(
        &mut self,
        node: &mut SimpleAssignmentTarget<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        let _ = self.try_computed_to_static_simple_assignment_target(node, ctx);
    }
}

impl Visitor {
    /// "hello"[0] → "h"
    fn try_string_index<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> bool {
        let Expression::ComputedMemberExpression(member) = expr else {
            return false;
        };

        // Object must be a string literal
        let Expression::StringLiteral(str_lit) = &member.object else {
            return false;
        };

        // Index must be a numeric literal
        let Expression::NumericLiteral(num_lit) = &member.expression else {
            return false;
        };

        let index = num_lit.value as i64;
        if index < 0 {
            return false;
        }

        let s = str_lit.value.as_str();
        let Some(ch) = s.chars().nth(index as usize) else {
            // Out of bounds - returns undefined in JS, leave unchanged
            return false;
        };
        let result = ctx.ast.alloc_string_literal(SPAN, ctx.ast.atom(&ch.to_string()), None);
        *expr = Expression::StringLiteral(result);
        self.modifications += 1;
        true
    }

    /// "hello"["length"] → 5
    /// "hello".length → 5
    fn try_string_property<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> bool {
        let (str_lit, prop_name) = match expr {
            Expression::ComputedMemberExpression(member) => {
                let Expression::StringLiteral(str_lit) = &member.object else {
                    return false;
                };
                let Expression::StringLiteral(prop_lit) = &member.expression else {
                    return false;
                };
                (str_lit, prop_lit.value.as_str())
            }
            Expression::StaticMemberExpression(member) => {
                let Expression::StringLiteral(str_lit) = &member.object else {
                    return false;
                };
                (str_lit, member.property.name.as_str())
            }
            _ => return false,
        };

        let s = str_lit.value.as_str();

        match prop_name {
            "length" => {
                // String length - count UTF-16 code units (JS behavior)
                let len = s.encode_utf16().count();
                *expr = ctx.ast.expression_numeric_literal(
                    SPAN,
                    len as f64,
                    None,
                    oxc::ast::ast::NumberBase::Decimal,
                );
                self.modifications += 1;
                true
            }
            _ => false,
        }
    }

    /// obj["prop"] → obj.prop (when prop is valid identifier)
    /// obj[`prop`] → obj.prop (template literal without expressions)
    fn try_computed_to_static<'a>(
        &mut self,
        expr: &mut Expression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> bool {
        let Expression::ComputedMemberExpression(member) = expr else {
            return false;
        };

        let prop_name = match &member.expression {
            // obj["prop"]
            Expression::StringLiteral(lit) => lit.value.as_str(),

            // obj[`prop`] (no expressions)
            Expression::TemplateLiteral(tpl) => {
                if !tpl.expressions.is_empty() || tpl.quasis.len() != 1 {
                    return false;
                }
                tpl.quasis[0]
                    .value
                    .cooked
                    .as_ref()
                    .map(|a| a.as_str())
                    .unwrap_or(tpl.quasis[0].value.raw.as_str())
            }

            _ => return false,
        };

        // Check if property name is a valid identifier
        if !is_valid_identifier(prop_name) {
            return false;
        }

        let new_member = StaticMemberExpression {
            span: member.span,
            object: member.object.clone_in(ctx.ast.allocator),
            property: ctx
                .ast
                .identifier_name(SPAN, ctx.ast.allocator.alloc_str(prop_name)),
            optional: member.optional,
        };
        *expr = Expression::StaticMemberExpression(ArenaBox::new_in(new_member, ctx.ast.allocator));
        self.modifications += 1;
        true
    }

    /// Assignment target: obj["prop"] = ... → obj.prop = ...
    fn try_computed_to_static_assignment_target<'a>(
        &mut self,
        target: &mut AssignmentTarget<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> bool {
        let AssignmentTarget::ComputedMemberExpression(member) = target else {
            return false;
        };

        let prop_name = match &member.expression {
            Expression::StringLiteral(lit) => lit.value.as_str(),
            Expression::TemplateLiteral(tpl) => {
                if !tpl.expressions.is_empty() || tpl.quasis.len() != 1 {
                    return false;
                }
                tpl.quasis[0]
                    .value
                    .cooked
                    .as_ref()
                    .map(|a| a.as_str())
                    .unwrap_or(tpl.quasis[0].value.raw.as_str())
            }
            _ => return false,
        };

        if !is_valid_identifier(prop_name) {
            return false;
        }

        let new_member = StaticMemberExpression {
            span: member.span,
            object: member.object.clone_in(ctx.ast.allocator),
            property: ctx
                .ast
                .identifier_name(SPAN, ctx.ast.allocator.alloc_str(prop_name)),
            optional: member.optional,
        };

        *target = AssignmentTarget::StaticMemberExpression(ArenaBox::new_in(
            new_member,
            ctx.ast.allocator,
        ));
        self.modifications += 1;
        true
    }

    /// Simple assignment target: obj["prop"]++ / obj["prop"] ||= ... etc.
    fn try_computed_to_static_simple_assignment_target<'a>(
        &mut self,
        target: &mut SimpleAssignmentTarget<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> bool {
        let SimpleAssignmentTarget::ComputedMemberExpression(member) = target else {
            return false;
        };

        let prop_name = match &member.expression {
            Expression::StringLiteral(lit) => lit.value.as_str(),
            Expression::TemplateLiteral(tpl) => {
                if !tpl.expressions.is_empty() || tpl.quasis.len() != 1 {
                    return false;
                }
                tpl.quasis[0]
                    .value
                    .cooked
                    .as_ref()
                    .map(|a| a.as_str())
                    .unwrap_or(tpl.quasis[0].value.raw.as_str())
            }
            _ => return false,
        };

        if !is_valid_identifier(prop_name) {
            return false;
        }

        let new_member = StaticMemberExpression {
            span: member.span,
            object: member.object.clone_in(ctx.ast.allocator),
            property: ctx
                .ast
                .identifier_name(SPAN, ctx.ast.allocator.alloc_str(prop_name)),
            optional: member.optional,
        };

        *target = SimpleAssignmentTarget::StaticMemberExpression(ArenaBox::new_in(
            new_member,
            ctx.ast.allocator,
        ));
        self.modifications += 1;
        true
    }
}

/// Check if a string is a valid JavaScript identifier (not reserved word)
fn is_valid_identifier(name: &str) -> bool {
    if name.is_empty() {
        return false;
    }

    let mut chars = name.chars();

    // First char: letter, underscore, or $
    let first = chars.next().unwrap();
    if !first.is_ascii_alphabetic() && first != '_' && first != '$' {
        return false;
    }

    // Rest: letter, digit, underscore, or $
    for c in chars {
        if !c.is_ascii_alphanumeric() && c != '_' && c != '$' {
            return false;
        }
    }

    // Reserved words - can't use as property with dot notation
    // Actually, in JS you CAN use reserved words as property names with dot notation
    // obj.class, obj.function, etc. are all valid
    // So we don't need to check reserved words here

    true
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    fn transform(source: &str) -> (String, usize) {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;
        let semantic = SemanticBuilder::new().build(&program).semantic;
        let scoping = semantic.into_scoping();

        let mut module = MemberSimplifier;
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        let code = Codegen::new().build(&program).code;
        (code, result.modifications)
    }

    #[test]
    fn test_computed_to_static() {
        let (code, mods) = transform(r#"obj["prop"]"#);
        assert_eq!(mods, 1);
        assert!(code.contains("obj.prop"), "got: {}", code);
    }

    #[test]
    fn test_template_to_static() {
        let (code, mods) = transform("obj[`prop`]");
        assert_eq!(mods, 1);
        assert!(code.contains("obj.prop"), "got: {}", code);
    }

    #[test]
    fn test_assignment_target_computed_to_static() {
        let (code, mods) = transform(r#"obj["prop"] = 1"#);
        assert_eq!(mods, 1);
        assert!(
            code.contains("obj.prop = 1") || code.contains("obj.prop=1"),
            "got: {}",
            code
        );
    }

    #[test]
    fn test_invalid_identifier_unchanged() {
        // "foo-bar" is not a valid identifier, should stay as computed
        let (code, mods) = transform(r#"obj["foo-bar"]"#);
        assert_eq!(mods, 0);
        assert!(code.contains(r#"obj["foo-bar"]"#), "got: {}", code);
    }

    #[test]
    fn test_numeric_key_unchanged() {
        // Numeric keys should stay as computed
        let (code, mods) = transform(r#"obj["123"]"#);
        assert_eq!(mods, 0);
        assert!(code.contains(r#"obj["123"]"#), "got: {}", code);
    }

    #[test]
    fn test_string_index() {
        let (code, mods) = transform(r#""hello"[0]"#);
        assert_eq!(mods, 1);
        assert!(code.contains(r#""h""#), "got: {}", code);
    }

    #[test]
    fn test_string_index_middle() {
        let (code, mods) = transform(r#""hello"[2]"#);
        assert_eq!(mods, 1);
        assert!(code.contains(r#""l""#), "got: {}", code);
    }

    #[test]
    fn test_string_length_computed() {
        let (code, mods) = transform(r#""hello"["length"]"#);
        assert_eq!(mods, 1);
        assert!(code.contains("5"), "got: {}", code);
    }

    #[test]
    fn test_string_length_static() {
        let (code, mods) = transform(r#""hello".length"#);
        assert_eq!(mods, 1);
        assert!(code.contains("5"), "got: {}", code);
    }

    #[test]
    fn test_reserved_word_as_property() {
        // Reserved words ARE valid as property names
        let (code, mods) = transform(r#"obj["class"]"#);
        assert_eq!(mods, 1);
        assert!(code.contains("obj.class"), "got: {}", code);
    }

    #[test]
    fn test_chained_member() {
        let (code, mods) = transform(r#"a["b"]["c"]"#);
        assert_eq!(mods, 2);
        assert!(code.contains("a.b.c"), "got: {}", code);
    }
}
