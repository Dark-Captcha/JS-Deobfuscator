//! Sequence expression simplifier module.
//!
//! Simplifies sequence expressions that create objects.
//!
//! Transforms:
//!   ((obj = {}).prop1 = val1, obj.prop2 = val2, obj)  → {prop1: val1, prop2: val2}
//!
//! Requirements:
//!   - First expression must be `(var = {})` (assignment to empty object)
//!   - Middle expressions must be property assignments `obj.prop = val` or `obj["prop"] = val`
//!   - Last expression must be the object variable
//!   - All assignments must be to the same object variable
//!   - Property keys must be static (identifier or string literal)

use oxc::allocator::{Allocator, CloneIn};
use oxc::ast::ast::{AssignmentTarget, Expression, Program, PropertyKey, PropertyKind};
use oxc::semantic::Scoping;
use oxc::span::SPAN;
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::utils::symbols::get_reference_symbol;

pub struct SequenceSimplifier;

impl Module for SequenceSimplifier {
    fn name(&self) -> &'static str {
        "SequenceSimplifier"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        let mut visitor = Visitor {
            modifications: 0,
        };
        let scoping = traverse_mut(&mut visitor, allocator, program, scoping, ());
        Ok(TransformResult {
            modifications: visitor.modifications,
            scoping,
        })
    }
}

struct Visitor {
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for Visitor {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let Expression::SequenceExpression(seq) = expr else { return };
        
        if seq.expressions.len() < 3 {
            return; // Need at least: (obj = {}).prop = val, obj.prop2 = val2, obj
        }

        // First expression might be: (var = {}).prop = val (chained) or (var = {})
        // We need to extract the object variable symbol from the first expression
        let obj_var_sym = {
            let first = &seq.expressions[0];
            
            // Pattern 1: (var = {}).prop = val (chained assignment)
            if let Expression::AssignmentExpression(assign) = first {
                if assign.operator == oxc::ast::ast::AssignmentOperator::Assign {
                    // Check if LHS is a member expression on a parenthesized assignment
                    if let AssignmentTarget::StaticMemberExpression(member) = &assign.left {
                        if let Expression::ParenthesizedExpression(p) = &member.object {
                            if let Expression::AssignmentExpression(inner_assign) = &p.expression {
                                if inner_assign.operator == oxc::ast::ast::AssignmentOperator::Assign {
                                    if let AssignmentTarget::AssignmentTargetIdentifier(var_id) = &inner_assign.left {
                                        if let Expression::ObjectExpression(obj) = &inner_assign.right {
                                            if obj.properties.is_empty() {
                                                get_reference_symbol(ctx.scoping(), var_id)
                                            } else {
                                                None
                                            }
                                        } else {
                                            None
                                        }
                                    } else {
                                        None
                                    }
                                } else {
                                    None
                                }
                            } else {
                                None
                            }
                        } else {
                            None
                        }
                    } else {
                        None
                    }
                } else {
                    None
                }
            }
            // Pattern 2: (var = {}) (standalone)
            else if let Expression::ParenthesizedExpression(p) = first {
                if let Expression::AssignmentExpression(assign) = &p.expression {
                    if assign.operator == oxc::ast::ast::AssignmentOperator::Assign {
                        if let AssignmentTarget::AssignmentTargetIdentifier(var_id) = &assign.left {
                            if let Expression::ObjectExpression(obj) = &assign.right {
                                if obj.properties.is_empty() {
                                    get_reference_symbol(ctx.scoping(), var_id)
                                } else {
                                    None
                                }
                            } else {
                                None
                            }
                        } else {
                            None
                        }
                    } else {
                        None
                    }
                } else {
                    None
                }
            }
            // Pattern 3: var = {} (no parentheses)
            else if let Expression::AssignmentExpression(assign) = first {
                if assign.operator == oxc::ast::ast::AssignmentOperator::Assign {
                    if let AssignmentTarget::AssignmentTargetIdentifier(var_id) = &assign.left {
                        if let Expression::ObjectExpression(obj) = &assign.right {
                            if obj.properties.is_empty() {
                                get_reference_symbol(ctx.scoping(), var_id)
                            } else {
                                None
                            }
                        } else {
                            None
                        }
                    } else {
                        None
                    }
                } else {
                    None
                }
            } else {
                None
            }
        };

        let obj_var_sym = match obj_var_sym {
            Some(sym) => sym,
            None => return,
        };

        // Last expression must be the object variable
        let last = &seq.expressions[seq.expressions.len() - 1];
        let last_is_obj = match last {
            Expression::Identifier(id) => {
                get_reference_symbol(ctx.scoping(), id) == Some(obj_var_sym)
            }
            _ => false,
        };
        if !last_is_obj {
            return;
        }

        // Collect all property assignments from the sequence
        // First expression might be: (var = {}).prop = val (chained) or (var = {})
        let mut properties = Vec::new();
        
        // Check if first expression is a chained assignment: (var = {}).prop = val
        if let Expression::AssignmentExpression(assign) = &seq.expressions[0] {
            if assign.operator == oxc::ast::ast::AssignmentOperator::Assign {
                // Check if LHS is a member expression on a parenthesized assignment
                if let AssignmentTarget::StaticMemberExpression(member) = &assign.left {
                    if let Expression::ParenthesizedExpression(p) = &member.object {
                        if let Expression::AssignmentExpression(inner_assign) = &p.expression {
                            if inner_assign.operator == oxc::ast::ast::AssignmentOperator::Assign {
                                if let AssignmentTarget::AssignmentTargetIdentifier(var_id) = &inner_assign.left {
                                    if get_reference_symbol(ctx.scoping(), var_id) == Some(obj_var_sym) {
                                        // Extract property from this chained assignment
                                        let key = ctx.ast.property_key_static_identifier(SPAN, member.property.name);
                                        properties.push((key, assign.right.clone_in(ctx.ast.allocator)));
                                    }
                                }
                            }
                        }
                    }
                } else if let AssignmentTarget::ComputedMemberExpression(member) = &assign.left {
                    if let Expression::ParenthesizedExpression(p) = &member.object {
                        if let Expression::AssignmentExpression(inner_assign) = &p.expression {
                            if inner_assign.operator == oxc::ast::ast::AssignmentOperator::Assign {
                                if let AssignmentTarget::AssignmentTargetIdentifier(var_id) = &inner_assign.left {
                                    if get_reference_symbol(ctx.scoping(), var_id) == Some(obj_var_sym) {
                                        if let Expression::StringLiteral(lit) = &member.expression {
                                            let key = PropertyKey::StringLiteral(ctx.ast.alloc_string_literal(SPAN, lit.value, None));
                                            properties.push((key, assign.right.clone_in(ctx.ast.allocator)));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Process remaining expressions (skip first if it was a chained assignment, otherwise start from second)
        let start_idx = if matches!(&seq.expressions[0], Expression::AssignmentExpression(_)) {
            1 // First expression was already processed as chained assignment
        } else {
            1 // First expression was (var = {}), start from second
        };
        
        for expr in &seq.expressions[start_idx..seq.expressions.len() - 1] {
            let (prop_key, value) = match expr {
                Expression::AssignmentExpression(assign) => {
                    if assign.operator != oxc::ast::ast::AssignmentOperator::Assign {
                        return;
                    }
                    
                    // Check LHS: obj.prop or obj["prop"]
                    let (is_obj_var, prop_key) = match &assign.left {
                        AssignmentTarget::StaticMemberExpression(member) => {
                            let Expression::Identifier(id) = &member.object else {
                                return;
                            };
                            let is_obj = get_reference_symbol(ctx.scoping(), id) == Some(obj_var_sym);
                            let key = ctx.ast.property_key_static_identifier(SPAN, member.property.name);
                            (is_obj, Some(key))
                        }
                        AssignmentTarget::ComputedMemberExpression(member) => {
                            let Expression::Identifier(id) = &member.object else {
                                return;
                            };
                            let is_obj = get_reference_symbol(ctx.scoping(), id) == Some(obj_var_sym);
                            if let Expression::StringLiteral(lit) = &member.expression {
                                let key = PropertyKey::StringLiteral(ctx.ast.alloc_string_literal(SPAN, lit.value, None));
                                (is_obj, Some(key))
                            } else {
                                return;
                            }
                        }
                        _ => return,
                    };
                    
                    if !is_obj_var {
                        return;
                    }
                    
                    let Some(prop_key) = prop_key else { return };
                    (prop_key, assign.right.clone_in(ctx.ast.allocator))
                }
                _ => return,
            };
            
            properties.push((prop_key, value));
        }

        if properties.is_empty() {
            return;
        }

        // Build object literal
        let mut obj_props = ctx.ast.vec();
        for (key, value) in properties {
            let prop = ctx.ast.alloc_object_property(
                SPAN,
                PropertyKind::Init,
                key,
                value,
                false,
                false,
                false,
            );
            obj_props.push(oxc::ast::ast::ObjectPropertyKind::ObjectProperty(prop));
        }

        let obj_expr = ctx.ast.expression_object(SPAN, obj_props);
        *expr = obj_expr;
        self.modifications += 1;
    }
}

