//! Object property inliner module.
//!
//! Inlines constant object properties at use sites.
//!
//! Transforms:
//!   var obj = {a: 1, b: "hello"};
//!   console.log(obj.a, obj.b);
//!   → console.log(1, "hello");
//!
//! Requirements:
//!   - Object must be a simple literal (no spread, no computed keys)
//!   - Object variable must have no writes
//!   - Property values must be literals (numbers, strings, booleans, null)
//!
//! Does NOT create new variables - just inlines values at use sites.

use oxc::allocator::Allocator;
use oxc::ast::ast::{Expression, ObjectPropertyKind, Program, PropertyKey};
use oxc::semantic::{Scoping, SymbolId};
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::utils::symbols::get_reference_symbol;
use crate::utils::literal::{LiteralValue, extract_literal_value, literal_value_to_expression};

pub struct ObjectFlattener;

impl Module for ObjectFlattener {
    fn name(&self) -> &'static str {
        "ObjectFlattener"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Pass 1: Collect constant objects
        let mut collector = Collector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        if collector.objects.is_empty() {
            return Ok(TransformResult {
                modifications: 0,
                scoping,
            });
        }

        // Pass 2: Inline property accesses
        let mut inliner = Inliner {
            objects: collector.objects,
            modifications: 0,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        Ok(TransformResult {
            modifications: inliner.modifications,
            scoping,
        })
    }
}

// ============================================================================
// Pass 1: Collect constant objects
// ============================================================================

/// Map from symbol_id -> (property_name -> property_value)
type ObjectMap = FxHashMap<SymbolId, FxHashMap<String, LiteralValue>>;

#[derive(Default)]
struct Collector {
    objects: ObjectMap,
}

impl<'a> Traverse<'a, ()> for Collector {
    fn enter_variable_declarator(
        &mut self,
        node: &mut oxc::ast::ast::VariableDeclarator<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Need an initializer that's an object
        let Some(Expression::ObjectExpression(obj)) = &node.init else {
            return;
        };

        // Need a simple binding
        let Some(binding) = node.id.get_binding_identifier() else {
            return;
        };
        let Some(symbol_id) = binding.symbol_id.get() else {
            return;
        };

        // For var declarations: no write references allowed (declaration doesn't count)
        self.try_collect_object(symbol_id, obj, ctx, 0);
    }

    fn enter_assignment_expression(
        &mut self,
        node: &mut oxc::ast::ast::AssignmentExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Only handle simple assignment (=), not +=, etc.
        if node.operator != oxc::ast::ast::AssignmentOperator::Assign {
            return;
        }

        // Left side must be a simple identifier
        let oxc::ast::ast::AssignmentTarget::AssignmentTargetIdentifier(id) = &node.left else {
            return;
        };

        // Right side must be an object
        let Expression::ObjectExpression(obj) = &node.right else {
            return;
        };

        // Get symbol for the identifier
        let Some(symbol_id) = get_reference_symbol(ctx.scoping(), id) else {
            return;
        };

        // For assignments: exactly 1 write reference allowed (this assignment)
        self.try_collect_object(symbol_id, obj, ctx, 1);
    }
}

impl Collector {
    fn try_collect_object<'a>(
        &mut self,
        symbol_id: SymbolId,
        obj: &oxc::ast::ast::ObjectExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
        max_writes: usize,
    ) {
        // Count write references (assignments to this variable)
        let write_count = ctx
            .scoping()
            .get_resolved_references(symbol_id)
            .filter(|r| r.flags().is_write())
            .count();

        // Check write count matches expected
        if write_count > max_writes {
            return;
        }

        // Collect properties (only if ALL are simple literals with static keys)
        let mut props: FxHashMap<String, LiteralValue> = FxHashMap::default();

        for prop in &obj.properties {
            let ObjectPropertyKind::ObjectProperty(p) = prop else {
                // Spread element or other - bail
                return;
            };

            // Must have static key
            let key_name = match &p.key {
                PropertyKey::StaticIdentifier(id) => id.name.to_string(),
                PropertyKey::StringLiteral(lit) => lit.value.to_string(),
                _ => return, // Computed key - bail
            };

            // Value must be a literal (we store a compact value representation).
            let Some(lit) = extract_literal_value(&p.value) else {
                return;
            };
            props.insert(key_name, lit);
        }

        if !props.is_empty() {
            self.objects.insert(symbol_id, props);
        }
    }
}

// ============================================================================
// Pass 2: Inline property accesses
// ============================================================================

struct Inliner {
    objects: ObjectMap,
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for Inliner {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        let (symbol_id, prop_name) = match expr {
            // obj.prop
            Expression::StaticMemberExpression(member) => {
                let Expression::Identifier(id) = &member.object else {
                    return;
                };
                let Some(sym) = get_reference_symbol(ctx.scoping(), id) else {
                    return;
                };
                (sym, member.property.name.as_str())
            }
            // obj["prop"]
            Expression::ComputedMemberExpression(member) => {
                let Expression::Identifier(id) = &member.object else {
                    return;
                };
                let Expression::StringLiteral(lit) = &member.expression else {
                    return;
                };
                let Some(sym) = get_reference_symbol(ctx.scoping(), id) else {
                    return;
                };
                (sym, lit.value.as_str())
            }
            _ => return,
        };

        // Check if we have this object and property
        let Some(props) = self.objects.get(&symbol_id) else {
            return;
        };
        let Some(value) = props.get(prop_name) else {
            return;
        };

        // Replace with the literal value
        *expr = literal_value_to_expression(value, ctx.ast);
        self.modifications += 1;
    }
}

// (literal handling lives in `crate::utils::literal`.)

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    fn transform(source: &str) -> (String, usize) {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;
        let semantic = SemanticBuilder::new().build(&program).semantic;
        let scoping = semantic.into_scoping();

        let mut module = ObjectFlattener;
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        let code = Codegen::new().build(&program).code;
        (code, result.modifications)
    }

    #[test]
    fn test_simple_object() {
        let (code, mods) = transform("var obj = {a: 1, b: 2}; console.log(obj.a, obj.b);");
        assert_eq!(mods, 2);
        assert!(code.contains("console.log(1, 2)"), "got: {}", code);
    }

    #[test]
    fn test_string_property() {
        let (code, mods) = transform(r#"var obj = {msg: "hello"}; console.log(obj.msg);"#);
        assert_eq!(mods, 1);
        assert!(code.contains(r#"console.log("hello")"#), "got: {}", code);
    }

    #[test]
    fn test_computed_access() {
        let (code, mods) = transform(r#"var obj = {a: 1}; console.log(obj["a"]);"#);
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(1)"), "got: {}", code);
    }

    #[test]
    fn test_no_inline_with_write() {
        let (code, mods) = transform("var obj = {a: 1}; obj = {}; console.log(obj.a);");
        assert_eq!(mods, 0);
        assert!(code.contains("obj.a"), "got: {}", code);
    }

    #[test]
    fn test_no_inline_non_literal() {
        // Function call is not a literal - don't inline
        let (code, mods) = transform("var obj = {a: foo()}; console.log(obj.a);");
        assert_eq!(mods, 0);
        assert!(code.contains("obj.a"), "got: {}", code);
    }

    #[test]
    fn test_negative_number() {
        let (code, mods) = transform("var obj = {a: -5}; console.log(obj.a);");
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(-5)"), "got: {}", code);
    }

    #[test]
    fn test_boolean_null() {
        let (code, mods) = transform("var obj = {a: true, b: null}; use(obj.a, obj.b);");
        assert_eq!(mods, 2);
        assert!(code.contains("use(true, null)"), "got: {}", code);
    }

    #[test]
    fn test_string_key() {
        let (code, mods) = transform(r#"var obj = {"foo-bar": 1}; console.log(obj["foo-bar"]);"#);
        assert_eq!(mods, 1);
        assert!(code.contains("console.log(1)"), "got: {}", code);
    }

    #[test]
    fn test_multiple_objects() {
        let (code, mods) = transform("var a = {x: 1}; var b = {x: 2}; use(a.x, b.x);");
        assert_eq!(mods, 2);
        assert!(code.contains("use(1, 2)"), "got: {}", code);
    }

    #[test]
    fn test_assignment_expression() {
        // Assignment without var/let/const
        let (code, mods) = transform("var obj; obj = {F: 493, E: 486}; use(obj.F, obj.E);");
        assert_eq!(mods, 2);
        assert!(code.contains("use(493, 486)"), "got: {}", code);
    }

    #[test]
    fn test_global_assignment() {
        // Global assignment (no declaration)
        let (_code, mods) = transform("_i171 = {F: 493}; use(_i171.F);");
        // This won't work because _i171 has no symbol_id (it's a global)
        // That's expected - we can only inline when we have symbol tracking
        assert_eq!(mods, 0);
    }
}
