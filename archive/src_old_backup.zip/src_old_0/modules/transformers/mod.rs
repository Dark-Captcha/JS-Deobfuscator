//! Transformer modules for deobfuscation (run in convergence loop).

// TODO: Fix these modules - they have compile errors with oxc 0.102.0
// pub mod alias_elim;
// pub mod anti_debug;
// pub mod builtin_eval;
// pub mod condition_expand;

pub mod alias_inliner;
pub mod constant_prop;
pub mod control_flow_deflat;
pub mod dead_code;
pub mod iife_optimizer;
pub mod member_simplify;
pub mod object_flatten;
pub mod proxy_inliner;
pub mod sequence_simplify;
pub mod static_eval;
pub mod string_array_decoder;
pub mod eval_call_inliner;

// TODO: Re-enable when fixed
// pub use alias_elim::AliasEliminator;
// pub use anti_debug::AntiDebugRemover;
// pub use builtin_eval::BuiltinEvaluator;
// pub use condition_expand::ConditionExpander;

pub use alias_inliner::AliasInliner;
pub use constant_prop::ConstantPropagator;
pub use control_flow_deflat::ControlFlowDeflattener;
pub use dead_code::DeadCodeEliminator;
pub use iife_optimizer::IifeOptimizer;
pub use member_simplify::MemberSimplifier;
pub use object_flatten::ObjectFlattener;
pub use proxy_inliner::ProxyInliner;
pub use sequence_simplify::SequenceSimplifier;
pub use static_eval::StaticEvaluator;
pub use string_array_decoder::StringArrayDecoder;
pub use string_array_decoder::StringArrayPostCleaner;
pub use eval_call_inliner::EvalCallInliner;
