//! IIFE optimizer module.
//!
//! Optimizes immediately invoked function expressions.
//!
//! Safe transformations:
//!   (function(x){return x+1})(5)  → (function(){return 5+1})()
//!   (function(){return expr})()  → expr
//!   (() => expr)()               → expr
//!   (function(){})()             → undefined
//!
//! Does NOT transform:
//!   - IIFEs with local variables (var hoisting issues)
//!   - IIFEs using `this` or `arguments`
//!   - IIFEs with non-literal arguments

use oxc::allocator::{Allocator, CloneIn};
use oxc::ast::ast::{
    Argument, ArrowFunctionExpression, CallExpression, Expression, Function, Program, Statement,
};
use oxc::semantic::{Scoping, SymbolId};
use oxc::span::SPAN;
use oxc_traverse::{Traverse, TraverseCtx, traverse_mut};
use rustc_hash::FxHashMap;

use crate::core::error::Result;
use crate::core::module::{Module, TransformResult};
use crate::utils::symbols::get_reference_symbol;
use crate::utils::literal::{LiteralValue, extract_literal_value, literal_value_to_expression};

pub struct IifeOptimizer;

impl Module for IifeOptimizer {
    fn name(&self) -> &'static str {
        "IifeOptimizer"
    }

    fn transform<'a>(
        &mut self,
        allocator: &'a Allocator,
        program: &mut Program<'a>,
        scoping: Scoping,
    ) -> Result<TransformResult> {
        // Pass 1: Collect IIFE parameter → argument mappings
        let mut collector = ParamCollector::default();
        let scoping = traverse_mut(&mut collector, allocator, program, scoping, ());

        // Pass 2: Inline parameters and simplify IIFEs
        let mut inliner = ParamInliner {
            params: collector.params,
            modifications: 0,
        };
        let scoping = traverse_mut(&mut inliner, allocator, program, scoping, ());

        Ok(TransformResult {
            modifications: inliner.modifications,
            scoping,
        })
    }
}

// ============================================================================
// Pass 1: Collect parameter mappings
// ============================================================================

#[derive(Default)]
struct ParamCollector {
    params: FxHashMap<SymbolId, LiteralValue>,
}

impl<'a> Traverse<'a, ()> for ParamCollector {
    fn enter_call_expression(
        &mut self,
        call: &mut CallExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) {
        // Extract function from IIFE pattern
        let iife = match &call.callee {
            Expression::ParenthesizedExpression(p) => IifeKind::from_expr(&p.expression),
            expr => IifeKind::from_expr(expr),
        };

        let Some(iife) = iife else { return };

        // Collect parameter → argument mappings
        let params = iife.params();
        for (i, param) in params.iter().enumerate() {
            // Only simple bindings (not destructuring)
            let Some(binding) = param.pattern.get_binding_identifier() else {
                continue;
            };
            let Some(symbol_id) = binding.symbol_id.get() else {
                continue;
            };

            // Check param has no writes
            let has_writes = ctx
                .scoping()
                .get_resolved_references(symbol_id)
                .any(|r| r.flags().is_write());
            if has_writes {
                continue;
            }

            // Get corresponding argument (must be literal)
            let Some(arg) = call.arguments.get(i) else {
                continue;
            };
            let Some(value) = get_literal_arg(arg) else {
                continue;
            };

            self.params
                .insert(symbol_id, value);
        }
    }
}

// ============================================================================
// Pass 2: Inline parameters and simplify
// ============================================================================

struct ParamInliner {
    params: FxHashMap<SymbolId, LiteralValue>,
    modifications: usize,
}

impl<'a> Traverse<'a, ()> for ParamInliner {
    fn exit_expression(&mut self, expr: &mut Expression<'a>, ctx: &mut TraverseCtx<'a, ()>) {
        // Inline identifier references to IIFE params
        if let Expression::Identifier(ident) = expr {
            if let Some(symbol_id) = get_reference_symbol(ctx.scoping(), ident) {
                if let Some(value) = self.params.get(&symbol_id) {
                    *expr = literal_value_to_expression(value, ctx.ast);
                    self.modifications += 1;
                    return;
                }
            }
        }

        // Simplify IIFE calls
        let Expression::CallExpression(call) = expr else {
            return;
        };

        if let Some(simplified) = self.try_simplify_iife(call, ctx) {
            *expr = simplified;
            self.modifications += 1;
        }
    }
}

impl ParamInliner {
    fn try_simplify_iife<'a>(
        &self,
        call: &CallExpression<'a>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> Option<Expression<'a>> {
        // Must have no arguments (after inlining)
        if !call.arguments.is_empty() {
            return None;
        }

        // Extract IIFE
        let iife = match &call.callee {
            Expression::ParenthesizedExpression(p) => IifeKind::from_expr(&p.expression),
            expr => IifeKind::from_expr(expr),
        }?;

        // Must have no params
        if !iife.params().is_empty() {
            return None;
        }

        match iife {
            // Arrow with expression body: (() => expr)() → expr
            IifeKind::ArrowExpr(arrow) => {
                // For expression arrows, body.statements[0] is an ExpressionStatement
                // containing the expression
                if let Some(Statement::ExpressionStatement(stmt)) = arrow.body.statements.first() {
                    Some(stmt.expression.clone_in(ctx.ast.allocator))
                } else {
                    None
                }
            }

            // Arrow with block body
            IifeKind::ArrowBlock(arrow) => self.simplify_body(&arrow.body.statements, ctx),

            // Function expression
            IifeKind::Function(func) => {
                let body = func.body.as_ref()?;
                self.simplify_body(&body.statements, ctx)
            }
        }
    }

    fn simplify_body<'a>(
        &self,
        statements: &oxc::allocator::Vec<'a, Statement<'a>>,
        ctx: &mut TraverseCtx<'a, ()>,
    ) -> Option<Expression<'a>> {
        // Empty body → undefined
        if statements.is_empty() {
            return Some(ctx.ast.expression_identifier(SPAN, ctx.ast.atom("undefined")));
        }

        // Single return statement → return value
        if statements.len() == 1 {
            if let Statement::ReturnStatement(ret) = &statements[0] {
                return Some(if let Some(arg) = &ret.argument {
                    arg.clone_in(ctx.ast.allocator)
                } else {
                    ctx.ast.expression_identifier(SPAN, ctx.ast.atom("undefined"))
                });
            }
        }

        // Can't simplify - has local vars or multiple statements
        None
    }
}

// ============================================================================
// Helpers
// ============================================================================

enum IifeKind<'a, 'b> {
    Function(&'b Function<'a>),
    ArrowExpr(&'b ArrowFunctionExpression<'a>),  // () => expr
    ArrowBlock(&'b ArrowFunctionExpression<'a>), // () => { ... }
}

impl<'a, 'b> IifeKind<'a, 'b> {
    fn from_expr(expr: &'b Expression<'a>) -> Option<Self> {
        match expr {
            Expression::FunctionExpression(f) => Some(IifeKind::Function(f)),
            Expression::ArrowFunctionExpression(a) => {
                if a.expression {
                    Some(IifeKind::ArrowExpr(a))
                } else {
                    Some(IifeKind::ArrowBlock(a))
                }
            }
            _ => None,
        }
    }

    fn params(&self) -> &'b oxc::allocator::Vec<'a, oxc::ast::ast::FormalParameter<'a>> {
        match self {
            IifeKind::Function(f) => &f.params.items,
            IifeKind::ArrowExpr(a) | IifeKind::ArrowBlock(a) => &a.params.items,
        }
    }
}

fn get_literal_arg<'a>(arg: &'a Argument<'a>) -> Option<LiteralValue> {
    let expr = arg.as_expression()?;
    extract_literal_value(expr)
}

#[cfg(test)]
mod tests {
    use super::*;
    use oxc::codegen::Codegen;
    use oxc::parser::Parser;
    use oxc::semantic::SemanticBuilder;
    use oxc::span::SourceType;

    fn transform(source: &str) -> (String, usize) {
        let allocator = Allocator::default();
        let source_type = SourceType::mjs();
        let ret = Parser::new(&allocator, source, source_type).parse();
        let mut program = ret.program;
        let semantic = SemanticBuilder::new().build(&program).semantic;
        let scoping = semantic.into_scoping();

        let mut module = IifeOptimizer;
        let result = module.transform(&allocator, &mut program, scoping).unwrap();
        let code = Codegen::new().build(&program).code;
        (code, result.modifications)
    }

    #[test]
    fn test_param_inline() {
        let (code, mods) = transform("(function(x) { return x + 1; })(5)");
        assert!(mods >= 1);
        assert!(code.contains("5 + 1") || code.contains("5+1"), "got: {}", code);
    }

    #[test]
    fn test_single_return_unwrap() {
        let (code, mods) = transform("(function() { return 42; })()");
        assert_eq!(mods, 1);
        assert!(code.contains("42") && !code.contains("function"), "got: {}", code);
    }

    #[test]
    fn test_arrow_expr_unwrap() {
        let (code, mods) = transform("(() => 42)()");
        assert_eq!(mods, 1);
        assert!(code.contains("42") && !code.contains("=>"), "got: {}", code);
    }

    #[test]
    fn test_arrow_block_unwrap() {
        let (code, mods) = transform("(() => { return 42; })()");
        assert_eq!(mods, 1);
        assert!(code.contains("42") && !code.contains("=>"), "got: {}", code);
    }

    #[test]
    fn test_empty_iife() {
        let (code, mods) = transform("(function() {})()");
        assert_eq!(mods, 1);
        assert!(code.contains("undefined"), "got: {}", code);
    }

    #[test]
    fn test_no_simplify_with_vars() {
        // Has local var - can't unwrap
        let (code, mods) = transform("(function() { var x = 1; return x; })()");
        assert_eq!(mods, 0);
        assert!(code.contains("function"), "got: {}", code);
    }

    #[test]
    fn test_no_simplify_with_args() {
        // Still has arguments - can't unwrap yet
        let (code, mods) = transform("(function(x) { return x; })(foo())");
        assert_eq!(mods, 0);
        assert!(code.contains("function"), "got: {}", code);
    }

    #[test]
    fn test_multiple_params() {
        let (code, mods) = transform("(function(a, b) { return a + b; })(1, 2)");
        assert!(mods >= 2);
        assert!(code.contains("1") && code.contains("2"), "got: {}", code);
    }

    #[test]
    fn test_negative_number_arg() {
        let (code, mods) = transform("(function(x) { return x; })(-5)");
        assert!(mods >= 1);
        assert!(code.contains("-5"), "got: {}", code);
    }
}
