//! Transformation modules for deobfuscation.

// Formatters - run once (pre/post deob loop)
pub mod formatters;

// Transformers - run in convergence loop
pub mod transformers;

// Re-export formatters
pub use formatters::BraceWrapper;
pub use formatters::ForVarHoister;
pub use formatters::IdentifierRenamer;
pub use formatters::StatementSplitter;

// Re-export transformers
pub use transformers::AliasInliner;
pub use transformers::ConstantPropagator;
pub use transformers::ControlFlowDeflattener;
pub use transformers::DeadCodeEliminator;
pub use transformers::IifeOptimizer;
pub use transformers::MemberSimplifier;
pub use transformers::ObjectFlattener;
pub use transformers::ProxyInliner;
pub use transformers::SequenceSimplifier;
pub use transformers::StaticEvaluator;
pub use transformers::StringArrayDecoder;
pub use transformers::StringArrayPostCleaner;
pub use transformers::EvalCallInliner;

// TODO: Re-enable when fixed
// pub use transformers::AliasEliminator;
// pub use transformers::AntiDebugRemover;
// pub use transformers::BuiltinEvaluator;
// pub use transformers::ConditionExpander;
