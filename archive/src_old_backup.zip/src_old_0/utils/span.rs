//! Span utilities.
//!
//! `oxc::span::Span` is a byte-range. This module provides small helpers that we reuse across
//! transformers to avoid duplicated span math.

use oxc::span::Span;

/// Returns true if `inner` is fully contained within `container`.
#[inline]
pub fn span_in(inner: Span, container: Span) -> bool {
    inner.start >= container.start && inner.end <= container.end
}





