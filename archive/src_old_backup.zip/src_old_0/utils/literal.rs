//! Literal helpers.
//!
//! Many transformers only care about *literal* values (numbers/strings/bools/null) and can avoid
//! cloning AST subtrees by storing a compact value representation and rebuilding the AST node on
//! demand.

use oxc::ast::ast::{Expression, NumberBase, UnaryOperator};
use oxc::span::SPAN;

/// A compact representation of common JavaScript literal values.
#[derive(Debug, Clone, PartialEq)]
pub enum LiteralValue {
    String(String),
    Number(f64),
    Boolean(bool),
    Null,
}

/// Extract a literal value from an expression, handling common wrappers:
/// - Parenthesized expressions
/// - Sequence expressions (comma operator): returns the last expression's literal value
/// - Unary +/- applied to numeric literals
pub fn extract_literal_value(expr: &Expression) -> Option<LiteralValue> {
    match expr {
        Expression::StringLiteral(lit) => Some(LiteralValue::String(lit.value.to_string())),
        Expression::NumericLiteral(lit) => Some(LiteralValue::Number(lit.value)),
        Expression::BooleanLiteral(lit) => Some(LiteralValue::Boolean(lit.value)),
        Expression::NullLiteral(_) => Some(LiteralValue::Null),

        Expression::ParenthesizedExpression(p) => extract_literal_value(&p.expression),

        Expression::SequenceExpression(seq) => seq.expressions.last().and_then(extract_literal_value),

        // -42, +42
        Expression::UnaryExpression(u)
            if matches!(
                u.operator,
                UnaryOperator::UnaryNegation | UnaryOperator::UnaryPlus
            ) =>
        {
            let Expression::NumericLiteral(n) = &u.argument else {
                return None;
            };
            let v = n.value;
            match u.operator {
                UnaryOperator::UnaryNegation => Some(LiteralValue::Number(-v)),
                UnaryOperator::UnaryPlus => Some(LiteralValue::Number(v)),
                _ => None,
            }
        }

        _ => None,
    }
}

/// Build an AST expression for a previously extracted literal value.
#[inline]
pub fn literal_value_to_expression<'a>(
    value: &LiteralValue,
    ast: oxc::ast::AstBuilder<'a>,
) -> Expression<'a> {
    match value {
        LiteralValue::String(s) => ast.expression_string_literal(SPAN, ast.atom(s), None),
        LiteralValue::Boolean(b) => ast.expression_boolean_literal(SPAN, *b),
        LiteralValue::Null => ast.expression_null_literal(SPAN),
        LiteralValue::Number(n) => {
            if n.is_sign_negative() && *n != 0.0 {
                // Keep negative numbers as unary expressions for AST fidelity.
                let inner = ast.expression_numeric_literal(SPAN, n.abs(), None, NumberBase::Decimal);
                ast.expression_unary(SPAN, UnaryOperator::UnaryNegation, inner)
            } else if *n == 0.0 && n.is_sign_negative() {
                // Preserve -0.
                let inner = ast.expression_numeric_literal(SPAN, 0.0, None, NumberBase::Decimal);
                ast.expression_unary(SPAN, UnaryOperator::UnaryNegation, inner)
            } else {
                ast.expression_numeric_literal(SPAN, *n, None, NumberBase::Decimal)
            }
        }
    }
}





