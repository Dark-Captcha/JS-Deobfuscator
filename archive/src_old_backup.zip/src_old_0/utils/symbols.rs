//! Symbol resolution utilities.

use oxc::ast::ast::{AssignmentTarget, Expression, IdentifierReference, SimpleAssignmentTarget};
use oxc::semantic::{Scoping, SymbolId};

/// Get the symbol ID from an identifier reference.
pub fn get_reference_symbol(
    scoping: &Scoping,
    reference: &IdentifierReference,
) -> Option<SymbolId> {
    // reference_id() can panic if not set, use reference_id.get() instead
    let ref_id = reference.reference_id.get()?;
    scoping.get_reference(ref_id).symbol_id()
}

/// Count read references to a symbol.
pub fn count_read_references(scoping: &Scoping, symbol_id: SymbolId) -> usize {
    scoping
        .get_resolved_references(symbol_id)
        .filter(|r| r.flags().is_read())
        .count()
}

/// Count write references to a symbol.
pub fn count_write_references(scoping: &Scoping, symbol_id: SymbolId) -> usize {
    scoping
        .get_resolved_references(symbol_id)
        .filter(|r| r.flags().is_write())
        .count()
}

/// Get symbol ID from the left-hand side of an assignment.
pub fn get_lhs_symbol_id(scoping: &Scoping, target: &AssignmentTarget) -> Option<SymbolId> {
    match target {
        AssignmentTarget::AssignmentTargetIdentifier(ident) => {
            let ref_id = ident.reference_id.get()?;
            scoping.get_reference(ref_id).symbol_id()
        }
        _ => None,
    }
}

/// Get symbol ID from a simple assignment target using scoping.
pub fn get_simple_target_symbol(
    scoping: &Scoping,
    target: &SimpleAssignmentTarget,
) -> Option<SymbolId> {
    match target {
        SimpleAssignmentTarget::AssignmentTargetIdentifier(ident) => {
            let ref_id = ident.reference_id.get()?;
            scoping.get_reference(ref_id).symbol_id()
        }
        _ => None,
    }
}

/// Check if an expression is a simple identifier reference.
pub fn is_identifier(expr: &Expression) -> bool {
    matches!(expr, Expression::Identifier(_))
}

/// Get symbol ID from an expression if it's an identifier.
pub fn get_expr_symbol(scoping: &Scoping, expr: &Expression) -> Option<SymbolId> {
    match expr {
        Expression::Identifier(ident) => get_reference_symbol(scoping, ident),
        _ => None,
    }
}
