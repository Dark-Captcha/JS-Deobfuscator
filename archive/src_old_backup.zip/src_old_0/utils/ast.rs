//! AST utilities for common operations.

use oxc::allocator::Allocator;
use oxc::ast::ast::{Function, Program};
use oxc::codegen::{Codegen, Context, Gen};
use oxc::parser::Parser;
use oxc::semantic::{Scoping, SemanticBuilder};
use oxc::span::SourceType;

/// Build scoping information from a program.
pub fn build_scoping(program: &Program<'_>) -> Scoping {
    SemanticBuilder::new()
        .build(program)
        .semantic
        .into_scoping()
}

/// Generate JavaScript code from a program.
pub fn generate_code(program: &Program<'_>) -> String {
    Codegen::new().build(program).code
}

/// Generate JavaScript code for a function declaration/expression.
#[inline]
pub fn function_to_code<'a>(func: &Function<'a>) -> String {
    let mut codegen = Codegen::new();
    func.print(&mut codegen, Context::empty());
    codegen.into_source_text()
}

/// Parse JavaScript source into a program.
///
/// Returns None if parsing fails.
pub fn parse<'a>(allocator: &'a Allocator, source: &'a str) -> Option<Program<'a>> {
    let source_type = SourceType::mjs();
    let ret = Parser::new(allocator, source, source_type).parse();
    if ret.errors.is_empty() {
        Some(ret.program)
    } else {
        None
    }
}
